# 来源与署名（PROVENANCE）

## 原件叫什么、从哪来
- **服务器**：`https://weishuxieyi.icu/`（卫戍协议：盟约 · 同人联机服，app 0.2.1）
- **原件数据**：该服 `/_build/f638115c25cd-20/data/bonds.json`（23 条盟约）
- **取证时间**：2026-10-13

## 原作者是谁
- 上游：`sganggs/Stronghold-Protocol`（GPL-3.0-or-later）
- 该同人服运营者：**未署名**
- 打包：jingjiangze

## 原件的许可
GPL-3.0-or-later（随上游）。无素材。

## 它改了什么
weishu 服的 `bonds.json` 与上游**同键（均 23 条）**，唯一差异是三条盟约的 `members` / `visibleMembers` 各追加了一个成员 `chess_char_4_27_a`（克莱门莎）：

| bondId | 名称 | members | visibleMembers |
|---|---|---|---|
| `egirShip` | 阿戈尔 | 9 → 10 | 9 → 10 |
| `swiftShip` | 迅捷 | 14 → 15 | 12 → 13 |
| `indomShip` | 不屈 | 9 → 10 | 7 → 8 |

本包只覆盖这两个数组字段，盟约的阈值、加成、权重、图标一律不动。

## 自带素材是哪来的
**无素材**。

## 已知不兼容 / 边界（必读）
1. **依赖 `clemntia-chess`**：只加成员 id 而池子里没有那个棋子，盟约弹窗会列出一个选不出来的名字。两个包请一起装。
2. 覆盖是**按字段打补丁**（`OVERRIDE_REPLACE_KEYS` + 数组整块替换），不是整条替换 —— 所以盟约其余字段原样保留。
3. `members` 与 `visibleMembers` 都是官方记录已有的字段（闭合世界校验通过），不会撞 `UNKNOWN_OVERRIDE_FIELD`。
