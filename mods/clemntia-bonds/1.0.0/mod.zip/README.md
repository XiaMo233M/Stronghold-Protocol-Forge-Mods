# 克莱门莎入盟约（三条盟约成员追加）

把克莱门莎（`chess_char_4_27_a`）加进三条盟约的 `members` / `visibleMembers`：阿戈尔、迅捷、不屈。

## 装上之后
- 克莱门莎可以凑齐这三条盟约的层数
- 盟约弹窗的成员列表里出现她

## 不兼容 / 边界
- **请与 `clemntia-chess` 一起装**：单独装只会得到一个选不出来的成员名
- 只改 members / visibleMembers 两个数组，其余字段一律不动
- 来源与许可见 `PROVENANCE.md`
