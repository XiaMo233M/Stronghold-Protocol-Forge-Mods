// name-guard / server/nameGuard.mjs — 分发前钩子：代号审查（hello 准入）。
//
// 这是 fork（jingjiangze/stronghold-server）昵称审查链的**包侧实现**：同一个判定与同一批词典，
// 用 `server.preDispatch` 挂在分发路径上（docs/WORKSHOP.md §1.9.1：钩子在 validateC2S 之后、ping/hello
// 与会话检查之前被调用；`intercepts: ["hello"]` 命中时否掉这条 hello，它就不会进大厅）。
//
// 四条纪律（与钩子契约逐条对应）：
//   * 纯函数、无 import、不读时钟/RNG、没有任何进程级可变状态 —— 词典与文案全部来自 `deps.policy`（装载期解析的 JSON）；
//   * 只放行或否决：不 hail 大厅、不注册 socket、不碰对局对象（deps 里本来就没有）；
//   * 不把命中的词写进日志（fork 的同一条要求：判定词不进调用方与日志），日志只记 reason；
//   * 判定与 fork 的 createNamePolicy 同链：
//       NFKC 归一 → 去孤立代理 / 折叠空白 / 去不可见与控制符 → trim
//       → 政治分类（不排除、不遮罩）→ 脏话分类（仅遮罩「妈妈的」这一处无害所有格）
//       → 12 字上限 → 通过
//     英文条目按拉丁/非拉丁交界处的边界符编码（Scunthorpe 安全：class 里的 ass 不是 ass）；
//     中文/全类条目另有「去空白标点符号」的 compact 形态（中间夹点、夹空格也拦得住）。
//
// 失败姿态：回帧失败（例如 socket 已断）时**仍然消费**这条 hello —— 被拒的名字绝不因为回执没发出去而获准进入；
// 回帧失败会记一条 error。判定函数本身不抛异常。

const BOUNDARY = '\u0001';
const LONE_SURROGATE_RE = /[\ud800-\udbff](?![\udc00-\udfff])|(?<![\ud800-\udbff])[\udc00-\udfff]/g;
const INVISIBLE_RE = /[\p{Default_Ignorable_Code_Point}\p{Cc}\p{Cf}]/gu;
const SEPARATOR_RE = /[\p{White_Space}\p{P}\p{S}]/gu;
const LATIN_WORD_RE = /[\p{Script=Latin}\p{N}\p{M}]/u;

const DEFAULTS = Object.freeze({
  limits: Object.freeze({ nameLength: 12, rawLength: 256 }),
  messages: Object.freeze({
    sensitive: '代号含有不适宜内容，请换一个昵称。',
    tooLong: '代号最多 12 字，请缩短后重试。',
    empty: '请输入有效的博士代号。',
    invalid: '请输入有效的博士代号。',
  }),
});

/** 与 fork 的 clean() 逐字同规则：NFKC → 去孤立代理 → 折叠空白 → 去不可见/控制符 → trim。 */
function clean(raw) {
  return raw.normalize('NFKC').replace(LONE_SURROGATE_RE, '').replace(/\s+/g, ' ')
    .replace(INVISIBLE_RE, '').replace(/ {2,}/g, ' ').trim();
}

/** 与 fork 同规则：去掉空白/标点/符号后的压缩形态（用于「f u c k」这类夹点写法）。 */
const compact = (text) => text.replace(SEPARATOR_RE, '');

/** 与 fork 的 englishForm 同规则：拉丁/非拉丁交界处插边界符，词首词尾也封边。 */
function englishForm(text) {
  let output = BOUNDARY, previous = null;
  for (const character of text) {
    const latin = LATIN_WORD_RE.test(character);
    if (previous !== null && latin !== previous) output += BOUNDARY;
    output += character;
    previous = latin;
  }
  return output + BOUNDARY;
}

/** 任一 haystack 含有任一词条即命中（fork 用 Aho–Corasick 的 verify；这里是等价的 includes 扫描，词典 ≤ 8192 条）。 */
function hits(words, texts) {
  if (!words.length) return false;
  for (const text of texts) {
    if (!text) continue;
    for (const word of words) if (word && text.includes(word)) return true;
  }
  return false;
}

/** 可选自检：装载期由 `loadWorkshopHooks` 调用；返回 true / undefined 通过，字符串即拒绝理由。 */
export function validatePolicy(policy) {
  if (!policy || typeof policy !== 'object') return 'policy must be a JSON object';
  if (typeof policy.version !== 'string' || !policy.version) return 'policy.version must name this policy revision';
  const words = policy.words;
  if (!words || typeof words !== 'object') return 'policy.words must be an object of word arrays';
  const names = ['english', 'englishCompact', 'chinese', 'chineseCompact', 'political', 'politicalCompact'];
  let total = 0;
  for (const key of names) {
    const list = words[key];
    if (!Array.isArray(list)) return `policy.words.${key} must be an array`;
    total += list.length;
    for (const word of list) {
      if (typeof word !== 'string' || !word.length || word.length > 96) {
        return `policy.words.${key} has an entry that is not a 1..96 character string`;
      }
    }
  }
  if (total > 8192) return `policy.words carries ${total} entries (max 8192)`;
  const limits = policy.limits;
  if (limits !== undefined) {
    if (!limits || typeof limits !== 'object') return 'policy.limits must be an object';
    for (const key of ['nameLength', 'rawLength']) {
      const value = limits[key];
      if (value !== undefined && (!Number.isInteger(value) || value < 1 || value > 4096)) return `policy.limits.${key} must be an integer in 1..4096`;
    }
  }
  return true;
}

/**
 * 工厂：每个连接调用一次（deps 是冻结的；实例只被挂在这条连接上）。
 * @param {{ policy: object, intercepts: readonly string[], c2s: object, log: object, now: () => number, send: (conn: any, msg: object) => unknown }} deps
 */
export function createPreDispatch(deps) {
  const policy = deps && deps.policy && typeof deps.policy === 'object' ? deps.policy : {};
  const limits = { ...DEFAULTS.limits, ...(policy.limits && typeof policy.limits === 'object' ? policy.limits : {}) };
  const messages = { ...DEFAULTS.messages, ...(policy.messages && typeof policy.messages === 'object' ? policy.messages : {}) };
  const words = policy.words && typeof policy.words === 'object' ? policy.words : {};
  const lists = {
    english: Array.isArray(words.english) ? words.english : [],
    englishCompact: Array.isArray(words.englishCompact) ? words.englishCompact : [],
    chinese: Array.isArray(words.chinese) ? words.chinese : [],
    chineseCompact: Array.isArray(words.chineseCompact) ? words.chineseCompact : [],
    political: Array.isArray(words.political) ? words.political : [],
    politicalCompact: Array.isArray(words.politicalCompact) ? words.politicalCompact : [],
  };

  const sensitive = () => ({ ok: false, reason: 'sensitive', message: messages.sensitive });

  /** 与 fork 的 createNamePolicy 返回值同形状：{ ok: true, name } | { ok: false, reason }。 */
  function moderate(raw) {
    if (typeof raw !== 'string') return { ok: false, reason: 'invalid_type', message: messages.invalid };
    if (raw.length > limits.rawLength) return { ok: false, reason: 'too_long', message: messages.tooLong };
    const name = clean(raw);
    if (!name) return { ok: false, reason: 'empty', message: messages.empty };
    const original = name.toLowerCase();
    const folded = compact(original);
    // 政治分类：不合并不排除、不遮罩（fork 的口径：没有名字级白名单能绕过它）。
    if (hits(lists.political, [original]) || hits(lists.politicalCompact, [folded])) return sensitive();
    // 脏话分类：仅遮罩「妈妈的」这一处无害所有格；其余按四种形态各自判定。
    const text = original.replaceAll('妈妈的', ' ');
    if (hits(lists.chinese, [text]) || hits(lists.chineseCompact, [compact(text)])
      || hits(lists.english, [englishForm(text)]) || hits(lists.englishCompact, [englishForm(compact(text))])) {
      return sensitive();
    }
    if (name.length > limits.nameLength) return { ok: false, reason: 'too_long', message: messages.tooLong };
    return { ok: true, name };
  }

  return {
    preDispatch(conn, msg) {
      if (!msg || msg.t !== 'hello') return false;
      const verdict = moderate(msg.name);
      if (verdict.ok) return false;
      try {
        const frame = { t: 'error', code: 'BAD_MSG', msg: verdict.message, detail: `name-guard:${verdict.reason}` };
        if (Number.isFinite(msg.rid)) frame.rid = msg.rid;
        deps.send(conn, frame);
        deps.log.info(`[name-guard] hello refused (${verdict.reason})`);
      } catch (e) {
        // 回执没发出去也不放行：名字被拒就要被拒，玩家重试即可。
        deps.log.error('[name-guard] refusal frame could not be sent; the hello stays consumed', e);
      }
      return true;
    },
  };
}
