# 署名与来源 · PROVENANCE

> 本文件由兼容交付流程生成，随包分发。原作者与改写者**分开显示，不抹掉任何一方**。
> 原件未署名的一律写「**原件未署名**」，不代填名字；许可**照实抄**，包括非 SPDX 的值。
> 包内原作者文本（`README.md`、`NOTICE-来源说明.md`）与包自带元数据（`pack.json`）**一字未改**；
> 与本版实现不符之处只写在本文件里。

## 1. 包

| 项 | 值 |
|---|---|
| 包 id | `name-guard` |
| 版本 | `1.0.0` |
| 名称 | 代号审查（名字策略链） |
| 目录名 = 包 id | 是（引擎逐包判 `PACK_ID_MISMATCH`，不一致会被拒） |
| 投稿编号 | `e7b3b3e1751f`（站点上「代号审查（名字策略链）」45,817 B） |
| 本包实测规模 | 5 个原件文件 / 187,599 字节解压（不含本文件） |

## 2. 原作者 / 上游（六项之一：原作者）

| 项 | 值 |
|---|---|
| 原作者 | **jingjiangze**（原件 `pack.json.author` 原文，照实抄录；原件 `NOTICE-来源说明.md` 亦写明「原作者与改写者是同一方」） |
| 上游仓库 | <https://github.com/jingjiangze/stronghold-server>（fork of sganggs/Stronghold-Protocol，fork HEAD `9a8127d` 一带） |
| 原件内对应文件 | `server/net.js` 的 hello 准入 + `shared/names.js` + `deploy/stardust/auth/name-policy.mjs`、`name-dictionary.mjs`、`name-sensitive-dictionary.mjs` |
| 原件快照日期 | 2026-10-11 |

**原件未署名的情况：无。** 原件 `pack.json.author` 与 `NOTICE-来源说明.md` 都写了署名，本包照抄，不代填。

## 3. 许可（六项之二：许可，照实抄）

原件 `pack.json.license` 原文，**逐字抄录**：

> `GPL-3.0-or-later（代码与包本体）；词典数据另随包保留授权：英文/中文脏话 LDNOOBW（CC-BY-4.0），政治/成人/违法分类 fwwdn 与 houbb（Apache-2.0），见 NOTICE-来源说明.md`

词典数据的许可（原件 `NOTICE-来源说明.md` §许可 原文）：

| 词典 | 语料 / 权利人 | 许可 |
|---|---|---|
| 英文 / 中文脏话 | LDNOOBW「List of Dirty, Naughty, Obscene, and Otherwise Bad Words」（Copyright (c) 2012–2020 Shutterstock, Inc.） | **CC-BY-4.0** |
| 政治分类 | houbb/sensitive-word、fwwdn/sensitive-stop-words political/tagged 分类 | **Apache-2.0** |
| 成人 / 违法分类 | fwwdn/sensitive-stop-words | **Apache-2.0** |

## 4. 责任人（六项之三：兼容改写者）

| 角色 | 是谁 |
|---|---|
| 原作者 | jingjiangze |
| 本版兼容改写者 | **Mo233** |
| 本包交付 | 第三方 mod 兼容交付流程，2026-10-11 |

## 5. 来源（六项之四：来源）

- 站点原件：`submissions/e7b3b3e1751f/mod.zip`，45,817 字节
- 原件 sha256（实测，与站点 `meta.json` 记录一致）：
  `072c94016b27c26486ee737c79273f7f0a6a1c98fd6ca6f456892e265dcc1f55`
- 原件 zip 形状：**5 个文件平铺在 zip 根**（`pack.json` 在根，无顶层目录）
- 交付形态：工坊包（workshop pack）· `api` = `>=1 <2` · `game` = `0.2.x` · `combat: false`

## 6. 改了什么（六项之五：改了什么）

**只改一件事：zip 形状。**

| # | 项 | 原件 | 本包 | 依据 |
|---|---|---|---|---|
| 1 | zip 顶层目录 | 无（文件平铺在 zip 根） | 一个顶层目录 `name-guard/`，`pack.json` 在 `name-guard/pack.json` | 本站发布工作流 ① / ⑤：包内文件放进**一个顶层目录**、目录名 = 包 id（`AGENTS.md` §6） |
| 2 | `PROVENANCE.md` | 无 | 新增本文件（六项） | `AGENTS.md` §3「署名与许可不可省」、§6 ⑥ |

**逐字节未动的文件（5 个，与原件 sha256 相同）**：`pack.json`、`README.md`、`NOTICE-来源说明.md`、
`name-policy.json`、`server/nameGuard.mjs`。逐文件哈希对照见交付清单。

**原作者元数据一字未改**：`pack.json` 的 `id` / `name` / `version` / `author` / `license` / `description` /
`api` / `game` / `combat` 与 `server.preDispatch` 声明**原样**；`README.md` 与 `NOTICE-来源说明.md` 原样。

**词典原文一字未改**：`name-policy.json` 的 `words.*` 六个数组（english 384 / englishCompact 381 /
chinese 963 / chineseCompact 944 / political 2294 / politicalCompact 2294）与其余字段全部原样，
本包未做任何归一、去重或改写。

### ⚠️ 包内有一节已与新实现不符（保持原样未改，按纪律只写在这里）

原件 `NOTICE-来源说明.md` 第 61–63 行写：「词典数据……授权随包保留；fork 仓库里对应的
`NAME-*-LICENSE.txt` 四份文本是其凭据」，并在 `pack.json.license` 里写「词典数据另随包保留授权」。

**事实核对（实测）**：本包内**没有**任何 `NAME-*-LICENSE.txt`，也没有 `LICENSE` / `COPYING` 文件 ——
包内只有 5 个文件，全部列在上表。也就是说：**那四份许可全文并未随包保留**。
本包按纪律**不代填、不补造**，只在此如实记录，并列为待业主裁决项（见第 9 节）。

## 7. 自带素材来源（六项之六：自带素材来源）

- **不带任何素材。** 没有图标、音频、字体、spine、解包数据；全部字节 = 一个 `.mjs` 钩子
  + 一份 `.json` 策略/词典 + 说明文档。与原件 `NOTICE-来源说明.md` §素材从哪来 一致。

## 8. 边界与风险（给业主看的部分）

### 8.1 `server.preDispatch` 用法核真（依代码，非依作者自述）

| 判据 | 文件:行 | 本包 |
|---|---|---|
| `intercepts` 必须是 `shared/protocol.js` 的 `C2S` 真实类型 | `shared/workshop.js:836-843`（名单在 `:423`，由 `Object.keys(C2S)` 反推） | 声明 `["hello"]`；`shared/protocol.js:527` 有 `hello` ⇒ 合法 |
| 不得自写 socket，只许用框架 `send` | `server/modDispatch.js:78-79`、`:90`、`:97-106`（冻结依赖注入 `send`） | 模块只用 `deps.send(conn, frame)`（`server/nameGuard.mjs:146`）；**无 `import`、无 socket、无 `ws`** ⇒ 未越界 |
| 冻结依赖面 | `server/modDispatch.js:96-107` | 只用 `deps.policy` / `deps.send` / `deps.log`；`intercepts` / `c2s` / `now` 声明了但未使用 ⇒ 未越界 |
| 钩子落点 | `server/net.js:642`（在 `validateC2S` 之后、`ping`/`hello` 分支与 `hello required` 之前） | 与声明相符 |
| 只能放行 / 否决，不能改写消息 | `server/modDispatch.js:154-168`（返回值即消费） | 返回 `false` 放行、`true` 消费；**不重写 `msg.name`** ⇒ 合规 |

**结论：合法使用，未发现越界。** 模块是纯函数（`server/nameGuard.mjs:1-19` 自述与实测一致：
无 `import`、无时钟/RNG、无顶层可变状态），回帧失败时仍消费该 `hello`（`:148-151`）。

### 8.2 误伤风险（如实报）

- **拦截行为**：命中时回一条 `error`（`code: BAD_MSG`、带原 `rid`、文案「代号含有不适宜内容，请换一个昵称。」）
  并**消费这条 `hello`**（`server/nameGuard.mjs:139-153`）。
- **后果**：**不建会话**，玩家进不去（`server/net.js:642` 直接 `return`，后续 `onHelloMsg` 不执行）。
  对玩家表现为「连接成功但被拒入」的报错，不是「改名提示后放行」。
  重连令牌不受影响 —— 换个名字重试即可。
- **救济**：**没有白名单、没有开关、无法关闭**。本包只有一个 `hello` 闸门，没有任何「信任名单」或
  「只提示不拦截」的档位；要放行只能**卸载这个包**。被误判的玩家**只能改名**。
- **误判面（要如实告知下载者）**：判定是**词典匹配**，不做语义分类，作者自述
  「不保证穷尽、也不保证不误伤」（`README.md:22-23`）。政治分类**不合并不排除、不遮罩**
  （`nameGuard.mjs:126-127`），所以政治类词条一旦出现在代号里**一定被拒**，误伤时没有任何后门。
  引擎侧对 `hello.name` 的清洗是 **NFC**（`server/net.js:374`），本链用的是 **NFKC**
  （`nameGuard.mjs:39`）—— 兼容分解字符（如全角、`㍿` 一类）在两条链下的形态不同，
  这是本包自己归一后的判定，与引擎看到的字符串可能不同。

### 8.3 与引擎自带 `hello` 准入的关系（会不会双重判定 / 互相覆盖）

三段**串联**，不是各判一遍：

| 顺序 | 位置 | 做什么 | 失败时 |
|---|---|---|---|
| ① 字段层 | `shared/protocol.js:527`（`validateC2S`，`server/net.js:626`） | `hello.name` 必须是字符串、长度 ≤ `NAME_MAX_LEN` = 12（`shared/constants.js:160`） | 引擎回 `BAD_MSG`，钩子**根本收不到**这条消息 |
| ② 钩子层（本包） | `server/net.js:642` ← `server/modDispatch.js:154-168` | 归一 + 词典判定 + 12 字上限 | 回 `error` 并**消费**该消息 |
| ③ 业务层 | `server/net.js:674-705`（`onHelloMsg`） | 版本检查、`sanitizeName`（NFC/去控制符/截 12 码点）、建会话 / 重连 | 引擎原有报错 |

- **不覆盖**：②只在 `validateC2S` 通过后才被调用，且只对 `msg.t === 'hello'` 生效
  （`nameGuard.mjs:140`）；③在②未消费时**逐字节照旧**。②返回 `false` 的 `hello` 与没有本包时完全同形。
- **不双重**：只有「名字超过 12 字」这一条在 ① 与 ② 重叠。协议字段上限（12 **UTF-16 码元**）
  比 ② 的 12 字（`name.length`，`nameGuard.mjs:134`）更早、更严，正常客户端**碰不到**
  ② 的 12 字分支（作者在 `NOTICE-来源说明.md` 第 43-44 行也这么写）。绕过客户端直接发原始帧时才可能看到它。
- **风险方向相反**：① 是「超长就拒」，② 是「命中词典就拒」；两者叠加的结果是**更多拒绝**，不是互相放行。

### 8.4 包内一节已与实现不符（保持原样未改）

见第 6 节末尾：原件自述「四份 `NAME-*-LICENSE.txt` 是其凭据 / 授权随包保留」，
但包内**没有**这四份文件。

## 9. 待业主裁决

1. **两份词典（四份许可文本）的许可全文缺失**：原件 `NOTICE-来源说明.md` 与 `pack.json.license`
   都声称授权随包保留，实测包内**没有** `NAME-*-LICENSE.txt` / `LICENSE` / `COPYING`。
   - **CC-BY-4.0**：署名**在包内**（`NOTICE-来源说明.md` 第 63-64 行写了作品名与
     `Copyright (c) 2012–2020 Shutterstock, Inc.`，`pack.json.license` 写了 `CC-BY-4.0`）、
     上游 URL 在包内（第 8 行、`name-policy.json.source.repo`），但**许可全文不在包内**、
     也无指向 `LICENSE` 的链接 ⇒ **未完整满足 CC-BY-4.0 的「随附许可文本」要求**。
   - **Apache-2.0**：署名**部分在包内**（写了 `fwwdn/sensitive-stop-words`、`houbb/sensitive-word`
     两个仓库名与 `Apache-2.0`，但**没有** `NOTICE` 文件、没有版权行）；**许可全文不在包内**
     ⇒ **未满足 Apache-2.0 §4 的「随附许可副本」要求**。
   - **结论：这是一个 blocker（许可文本缺随包），列出来交业主裁决。**
     按纪律**不由本流程代填、不补造许可文本、不改原件文本**。
     若业主要求补齐，做法应是**新增我们自己的文件**（例如 `PROVENANCE-LICENSES/`）指向上游，
     而不是改原作者文本 —— 需业主先裁决授权的具体处置。
2. **误伤无救济**：8.2 的结论（无白名单、无开关、只能改名或卸包）要不要在上架时向下载者明示，
   请业主定。
3. **`NOTICE-来源说明.md` 与实现不符的那一节**：按纪律保持原样未改，是否需要在站点「兼容说明」里补一句。

## 10. 校验（本条是装载契约）

- 本包**单独**装载于干净的 workshop 根（根内**只有这一个包**）：
  装载器 `server/workshop.js loadWorkshop` → `errors = 0`；
  校验器 `node tools/workshop-validate.mjs --workshop <根>` → `0 error(s), 0 warning(s)` / `VALID`。
  原始输出留在交付清单里。

## 11. 许可文本补齐（业主批准；本节取代第 9 节第 1 项的处置结论）

第 9 节第 1 项实测到：**两份词典的许可全文都没有随包**（原件包内没有
`NAME-*-LICENSE.txt`、也没有 `LICENSE` / `COPYING`）。业主要求按 CC-BY-4.0 与 Apache-2.0
各自的**随附许可文本**义务补齐；做法是**新增我们自己的目录**，**不碰原作者任何文件**。

| 项 | 值 |
|---|---|
| 新增目录 | `PROVENANCE-LICENSES/`（在**包根**，与 `pack.json` 同级） |
| 补入的文件 | `PROVENANCE-LICENSES/CC-BY-4.0.txt`、`PROVENANCE-LICENSES/Apache-2.0.txt` |
| 谁补的 | 本版**兼容改写者 Mo233**（不是原作者；原作者文件一字未改） |
| 这些文本是什么 | **兼容改写方为满足 CC-BY-4.0 与 Apache-2.0 的随附要求而加入的许可文本** |

两份文本都是**从官方来源逐字取回的全文**，未做任何改写、删节或再排版：

| 文本 | 官方来源 URL（实际取值处） | 字节 | sha256 |
|---|---|---|---|
| CC-BY-4.0 法律文本（legalcode） | <https://creativecommons.org/licenses/by/4.0/legalcode.txt> | 18,657 | `9ba9550ad48438d0836ddab3da480b3b69ffa0aac7b7878b5a0039e7ab429411` |
| Apache License 2.0 | <https://www.apache.org/licenses/LICENSE-2.0.txt> | 11,358 | `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30` |

**为什么必须补**：CC-BY-4.0 要求分发时随附许可文本（或指向它的 URI）；
Apache-2.0 §4(a) 要求随附一份许可副本。原件包内**没有**这些文本
（见第 6 节末尾与第 8.4 节），所以不补就是分发方违规。

**这一节改了什么、没改什么**：

- 改动只限：**本文件**（追加本节）+ **新增** `PROVENANCE-LICENSES/` 两个文件；
- 原作者文件 `pack.json`、`README.md`、`NOTICE-来源说明.md`、`name-policy.json`、
  `server/nameGuard.mjs` **仍然一字未改**（逐文件哈希对照见交付清单）；
- `NOTICE-来源说明.md` 第 61–62 行那句「授权随包保留」**保持原样未改** ——
  那两句与包内实际内容不符这件事，我们**不去改原作者文本**，而是**在本节与
  `PROVENANCE-LICENSES/` 里另行补齐**；
- 本节**只**结束第 9 节第 1 项（许可全文缺失）。第 9 节第 2、3 项（误伤无救济要不要向下载者明示、
  与实现不符的那一节要不要在站点「兼容说明」里补一句）**不受本节影响**。

*English: this section records licence texts added by the compatibility rewriter, not by the original author.
`PROVENANCE-LICENSES/` holds the verbatim CC-BY-4.0 legalcode and the verbatim Apache-2.0 text, both fetched
from the official URLs above (sha256 listed), to satisfy the CC-BY-4.0 licence-inclusion requirement and
Apache-2.0 §4(a). No original file was modified.*

---

*English summary: this pack is a compatibility conversion delivered for Stronghold-Protocol. The original
author (`jingjiangze`) and the compatibility rewriter (`Mo233`) are listed separately above; where the
original was uncredited it is stated as “原件未署名 (uncredited original)” rather than being invented —
here nothing was missing, so no name was invented. The licence string is copied verbatim from the original.
The only change to the pack is the zip shape (one top-level directory named after the pack id) plus this
`PROVENANCE.md`; every original file is byte-identical. Two licence-text obligations (CC-BY-4.0 attribution
text, Apache-2.0 licence copy) are NOT met by the original bundle and are reported here as a blocker, without
fabricating anything.*
