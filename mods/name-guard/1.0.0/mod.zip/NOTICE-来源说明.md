# NOTICE-来源说明

## 原件是什么、从哪来

- **原件**：`jingjiangze/stronghold-server`（fork of sganggs/Stronghold-Protocol）的**昵称审查链**，即
  `server/net.js` 的 hello 准入 + `shared/names.js` + `deploy/stardust/auth/name-policy.mjs`、
  `name-dictionary.mjs`、`name-sensitive-dictionary.mjs`（2026-10-11，fork HEAD `9a8127d` 一带）。
  仓库：<https://github.com/jingjiangze/stronghold-server>
- 本包是**原作者自己**把同一件事按管理器（Forge 工坊包）的表面重做的一版：判定链与词典一致，
  挂点从 fork 的 `server/net.js` 换成管理器的 `server.preDispatch`（`docs/WORKSHOP.md` §1.9.1）。
  「原作者」与「改写者」是同一方；署名以本包 `pack.json` 的 `author` 为准。

## 它改了什么

**没有改引擎。** 这是「用管理器已有的表面重新实现同一功能」：

| 件 | 落点 | 说明 |
|---|---|---|
| `server/nameGuard.mjs` | `server.preDispatch.module` | 拦 `hello` 的钩子工厂：归一化 → 词典判定 → 12 字上限 → 放行或否决（回 error 帧、带 rid） |
| `name-policy.json` | `server.preDispatch.policy` | 只读策略：四类词典（英文/中文/政治/成人/违法，已归一去重编码）、排除表、上限与文案 |
| `README.md` | — | 用法、边界、组成 |

**与 fork 原链逐条对应**（不是重新发明）：

| fork 处 | 本包处 |
|---|---|
| `NAME_POLICY_LIMITS`（nameLength 12 / rawLength 256） | `name-policy.json.limits`，模块 `DEFAULT` 同值 |
| `clean()`：NFKC / 去孤立代理 / 折叠空白 / 去 `Default_Ignorable + Cc/Cf` | `nameGuard.mjs` 的 `clean()` 逐字同规则 |
| `compact()`：去空白/标点/符号；`englishForm()`：拉丁/非拉丁边界编码 | 同名函数，逐字同规则；词典侧形态在**建包时**用同一套规则预先算好 |
| 政治分类不合并不排除、不遮罩 | 同 |
| 脏话分类遮罩「妈妈的」，排除表只作用于脏话（英文/中文），中文条目 ≥2 字 | 同 |
| `moderateName()` 返回 `{ok, reason}`；拒绝文案 `NAME_REJECTED_MESSAGE` | 同；回帧 `msg` 用同一句文案 |
| `server/net.js` 在 `msg.name` 上判完才建会话 | 钩子在 `validateC2S` 之后、`hello` 处理之前运行；命中时**消费**消息 ⇒ 不建会话 |

**与 fork 的差异（如实列出）**：

1. **只能否决，不能改名。** fork 的同一条链也是「拒绝并要求改名」，语义一致；差别是本包**不重写** `msg.name`
   （钩子纪律：观察/记录/上报/否决）。
2. **词典在包内是预处理后的数组**（`words.*`），建包时用同一套 `clean/compact/englishForm` 算好；
   运行时不再逐连接准备词典（fork 在进程启动时准备一次）。
3. **匹配实现**从 Aho–Corasick（mint-filter）换成等价的 `includes` 扫描 —— 词典 ≤ 8192 条、名字 ≤ 12 字，
   判定结果与「任一词条出现」同义。
4. **rawLength/12 字两条上限**在管理器里通常先被协议字段校验挡下（`hello.name` ≤ 12 是引擎字段规则）；
   本包照旧实现，链的可核对行为与 fork 一致。

## 做不了的部分（明确边界）

- **自动改名 / 净化后放行**：需要引擎给「可重写的入站消息」表面；今天没有（钩子只放行或否决）。
- **语义级判定**：词典法不保证穷尽；这是 fork 自己的声明（「Coverage is dictionary-based, not a semantic
  classifier and never guaranteed exhaustive」）。
- **对已在线玩家改名**：没有改名入口；本包只管 hello 准入。

## 素材从哪来

**没有游戏素材。** 没有图标、音频、字体、解包数据。全部字节 = 一个 `.mjs` 钩子 + 一份 `.json` 词典
+ 说明文档。

## 许可

- 包本体与代码：**GPL-3.0-or-later**（与 fork 相同）。
- 词典数据（`name-policy.json` 的 `words.*` 来自以下语料快照，授权随包保留；fork 仓库里对应的
  `NAME-*-LICENSE.txt` 四份文本是其凭据）：
  - **英文/中文脏话**：LDNOOBW「List of Dirty, Naughty, Obscene, and Otherwise Bad Words」
    （Copyright (c) 2012–2020 Shutterstock, Inc.），**CC-BY-4.0**；
  - **政治分类**：houbb/sensitive-word 等政治敏感词分类与 fwwdn/sensitive-stop-words 的
    political/tagged 分类，**Apache-2.0**；
  - **成人/违法分类**：fwwdn/sensitive-stop-words，**Apache-2.0**。
- 上述字典在 fork 的 `name-policy.mjs` 中另有「不遮蔽、不排除政治分类」「只遮罩无害所有格」
  「排除表只作用于脏话」等纪律，本包逐条保留。
- 《明日方舟》及其素材版权归鹰角网络 / Yostar 所有；本包不含、也不主张任何此类素材。
