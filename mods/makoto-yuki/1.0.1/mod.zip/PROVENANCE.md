# 署名与来源 · PROVENANCE

> 本文件由**交付流程**在拆包时生成，随包分发。原作者与改写者**分开显示，不抹掉任何一方**。
> 原件未署名的一律写**「原件未署名」**，不代填名字；许可**照实抄**，包括非 SPDX 的值。

## 包

| 项 | 值 |
|---|---|
| 包 id | `makoto-yuki` |
| 版本 | `1.0.1` |
| 名称 | 结城理（Persona 3 Reload） |
| 目录名 = 包 id | 是（引擎逐包判 `PACK_ID_MISMATCH`，不一致会被拒） |
| 本包实测规模 | 29 个文件 / 8656758 字节（不含本文件） |

## 原作者 / 上游

**原件未署名（uncredited original）**。对原件两份文件全文搜 `licen|MIT|GPL|Copyright|版权|作者|署名`：**零命中**。**不代填名字。**本版修改者：Mo233（工坊包通道改写 + `api` 类型修正）。

- 上游：覆盖式安装脚本（`install.mjs`）

## 许可（照实抄）

原件**无任何许可声明**。按仓库规矩与业主口径**照实抄**，`pack.json.license` 写 `NOASSERTION`：

```
NOASSERTION
```

## 责任人

| 角色 | 是谁 |
|---|---|
| 原作者 | **原件未署名** |
| 本版兼容改写者 | Mo233（工坊包通道改写 / 按中间层重写；本包具体改写点见下节） |
| 本包交付 | 第三方 mod 兼容交付流程，2026-10-11 |

## 来源

- 原件：E:\destop\mod\b65c7f9320ca-结城理mod.zip
- 交付形态：工坊包（workshop pack）· 包契约 **MOD_API_VERSION 1**（据此判能否装载）· 打包时工作树 `3396438a` 的 APP_VERSION 为 0.14.0（该号只表示发行版，不参与包兼容判定；交付后 HEAD 已推进到 `d46cfdaa` / APP_VERSION 0.15.0，MOD_API_VERSION 仍为 1，本轮已在该 HEAD 上复测通过）

## 改了什么

- 原件**装不上**的原因：原件根本不是包，是一份往引擎源码里插代码的**覆盖式安装脚本**。
- **本版（1.0.1）必改**：`pack.json` 的 `"api": 1`（**数字**）改为字符串 `">=1 <2"`，版本 `1.0.0 → 1.0.1`。引擎判 `BAD_API_TYPE` 并把**整包移出已加载集合** —— 上一轮交付的 1.0.0 在本工作树上是**装不上的**，本轮修掉。
- **上一轮**：`data/unit.json` 单条记录 → `units.json` 按 `charId` 建键；`backups` + `diy` 写入 → `pack.json.content` + `operators`；`tokens.json` 独立成文件；`assets.json` → `pack.json.art`；补 `anims`（骨架实测 clip 名，缺了报 `ART_SPINE_NO_ANIMS`）；`skins.json` → `pack.json.skins`，皮肤 id `char_4217_makoto@p3r#1` → `makoto_p3r`（`SKIN_ID_RE` 不允许 `@` 与 `#`）；**不声明** `pack.json.assets`（无 `.spresources` 容器）；不收 `install.mjs` / `README.md` / `uninstall-snapshot`。
- 逐条对照表见包内 `README.md` 的「与原件不一致的地方（改写点）」。

## 自带素材来源

- 是，22 个文件：`char/avatar` 2 · `char/portrait` 2 · `char/skin` 2 · `char/skin_portrait_shop` 1 · `prof/sub` 1 · `skill` 3 · `spine/op` 9 · `token/avatar` 2。
- 素材来源：**Hypergryph / Yostar 官方客户端解包**（包内改写说明已注明）。

## 备注 / 边界

- **已知缺口（三条）**：① 战斗 kit **没有随包发出** —— 自选池槽位的记录是通用槽位（`chess_char_6_diy1_a/b`），没有任何 chess 记录以 `char_4217_makoto` 为 id，kit 挂不上去；② 面具形态：`pack.json` **没有** `forms`，也**没有** `fx.silentPhases` 两节（引擎**已有**这两条包通道，是**包还没去声明**）⇒ 模型出得来但**不会切面具形态**；③ 1 条 warning 是 `ART_UNKNOWN_ID` 同类（自选池这条路的固有形状，不是缺陷）。
- 本包**不应进入 git**：仓库红线（`AGENTS.md`「No game art in git」）禁止提交游戏素材。

## 包内其它署名 / 来源文件

- `README.md`（含「出处与许可（如实，不填）」与「与原件不一致的地方（改写点）」两表）

## 校验

- 本包**单独**装载于干净的 workshop 根（根内只有这一个包）：见交付索引 `../../INDEX.md` 的 8 条原始输出。
- 校验器：`node tools/workshop-validate.mjs`；装载器：`server/workshop.js loadWorkshop`。

---

*English summary: this pack is a compatibility conversion delivered for Mo233. The original
author and the compatibility rewriter are listed separately above; where the original was uncredited it is
stated as "原件未署名 (uncredited original)" rather than being invented. The licence text is copied verbatim
from the original. See the Chinese sections above for the exact source, the list of changes, and the origin
of any bundled assets.*
