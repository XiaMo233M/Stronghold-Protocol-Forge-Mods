# 结城理包（makoto-yuki）· 改写说明

本目录是一份**改写产物**，不是原件。原件是一份**覆盖式安装脚本**（`install.mjs`），本包只保留其中
**能用工坊包通道表达**的那部分。

## 出处与许可（如实，不填）

| 项 | 值 | 依据 |
|---|---|---|
| 原作 | `makoto-mod`（`install.mjs` 512 行 + `README.md` 343 行） | 只读原件 |
| 原作者 | **原件未署名（uncredited original）** | 两份文件全文搜 `licen|MIT|GPL|Copyright|版权|作者|署名` **零命中** |
| 许可 | **原件无许可** | 同上；`pack.json.license` 如实写 `NOASSERTION` |
| 素材版权 | Hypergryph / Yostar（官方解包） | 25 个素材来自官方客户端资源 |

按本仓库规矩：**未署名也要写明「原件未署名」，不许自填**。原 README 里写死了原作者的本机路径与用户名，
**未抄进本包**。

> ⚠️ 本包**不应进入 git**：仓库红线（`AGENTS.md`「No game art in git」）禁止提交游戏素材。
> 本包只作为 `_up/` 下的交付副本存在。

## 装上了能干什么

- **干员记录**：`char_4217_makoto`（结城理，6★，SPECIAL / 傀儡师 `dollkeeper`），三个档位
  `2/1/4/0`、`2/60/7/1`、`2/60/7/3` 齐备。
- **自选池**：进 `diy.ownedPool` 与 `diy.operators`（盟约 `lateranoShip`，权能 `laterano`）。
- **外观素材**：立绘 / 头像 / 模型（正背面 Spine 3.8.99）/ 技能图标 / 分支图标 / 召唤物头像。
- **时装**：`makoto_p3r`（Persona 3 Reload），带自己的一套模型与立绘。

## 装上了**干不了**什么（三件，逐条说清）

1. **战斗 kit 没有随包发出。**
   原件的 `op-makoto.js`（561 行）是**引擎内容层**的 tier-3 kit，走的是
   `kits/index.js` 注册表这条路。工坊包的 kit 通道是 `kits/<chessId>.js`，而
   `loadWorkshopKits` 要求 kit id 必须是**本包 chess 记录自己的 id**（或 `overrides` 里声明的官方 id）。
   结城理走的是**自选池**那条路：自选槽的记录是 `chess_char_6_diy1_a/b` 这类**通用槽位**，
   引擎在开局时用 `shared/diy.js diyRecordOf()` 把干员**组合**成临时记录 ——
   所以没有任何 chess 记录以 `char_4217_makoto` 为 id，
   kit 挂不上去（会得到 `KIT_NO_TARGET` 或 `KIT_OFFICIAL_OVERRIDE_UNDECLARED`）。
   原件的注释也确认了这一点：它**刻意不**写进 `kits/index.js` 的 `OPERATOR_KIT_FILES`，因为那会让 charId 进 `KITTED_CHARS`。

2. **两处客户端源码插入无包通道。**
   - `public/js/render/units.js` 的 `FORMS` 加 4 个子形态（`doll1`/`doll2`/`doll3p1`/`doll3p2`）。
     `FORMS` 是模块内的硬编码字面量，**25 个表面里没有对应通道**（C 层只有 panels/wraps/styles/theme/data/messages/requires）。
     没有它，客户端 `units.js:635` 的 `if (k && !FORMS[...]?.[k]) return;` 会把形态变更**静默丢掉**：
     模型出得来，但**不会切面具形态**。
   - `public/js/render/fx/kinds.js` 的 `SILENT_PHASES` 加 4 个形态名。同样是模块内常量，无包通道。
     没有它只是每次切面具多冒一团紫色 vanish（原件自己标注为「可选但强烈建议」）。

3. **原件 `uninstall-snapshot/` 里的 `kits/index.js` 未收进包。**
   那份是要盖回引擎的**源实例文件**；收进包会让装载器把它当数据读，属于危险项。

## 与原件不一致的地方（改写点）

| # | 改动 | 为什么 |
|---|---|---|
| 1 | `data/unit.json`（单条记录）→ `units.json` 的 `{ "char_4217_makoto": … }` | 内容文件那一层要求按 id 建键（`ID_FIELD_BY_FILE.units = 'charId'`） |
| 2 | `backups.units` + `diy.ownedPool` + `diy.operators` → `pack.json.content:["units"]` + `pack.json.operators` | 引擎在装载期合并，不写 `data/*.json` |
| 3 | `data/tokens.json` 两个面具 → `tokens.json` | 同为内容文件 |
| 4 | `data/assets.json` 的 chars/tokens/skills → `pack.json.art` | 叠加层 `mergeWorkshopArt` 把路径改写成 `/workshop-assets/makoto-yuki/…` |
| 5 | **新增 `anims`** 到每个 spine 条目 | 客户端 `validSpine` 要求 `anims` 是对象；没有它校验器报 `ART_SPINE_NO_ANIMS`（error）。动画名逐个取自**骨架里真实存在的** clip（`tools/assets/skel.mjs` 实测）。`die` 留 `null`：这几个骨架**没有**不带后缀的 `Die`，只有 `<替身>` 形态的 `Doll_Skill_*_Die` |
| 6 | `data/skins.json` → `pack.json.skins` | 引擎**不读** `data/skins.json`（死数据）。皮肤 id 由 `char_4217_makoto@p3r#1` 改成 `makoto_p3r`：`SKIN_ID_RE` 不允许 `@` 与 `#` |
| 7 | **不声明 `pack.json.assets`**（无 `.spresources` 容器） | 见下 |
| 8 | 不携带 `install.mjs` / `README.md` / `uninstall-snapshot/` | 覆盖式安装脚本与源实例快照对工坊包无意义 |

### 为什么包里没有 `.spresources` 容器

`assets` 声明的语义是「客户端资源容器」：一旦**任何**包声明它，引擎自带的资源 Service Worker 就会注册，
并且它**只用本地导入并通过校验的缓存**回答 `/assets/`、`/fonts/`、`/media/` 三棵树，**命不中回 412、绝不回源**
（`docs/WORKSHOP.md` §1.9.4 的警告原话：「容器的内容必须覆盖页面真的会去取的那三棵树，否则玩家看到的是一页没有素材的界面」）。

本包的 25 个素材全部住在 `/workshop-assets/<包>/…` 这条**另一条**路由上，容器**覆盖不到**它们；
而容器里若只装结城理自己的几件素材，就会让核心游戏那三棵树变成 412 且不回源 —— **装上等于把页面打坏**。
容器还要求每条 `url` 以 `/assets/` 或 `/fonts/` 开头（`tools/spresources.mjs assertResourceUrl`），
与本包素材的真实路径不一致，只能靠复制一份文件来伪造。

所以**工程上正确的做法是不声明 `assets`**：外观素材照旧由 `/workshop-assets/` 服务，零损失。
`license` 仍然必须写 —— 「有 `assets/` 文件夹就必须声明 `license`」（`ASSETS_NEED_LICENSE`）。

## 验收记录（2026-10-11）

```
# 1) 校验器（用仓库的 tools/workshop-validate.mjs；见下方说明）
0 error(s), 5 warning(s)
VALID: the engine accepts this content.

# 2) 引擎装载器 server/workshop.js loadWorkshop
packs : makoto-yuki (layer A, combat false)   errors: 0
units : char_4217_makoto
tokens: token_makoto_thanatos, token_makoto_orpheus
skins : makoto_p3r / Persona 3 Reload / 联动
# 3) 合并后的数据
backups.units[char_4217_makoto] = true
diy.ownedPool 含他 = true ... diy.operators 记录已生成
assets.chars[char_4217_makoto].avatar = /workshop-assets/makoto-yuki/char/avatar/char_4217_makoto.png
# 4) 临时服务器 SP_WORKSHOP=… PORT=39131 node server/index.js
[workshop] applied 1 pack(s): 结城理（Persona 3 Reload）(makoto-yuki): tokens +2, units +1,
           3 art entries …, 1 outfit, 4 icons …, 自选池 +1
GET /workshop-assets/makoto-yuki/char/avatar/char_4217_makoto.png -> 200 image/png 51518 bytes
GET /workshop-assets/makoto-yuki/spine/op/char_4217_makoto/front/char_4217_makoto.skel -> 200 1750749 bytes
```

**5 条 warning 都是 `ART_UNKNOWN_ID` 同类**，含义与处理：

| 资源 | 为什么报 | 处理 |
|---|---|---|
| `art.chars.char_4217_makoto` | 客户端是拿 **chess 记录**的 `assets.spine` 去查 `assets.chars` 的；而结城理的 chess 记录是自选槽**运行时组合**出来的 | 装机后自选槽选中他时**照常显示**；这是自选池这条路的固有形状，不是缺陷 |
| `art.skills.skchr_makoto_*` | 技能图标由 units 记录的 `skills[].iconId` 指向 —— 该 id 在 `data/assets.json` 的 `skills` 表里本来没有 | 需要技能图标时把 `iconId` 写进 `units.json` 的技能条目；**原件也没写**（它直接往 `assets.skills` 加键） |
| `art.profSub.dollkeeper` | 同一类：分支图标 id 不在官方 `prof.sub` 表里 | 同上 |

## 已知的引擎侧副作用（不是本包引入的）

原件的 `data/*.json` 改动会与两条既有测试冲突，本包走工坊通道**同样**会碰到，因为合并后的数据是一样的：

- `test/backups.test.js` 断言 7 位联动干员（含 `char_4217_makoto`）在 `units` / `operators` 里为 `undefined`；
- `test/diy.test.js` 断言自选池不含 COLLAB。

这是**引擎侧口径**问题（结城理是被因版权移出数据与卡池的 7 位联动干员之一），**不是改写引入的**。
不要在改写里改这些测试。

## 校验器的一个真实缺陷（请维护者看）

`tools/workshop-validate.mjs:496` 缺一个存在性守卫（同一段代码的 473 行有）：

```js
// 第 473 行（有守卫）
const inherits = OFFICIAL_ART_IDS[table] ? OFFICIAL_ART_IDS[table].has(id) : false;
// 第 496 行（没有守卫）—— OFFICIAL_ART_IDS 只有 chars/enemies/tokens
if (OFFICIAL_ART_IDS[table].has(id) || ownIds[table].has(id)) continue;
```

`OFFICIAL_ART_IDS = { chars, enemies, tokens }` 只有三张**非扁平**表；而第 494 行的循环遍历 `art` 的**每一个**键，
所以只要包声明了 `art.skills` 或 `art.profSub`（两者都是文档支持的扁平表，见 §1.4 与 `ART_TABLES`），
校验器就 `TypeError: Cannot read properties of undefined (reading 'has')` 崩掉，退出码 2。

最小复现：一个只有 `art: { skills: { skchr_probe_1: "skill/p.png" } }` 的包即崩。
本包命中它，因此上面第 1 条验收是在**仓库外的一份打了上面这个补丁的副本**上跑的
（`_up/mod-rewrites/_patcher/workshop-validate.patched.mjs`，只改了那一行）；**仓库文件一行未动**。

建议修法（一行）：

```js
if ((OFFICIAL_ART_IDS[table]?.has(id) ?? false) || (ownIds[table]?.has(id) ?? false)) continue;
```

顺带一提，第 500 行的 `hint: unknownHint[table]` 对扁平表也是 `undefined`（不崩，但提示文案会写 `undefined`）。
