// net-panel/client/status.js — 连接与服务器状态面板（`screen.game.aside` 面板，纯只读）。
//
// 两块读数，都是引擎给面板的：
//   * **连接**：`ctx.net.status()`（DESIGN §28.24）—— 连接状态、重连次数与倒计时、**延迟**（心跳往返 ms）、最后一条错误；
//   * **服务器身份**：`ctx.net.welcome()`（DESIGN §28.25）—— 协议版本 + 这台服务器声明的包集合（`{digest, packs}`）。
//     为什么不是 `ctx.net.on('welcome')`：面板由**同一条 welcome 帧**里的 `modPanels` 装载，等于帧发完了面板才挂上，
//     事件订阅只赶得上重连 —— 要答「我连的是哪台服务器」只有这一格。
//
// 一个 1 秒的轮询画这两块（心跳本来就每秒更新 `net.ping`，再快没有意义）。面板**不发送任何东西**：它不重连、
// 不改名、不刷页 —— 引擎自己的连接横幅（`public/js/ui/connBanner.js`）负责那些动作，这里只报数。
//
// 「什么时候画」：这是个常驻浮层（`docs/WORKSHOP.md` §1.9.3：挂一次就一直在），所以由面板自己判 ——
// **结算屏（`.screen.result`）出来时整块收起**（那是结算的地盘，底部横条留给它），其余时候贴右下角。

/** 连接状态 → 一句中文（键与引擎 `Net.status` 的取值一字不差）。 */
export const STATUS_TEXT = Object.freeze({
  idle: '未连接',
  connecting: '连接中',
  connected: '已连接',
  handshaking: '握手中',
  online: '在线',
  reconnecting: '重连中',
  closed: '连接已断开',
});

/** 延迟分档（ms）：好 / 一般 / 差。阈值是给人看的经验值，不参与任何判据。 */
export const PING_OK = 80;
export const PING_WARN = 150;

/** 延迟读数：数字或 `—`（还没测出来）。 */
export function pingText(ms) {
  return Number.isFinite(ms) ? `${Math.round(ms)}ms` : '—';
}

/** 延迟分档：`ok` / `warn` / `bad` / `none`（没有读数）。 */
export function pingTone(ms) {
  if (!Number.isFinite(ms)) return 'none';
  if (ms < PING_OK) return 'ok';
  if (ms < PING_WARN) return 'warn';
  return 'bad';
}

/**
 * 把 `ctx.net.status()` 的一份读数翻成这一行要画的东西。
 * @param {{status?: string, attempt?: number, retryAt?: number|null, ping?: number|null, lastError?: any}|null} st
 * @param {number} now 当前时间（测试注入；真实调用是 `Date.now()`）
 * @returns {{ tone: 'ok'|'warn'|'bad'|'none', main: string, meta: string|null } | null} null = 这一格不该画
 */
export function readoutFor(st, now = Date.now()) {
  if (!st || typeof st !== 'object' || typeof st.status !== 'string') return null;
  const err = st.lastError && typeof st.lastError === 'object'
    ? (typeof st.lastError.text === 'string' && st.lastError.text) || (typeof st.lastError.code === 'string' ? st.lastError.code : null)
    : null;
  if (st.status === 'online') {
    // 在线：主角就是延迟；有错误残留（例如刚被拒过一次又连上）时附一句
    return { tone: pingTone(st.ping), main: pingText(st.ping), meta: err };
  }
  const text = STATUS_TEXT[st.status] || st.status;
  if (st.status === 'reconnecting') {
    const secs = Number.isFinite(st.retryAt) && st.retryAt > now ? Math.max(0, Math.ceil((st.retryAt - now) / 1000)) : 0;
    const attempt = Number.isFinite(st.attempt) && st.attempt > 0 ? `第 ${st.attempt} 次` : null;
    return { tone: 'warn', main: text, meta: [attempt, secs > 0 ? `${secs}s 后重试` : '正在重试'].filter(Boolean).join(' · ') };
  }
  if (st.status === 'closed') return { tone: 'bad', main: text, meta: err };
  if (st.status === 'connected') return { tone: err ? 'bad' : 'warn', main: err ? '连接被拒' : text, meta: err };
  if (st.status === 'idle') return { tone: 'none', main: text, meta: null };
  return { tone: 'warn', main: text, meta: err }; // connecting / handshaking
}

/** 摘要短写：64 位十六进制只露前 8 位（它是身份的指纹，不是给人读全的）。 */
export const shortDigest = (d) => (typeof d === 'string' && d.length > 8 ? `${d.slice(0, 8)}…` : d);

/**
 * 服务器身份那一行：`协议 v0.2.3 · 本服包 5 · a1b2c3d4…`；没有读数（还没到过 welcome）时 null。
 * `mods` 为 null 是两种「没有包」都算：`welcome` 里没有这个字段（干净安装）或那一帧不成形。
 */
export function identityFor(w) {
  if (!w || typeof w !== 'object') return null;
  const parts = [];
  if (typeof w.version === 'string' && w.version) parts.push(`协议 v${w.version}`);
  const mods = w.mods && typeof w.mods === 'object' ? w.mods : null;
  if (mods) {
    const n = Array.isArray(mods.packs) ? mods.packs.length : 0;
    parts.push(n ? `本服包 ${n} · ${shortDigest(mods.digest)}` : '本服无包');
  } else {
    parts.push('本服无包');
  }
  return parts.join(' · ');
}

/** 本局跑哪几个包（`ctx.me.room.mods`，房间声明过才有；没声明是 null → 不画这一行）。 */
export function roomLine(room) {
  if (!room || !Array.isArray(room.mods) || !room.mods.length) return null;
  return `本局：${room.mods.join(' · ')}`;
}

/** 结算屏在场时收起（底部是结算横条的地盘）；统计页浮层（`.st`）开着时同样不画。 */
export function visibleOn(doc) {
  if (!doc || typeof doc.querySelector !== 'function') return false;
  try {
    if (doc.querySelector('.st')) return false;
    return !doc.querySelector('.screen.result');
  } catch { return false; }
}

export function mount(ctx) {
  const host = ctx.host;
  const doc = host && host.ownerDocument ? host.ownerDocument : (typeof document !== 'undefined' ? document : null);

  const box = doc.createElement('section');
  box.className = 'net-panel';
  box.setAttribute('aria-label', '连接与服务器状态');
  host.appendChild(box);

  const el = (tag, cls, text) => {
    const n = doc.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  };

  // 这两格读数比本包新（§28.24 连接读数 / §28.25 身份读数）：老引擎上没有它们。**不允许静默什么都不画** ——
  // 「装了但没反应」是这个仓库最不接受的失败形态，所以这里明说一句并记一条日志，玩家与作者都看得见。
  if (typeof ctx.net.status !== 'function' || typeof ctx.net.welcome !== 'function') {
    box.appendChild(el('small', 'net-panel__need', '此面板需要带连接读数（§28.24/§28.25）的引擎版本'));
    ctx.log.warn('ctx.net.status()/welcome() 不存在：这版引擎还没有 §28.24/§28.25 这两格读数，面板不会显示');
    return { unmount() { box.remove(); } };
  }

  const dot = el('i', 'net-panel__dot');
  const main = el('b', 'net-panel__main');
  const meta = el('span', 'net-panel__meta');
  const ident = el('small', 'net-panel__ident');
  const roomEl = el('small', 'net-panel__room');

  let drawn = null; // 上一帧画下去的那份内容（每秒轮询时状态没变就一个 DOM 写都不做）
  function render() {
    if (!doc) return;
    const st = typeof ctx.net.status === 'function' ? ctx.net.status() : null;
    const w = typeof ctx.net.welcome === 'function' ? ctx.net.welcome() : null;
    const room = ctx.me && ctx.me.room ? ctx.me.room : null;
    const r = readoutFor(st, Date.now());
    const id = r && visibleOn(doc) ? identityFor(w) : null;
    const rl = r ? roomLine(room) : null;
    const sig = r && visibleOn(doc) ? `${r.tone}|${r.main}|${r.meta || ''}|${id || ''}|${rl || ''}` : '';
    if (sig === drawn) return;
    drawn = sig;
    box.textContent = '';
    if (!sig) return;
    const line = el('div', 'net-panel__line');
    dot.className = `net-panel__dot is-${r.tone}`;
    line.appendChild(dot);
    main.textContent = r.main;
    main.className = `net-panel__main is-${r.tone}`;
    line.appendChild(main);
    if (r.meta) {
      meta.textContent = r.meta;
      meta.title = r.meta;
      line.appendChild(meta);
    }
    box.appendChild(line);
    if (id) {
      ident.textContent = id;
      box.appendChild(ident);
    }
    if (rl) {
      roomEl.textContent = rl;
      roomEl.title = rl;
      box.appendChild(roomEl);
    }
  }

  render();
  const timer = setInterval(render, 1000);

  return {
    unmount() { clearInterval(timer); box.remove(); },
  };
}
