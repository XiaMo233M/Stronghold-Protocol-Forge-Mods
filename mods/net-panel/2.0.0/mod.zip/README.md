# net-panel · 连接与服务器状态

屏幕右下角一枚**只读徽标**：延迟、连接状态、以及**这台服务器的身份**（协议版本 + 本服声明的包集合）。

三行，自上而下：

```
● 42ms
协议 v0.2.3 · 本服包 5 · a1b2c3d4…
本局：dmg-board · net-panel        （房间声明过包集合才有这一行）
```

- **延迟**：引擎心跳测出的最近一次往返毫秒数（`ctx.net.status().ping`）。分档上色：<80ms 薄荷绿 · 80–150ms 琥珀 ·
  ≥150ms 红；还没测出来是 `—`（不是 0）。
- **连接状态**：在线 / 重连中（`第 N 次 · 8s 后重试`）/ 握手中 / 连接被拒（带引擎给的那句话）/ 已断开 / 未连接。
- **服务器身份**：`ctx.net.welcome()` —— 协议版本 + 本服声明的包集合（个数 + 集合摘要前 8 位）。
- **本局包**：房间自己声明的那一套（`ctx.me.room.mods`）；房间没声明就不画这一行。

## 下载

- 工坊 mod 站（投稿 / 已上线列表）：`http://47.103.14.217:25570/`（列表在 [`/mods`](http://47.103.14.217:25570/mods)）
- 源码：`https://github.com/jingjiangze/Stronghold-Protocol-Forge`（工坊包工作树，分支 `feat/stardust-mods`）

## ⚠️ 版本前提（先读这条）

本包用管理器**新增的两格只读面**：

| 读数 | 设计稿 | 说明 |
|---|---|---|
| `ctx.net.status()` | §28.24 | 连接状态 / 重连次数与倒计时 / **延迟** / 最后一条错误 |
| `ctx.net.welcome()` | §28.25 | 最后一次 `welcome` 的身份：协议版本 + 包集合（`digest` + 每包 `id/layer/combat`） |

两者都在 `jingjiangze/Stronghold-Protocol-Forge` 的 PR #3（分支 `feat/mod-registry`）里，**尚未合入上游**。
在没有这两格的引擎上，面板**明说一句**「此面板需要带连接读数（§28.24/§28.25）的引擎版本」并记一条 warn 日志 ——
按要求，装了却不能工作的东西不允许静默。

为什么身份读数不能靠 `ctx.net.on('welcome')`：面板由**同一条 welcome 帧**里的 `modPanels` 装载 —— 帧发完了面板才挂上，
事件订阅只赶得上重连；这就是 §28.25 存在的理由。

## 它不做什么

- **不发送任何消息**：不重连、不改名、不刷新页面 —— 那些是引擎自己的连接横幅（`public/js/ui/connBanner.js`）的事。
  本包只报数（`ctx.net.status()` / `welcome()` 都是只读函数，面板也没有 send 的口子）。
- **不显示服务端健康**：`/healthz` 的负载 / 队列 / Worker 池**刻意不公开**给面板（写死在 §28.24 的边界里），
  所以「服务器状态」到这里为止 = 连接读数 + 身份读数 + 本局包集合。
- **结算屏与统计页在场时自动收起**：右下角是它们的地盘（结算横条在底部）。

## 安装

```bash
node tools/workshop-pack.mjs import "连接与服务器状态.zip"   # 或把 net-panel/ 目录复制进 workshop/
# 重启游戏服务器（包的装载是进程级的）
```

## 开发/验收

```bash
node --test net-panel/test/status.test.mjs        # 8 条：读数分档 / 身份行 / 可见性 / 轮询-收起 / 老引擎明说
node tools/workshop-validate.mjs --workshop <装好的根>    # 作者侧校验器
```

许可证：代码 GPL-3.0-or-later；本包不含任何游戏素材。
