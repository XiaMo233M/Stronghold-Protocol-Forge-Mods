// net-panel/test/status.test.mjs — 连接与服务器状态面板的纯逻辑与宿主交互验收。
//
// 怎么跑：在**管理器树**里 `node --test net-panel/test/status.test.mjs`。
// 包本身不 import 引擎的任何东西；test 是作者侧的：纯函数直接测，`mount` 用迷你 DOM + 假的 `ctx.net` / `ctx.me`
// （形状照 `public/js/ui/extensions.js` 的注入面），setInterval 换成可手动驱动的版本。
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  STATUS_TEXT, PING_OK, PING_WARN, pingText, pingTone, readoutFor, shortDigest, identityFor, roomLine, visibleOn, mount,
} from '../client/status.js';

// ---- 迷你 DOM（与 dmg-board 的测试同一套最小面） ----
function makeEl(tag) {
  const el = {
    tagName: tag, children: [], attrs: {},
    className: '', title: '',
    setAttribute(k, v) { el.attrs[k] = String(v); },
    getAttribute(k) { return k in el.attrs ? el.attrs[k] : null; },
    appendChild(child) { el.children.push(child); child.parentElement = el; return child; },
    remove() {
      if (el.parentElement) el.parentElement.children = el.parentElement.children.filter((c) => c !== el);
      el.parentElement = null;
    },
  };
  Object.defineProperty(el, 'textContent', {
    get: () => el._text || '',
    set: (v) => { el._text = String(v); if (v === '') el.children = []; },
  });
  return el;
}
function makeDoc({ result = false, stats = false } = {}) {
  const doc = {
    body: makeEl('body'),
    _result: result, _stats: stats,
    createElement: makeEl,
    querySelector(sel) {
      if (sel === '.st') return doc._stats ? makeEl('div') : null;
      if (sel === '.screen.result') return doc._result ? makeEl('div') : null;
      return null;
    },
  };
  doc.body.ownerDocument = doc;
  return doc;
}

const WELCOME = Object.freeze({
  version: '0.2.3',
  mods: Object.freeze({ digest: 'a1b2c3d4e5f6'.repeat(5) + 'abcd', packs: Object.freeze([{ id: 'dmg-board', layer: 'C', combat: false }]) }),
});
const st = (over = {}) => ({ status: 'online', attempt: 0, retryAt: null, ping: 42, lastError: null, playerId: 'p1', ...over });

test('pingText / pingTone：延迟读数与分档（— 是「还没测出来」，不是 0）', () => {
  assert.equal(pingText(42.4), '42ms');
  assert.equal(pingText(null), '—');
  assert.equal(pingText(undefined), '—');
  assert.equal(pingTone(10), 'ok');
  assert.equal(pingTone(PING_OK - 1), 'ok');
  assert.equal(pingTone(PING_OK), 'warn');
  assert.equal(pingTone(PING_WARN), 'bad');
  assert.equal(pingTone(null), 'none');
});

test('readoutFor：在线看延迟；重连看次数与倒计时；被拒/断开带错误；idle 是「未连接」', () => {
  assert.deepEqual(readoutFor(st()), { tone: 'ok', main: '42ms', meta: null });
  assert.deepEqual(readoutFor(st({ ping: 300 })), { tone: 'bad', main: '300ms', meta: null });
  assert.deepEqual(readoutFor(st({ ping: null })), { tone: 'none', main: '—', meta: null });
  const now = 1_000_000;
  assert.deepEqual(readoutFor(st({ status: 'reconnecting', attempt: 3, retryAt: now + 8000, ping: null }), now),
    { tone: 'warn', main: '重连中', meta: '第 3 次 · 8s 后重试' });
  assert.deepEqual(readoutFor(st({ status: 'reconnecting', attempt: 1, retryAt: now - 5, ping: null }), now),
    { tone: 'warn', main: '重连中', meta: '第 1 次 · 正在重试' });
  assert.deepEqual(readoutFor(st({ status: 'closed', lastError: { code: 'REPLACED', text: '该身份已在其他页面登录' } })),
    { tone: 'bad', main: '连接已断开', meta: '该身份已在其他页面登录' });
  assert.deepEqual(readoutFor(st({ status: 'connected', lastError: { code: 'VERSION', text: '版本不一致' } })),
    { tone: 'bad', main: '连接被拒', meta: '版本不一致' });
  assert.deepEqual(readoutFor(st({ status: 'idle', ping: null })), { tone: 'none', main: '未连接', meta: null });
  assert.equal(readoutFor(null), null);
  assert.equal(readoutFor({}), null);
  assert.equal(readoutFor({ status: 'weird' }).main, 'weird', '未知状态原样显示，不假装认识');
  // 状态表与引擎 Net.status 的取值一致（七个）
  assert.deepEqual(Object.keys(STATUS_TEXT).sort(), ['closed', 'connected', 'connecting', 'handshaking', 'idle', 'online', 'reconnecting']);
});

test('identityFor / roomLine：服务器身份与「本局哪几个包」', () => {
  assert.equal(shortDigest('a1b2c3d4e5f6'), 'a1b2c3d4…');
  assert.equal(shortDigest('short'), 'short');
  const id = identityFor(WELCOME);
  assert.match(id, /^协议 v0\.2\.3 · 本服包 1 · a1b2c3d4…$/);
  assert.equal(identityFor({ version: '0.2.3', mods: null }), '协议 v0.2.3 · 本服无包');
  assert.equal(identityFor({ version: null, mods: null }), '本服无包');
  assert.equal(identityFor(null), null);
  assert.equal(roomLine({ mods: ['a', 'b'] }), '本局：a · b');
  assert.equal(roomLine({ mods: [] }), null);
  assert.equal(roomLine({ mods: null }), null);
  assert.equal(roomLine(null), null);
});

test('visibleOn：结算屏与统计页在场时收起', () => {
  assert.equal(visibleOn(makeDoc()), true);
  assert.equal(visibleOn(makeDoc({ result: true })), false);
  assert.equal(visibleOn(makeDoc({ result: true, stats: true })), false);
  assert.equal(visibleOn(makeDoc({ stats: true })), false);
  assert.equal(visibleOn(null), false);
});

// ---- mount：轮询 → 判可见 → 画 / 收 ----
function stage({ result = false, status = st(), welcome = WELCOME, room = null, legacy = false } = {}) {
  const doc = makeDoc({ result });
  const host = makeEl('div');
  host.ownerDocument = doc;
  const warns = [];
  const ctx = {
    pack: 'net-panel', id: 'status', slot: 'screen.game.aside', hostKey: null, host,
    net: legacy ? {} : { status: () => status, welcome: () => welcome },
    me: { get room() { return room; }, playerId: 'p1', name: '甲' },
    log: { info() {}, warn: (m) => warns.push(m), error() {} },
  };
  const saved = { setInterval: globalThis.setInterval, clearInterval: globalThis.clearInterval };
  const ticks = [];
  let cleared = 0;
  globalThis.setInterval = (fn) => { ticks.push(fn); return ticks.length; };
  globalThis.clearInterval = () => { cleared += 1; };
  const api = mount(ctx);
  const tick = (n = 1) => { for (let i = 0; i < n; i++) for (const fn of ticks.slice()) fn(); };
  const restore = () => { globalThis.setInterval = saved.setInterval; globalThis.clearInterval = saved.clearInterval; };
  return { doc, host, ctx, api, tick, restore, warns, get cleared() { return cleared; }, setStatus: (s) => { ctx.net.status = () => s; }, setRoom: (r) => { room = r; } };
}

const box = (host) => host.children[0];

test('mount：在线时画「延迟 + 身份」，每秒重画一次但状态没变就不动 DOM', () => {
  const s = stage();
  const b = box(s.host);
  assert.equal(b.className, 'net-panel');
  const line = b.children[0];
  assert.equal(line.children[0].className, 'net-panel__dot is-ok');
  assert.equal(line.children[1]._text, '42ms');
  assert.equal(b.children[1]._text, '协议 v0.2.3 · 本服包 1 · a1b2c3d4…');
  const children = b.children.slice();
  s.tick(3); // 三次轮询、状态一字不变
  assert.deepEqual(b.children, children, '内容没变：一个 DOM 写都不做（引用都不换）');
  s.setStatus(st({ ping: 210 }));
  s.tick();
  assert.equal(b.children[0].children[1]._text, '210ms', '延迟变了就重画');
  assert.equal(box(s.host).children[0].children[1].className, 'net-panel__main is-bad');
  s.restore();
});

test('mount：重连中显示次数与倒计时；本局面板有声明时多一行；结算屏在场就收起', () => {
  const s = stage({ status: st({ status: 'reconnecting', attempt: 2, retryAt: Date.now() + 5000, ping: null }), room: { mods: ['dmg-board', 'net-panel'] } });
  const b = box(s.host);
  assert.equal(b.children[0].children[1]._text, '重连中');
  assert.match(b.children[0].children[2]._text, /^第 2 次 · \ds 后重试$/, '倒计时是活的（按 Date.now() 算）');
  assert.equal(b.children[2]._text, '本局：dmg-board · net-panel');
  s.doc._result = true;
  s.tick();
  assert.equal(b.children.length, 0, '结算屏在场：整块收起');
  s.doc._result = false;
  s.tick();
  assert.ok(b.children.length >= 2, '结算屏撤了就画回来');
  s.restore();
});

test('mount：没有引擎连接读数（status() 为 null）时什么都不画；unmount 停轮询 + 摘掉自己', () => {
  const s = stage({ status: null });
  const b = box(s.host);
  assert.equal(b.children.length, 0);
  s.setStatus(st({ status: 'online', ping: 10 }));
  s.tick();
  assert.ok(b.children.length > 0);
  s.api.unmount();
  assert.equal(b.parentElement, null, '箱子从宿主里摘掉');
  assert.equal(s.cleared, 1, '轮询停掉');
  s.restore();
});

test('mount：老引擎没有 §28.24/§28.25 这两格读数 ⇒ 明说一句 + 记一条日志（不许静默什么都不画）', () => {
  const s = stage({ legacy: true });
  const b = box(s.host);
  assert.equal(b.children.length, 1);
  assert.match(b.children[0]._text, /§28\.24\/§28\.25/);
  assert.equal(s.warns.length, 1);
  assert.match(s.warns[0], /ctx\.net\.status\(\)\/welcome\(\) 不存在/);
  s.api.unmount();
  assert.equal(b.parentElement, null);
  s.restore();
});
