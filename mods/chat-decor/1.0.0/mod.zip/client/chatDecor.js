// 房内聊天增强 —— chat-decor 的客户端面板。
//
// 出身：wei.isomer319.xyz 的 `_v024/js/ui/roomChat.js` + `accounts.js` + `ownerName.js`。
// 那套东西有几块在这个引擎上**没有对应面**，所以本面板只搬能搬的那几块：
//
//   ✅ 搬过来：悬浮入口（可折叠、可拖动 remembered 位置）、未读计数、最近消息列表、
//              房主名单徽章（ownerNames）、被 @ 的名字高亮、aria-live 播报。
//   ❌ 搬不过来：账号头像与 #tag（isomer 的 /accounts/ 后端，引擎没有这个面）、
//                贴纸图片（见 sticker-pack）、弹幕（roomDanmaku，引擎无此面）、
//                历史回填（isomer 用 room.chatHistory，引擎 C2S 没有这个类型）。
//
// 数据全部来自引擎原生 `chat.msg { from, name, seat, text, at }` —— 本面板**只读**，
// 不发任何消息（`ctx.net.send` 一次都没调），所以它改不了任何一局。
//
// 为什么挂 root.overlays：这是一个浮层，不属于任何具体界面元素；`MOD_PANEL_CREATED`
// 那四个槽位里只有它与 root.guide 是「任何时候都可能想看到」的。

const MAX_ROWS = 60;
const MENTION_RE = /@([^\s@]{1,24})/g;

const el = (tag, cls, text) => {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text != null) node.textContent = text;
  return node;
};

/** 房主名单：isomer 的 ownerName.js 是同一形状（一个闭集合，命中加徽章）。按你的服改这里。 */
const OWNER_NAMES = new Set(['isomer', '凑鹈鹕', '香鹈鹕']);

/** 我自己的名字：用于「这条是我发的」与 @ 我时高亮。每次读都取当前值（ctx.me 是活读数）。 */
const myName = (ctx) => (ctx.me && typeof ctx.me.name === 'string' ? ctx.me.name : '');

export function mount(ctx) {
  const { host, net, me, session, log } = ctx;
  let disposed = false;
  let rows = [];
  let unread = 0;
  let open = false;

  const box = el('div', 'cd');
  const fab = el('button', 'cd__fab');
  fab.type = 'button';
  fab.setAttribute('aria-expanded', 'false');
  fab.setAttribute('aria-label', '房内聊天增强（未读 0 条）');

  const badge = el('span', 'cd__badge');
  badge.hidden = true;
  fab.append(badge);

  const panel = el('section', 'cd__panel');
  panel.hidden = true;
  panel.setAttribute('aria-label', '房内聊天增强');

  const head = el('header', 'cd__head');
  const title = el('strong', null, '房内聊天');
  const hint = el('span', 'cd__hint', '未读 0');
  head.append(title, hint);

  const list = el('div', 'cd__list');
  list.setAttribute('role', 'log');
  list.setAttribute('aria-live', 'polite');
  list.setAttribute('aria-relevant', 'additions');

  const clearBtn = el('button', 'cd__clear', '清空本机记录');
  clearBtn.type = 'button';

  panel.append(head, list, clearBtn);
  box.append(fab, panel);
  host.append(box);

  // 位置：记住一个归一化比例（isomer 的 roomVoice 也是这个做法）。失败就忽略 —— 位置是锦上添花。
  let ratio = null;
  try {
    const saved = JSON.parse(localStorage.getItem('cd.position.v1') || 'null');
    if (saved && [saved.x, saved.y].every((n) => Number.isFinite(n) && n >= 0 && n <= 1)) ratio = saved;
  } catch { /* 隐私模式或坏 JSON：用缺省位置 */ }

  const layout = () => {
    const v = window.visualViewport;
    const w = (v && v.width) || window.innerWidth;
    const h = (v && v.height) || window.innerHeight;
    const sx = Math.max(0, w - 56);
    const sy = Math.max(0, h - 56);
    box.style.left = `${((v && v.offsetLeft) || 0) + 8 + (ratio ? ratio.x * sx : sx)}px`;
    box.style.top = `${((v && v.offsetTop) || 0) + 8 + (ratio ? ratio.y * sy : sy - 180)}px`;
  };
  layout();
  window.addEventListener('resize', layout);

  const syncBadge = () => {
    badge.hidden = unread === 0;
    badge.textContent = unread > 99 ? '99+' : String(unread);
    hint.textContent = `未读 ${unread}`;
    fab.setAttribute('aria-label', `房内聊天增强（未读 ${unread} 条）`);
  };

  const setOpen = (next) => {
    open = next;
    panel.hidden = !open;
    fab.setAttribute('aria-expanded', String(open));
    if (open) { unread = 0; syncBadge(); list.scrollTop = list.scrollHeight; }
  };

  /** 一条消息一行：房主徽章 + 我自己标记 + @高亮。只读渲染，不改原文。 */
  const renderRow = (m) => {
    const mine = myName(ctx) && m.name === myName(ctx);
    const row = el('div', 'cd__row' + (mine ? ' cd__row--mine' : ''));
    const who = el('span', 'cd__who');
    who.textContent = m.seat == null ? String(m.name || m.from || '?') : `${m.seat + 1}# ${m.name || m.from}`;
    if (OWNER_NAMES.has(String(m.name || ''))) who.append(el('span', 'cd__owner', '服主'));
    if (mine) who.append(el('span', 'cd__mine', '我'));
    const text = el('span', 'cd__text');
    const at = Number.isFinite(m.at) ? new Date(m.at) : null;
    text.title = at ? at.toLocaleTimeString() : '';
    // @ 高亮：切段渲染，不用 innerHTML（XSS 面归零）。
    const raw = String(m.text == null ? '' : m.text);
    let last = 0;
    for (const hit of raw.matchAll(MENTION_RE)) {
      if (hit.index > last) text.append(document.createTextNode(raw.slice(last, hit.index)));
      const mark = el('mark', 'cd__mention', hit[0]);
      text.append(mark);
      last = hit.index + hit[0].length;
    }
    if (last < raw.length) text.append(document.createTextNode(raw.slice(last)));
    row.append(who, text);
    return row;
  };

  const push = (m) => {
    if (!m || typeof m !== 'object') return;
    rows.push(m);
    if (rows.length > MAX_ROWS) rows.splice(0, rows.length - MAX_ROWS);
    list.append(renderRow(m));
    while (list.firstChild && list.childElementCount > MAX_ROWS) list.firstChild.remove();
    if (!open) { unread += 1; syncBadge(); }
    else list.scrollTop = list.scrollHeight;
  };

  const offChat = net.on('chat.msg', push);
  // 重连时引擎会把 history 单独发给这个会话：一并渲染，让刷新/重连的人看到之前那几条。
  const offHistory = net.on('chat.history', (m) => {
    const msgs = m && Array.isArray(m.messages) ? m.messages : [];
    for (const x of msgs) push(x);
  });

  fab.addEventListener('click', () => { setOpen(!open); rememberCollapsed(!open); });
  clearBtn.addEventListener('click', () => {
    rows = [];
    list.replaceChildren();
    unread = 0;
    syncBadge();
  });

  // 拖动：按住 fab 移动，松手记住比例。点击（没移动）仍由 click 处理开关。
  let drag = null;
  fab.addEventListener('pointerdown', (e) => {
    if (e.button != null && e.button !== 0) return;
    drag = { x: e.clientX, y: e.clientY, moved: false };
    fab.setPointerCapture(e.pointerId);
  });
  fab.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    if (!drag.moved && Math.abs(dx) + Math.abs(dy) < 4) return;
    drag.moved = true;
    const rect = box.getBoundingClientRect();
    const v = window.visualViewport;
    const w = (v && v.width) || window.innerWidth;
    const h = (v && v.height) || window.innerHeight;
    box.style.left = `${Math.min(Math.max(0, rect.left + dx), w - 56)}px`;
    box.style.top = `${Math.min(Math.max(0, rect.top + dy), h - 56)}px`;
    const sx = Math.max(1, w - 56), sy = Math.max(1, h - 56);
    ratio = { x: Math.min(1, Math.max(0, (rect.left + dx - 8) / sx)), y: Math.min(1, Math.max(0, (rect.top + dy - 8) / sy)) };
    drag.x = e.clientX; drag.y = e.clientY;
  });
  const endDrag = () => {
    if (!drag) return;
    const moved = drag.moved;
    drag = null;
    if (moved && ratio) { try { localStorage.setItem('cd.position.v1', JSON.stringify(ratio)); } catch { /* 记不住就算了 */ } }
  };
  fab.addEventListener('pointerup', endDrag);
  fab.addEventListener('pointercancel', endDrag);

  // 偏好口是面板唯一能写的东西（`ctx.session.setPref` / `getPref`）。这里只把「默认收起」这一个
  // 布尔量写进去，不写任何对局相关状态 —— 那本来就是这一格的设计意图（只收短标量）。
  let remembered = null;
  try { remembered = session.getPref('collapsed'); } catch { /* 老版本没有 getPref 时忽略 */ }
  setOpen(remembered !== true);

  // 关上面板时记住这个选择；展开则不写（缺省就是展开）。
  const rememberCollapsed = (collapsed) => {
    try { session.setPref('collapsed', collapsed); } catch { /* 写不进去不影响功能 */ }
  };

  syncBadge();
  log.info('chat-decor mounted');

  return () => {
    disposed = true;
    offChat();
    offHistory();
    window.removeEventListener('resize', layout);
    box.remove();
  };
}
