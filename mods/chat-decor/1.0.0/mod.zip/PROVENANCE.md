# 来源与署名（PROVENANCE）

## 原件叫什么、从哪来
- **服务器**：`https://wei.isomer319.xyz/`（卫戍协议：盟约 · 社区节点，app 0.2.5）
- **原件客户端**（三个模块）：
  - `_v024/js/ui/roomChat.js` —— 房内聊天 UI（16,093 B）
  - `_v024/js/ui/accounts.js` —— 账号头像与 #tag 美化（20,620 B）
  - `_v024/js/ui/ownerName.js` —— 房主徽章（659 B）
- **取证时间**：2026-10-13

## 原作者是谁
- 上游：`sganggs/Stronghold-Protocol`（GPL-3.0-or-later）
- isomer 节点维护者：目录站标注 **Wiš'adel**
- 打包：jingjiangze

## 原件的许可
GPL-3.0-or-later（随上游）。本包**不照抄其代码**，按工坊表面重写。

## 它改了什么（搬了哪些、没搬哪些，逐条列）

| isomer 的做法 | 本包 | 为什么 |
|---|---|---|
| 悬浮入口 + 未读计数 + 最近消息 | ✅ 搬 | 纯客户端渲染，引擎 `root.overlays` 浮层槽位承载 |
| 可拖动、位置记 localStorage | ✅ 搬 | 同上（另加 `ctx.session.setPref` 记「默认收起」） |
| 房主名单徽章（`ownerNames` 闭集合） | ✅ 搬 | 纯渲染 |
| 被 @ 的名字高亮 | ✅ 搬 | 纯渲染（切段渲染，不用 innerHTML） |
| `chat.history` 历史回填 | ✅ 搬（部分） | 引擎的 `chat.history` **只在重连 resync 时发给当前会话**，所以只有重连能补到；isomer 用服务端 `room.chatHistory` 补常规回填，**引擎 C2S 没有这个类型** |
| 账号头像与 `#tag` | ❌ 没搬 | 依赖 isomer 的 `/accounts/` 后端（注册 / 登录 / QQ 绑定 / 头像审核），引擎没有这个面 |
| 贴纸图片 | ❌ 没搬 | 属 `sticker-pack` 的职责（避免两个包重叠） |
| 弹幕（`roomDanmaku`） | ❌ 没搬 | 引擎无此面；且会遮挡战场 |
| 战场表情气泡（`showBattleSticker`） | ❌ 没搬 | 引擎已有原生 `m.emote` 气泡，重复 |

## 自带素材是哪来的
**无素材**。

## 已知不兼容 / 边界（必读）
1. **刷新页面历史即清空**。引擎的 `chat.history` 只在重连时发给当前会话且**永不落盘**，本面板从挂载时刻开始记，最多留 60 行（`MAX_ROWS`）。
2. **只读，不发任何消息**。`ctx.net.send` 一次都没调 —— 它不新增协议消息、不改聊天内容、不碰对局。
3. **房主名单是硬编码的**（`OWNER_NAMES`，默认沿用 isomer 的三个名字）。要改成你的服，编辑 `client/chatDecor.js` 顶部那一行。
4. 与引擎自带的房内聊天**并存**，不替代它：引擎那个照常工作，本面板只是旁路读数。
