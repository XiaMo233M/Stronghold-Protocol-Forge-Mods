// skin-catalogue/test/catalogue.test.mjs — 目录包的两个文件要一直满足管理器时装层的**闭集与形状**。
//
// 怎么跑：`node --test skin-catalogue/test/catalogue.test.mjs`（**不要求**把包放进引擎的 `workshop/` 下）。
// 判据不抄第二份：直接 import 引擎的 `shared/workshop.js`（`normalizePackManifest` / `SKIN_FIELDS` / `SKIN_ID_RE`），
// 所以「管理器换了规则、这个包不再合法」会在这里变红 —— 而不是等装载器在别人的服务器上点名拒绝。
//
// 【我方改写说明】原文件写死 `from '../../shared/workshop.js'`，那是「包位于引擎仓库的 `workshop/` 下」这一条
// 布局假设（与 skin-picker 的测试同一处毛病）：改写产物放在 `_up/mod-rewrites/时装/skin-catalogue/` 时它报
// ERR_MODULE_NOT_FOUND。现在按 `SP_ENGINE_ROOT` → 从本文件往上逐级 → 同级 `_engine/` / `engine/` 的顺序找引擎，
// 找不到就**明确 skip 并打印原因**；**判据一条没放松**（闭集与形状只有拿真引擎那一份才算数）。
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));

/** 找一个「根目录」，它下面 relative 指的那些文件都存在（都找到才算）。 */
function probe(candidates, relative) {
  for (const dir of candidates) {
    if (!dir) continue;
    const root = path.resolve(dir);
    if (relative.every((rel) => fs.existsSync(path.join(root, rel)))) return root;
  }
  return null;
}

function resolveEngineRoot() {
  const ancestors = [];
  for (let dir = HERE; ; ) {
    ancestors.push(dir);
    const up = path.dirname(dir);
    if (up === dir) break;
    dir = up;
  }
  const siblings = [];
  for (const dir of ancestors) {
    const base = path.dirname(dir);
    siblings.push(path.join(base, '_engine'), path.join(base, 'engine'));
  }
  return probe([
    process.env.SP_ENGINE_ROOT,
    ...ancestors,
    ...siblings,
  ], [path.join('shared', 'workshop.js')]);
}

const ENGINE_ROOT = resolveEngineRoot();
let normalizePackManifest = null;
let SKIN_FIELDS = null;
let SKIN_ID_RE = null;
let engineSkipReason = '';

if (ENGINE_ROOT) {
  // pathToFileURL：Windows 绝对路径直接 import 会被当成协议名
  ({ normalizePackManifest, SKIN_FIELDS, SKIN_ID_RE } =
    await import(pathToFileURL(path.join(ENGINE_ROOT, 'shared', 'workshop.js')).href));
  if (typeof normalizePackManifest !== 'function' || !Array.isArray(SKIN_FIELDS)) {
    engineSkipReason = `引擎模块 ${ENGINE_ROOT}/shared/workshop.js 没有导出 normalizePackManifest / SKIN_FIELDS`;
    normalizePackManifest = null;
  }
} else {
  engineSkipReason = `找不到引擎的 shared/workshop.js（试过 SP_ENGINE_ROOT=${process.env.SP_ENGINE_ROOT || '<未设置>'}，并从 ${HERE} 往上逐级探过）`;
}

/** 每一条的前置：只在真引擎就位时跑；否则点名 skip（不抄一份假判据代替）。 */
function needEngine(t) {
  if (normalizePackManifest) return true;
  console.error(`[skin-catalogue/test] SKIP：${engineSkipReason}；设 SP_ENGINE_ROOT=<引擎仓库根> 再跑（判据不放松）`);
  if (t && typeof t.skip === 'function') t.skip(`需要引擎的形状层：${engineSkipReason}`);
  return false;
}

const PACK_DIR = path.resolve(HERE, '..');
const pack = JSON.parse(fs.readFileSync(path.join(PACK_DIR, 'pack.json'), 'utf8'));
const sources = JSON.parse(fs.readFileSync(path.join(PACK_DIR, 'sources.json'), 'utf8'));

test('pack.json 过管理器的形状层（含时装闭集），且只带时装也算贡献项', (t) => {
  if (!needEngine(t)) return;
  const res = normalizePackManifest(pack, 'skin-catalogue', { hasAssets: false });
  assert.equal(res.ok, true, res.ok ? '' : `${res.error}: ${res.detail}`);
  assert.equal(res.pack.skins.length, pack.skins.length);
  assert.equal(res.pack.id, 'skin-catalogue');
});

test('条目字段是闭集、id 合规、干员/名称齐全、id 唯一', (t) => {
  if (!needEngine(t)) return;
  assert.ok(pack.skins.length > 0);
  const seen = new Set();
  for (const [i, skin] of pack.skins.entries()) {
    for (const key of Object.keys(skin)) {
      assert.ok(SKIN_FIELDS.includes(key), `skins[${i}] 多了一个字段 "${key}"`);
    }
    assert.match(skin.id, SKIN_ID_RE, `skins[${i}].id "${skin.id}" 超出管理器上限（≤32）`);
    assert.ok(skin.id.length <= 32);
    assert.match(skin.charId, /^[A-Za-z0-9_.:-]{1,64}$/, `skins[${i}].charId`);
    assert.ok(typeof skin.name === 'string' && skin.name.trim(), `skins[${i}].name`);
    if (skin.series !== undefined) assert.ok(typeof skin.series === 'string' && skin.series.trim());
    assert.equal(seen.has(skin.id), false, `id 重复：${skin.id}`);
    seen.add(skin.id);
  }
});

test('目录规模是钉住的（fork 快照 2026-10-10：172 干员 / 271 套；更新时改这一行）', () => {
  assert.equal(pack.skins.length, 271);
  assert.equal(new Set(pack.skins.map((s) => s.charId)).size, 172);
});

test('sources.json 与条目一一对应，且带导入工具需要的 charName / wikiIndex', () => {
  const ids = pack.skins.map((s) => s.id).sort();
  assert.deepEqual(Object.keys(sources).sort(), ids, '来源表与目录必须一一对应');
  for (const [id, row] of Object.entries(sources)) {
    assert.ok(typeof row.charName === 'string' && row.charName.trim(), `${id}.charName`);
    assert.ok(Number.isInteger(row.wikiIndex) && row.wikiIndex >= 1, `${id}.wikiIndex`);
  }
  // 归一化过的 id 必须留下 forkId（溯源；这次的 17 条音律联觉）
  const renamed = Object.entries(sources).filter(([, row]) => row.forkId);
  assert.ok(renamed.length >= 17, `重命名条目应当带 forkId，实际 ${renamed.length}`);
  for (const [id, row] of renamed) assert.notEqual(id, row.forkId);
});
