# 署名与来源 · PROVENANCE

> 本文件由**交付流程**在拆包时生成，随包分发。原作者与改写者**分开显示，不抹掉任何一方**。
> 原件未署名的一律写**「原件未署名」**，不代填名字；许可**照实抄**，包括非 SPDX 的值。

## 包

| 项 | 值 |
|---|---|
| 包 id | `skin-catalogue` |
| 版本 | `1.0.0` |
| 名称 | 时装目录（皮肤数据） |
| 目录名 = 包 id | 是（引擎逐包判 `PACK_ID_MISMATCH`，不一致会被拒） |
| 本包实测规模 | 9 个文件 / 6878374 字节（不含本文件） |

## 原作者 / 上游

**jingjiangze** —— 原件 `pack.json.author` 原文，照实抄录。

- 上游：皮肤数据包（时装目录）

## 许可（照实抄）

原件 `pack.json.license` 原文，逐字抄录：

```
代码 GPL-3.0-or-later；时装美术 © Hypergryph / Yostar，仅个人非商业使用，随包再分发由其分发者承担
```

## 责任人

| 角色 | 是谁 |
|---|---|
| 原作者 | jingjiangze |
| 本版兼容改写者 | Mo233（工坊包通道改写 / 按中间层重写；本包具体改写点见下节） |
| 本包交付 | 第三方 mod 兼容交付流程，2026-10-11 |

## 来源

- 原件：E:\destop\mod\381205b5e0db-时装目录（皮肤数据）.zip
- 交付形态：工坊包（workshop pack）· 包契约 **MOD_API_VERSION 1**（据此判能否装载）· 打包时工作树 `3396438a` 的 APP_VERSION 为 0.14.0（该号只表示发行版，不参与包兼容判定；交付后 HEAD 已推进到 `d46cfdaa` / APP_VERSION 0.15.0，MOD_API_VERSION 仍为 1，本轮已在该 HEAD 上复测通过）

## 改了什么

- 原件**装不上**的原因：原件的 `pack.json` 在**压缩包根目录**，不是工坊包要的 `<包id>/pack.json` 形状 ⇒ 装载器把 `assets/` 与 `test/` 当包读，报两条 `pack.json is missing`（实测）。
- 改写：归位为 `skin-catalogue/` 目录；`pack.json` 新增 `"api": ">=1 <2"`；`README.md` 改写。
- **包数据一处未改**：`assets/` 与 `sources.json` 与原件**逐字节一致**（271 套时装、172 名干员）。

## 自带素材来源

- 是，4 张 PNG（`char_103_angel_wild_1` 的 avatar + portrait、`char_1033_swire2_ambSyn_4` 的 avatar + portrait）；其余 271 条**只有元数据、没有图**。
- 素材来源：包内 `sources.json` **逐条记录出处**（Hypergryph / Yostar 官方素材）。

## 备注 / 边界

- 本包与 `skin-picker` 是一对：本包提供时装元数据与 2 套图，`skin-picker` 提供换装界面与解析链。**两个都要装**换装才真的生效。

## 包内其它署名 / 来源文件

- `README.md`（含「许可与再分发」与「我方改写说明」两节）
- `sources.json`（271 条时装的来源元数据，逐条记录出处）

## 校验

- 本包**单独**装载于干净的 workshop 根（根内只有这一个包）：见交付索引 `../../INDEX.md` 的 8 条原始输出。
- 校验器：`node tools/workshop-validate.mjs`；装载器：`server/workshop.js loadWorkshop`。

---

*English summary: this pack is a compatibility conversion delivered for Mo233. The original
author and the compatibility rewriter are listed separately above; where the original was uncredited it is
stated as "原件未署名 (uncredited original)" rather than being invented. The licence text is copied verbatim
from the original. See the Chinese sections above for the exact source, the list of changes, and the origin
of any bundled assets.*
