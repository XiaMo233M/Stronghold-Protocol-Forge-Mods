# skin-catalogue · 时装目录（皮肤数据）

**皮**（数据那一半）：把 Stardust fork 的时装目录（`shared/skin-catalogue.js`，2026-10-10 快照：**172 名干员 /
271 套**）翻成管理器的 `pack.json.skins` 声明 —— `{ id, charId, name, series }`。

## 下载

- 工坊 mod 站（投稿 / 已上线列表）：`http://47.103.14.217:25570/`（列表在 [`/mods`](http://47.103.14.217:25570/mods)）
- 源码：`https://github.com/jingjiangze/Stronghold-Protocol-Forge`（分支 `feat/stardust-mods`）

- **不含美术**（版权属鹰角 / Yostar）。`art`（头像 / 立绘 PNG）由导入工具按需落到本包的 `assets/`（git-ignored）：
  ```bash
  node stardust-tools/import-skins.mjs --pack skin-catalogue --dry-run --limit 3   # 先看要取什么
  node stardust-tools/import-skins.mjs --pack skin-catalogue --only char_103_angel_wild_1
  node stardust-tools/import-skins.mjs --pack skin-catalogue                       # 全量（较慢：每人两次请求 + 两张图）
  ```
  导入成功后 pack.json 对应的条目会得到 `art`（如 `skins/<id>/avatar.png`），`node tools/workshop-pack.mjs export skin-catalogue`
  导出的 zip 就带素材，可以直接给别人的服装。
- `sources.json` 是**来源元数据**（`id → { charName, wikiIndex, officialId?, forkId? }`）：导入工具用它拼 PRTS 的页面标题。
  归一化过的 id（fork 里超 32 字符的那 17 套「音律联觉」）保留 `forkId` 溯源。
- 目录由 `stardust-tools/build-catalogue.mjs` 从 fork 生成（`--check` 比对；重生成会**保留已导入的 art**）。

## 安装

与 [skin-picker](../skin-picker/README.md)（行为）一起装：只有数据、没有行为时不会被渲染；只有行为、没有数据时
面板显示空态提示。

```bash
node tools/workshop-pack.mjs import "时装目录（皮肤数据）.zip"
```

## 许可与再分发

- 代码 / 目录元数据：GPL-3.0-or-later。
- 时装美术（导入进 `assets/` 的部分）：© Hypergryph / Yostar，**仅供个人非商业使用**；导入的文件默认 git-ignored，
  是否随包分发由分发者自己承担（管理器要求有 `assets/` 的包声明 `license` —— 本包的 `license` 字段已如实写明）。

## 验收

```bash
node --test skin-catalogue/test/catalogue.test.mjs    # 4 条：过管理器形状层（含时装闭集）/ 字段与 id / 规模钉死 / 来源表一一对应
node tools/workshop-validate.mjs --workshop <装好的根>
```

跑测试时给引擎根目录（下面「我方改写说明」第 2 条解释了为什么现在需要它）：

```powershell
$env:SP_ENGINE_ROOT = "<引擎仓库根>"; node --test skin-catalogue/test/catalogue.test.mjs
```

---

## 我方改写说明（Stronghold-Protocol 引擎维护方，2026-10）

**包内容本身不需要改，实际也一条数据没改**：`pack.json`、`sources.json` 与 `assets/` 与原投稿逐字节一致
（271 套、172 名干员）。原作者：`jingjiangze`；许可仍是「代码 / 元数据 GPL-3.0-or-later；时装美术 © Hypergryph /
Yostar，仅个人非商业使用」。本仓库的实测：`workshop-validate` 判 **VALID**（0 error / 0 warning），
装载后 **271 套真的落进 `assets.skins`，覆盖 172 个 charId，其中只有 2 套带 `art`**。

**「271 套里 269 套没有图」这件事，如实写在这里（不伪造图、不删条目）：**
本包是**元数据目录**：每条只有 `{ id, charId, name, series }`，`art` 要靠作者自己的导入工具
（`stardust-tools/import-skins.mjs`，见上文「下载」一节）把 PNG 落到本包 `assets/skins/<id>/` 之后才会出现。
目前只有 2 套带上：`char_103_angel_wild_1`（野地秘行）与 `char_1033_swire2_ambSyn_4`。
**其余 269 套在没有导入美术之前，装上后是"有名字、没图"的状态**：换装面板会列出它们（列表项退回首字图标），
选中它们**不会改变画面**（提供者按契约返回 `null`，链回落原版）——这是如实行为，不是 bug。
**要显示需要作者用他的导入工具补 `art`**；版权原因（美术属鹰角 / Yostar）维护方不会代劳，也不会删除缺图的条目
（业主明确要求不删东西）。

1. **包数据一处未改**：确实不需要 —— 已实测 `assets.skins` 落地（见上）。
2. **`test/catalogue.test.mjs` 不再假设仓库布局。** 原文件写死 `from '../../shared/workshop.js'`，
   那是「包位于引擎仓库的 `workshop/` 下」这一条假设：把包放到别处（例如本仓库外的 `_up/mod-rewrites/时装/`）
   就报 `ERR_MODULE_NOT_FOUND`。现在按 `SP_ENGINE_ROOT` 环境变量 → 从测试文件往上逐级探 → 同级
   `_engine/`、`engine/` 的顺序找引擎；找不到就**明确 skip 并打印原因**。**判据没放松**：闭集与形状仍然只认
   引擎那份 `normalizePackManifest` / `SKIN_FIELDS` / `SKIN_ID_RE`（抄一份假判据自证清白才是真的削弱）。
   包**运行时**不 import 引擎任何东西，所以这一条只影响作者侧测试。
