# NOTICE · 来源说明

> 本文件由第三方 mod 兼容交付流程生成，随包分发，用于如实说明本包的来源与边界。
> **原件不带 README**，所以本包不设 `NOTICE-原件-README.md`（没有可逐字复制的原文）。
> 下列文字取自**投稿人在站点投稿正文（`note`）里的原话**与原件 `pack.json` 字段，逐字引用、不改写。

## 原件

| 项 | 值 |
|---|---|
| 站点记录 id | `6a40ac64cc61` |
| 原件 sha256 | `11b0b8bb517c9a9635f38a29fbf87900287bef46d20235aff7c3ec71e44ce007` |
| 上传时间 | `2026-10-11T17:39:52.563Z` |
| 上传来源 ip | `119.181.30.24` |
| 原件 `pack.json.id` | `duel-fighter` |
| 原件 `pack.json.author` | `jingjiangze` |
| 原件 `pack.json.license` | `AGPL-3.0-or-later`（照实抄，未独立核对上游 LICENSE） |

- 作者声明的上游：**争锋频道 Duel-Channel（非官方同人复刻）** <https://github.com/Cloudnyco/Duel-Channel>
- 作者声明的取用点：`main@4d3b33be6c08b9c93e0c847b69e70e8bffbd2b77`（2026-10-11 的 304 文件树）
- 作者声明：原作者为 **Duel Channel contributors**；投稿人 `jingjiangze` 只做**拆分与搬运**，不宣称对原件的原创权
- ⚠️ 上述上游事实**来自作者投稿正文（`note`）的声明**。本次交付**无法联网核对**该仓库与 commit；**未**独立验证，
  也**没有**代填任何作者名字。

## 投稿人自述（逐字引用，来自站点投稿正文）

作者原话：「把 `data/fighters.json`（128,455 字符、纯数据：敌人条目 / 名称 / 描述 / 属性引用）原样搬进包内，挂成 `/duel/fighters.json`。
已核对：文件内不含 base64、不含 .png/.jpg/.webp 引用 —— 只有 id 与文字。」
本次交付**独立复核**了这一点：全包扫描 `.png|.jpg|.jpeg|.webp|.gif|.skel|.atlas|.mp3|.ogg|.wav` 与 `data:*;base64` —— **零命中**。
原件**不带 README**，故本包不设 `NOTICE-原件-README.md`。

## 红线声明

- 本包**不含任何游戏美术字节**（无 `.png/.jpg/.webp/.skel/.atlas/.mp3/.ogg/.wav`、无 base64 素材）。
- 本包**不改任何官方 `data/*.json` 数值**（包内 `data/` 是 Duel 自己的资料表，不是引擎的官方数值表）。
- 本包**未声明 `combat`**：它不改变对局结果（引擎里没有任何代码去读这些 URL / 渲染威胁对局）。
- 本包**不含安装脚本**（无 `install.mjs` / `.bat` / `.cmd` / `.exe` / `payload/`）。
