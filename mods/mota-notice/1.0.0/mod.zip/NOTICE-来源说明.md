# NOTICE · 来源说明

> 本文件随包分发，用于如实说明本包的来源与边界。
> 本包为**新作**（不是改件），不存在被搬运的「原件」，所以不设「原件 README 逐字复制」一节。
> 下列内容取自 `pack.json` 字段与本包的公开来源，逐条可核。

## 本包

| 项 | 值 |
|---|---|
| 包名 | 魔塔公告 |
| `pack.json.id` | `mota-notice` |
| `pack.json.author` | `jingjiangze` |
| `pack.json.license` | `AGPL-3.0-or-later` |
| 性质 | 新作 · 纯数据包（零素材、零代码） |

## 内容来源（逐条可核）

| 事实 | 来源 |
|---|---|
| 本仓指向哪一台 | <https://github.com/jingjiangze/stronghold-server> |
| 公网入口 | `https://jingjiangze-stronghold-protocol.ms.show` |
| 创空间主页 | <https://www.modelscope.cn/studios/jingjiangze/Stronghold-Protocol> |
| 入口页 | <https://arknights.jiangjiangze.icu> |
| 公告面契约 | Forge `docs/WORKSHOP.md` §1.13、`docs/design/mod-layer.md` §28.15 |

同源的网页版：`https://arknights.jiangjiangze.icu`（入口页）与
`sp-mota-notice/site/index.html`（最小网站）。三处内容同源，改一处需同步另外两处。

## 边界

- 本包只送公告与鸣谢两份 `.json`，不注册消息、不起进程、不碰 WebSocket、不带干员、不带素材、
  不改任何对局数值；装与不装都不影响一局的胜负与掉线。
- **这台服务器当前不装载工坊包**：`stronghold-server/shared/packs.js` 的
  `workshop = { status: 'supported', live: false }`。这是服务器侧开关。
- 别的服务器（国际站 / 长沙站 / 济南站）不是本仓指向的这一台；本包不代它们披露任何状态。

## 许可

代码与文档 `AGPL-3.0-or-later`（随 Forge 工坊包契约）。公告内容均为公开事实，不含任何游戏官方素材。
