# 署名与来源 · PROVENANCE

> 本文件随包分发。原作者与本版整理者**分开显示，不抹掉任何一方**。
> 本包是**新作**（不是改件），所以不存在「原件」；下面如实写明作者、许可与内容来源。

## 一、作者

**jingjiangze**（`pack.json` 的 `author` 字段，如实照抄）。

本包由作者**原创**：它不复刻任何第三方项目的代码或文案，只是把一条公开事实
（`jingjiangze/stronghold-server` 部署线当前指向哪一台服务器）整理成工坊包能送的公告面。

## 二、许可（照实抄）

`pack.json` 声明 `AGPL-3.0-or-later`，与 Forge 工坊包工作树一致，本包未改该字段。

## 三、整理与交付

| 角色 | 是谁 |
|---|---|
| 原作者 | jingjiangze |
| 本包交付 | 第三方 mod 兼容交付流程，2026-10-12 |

## 四、来源

| 项 | 值 |
|---|---|
| 站点 | sp-modsite（`http://47.103.14.217:25570/`）投稿 |
| 投稿包名 | 魔塔公告 |
| 包 id | `mota-notice` |
| 同源网页 | `https://arknights.jiangjiangze.icu` |

**内容来源都是公开事实**，逐条可核：

- 仓库与部署线：<https://github.com/jingjiangze/stronghold-server>
- 公网入口：`https://jingjiangze-stronghold-protocol.ms.show`（ModelScope 创空间）
- 创空间主页：`https://www.modelscope.cn/studios/jingjiangze/Stronghold-Protocol`
- 入口页：`https://arknights.jiangjiangze.icu`
- 契约出处：Forge `docs/WORKSHOP.md` §1.13 与 `docs/design/mod-layer.md` §28.15

## 五、改了什么

新作，无「原件」可改。包内只有四个文件，全部为本包原创内容：

```
pack.json               # 身份 + notices 声明
notice/announcement.json
notice/credits.json
PROVENANCE.md           # 本文件
```

**未包含任何游戏官方素材**（无图片 / 音频 / Spine / 字体 / 数值表），也没有任何 `.js` 代码 ——
workshop 包的 `routes` 只发 `.json`，`.js` / `.html` 一律拒绝，所以本包在设计上就只可能是纯数据。

## 六、自带素材

**无**。独立复核：全包零命中美术扩展名、零 base64 内联、零 `.js`。

## 校验

- 官方校验器单独装载：`node tools/workshop-validate.mjs --workshop <root>`
  （根内只有这一个包）→ **0 error(s), 0 warning(s)，VALID**。
- 引擎版本：Stronghold-Protocol `0.15.x`，`MOD_API_VERSION` 1（`pack.json` 的 `api: ">=1 <2"`）。
- 数值一个字节未改：本包不含任何 `data/*.json` 官方数值改写，未声明 `combat`（不改对局结果）。

## 七、边界（照实说）

- `stronghold-server` 的 `shared/packs.js` 里 `workshop = { status: 'supported', live: false }`：
  格式被认、能被列出，但**当前不会被装载**。这是服务器侧开关，不是本包写错。
- 公告正文静态：workshop 包的 notices 是装载期读进来的 `.json`，包不 fetch 任何 URL，
  换公告内容 = 换一份包。动态公告要走服务器侧的 `SP_ANNOUNCEMENTS_URL`（已实现未部署）。
- 公告正文尚无多语，未接入 `i18n` 通道。
