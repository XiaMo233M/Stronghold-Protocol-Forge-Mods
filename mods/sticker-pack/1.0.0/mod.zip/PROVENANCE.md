# 来源与署名（PROVENANCE）

## 原件叫什么、从哪来
- **服务器**：`https://wei.isomer319.xyz/` 与 `https://sp.isomer319.xyz/`（卫戍协议：盟约 · 社区节点）
- **原件清单位置**：`https://wei.isomer319.xyz/community-emotes/manifest.json`（**注意：不在 `_v024/` 子路径下**，在根）
- **原件客户端**：`_v024/js/ui/communityChat.js`（`stickerManifest` / `mountStickerPicker` / `stickerImage`）
- **取证时间**：2026-10-13；清单 62 条（14 gif / 46 jpg / 2 png）

## 原作者是谁
- 上游：`sganggs/Stronghold-Protocol`（GPL-3.0-or-later）
- isomer 节点维护者：目录站标注 **Wiš'adel** / **凑鹈鹕**
- 贴纸图片的作者：**未署名**（manifest 里只有 id / 文件名，无作者字段）
- 打包：jingjiangze

## 原件的许可
GPL-3.0-or-later（清单结构与字段来自 isomer 客户端）。**贴纸图片版权归各原作者**，本包**不含图片字节**，也**不再分发**图片。

## 它改了什么
| 项 | isomer 原件 | 本包 |
|---|---|---|
| 清单字段 | `id` / `name` / `file` / `preview` / `cdnFile` / `cdnPreview` | **只留 `id` / `name` / `file` / `preview`** |
| `cdnFile` / `cdnPreview` | 指向 `weishucdn.jiangjiangze.icu` | **删掉** —— 本包不绑定第三方域名 |
| 传输 | `/community-chat/send`（HTTP + `community.auth` ticket） | `pack.msg` 自家通道（引擎原生，同房同包客户端互收） |
| 面板形态 | `mountStickerPicker` 挂进它的房内聊天 UI | 独立面板挂 `screen.game.aside` |

## 自带素材是哪来的
**无素材**（用户明确要求）。清单只带文件名，图片要另行放到 `<包>/assets/stickers/<file>`。

## 已知不兼容 / 边界（必读）
1. **不跨节点**。isomer 的贴纸靠 `/community-chat/send` 在两个游戏节点之间互通；本包走 `pack.msg`，**只在同一个房间内、且双方都装了本包**的客户端之间广播。这是引擎包格式的能力边界，不是缺陷。
2. **没有图片就只有一个占位小块**。清单能读、按钮能点、广播能发，但看不到图 —— 图要自己放（见 README）。
3. **跨服聊天里不会出现**。本包只在面板里显示「同房玩家发了贴纸：<名称>」，不往引擎的房内聊天窗口插行 —— 那是另一个包（`chat-decor`）的职责，两者不重叠。
4. `pack.msg` 的载荷有大小上限（引擎 `PACK_MSG_LIMITS`）；本包每条只发 `{ id }`，远在下限内。
