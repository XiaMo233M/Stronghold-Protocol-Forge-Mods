// 卫戍协议：盟约 · 房间贴纸面板（逆向自 isomer 社区节点的 /community-emotes/）
//
// 出身：wei.isomer319.xyz 与 sp.isomer319.xyz 的 `_v024/js/ui/communityChat.js` 有一套贴纸选择器
// （stickerManifest / mountStickerPicker / stickerImage）。本面板按引擎的工坊表面重写同一件事：
// 清单一走包内只读路由，图片走引擎的 workshop-assets 通道，广播走 pack.msg。
//
// 它做三件事，一件不多：
//   1. 从包内的只读路由读清单（`/mod/sticker-pack/stickers.json`），渲染成格子；
//   2. 点一格 → `ctx.net.send('sticker', { id })` —— 引擎把这条不透明载荷转给同房、装了本包、
//      声明了这条通道的客户端（`pack.msg`，docs/WORKSHOP.md §1.9.6）；
//   3. 收到别人的 `sticker` → 在状态行报一句可读的话，不弹窗、不抢焦点。
//
// **它不自己画聊天窗口**：引擎的 `room.chat` / `chat.msg` 才是房内聊天，本面板只是它的一个贴纸来源。
// 这与 isomer 的做法一致（它的 roomChat 复用引擎原生 room.chat，贴纸是额外一层）。
//
// **图片不在这个包里**：清单只带文件名。要看到图，把图片放到 `<包>/assets/stickers/<file>`，
// 面板会优先就地取 `/workshop-assets/sticker-pack/stickers/<file>`，取不到才显示 id 占位。
// 这是「不包含素材」那条约束的直接结果 —— 详见 README 的「装完之后还要做什么」。

// 不 import 引擎任何内部模块：工坊面板在浏览器里按 URL 单独加载，依赖越少越不会因为引擎
// 内部文件搬家而整块挂不上。这里只用原生 DOM。
const el = (tag, cls, text) => {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text != null) node.textContent = text;
  return node;
};

const LIST_URL = '/mod/sticker-pack/stickers.json';
const ASSET_BASE = '/workshop-assets/sticker-pack/stickers/';

/** 名字旁边那枚小图：就地取，取不到就退成 id 占位（不显示破图）。 */
function thumb(sticker) {
  const img = el('img');
  img.className = 'stp__thumb';
  img.alt = sticker.name || sticker.id;
  img.loading = 'lazy';
  img.decoding = 'async';
  img.referrerPolicy = 'no-origin';
  const local = ASSET_BASE + sticker.file;
  img.addEventListener('error', () => {
    if (img.dataset.fallback) { img.replaceWith(el('span')); return; }
    img.dataset.fallback = '1';
    img.removeAttribute('src');
    img.className = 'stp__thumb stp__thumb--missing';
    img.alt = sticker.id;
  });
  img.src = local;
  return img;
}

export function mount(ctx) {
  const { host, net, log } = ctx;
  let stickers = [];
  let disposed = false;

  const box = el('div');
  box.className = 'stp';

  const head = el('div');
  head.className = 'stp__head';
  const title = el('strong');
  title.textContent = '房间贴纸';
  const hint = el('span');
  hint.className = 'stp__hint';
  hint.textContent = '读取中…';
  head.append(title, hint);

  const grid = el('div');
  grid.className = 'stp__grid';
  grid.setAttribute('role', 'group');
  grid.setAttribute('aria-label', '房间贴纸');

  const status = el('p');
  status.className = 'stp__status';
  status.setAttribute('role', 'status');
  status.setAttribute('aria-live', 'polite');

  box.append(head, grid, status);
  host.append(box);

  // 收别人的贴纸：只报一句可读的话，不弹窗、不抢焦点。
  const offMsg = net.on('sticker', (data) => {
    if (!data || typeof data.id !== 'string') return;
    const hit = stickers.find((s) => s.id === data.id);
    status.textContent = `同房玩家发了贴纸：${hit ? hit.name : data.id}`;
  });

  fetch(LIST_URL, { cache: 'no-cache' })
    .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`))))
    .then((doc) => {
      if (disposed) return;
      stickers = Array.isArray(doc && doc.stickers) ? doc.stickers : [];
      hint.textContent = `${stickers.length} 枚`;
      for (const s of stickers) {
        const cell = el('button');
        cell.type = 'button';
        cell.className = 'stp__cell';
        cell.title = s.name || s.id;
        cell.setAttribute('aria-label', s.name || s.id);
        cell.append(thumb(s));
        cell.addEventListener('click', () => {
          const ok = net.send('sticker', { id: s.id });
          status.textContent = ok ? `已发送：${s.name || s.id}` : '发送失败（不在房间或未连接）';
        });
        grid.append(cell);
      }
      if (!stickers.length) hint.textContent = '清单为空';
    })
    .catch((err) => {
      if (disposed) return;
      hint.textContent = '不可用';
      log.warn('sticker list unavailable', err && err.message ? err.message : String(err));
      status.textContent = '贴纸清单读取失败（路由未注册或未装载本包）';
    });

  return () => {
    disposed = true;
    offMsg();
    box.remove();
  };
}
