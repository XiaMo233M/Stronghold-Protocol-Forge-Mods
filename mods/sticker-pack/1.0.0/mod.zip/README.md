# 房间贴纸包（62 枚社区表情清单）

把 isomer 社区节点那 62 枚房间贴纸的清单搬进工坊包。

## 装上之后
- `GET /mod/sticker-pack/stickers.json` 可读（只读 JSON 路由）
- 对局界面侧边多一个「房间贴纸」格子面板
- 点一格 → 同房装了本包的人收到一条广播，面板状态行显示「同房玩家发了贴纸：<名称>」

## 装完之后还要做什么（要看到图）
清单只带文件名，**本包不含图片字节**。要看到图：

1. 建目录 `<包>/assets/stickers/`
2. 把图片按清单里的 `file` 字段命名放进去（如 `f76a6ff2dcc515ecf15c.gif`）
3. 重启 / 重载 —— 面板会优先就地取 `/workshop-assets/sticker-pack/stickers/<file>`
4. 取不到就显示一个中性占位小块（不显示破图）

图片版权归各原作者，本包不再分发。

## 不兼容 / 边界（重要）
- **只在同一房间内广播**（引擎 `pack.msg` 的能力边界），**不跨节点** —— isomer 原版靠 `/community-chat/send` 跨两个游戏节点互通，那需要服务端 `community.auth` 网关，引擎没有这个面
- 不往引擎的房内聊天窗口插行（那是 `chat-decor` 的职责）
- 来源与许可见 `PROVENANCE.md`
