# PROVENANCE — 本站收件的改写留档（故事集 / side-story）

本文件由站点维护者写入，用于如实记录**这一版与作者原稿的差异**。原件文件一个字节都没有删除，
作者的原始投稿在站点上仍完整保留。

## 1. 改了什么

**只改一处：删掉 `client.panels[]` 里两处 `wraps` 条目。**

| 项 | 值 |
|---|---|
| 包 id | `side-story` |
| 版本 | `1.1.0`（未改动） |
| 作者原稿 `pack.json` sha256 | `02fab6f969b6614c977ee536d997ead429adc9e85e653ff88d6f4f6ebb05b73b`（2,787 字节） |
| 改写后 `pack.json` sha256 | `0086b2e678ccf39c63831a15ba344334b8d57fcc493a70a7e8ab970bf7edbac6`（2,522 字节） |
| 包内其余 8 个文件 | **一个字节都没有改动**（同一份文件清单，逐文件 sha256 相同） |

逐条列出被移除的声明：

- `client.panels["briefing"].wraps` → `briefing.bonds`（`mode: "replace"`）、`briefing.banned`（`mode: "wrap"`）
- `client.panels["sweep"].wraps` → `sweep.bonds`（`mode: "replace"`）

**保留下来的**：`client.panels["story"].wraps` → `game.bondStrip`（引擎合法组件）；三个面板本体
（`story` / `briefing` / `sweep`）以及它们的 `slot` / `module` / `styles` / `data` **一字未动**；
`server.battle`（`battle/main.mjs`）、`notices`（`notice/announcement.json`）、三个 `ui/*.js`
与 `ui/badge.css` **一字未动**。

## 2. 为什么删

引擎的「可改写组件」是**闭枚举**：`shared/workshop.js` 的 `CLIENT_WRAP_COMPONENTS` 今天只有四个 ——
`game.bondStrip` / `game.hud.topBar` / `game.shopCard` / `loadout.detail`。作者写的
`briefing.bonds` / `briefing.banned` / `sweep.bonds` 不在其中 ⇒ 装载器按
`CLIENT_WRAP_UNKNOWN_COMPONENT` **点名拒收整包**（改写前实测 `errors = 1`，第 2、3 层因此根本没跑到）。

这三条**不是某个合法组件的错名**：引擎里不存在「简报分区」与「S.W.E.E.P. 盟约报告」这两个可改写组件，
所以本站**不做任何映射** —— 把一个未知组件名改写成 `game.bondStrip` 之类是**猜语义**，
写下去只会得到一条「声明了、没人读」的静默失效，正是这一层到处在拒绝的形态。

## 3. 语义有没有变

**变了，如实说明。** 作者原意在包自述里写明：② 改写 `game.bondStrip` 给故事集圆盘打金环徽标；
③ 改写 `briefing.bonds` / `briefing.banned` 在简报里新开两栏；⑦ 改写 `sweep.bonds`
在 S.W.E.E.P. 报告里新开一栏。

- 第 ② 项**保留**（`game.bondStrip` 在闭枚举内）。
- 第 ③、⑦ 项**不再生效**：这三处界面不再被本包改写。
- 服务端的故事集运行时（`server.battle`，`battle/main.mjs`）**完全不受影响**。

一句话：**本包仍然会生效，但少了两处界面改写。**

## 4. 本站改写版的校验结果

`node tools/workshop-validate.mjs`（引擎仓库，三层判据：包格式 → 记录语义 → 真引擎装载）：

- 改写前：`errors = 1`，唯一一条是 `CLIENT_WRAP_UNKNOWN_COMPONENT`。
- 改写后：`errors = 0`，`warnings = 0`（`VALID: the engine accepts this content.`）。

## 5. 素材与版权

包内素材清点：**1 个 PNG**（`assets/icon_story.png`，26,222 字节）。原稿未声明该素材的来源与授权，
本站如实照录、不以任何方式主张其权利。原作者标注许可为 `GPL-3.0-or-later`。

若包内素材涉及《明日方舟》官方素材，版权归上海鹰角网络科技有限公司 / Yostar 及其授权方所有；
仅供非商业的学习与个人娱乐使用，请勿用于任何商业场景。
