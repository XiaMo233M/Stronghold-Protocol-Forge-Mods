# ausevaywstr 棋子扩充（8 名干员）

把 ausevaywstr.top（`https://ausevaywstr.top/`，app 0.2.1）`data/chess.json` 里引擎没有、且无冲突的 **8 条**棋子记录搬过来（chess_bellone_* / chess_chen3_* / chess_hsgma2_* / chess_wang_*）。

## 实测
抽样上场成功，技能名正确：贝洛内「家主的余裕」、陈、灰毫、望。

## 不兼容 / 边界
- **⚠️ 会影响对局结果**，包已标 `combat: true`
- **不含素材**：图标/立绘/Spine 需另行配置，界面显示占位
- **kit 覆盖部分**：charId 命中引擎 kit 注册表的正常复用引擎技能；未命中的落通用 kit（效果简化）
- 与已上传的 `clemntia-chess` / `s8-chess-extras` 及他服零 id 冲突（逐条核验）
- 来源与许可见 `PROVENANCE.md`
