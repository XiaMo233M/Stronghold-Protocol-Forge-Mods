# PROVENANCE — 兼容改写说明（`stripDiyOverlaps` → `behaviour.diyPoolOverlap`）

本文件由**兼容改写者**添加。**包内原作者的文件一字未改**（除下面这一处 `pack.json` 的字段迁移）。

## 1. 原作者

见包内 `pack.json` 的 `author` 原文（原样保留，未改写）。

## 2. 许可

见包内 `pack.json` 的 `license` 原文（原样保留）。
随包的《明日方舟》游戏素材版权归**上海鹰角网络科技有限公司 / Yostar** 及其授权方，
**不在包代码的许可范围内**，仅供**非商业**的学习与个人娱乐使用，请勿用于任何商业场景。
本包与改写者**不主张**这些素材的任何权利。

## 3. 兼容改写者

Stronghold-Protocol-Forge-Mods 维护者（本站）。

## 4. 来源

站上待审记录（作者提交的原件）。原件在本引擎（`UPSTREAM_VERSION = 0.3.1`、`MOD_API_VERSION = 1`）下
报 `PACK_UNKNOWN_FIELD: pack.json: "stripDiyOverlaps" is not a field of this pack format`，整包被拒。

## 5. 改了什么（一处，字段迁移）

| 原件写法 | 本包写法 | 为什么 |
|---|---|---|
| `"stripDiyOverlaps": true` | 删除该键，并在 `behaviour` 里加一条 `{ "switch": "diyPoolOverlap", "option": "strip" }` | `stripDiyOverlaps` **不是本引擎的字段**（`PACK_FIELDS` 38 键闭集里没有它；引擎文档 `docs/design/mod-layer.md` 已把这个键点名成「不存在的字段」的例子）。它想做的「把本包做成棋子的那几名干员从自选池摘掉」在引擎里**有唯一对应物**：`behaviour` 的 `diyPoolOverlap` 开关，取值 `report` / `strip`。原件的 `true` 语义就是「摘掉」，因此映射成 `strip`（不是 `report`）。 |

**语义核对**（不是随手删字段）：`shared/behaviour.js` 的 `diyPoolOverlap` 定义写着 ——
`strip: 把本包做成棋子的那几名干员从自选池摘掉`，对应装载器 `stripPackOperators` 的 `{ apply: true }` 那一支；
`report` 只是逐条点名、池子不变。原件写 `true` 要的是「摘掉」，所以 `strip` 是正确的映射。

`combat: true` 原样保留（这条规则会改结果，作者本来就标了）。

## 6. 包自带素材的来源

见第 2 项：随包素材来自《明日方舟》客户端解包（干员头像/立绘、Spine、技能图标等），
版权归**鹰角网络 / Yostar**，仅供非商业使用。

## 验证

```
引擎：Stronghold-Protocol（UPSTREAM_VERSION 0.3.1 · MOD_API_VERSION 1）
loadWorkshop → packsLoaded = [<本包 id>] · errors = 0
```
