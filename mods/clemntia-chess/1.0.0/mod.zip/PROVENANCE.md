# 来源与署名（PROVENANCE）

## 原件叫什么、从哪来
- **服务器**：`https://weishuxieyi.icu/`（卫戍协议：盟约 · 同人联机服，app 0.2.1，build `f638115c25cd-20`）
- **原件数据**：该服 `/_build/f638115c25cd-20/data/chess.json`（268 条记录）
- **取证时间**：2026-10-13；本地副本 `_tmp/reverse-weishu-2026-10-13/data/chess.json`

## 原作者是谁
- 游戏本体：`sganggs/Stronghold-Protocol`（上游，GPL-3.0-or-later）
- 该同人服的运营者：**未署名**（站点与目录清单均未标注维护者；`dl.jiangjiangze.icu/site/servers.json` 的 note 只写「自动发现 · B站公开位」）
- 打包：jingjiangze

## 原件的许可
- 上游仓库 GPL-3.0-or-later；本包照此许可
- **角色设定与美术版权属鹰角网络 / Yostar**。本包只含数值记录（stats / skill / talents 的 bb 数值），**不含任何素材字节**

## 它改了什么
| 项 | 上游（引擎 0.16.0） | weishu 服 | 本包 |
|---|---|---|---|
| `chess_char_4_27_a`（克莱门莎，5 费 WARRIOR） | **无此记录** | 有 | ✅ 收录 |
| `chess_char_4_27_b`（克莱门莎·精锐） | **无此记录** | 有 | ✅ 收录 |
| 其余 266 条 | — | md5 与上游**逐字节相同** | ❌ 不收录（避免重复） |

## 自带素材是哪来的
**无素材**。`assets` 字段指向的图标 / 立绘 / Spine 模型均未随包分发（用户明确要求不含素材）。

## 已知不兼容 / 边界（必读）
1. **装了这个包，克莱门莎的两个形态会进入棋子池**，但她的图标、立绘、Spine 模型是缺的 —— 界面会显示为占位。要补图需另配 `art` 或本地素材。
2. 引擎**已自带**该干员的战斗 kit（`server/sim/content/kits/ops/op-clemnt.js`，`kits/index.js:159` 已注册）。本包只补数据记录，**不含任何代码**。
3. 校验器会报 12 条 `BB_UNKNOWN_KEY` warning（`attack@aoe_atk_scale` 等）—— 那是**泛化 kit 扫描**的提示，不是错误：这些 bb 键由上面那个专用 kit 读取，不是由通用 kit 读取。**0 error**。
4. 若另一个包也新增同 id 的棋子，**包 id 字典序小的一方赢**（DESIGN §28.3），输的一方会得到一条点名报告 —— 这不是本包能决定的。
