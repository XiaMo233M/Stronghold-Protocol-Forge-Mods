// duel-mode/client/duelMode.js — 只读卡片。不 fetch、不起定时器、不 send（包界面层给不了这些）。
// 面板能做的是把「榜在哪儿、这一格为什么不能点」说清楚；实时榜由服务端算，走 /mod/duel-mode/standings.json。

export const CARDS = Object.freeze([
  ['争锋分怎么算', '每局结算时按 Duel 的 basicScores / extraScore 逐席计算并累计（计分表在包的服务端模块里，与上游数据同源）。'],
  ['榜在哪儿看', '服务端现算的只读端点 /mod/duel-mode/standings.json（浏览器直接打开），/healthz 里也有局数与榜首两个字段。'],
  ['为什么不并进奖励', 'APPLY_TO_REWARDS=false：把分变成钱/资源是数值裁决，需要业主点头，不随包默认生效。'],
  ['为什么这里没有按钮', '工坊包今天拿不到自定义消息通道（上游 PR #2 未合并），下注/借干员这类玩家命令无处可发。'],
]);

export function mount(ctx) {
  const host = ctx && ctx.host;
  if (!host || typeof host.appendChild !== 'function') return;
  const doc = host.ownerDocument || (typeof document !== 'undefined' ? document : null);
  if (!doc || typeof doc.createElement !== 'function') return;
  const card = doc.createElement('div');
  card.className = 'duel-mode';
  const h = doc.createElement('strong'); h.className = 'duel-mode__t'; h.textContent = '争锋频道 · 玩法叠加层';
  card.appendChild(h);
  for (const [k, v] of CARDS) {
    const row = doc.createElement('div'); row.className = 'duel-mode__row';
    const t = doc.createElement('span'); t.className = 'duel-mode__k'; t.textContent = k;
    const d = doc.createElement('span'); d.className = 'duel-mode__v'; d.textContent = v;
    row.appendChild(t); row.appendChild(d); card.appendChild(row);
  }
  host.appendChild(card);
  if (ctx.log && typeof ctx.log.info === 'function') ctx.log.info('[duel-mode] read-only card mounted; standings via /mod/duel-mode/standings.json');
}

export function unmount(ctx) {
  const host = ctx && ctx.host;
  if (host && typeof host.querySelector === 'function') {
    const card = host.querySelector('.duel-mode');
    if (card && card.parentNode) card.parentNode.removeChild(card);
  }
}
