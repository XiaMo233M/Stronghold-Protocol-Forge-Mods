// duel-mode/server/core.mjs — 争锋分叠加层：服务端驱动的玩法 mod（不依赖未合并的包通道）。
//
// 为什么是这个形状：今天的 pack 格式给不了「玩家主动发起的自定义命令」
// （server.modules[].channels 与 Match.handlePackMsg 还在上游 PR #2 里；面板的 messages 只认闭枚举），
// 所以本包做的是**服务端侧真的改变行为**的那一半：每一局结算时按 Duel 的计分表算出争锋分、
// 记成一张有界榜单，再通过已合并的两个面送出去：
//   · uses:["route"]      ⇒ GET /mod/duel-mode/standings.json（现算、no-store、同步返回）
//   · uses:["healthz"]    ⇒ /healthz 多两个只读标量字段（结算了几局、当前榜首）
// 而「把分发进玩家的正式奖励」刻意关着（APPLY_TO_REWARDS = false）：那是数值裁决，得业主点头，不随包默认改。

// 计分表：从 Duel 的 data/duelcfg.json 原样搬来（basicScores / extraScore），不手抄。
export const BASIC_SCORES = [30,32,34,36,38,40,42,44,46,50];
export const EXTRA_SCORES = {"multiOperationMatch":{"modeId":"multiOperationMatch","data":[{"rankMin":1,"rankMax":1,"tokenNum":100},{"rankMin":2,"rankMax":2,"tokenNum":70},{"rankMin":3,"rankMax":3,"tokenNum":50},{"rankMin":4,"rankMax":5,"tokenNum":35},{"rankMin":6,"rankMax":8,"tokenNum":20}]},"multiStandMatch":{"modeId":"multiStandMatch","data":[{"rankMin":1,"rankMax":1,"tokenNum":120},{"rankMin":2,"rankMax":2,"tokenNum":100},{"rankMin":3,"rankMax":3,"tokenNum":80},{"rankMin":4,"rankMax":10,"tokenNum":60},{"rankMin":11,"rankMax":15,"tokenNum":50},{"rankMin":16,"rankMax":20,"tokenNum":35},{"rankMin":21,"rankMax":30,"tokenNum":20}]}};

/** 榜单上限：一条无上限的榜就是本机 duel-sync-gate 抓到的那类毛病，这里一开始就封顶。 */
export const MAX_RECORDS = 50;

/** 把「要不要把争锋分并入正式奖励」写成常量：默认 false，改了要重打包（避免默默改数值）。 */
export const APPLY_TO_REWARDS = false;

/**
 * 一局的结果 → 每个席位这一局的争锋分。纯函数，输入全给、不碰时钟与随机。
 * 名次奖励直接查 Duel 表里明写的 `rankMin / rankMax → tokenNum`（不解释、不外推）。
 * [ASSUMED] BASIC_SCORES 是一维数组，这里按「第 n 期 → 下标 n-1」当每期的基础分用；
 * 上游若另有含义（例如它是波次奖励），改这一处映射即可，其余不动。
 * @param {Array<{ id?: string, modeId?: string, rank?: number, wave?: number }>} seats
 * @returns {Array<{ id: string, rank: number, wave: number, base: number, bonus: number, total: number }>}
 */
export function scoreRound(seats) {
  const list = Array.isArray(seats) ? seats : [];
  return list.map((s, i) => {
    const id = typeof s?.id === 'string' && s.id ? s.id : 'seat-' + i;
    const rank = Number.isFinite(s?.rank) ? s.rank : 0;
    const wave = Number.isFinite(s?.wave) ? s.wave : 0;
    const table = (s && typeof s.modeId === 'string' && EXTRA_SCORES[s.modeId] && EXTRA_SCORES[s.modeId].data) || [];
    const hit = table.find((r) => rank >= r.rankMin && rank <= r.rankMax);
    const base = hit ? Number(hit.tokenNum) || 0 : 0;
    const bonus = wave > 0 && wave <= BASIC_SCORES.length ? Number(BASIC_SCORES[wave - 1]) || 0 : 0;
    return { id, rank, wave, base, bonus, total: base + bonus };
  });
}

/** 把多条记录压成榜单：按累计分降序、同分按 id，长度封顶。 */
export function standings(records) {
  const byId = new Map();
  for (const r of records || []) {
    for (const line of r.scores || []) {
      const cur = byId.get(line.id) || { id: line.id, total: 0, rounds: 0, best: 0 };
      cur.total += line.total;
      cur.rounds += 1;
      if (line.total > cur.best) cur.best = line.total;
      byId.set(line.id, cur);
    }
  }
  return [...byId.values()].sort((a, b) => (b.total - a.total) || String(a.id).localeCompare(String(b.id)));
}

export function registerServer(host) {
  /** @type {Array<{ at: number, roomId: string, scores: any[] }>} */
  const records = [];

  host.matchClass((Base) => class DuelModeMatch extends Base {
    settle(plan, uniteResult) {
      const out = super.settle(plan, uniteResult);
      try {
        // [ASSUMED] 席位结果的取法：uniteResult 是「每席一条」的数组时才记账；形状不认识就记 0 条，
        // 绝不猜着写。结算本身已经由上面的 super.settle 走完，本包任何失败都不该影响对局。
        const seats = Array.isArray(uniteResult) ? uniteResult : [];
        const scores = scoreRound(seats.map((s) => ({
          id: s && (s.id || s.name || s.seatId || s.charId), modeId: s && s.modeId, rank: s && s.rank, wave: s && s.wave,
        }))).filter((x) => x.base || x.bonus);
        if (scores.length) {
          records.push({ at: Date.now(), roomId: String(this.id || this.roomId || '-'), scores });
          while (records.length > MAX_RECORDS) records.shift();
        }
      } catch { /* 记不上榜不影响结算 */ }
      return out;
    }
  });

  host.route('/mod/duel-mode/standings.json', () => ({
    pack: 'duel-mode',
    appliedToRewards: APPLY_TO_REWARDS,
    rounds: records.length,
    scoring: { basicScoresWaves: BASIC_SCORES.length, extraScore: EXTRA_SCORES },
    standings: standings(records),
  }));

  host.healthz(() => {
    const top = standings(records)[0];
    return { duelModeRounds: records.length, duelModeLeader: top ? String(top.id) : null };
  });
}
