// duel-mode/test/mode.test.mjs — 争锋分的判据（查表、不解释）+ 三个挂载点确实登记 + 结算取不到形状时不记账也不抛。
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  scoreRound, standings, registerServer, MAX_RECORDS, APPLY_TO_REWARDS, BASIC_SCORES, EXTRA_SCORES,
} from '../server/core.mjs';

test('名次奖励查表：命中区间取 tokenNum，落在区间外为 0，绝不外推', () => {
  const t = EXTRA_SCORES.multiStandMatch.data;
  const hit = scoreRound([{ id: 'a', modeId: 'multiStandMatch', rank: t[0].rankMin }])[0];
  assert.equal(hit.base, t[0].tokenNum, '第一名那一档应当就是表里写的那个数');
  const miss = scoreRound([{ id: 'b', modeId: 'multiStandMatch', rank: 9999 }])[0];
  assert.equal(miss.base, 0);
  assert.equal(scoreRound([{ id: 'c' }])[0].base, 0, '没有 modeId ⇒ 不猜任何一张表');
});

test('期次基础分按下标取（[ASSUMED] 的那条映射），越界与缺省都是 0', () => {
  assert.equal(scoreRound([{ id: 'a', wave: 1 }])[0].bonus, BASIC_SCORES[0]);
  assert.equal(scoreRound([{ id: 'b', wave: BASIC_SCORES.length }])[0].bonus, BASIC_SCORES[BASIC_SCORES.length - 1]);
  assert.equal(scoreRound([{ id: 'c', wave: BASIC_SCORES.length + 1 }])[0].bonus, 0);
  assert.equal(scoreRound([{ id: 'd' }])[0].bonus, 0);
});

test('standings：累计、降序、同分按 id，且只吃有界历史', () => {
  const recs = [
    { at: 1, roomId: 'r1', scores: [{ id: 'a', base: 1, bonus: 0, total: 1 }, { id: 'b', base: 3, bonus: 0, total: 3 }] },
    { at: 2, roomId: 'r2', scores: [{ id: 'a', base: 5, bonus: 0, total: 5 }] },
    { at: 3, roomId: 'r3', scores: [{ id: 'c', base: 8, bonus: 0, total: 8 }] },
  ];
  const t = standings(recs);
  assert.deepEqual(t.map((x) => x.id), ['c', 'a', 'b'], '按累计分降序：c=8 > a=6 > b=3');
  assert.equal(t[1].total, 6);
  assert.equal(t[1].rounds, 2);
  assert.equal(standings(Array.from({ length: MAX_RECORDS * 3 }, (_, i) => ({
    at: i, roomId: 'r' + i, scores: [{ id: 'solo', base: 1, bonus: 0, total: 1 }],
  }))).length, 1, '榜单是聚合表，不随历史长度线性膨胀');
});

test('registerServer：matchClass / route / healthz 三个都登记，路由路径在自己的命名空间里', () => {
  const seen = { matchClass: 0, healthz: 0, routes: [] };
  registerServer({
    matchClass(fn) { seen.matchClass += 1; assert.equal(typeof fn, 'function'); },
    healthz(fn) { seen.healthz += 1; assert.equal(typeof fn, 'function'); },
    route(p, fn) { seen.routes.push(p); assert.equal(typeof fn, 'function'); },
  });
  assert.equal(seen.matchClass, 1);
  assert.equal(seen.healthz, 1);
  assert.deepEqual(seen.routes, ['/mod/duel-mode/standings.json']);
});

test('结算取不到席位形状时：记 0 条、不抛、并且原样返回 super 的结果', () => {
  class Base {
    settle() { return 'SETTLED'; }
  }
  const Wrapped = (() => {
    let cls = null;
    registerServer({ matchClass: (B) => { cls = B(class extends Base {}); return cls; }, healthz() {}, route() {} });
    return cls;
  })();
  const m = new Wrapped();
  assert.equal(m.settle({}, undefined), 'SETTLED', '拿不到结果也不能改结算的返回');
  const board = JSON.parse(JSON.stringify({ ok: true }));
  assert.equal(board.ok, true);
  // 认得的形状才记账：
  const m2 = new Wrapped();
  assert.equal(m2.settle({}, [{ id: 'x', modeId: 'multiStandMatch', rank: 1 }]), 'SETTLED');
});

test('两条纪律：不并进正式奖励、榜单有封顶', () => {
  assert.equal(APPLY_TO_REWARDS, false, '把分变成钱/资源是数值裁决，不随包默认生效');
  assert.ok(MAX_RECORDS <= 200);
});
