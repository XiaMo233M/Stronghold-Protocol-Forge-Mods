// duel-mode/client/duelMode.js — 房内命令面板：下注与借干员的请求/应答都走包通道。
//
// 用到的面（都已合并）：
//   ctx.net.send('<通道>', data)  ⇒ 线上是 { t:'pack.msg', pack:'duel-mode', channel, data }（WORKSHOP §1.9.6）
//   ctx.net.on('<通道>', fn)      ⇒ 只收自己包、自己声明过的通道
//   ctx.net.on('m.public', fn)    ⇒ 引擎类型原样透传，席位与 LP 从这儿来（server/match/match/views.js 的 players[]）
//   ctx.net.welcome()             ⇒ 自己的 playerId（welcome 帧里带的）
// 没声明通道时 send 返回 false 并在控制台点名（CLIENT_CHANNEL_UNDECLARED）——这里把结果如实显示出来，不假装成功。

const AMOUNTS = [1, 5, 20];
const FEED_CAP = 12;
const UNIT_RE = /^[A-Za-z0-9_.:-]{1,48}$/;
const ENDPOINT = '/mod/duel-mode/standings.json';

export const CARDS = Object.freeze([
  ['争锋分怎么算', '每局结算时按名次与波次查 Duel 的 extraScore / basicScores 表（计分表在包的服务端模块里）。名次 = 剩余 LP → 击杀 → 伤害 → id，这条排序与「第 n 波 → basicScores[n-1]」都是本包的映射。'],
  ['榜在哪儿看', '服务端现算的只读端点 ' + ENDPOINT + '（浏览器直接打开），/healthz 里还有局数、榜首、命令计数等六个字段。'],
  ['为什么不并进奖励', 'APPLY_TO_REWARDS=false：把分变成钱/资源是数值裁决，需要业主点头，不随包默认生效。'],
  ['借干员借到什么', '本包做请求 → 对方同意/拒绝 → 记账，**不**把单位真的搬进别人阵型（那要改 Match 内部状态，属玩法裁决）。成交数在 /healthz 的 duelModeBorrowGrants。'],
]);

export function mount(ctx) {
  const host = ctx && ctx.host;
  if (!host || typeof host.appendChild !== 'function') return;
  const doc = host.ownerDocument || (typeof document !== 'undefined' ? document : null);
  if (!doc || typeof doc.createElement !== 'function') return;

  const net = ctx.net || null;
  const log = ctx.log || null;
  const offs = [];
  const state = { me: null, players: [], feed: [], pending: new Map(), lastSend: '（还没发过）' };

  const card = doc.createElement('div');
  card.className = 'duel-mode';
  const title = doc.createElement('strong');
  title.className = 'duel-mode__t';
  title.textContent = '争锋频道 · 玩法叠加层';
  card.appendChild(title);

  for (const [k, v] of CARDS) {
    const row = doc.createElement('div'); row.className = 'duel-mode__row';
    const t = doc.createElement('span'); t.className = 'duel-mode__k'; t.textContent = k;
    const d = doc.createElement('span'); d.className = 'duel-mode__v'; d.textContent = v;
    row.appendChild(t); row.appendChild(d); card.appendChild(row);
  }

  const seats = doc.createElement('div'); seats.className = 'duel-mode__seats'; card.appendChild(seats);
  const feed = doc.createElement('div'); feed.className = 'duel-mode__feed'; card.appendChild(feed);
  const status = doc.createElement('div'); status.className = 'duel-mode__status'; card.appendChild(status);

  const draw = () => {
    while (seats.firstChild) seats.removeChild(seats.firstChild);
    if (!net) {
      const p = doc.createElement('div'); p.textContent = '没有网络面（ctx.net 不在）——只显示说明，不假装能玩。';
      seats.appendChild(p);
    } else if (!state.players.length) {
      const p = doc.createElement('div'); p.textContent = '还没收到席位表（m.public 未到，或这局还没开始）。';
      seats.appendChild(p);
    }
    for (const pl of state.players) {
      const line = doc.createElement('div'); line.className = 'duel-mode__seat';
      const who = doc.createElement('span'); who.textContent = (pl.name || pl.playerId) + ' · LP ' + (Number.isFinite(pl.lp) ? pl.lp : '?');
      line.appendChild(who);
      for (const a of AMOUNTS) {
        const b = doc.createElement('button'); b.className = 'duel-mode__btn'; b.type = 'button';
        b.textContent = '押' + a;
        b.addEventListener('click', () => bet(pl.playerId, a));
        line.appendChild(b);
      }
      const ask = doc.createElement('button'); ask.className = 'duel-mode__btn'; ask.type = 'button'; ask.textContent = '借';
      ask.addEventListener('click', () => borrowRequest(pl.playerId));
      line.appendChild(ask);
      seats.appendChild(line);
    }

    while (feed.firstChild) feed.removeChild(feed.firstChild);
    for (const f of state.feed) {
      const p = doc.createElement('div'); p.className = 'duel-mode__line'; p.textContent = f; feed.appendChild(p);
    }
    status.textContent = '我：' + (state.me || '（未知）') + ' · 最近一次 send：' + state.lastSend + ' · 通道：bets / borrow';
  };

  const note = (line) => {
    state.feed.push(line);
    while (state.feed.length > FEED_CAP) state.feed.shift();
    draw();
  };

  const send = (channel, data) => {
    if (!net || typeof net.send !== 'function') { state.lastSend = '失败：没有 ctx.net.send'; draw(); return false; }
    let ok = false;
    try { ok = net.send(channel, data) === true; } catch (err) { ok = false; }
    state.lastSend = (ok ? '已发 ' : '被拒 ') + channel + ' ' + JSON.stringify(data);
    draw();
    return ok;
  };

  const bet = (on, amount) => {
    if (!on || !Number.isInteger(amount)) return;
    if (send('bets', { on, amount })) note('我押 ' + on + '：' + amount);
  };
  const borrowRequest = (to) => {
    const unit = (state.pending.get('draft:' + to) || '').trim();
    if (!UNIT_RE.test(unit)) { note('单位 id 不合格（^[A-Za-z0-9_.:-]{1,48}$）：先在该席位旁输入框里填一个。'); return; }
    if (send('borrow', { op: 'request', unit, from: state.me || undefined, to })) note('我向 ' + to + ' 借 ' + unit);
  };
  const borrowAnswer = (op, from, unit) => { send('borrow', { op, unit, from }); note('对 ' + from + ' 的 ' + unit + '：' + (op === 'accept' ? '同意' : '拒绝')); };

  if (net && typeof net.on === 'function') {
    const w = typeof net.welcome === 'function' ? net.welcome() : null;
    if (w && typeof w.playerId === 'string') state.me = w.playerId;
    offs.push(net.on('welcome', (msg) => {
      if (msg && typeof msg.playerId === 'string') { state.me = msg.playerId; draw(); }
    }));
    offs.push(net.on('m.public', (msg) => {
      const list = msg && Array.isArray(msg.players) ? msg.players : [];
      state.players = list.filter((p) => p && typeof p.playerId === 'string').map((p) => ({ playerId: p.playerId, name: p.name || '', lp: p.lp }));
      draw();
    }));
    offs.push(net.on('bets', (data, msg) => {
      const from = msg && msg.from ? msg.from : (data && data.by) || '?';
      note(from + ' 押 ' + (data && data.on) + '：' + (data && data.amount));
    }));
    offs.push(net.on('borrow', (data, msg) => {
      const from = msg && msg.from ? String(msg.from) : '?';
      const d = data || {};
      if (d.op === 'request') {
        note(from + ' 想借 ' + d.unit);
        if (state.me && from !== state.me) {
          const key = from + '→' + state.me + '→' + d.unit;
          state.pending.set(key, d.unit);
          const row = doc.createElement('div'); row.className = 'duel-mode__ask';
          const label = doc.createElement('span'); label.textContent = '应答 ' + from + ' 的 ' + d.unit + '：';
          const yes = doc.createElement('button'); yes.className = 'duel-mode__btn'; yes.type = 'button'; yes.textContent = '同意';
          yes.addEventListener('click', () => { borrowAnswer('accept', from, d.unit); if (row.parentNode) row.parentNode.removeChild(row); });
          const no = doc.createElement('button'); no.className = 'duel-mode__btn'; no.type = 'button'; no.textContent = '拒绝';
          no.addEventListener('click', () => { borrowAnswer('decline', from, d.unit); if (row.parentNode) row.parentNode.removeChild(row); });
          row.appendChild(label); row.appendChild(yes); row.appendChild(no);
          feed.appendChild(row);
        }
      } else if (d.op === 'accept') note((d.from || '?') + ' 的 ' + d.unit + '：对方同意（本包不改队伍，只记账）');
      else if (d.op === 'decline') note((d.from || '?') + ' 的 ' + d.unit + '：对方拒绝');
    }));
    // 借干员要先有个单位 id：给每个席位一个输入框，值记在 pending 里（不写引擎的存档面）。
    if (typeof doc.createElement === 'function') {
      const box = doc.createElement('div'); box.className = 'duel-mode__draft';
      const inp = doc.createElement('input'); inp.className = 'duel-mode__input'; inp.type = 'text'; inp.placeholder = '要借的单位 id';
      inp.addEventListener('input', () => { for (const pl of state.players) state.pending.set('draft:' + pl.playerId, inp.value); });
      const t = doc.createElement('span'); t.textContent = '单位 id：';
      box.appendChild(t); box.appendChild(inp); card.appendChild(box);
    }
  }

  host.appendChild(card);
  draw();
  if (log && typeof log.info === 'function') {
    log.info('[duel-mode] commands on channels bets/borrow; standings at ' + ENDPOINT);
  }
  return { offs, state };
}

export function unmount(ctx) {
  const host = ctx && ctx.host;
  if (host && typeof host.querySelector === 'function') {
    const card = host.querySelector('.duel-mode');
    if (card && card.parentNode) card.parentNode.removeChild(card);
  }
}
