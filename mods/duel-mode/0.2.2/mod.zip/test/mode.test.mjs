// duel-mode/test/mode.test.mjs — 单元层：查表不解释、命令判据、台账有界、三个挂载点登记。
// 真对局那一半在同目录 commands.test.mjs（需要引擎根）。
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  BASIC_SCORES, EXTRA_SCORES, RANK_TABLE, MAX_RECORDS, MAX_BETS_PER_ROOM, BET_MIN, BET_MAX, BET_MULTIPLIER,
  CHANNELS, PACK_ID, APPLY_TO_REWARDS, isDuelRoom, rankSeats, scoreRound, settleBets, standings, betOf, borrowOf, applyBorrow, registerServer,
} from '../server/core.mjs';

const newMatch = (opts = {}) => {
  let cls = null;
  registerServer({ matchClass: (B) => { cls = B(class { settle() { return 'SETTLED'; } }); }, healthz() {}, route() {} });
  const m = new cls();
  // 真房间里引擎给的是 { digest, packs:[{id,…}] }；这里默认让本包在集合内，门控用例再显式改掉。
  m.mods = 'mods' in opts ? opts.mods : { digest: 'x', packs: [{ id: 'duel-mode' }] };
  return m;
};

test('进程级包装器的两道门：没选本包的房间与别的包的消息，都不碰', () => {
  const off = newMatch({ mods: null });
  assert.equal(off.handlePackMsg('p1', { pack: 'duel-mode', channel: 'bets', data: { on: 'p2', amount: 5 } }), undefined, '房间没选本包 ⇒ 不消费');
  assert.equal(off.__duel().bets.length, 0, '不记账');
  assert.equal(off.settle(null, null), 'SETTLED', '结算返回值原样');

  const other = newMatch({ mods: { digest: 'x', packs: [{ id: 'duel-mode' }, { id: 'another-pack' }] } });
  assert.equal(other.handlePackMsg('p1', { pack: 'another-pack', channel: 'bets', data: { on: 'p2', amount: 5 } }), undefined, '别的包的同名通道 ⇒ 原样转交引擎，不认');
  assert.equal(other.__duel().bets.length, 0, '跨包通道不进本包台账');
  assert.equal(isDuelRoom(null), false);
  assert.equal(isDuelRoom({ packs: [] }), false);
  assert.equal(isDuelRoom({ packs: [{ id: 'duel-mode' }] }), true);
});

test('名次排序：剩余 LP → 击杀 → 伤害 → id，且可重现', () => {
  const r = rankSeats([
    { playerId: 'a', lp: 3, stats: { kills: 9, dmgDealt: 900 } },
    { playerId: 'b', lp: 5, stats: { kills: 1, dmgDealt: 5 } },
    { playerId: 'c', lp: 5, stats: { kills: 1, dmgDealt: 5 } },
  ]);
  assert.deepEqual(r.map((x) => [x.id, x.rank]), [['b', 1], ['c', 2], ['a', 3]], '同 LP 同战绩时按 id 定序，不靠输入顺序');
  const byKills = rankSeats([{ playerId: 'x', lp: 1, stats: { kills: 2, dmgDealt: 1 } }, { playerId: 'y', lp: 1, stats: { kills: 7, dmgDealt: 1 } }]);
  assert.equal(byKills[0].id, 'y', 'LP 相同时击杀多者在前');
  assert.deepEqual(rankSeats(undefined), [], '拿不到席位就返回空表，不猜');
});

test('争锋分查表：命中区间取 tokenNum，区间外与缺省都是 0，绝不外推', () => {
  const t = EXTRA_SCORES[RANK_TABLE].data;
  const hit = scoreRound([{ id: 'a', rank: t[0].rankMin }], 1)[0];
  assert.equal(hit.base, t[0].tokenNum, '第一名那一档应当就是表里写的那个数');
  assert.equal(scoreRound([{ id: 'b', rank: 9999 }], 1)[0].base, 0);
  assert.equal(scoreRound([{ id: 'c', rank: 1 }], 1)[0].bonus, BASIC_SCORES[0]);
  assert.equal(scoreRound([{ id: 'd', rank: 1 }], BASIC_SCORES.length)[0].bonus, BASIC_SCORES[BASIC_SCORES.length - 1]);
  assert.equal(scoreRound([{ id: 'e', rank: 1 }], BASIC_SCORES.length + 1)[0].bonus, 0, '波次越界给 0，不外推');
});

test('下注结算：押中前三按倍数得，押空扣额，押不在席上的人不结算', () => {
  const ranked = [{ id: 'a', rank: 1 }, { id: 'b', rank: 2 }, { id: 'c', rank: 3 }, { id: 'd', rank: 4 }];
  const out = settleBets([
    { by: 'x', on: 'a', amount: 10 },
    { by: 'x', on: 'd', amount: 4 },
    { by: 'y', on: 'ghost', amount: 3 },
  ], ranked);
  assert.equal(out.settled, 2, '押席外的人不算结算');
  const x = out.deltas.find((d) => d.by === 'x');
  assert.equal(x.gain, 10 * BET_MULTIPLIER[1] - 4, '押中 3×、押空扣额');
  assert.equal(x.won, true);
  assert.deepEqual(settleBets([], ranked).deltas, []);
});

test('榜单：累计、降序、同分按 id，下注净额单列', () => {
  const t = standings([
    { scores: [{ id: 'a', base: 1, bonus: 0, bets: 0 }, { id: 'b', base: 3, bonus: 0, bets: 0 }] },
    { scores: [{ id: 'a', base: 5, bonus: 0, bets: 2 }] },
    { scores: [{ id: 'c', base: 8, bonus: 0, bets: 0 }] },
  ]);
  assert.deepEqual(t.map((x) => x.id), ['a', 'c', 'b'], 'a=1+5+2=8 与 c=8 同分 ⇒ 按 id 定序，b=3 在后');
  assert.equal(t[0].total, 8);
  assert.equal(t[0].rounds, 2);
  assert.equal(t.find((x) => x.id === 'a').betGain, 2);
});

test('命令判据：坏载荷一律 null（不猜形状）', () => {
  assert.equal(betOf({ on: 'p1', amount: BET_MIN - 1 }), null);
  assert.equal(betOf({ on: 'p1', amount: BET_MAX + 1 }), null);
  assert.equal(betOf({ on: 'p1', amount: 2.5 }), null);
  assert.equal(betOf({ on: '', amount: 1 }), null);
  assert.deepEqual(betOf({ on: 'p1', amount: BET_MAX }), { on: 'p1', amount: BET_MAX });
  assert.equal(borrowOf({ op: 'request', unit: 'op_a' }), null, 'request 没点名向谁借');
  assert.equal(borrowOf({ op: 'accept', unit: 'op_a' }), null, '应答没点名是谁借的');
  assert.equal(borrowOf({ op: 'offer', unit: 'op_a', from: 'p1', to: 'p2' }), null, '动作不在闭集里');
  assert.equal(borrowOf({ op: 'request', unit: 'bad unit!', to: 'p2' }), null, '单位 id 形状不合格');
  assert.deepEqual(borrowOf({ op: 'request', unit: 'op_a', from: 'p1', to: 'p2' }), { op: 'request', unit: 'op_a', from: 'p1', to: 'p2' });
});

test('借干员台账：request→accept 成交，无请求的应答被拒，封顶不涨', () => {
  const st = { bets: [], pending: [], grants: [], requests: 0, forwarded: 0, refused: 0 };
  assert.equal(applyBorrow(st, 'p1', { op: 'request', unit: 'u', from: 'p1', to: 'p2' }), 'forward');
  assert.deepEqual(st.pending, ['p1→p2→u']);
  assert.equal(applyBorrow(st, 'p2', { op: 'accept', unit: 'u', from: 'p1' }), 'granted');
  assert.equal(st.grants.length, 1);
  assert.equal(applyBorrow(st, 'p2', { op: 'accept', unit: 'u', from: 'p1' }), 'refused', '重复应答没有 pending 可对');
  assert.equal(st.refused, 1);
  assert.equal(applyBorrow(st, 'p2', { op: 'decline', unit: 'u', from: 'p1' }), 'refused');
  const big = { bets: [], pending: [], grants: [], requests: 0, forwarded: 0, refused: 0 };
  for (let i = 0; i < MAX_BETS_PER_ROOM + 20; i++) applyBorrow(big, 'p1', { op: 'request', unit: 'u' + i, from: 'p1', to: 'p2' });
  assert.equal(big.pending.length, MAX_BETS_PER_ROOM, '房内台账封顶');
});

test('registerServer：三个挂载点都登记，子类带 handlePackMsg，路由路径在自己的命名空间里', () => {
  const seen = { matchClass: 0, healthz: 0, routes: [] };
  registerServer({
    matchClass(fn) { seen.matchClass += 1; assert.equal(typeof fn, 'function'); },
    healthz(fn) { seen.healthz += 1; assert.equal(typeof fn, 'function'); },
    route(p, fn) { seen.routes.push(p); assert.equal(typeof fn, 'function'); },
  });
  assert.deepEqual([seen.matchClass, seen.healthz], [1, 1]);
  assert.deepEqual(seen.routes, ['/mod/duel-mode/standings.json']);
  const m = newMatch();
  assert.equal(typeof m.handlePackMsg, 'function', '子类必须真的带这条消息驱动的钩子');
});

test('handlePackMsg：好载荷不消费（同房要看到），坏载荷消费掉不外溢', () => {
  const m = newMatch();
  const pkt = (channel, data) => ({ t: 'pack.msg', pack: PACK_ID, channel, data });
  const ok = m.handlePackMsg('p1', pkt('bets', { on: 'p2', amount: 5 }));
  assert.equal(ok, undefined, '正常下注返回 undefined ⇒ 引擎照旧转发');
  assert.equal(m.handlePackMsg('p1', pkt('bets', { on: 'p2', amount: 99999 })), true, '坏金额被消费');
  assert.equal(m.handlePackMsg('p1', pkt('borrow', { op: 'nope' })), true, '坏动作被消费');
  assert.equal(m.__duel().bets.length, 1, '只有合法的那条进了台账');
  assert.equal(m.handlePackMsg('p1', pkt('别的通道名', {})), undefined, '不认识的外部通道不改转发行为');
});

test('settle：真形状记账、押注并进同一局、坏形状不记账也不抛、返回值原样交还', () => {
  const m = newMatch();
  m.roomCode = 'ABCD';
  m.round = 2;
  m.order = [{ playerId: 'p1', lp: 3, stats: { kills: 1, dmgDealt: 1 } }, { playerId: 'p2', lp: 5, stats: { kills: 1, dmgDealt: 1 } }];
  m.handlePackMsg('p1', { t: 'pack.msg', pack: PACK_ID, channel: 'bets', data: { on: 'p2', amount: 5 } });
  assert.equal(m.settle(null, null), 'SETTLED', '结算返回值一个字都不改');
  const board = standings([{ scores: [] }]); // 只用来确认 standings 仍可调用
  assert.ok(Array.isArray(board));
  const m2 = newMatch();
  m2.order = undefined;
  assert.equal(m2.settle({}, { synthetic: true }), 'SETTLED', '拿不到席位时不抛');
});

test('三条纪律：不并进正式奖励、两份台账都封顶、通道名与 pack.json 一致', () => {
  assert.equal(APPLY_TO_REWARDS, false, '把分变成钱/资源是数值裁决，不随包默认生效');
  assert.ok(MAX_RECORDS <= 200 && MAX_BETS_PER_ROOM <= 200);
  assert.deepEqual(CHANNELS, ['bets', 'borrow']);
  const pack = JSON.parse(process.env.DUEL_PACK_JSON || '{}');
  if (pack.client) {
    const msgs = pack.client.panels.flatMap((p) => p.messages || []);
    assert.deepEqual(msgs.slice().sort(), CHANNELS.slice().sort(), '面板声明的通道必须与代码里的常量逐字相同');
  }
});
