// duel-mode/test/panel-mount.test.mjs — 面板真的走一遍引擎的注册点（createPanelRegistry）：
// 被收下 ⇒ import ⇒ mount ⇒ 零拒绝，并且点一下按钮发出去的就是 pack.msg 帧。
// 这条覆盖是补出来的：维护方拉回来的 perf-lite 基线里同款测试把引擎路径写死在他自己机器上，本机永远 skip。
// 需要引擎根：SP_ENGINE_ROOT=<Stronghold-Protocol-Forge 根>；找不到就显式 skip（判据不放松）。
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const PACK_DIR = path.dirname(path.dirname(fileURLToPath(import.meta.url)));

function findEngine() {
  const env = process.env.SP_ENGINE_ROOT;
  if (env && fs.existsSync(path.join(env, 'public/js/ui/extensions.js'))) return env;
  let dir = path.resolve(PACK_DIR, '..', '..');
  for (let i = 0; i < 6; i++) {
    if (fs.existsSync(path.join(dir, 'public/js/ui/extensions.js'))) return dir;
    const up = path.dirname(dir);
    if (up === dir) break;
    dir = up;
  }
  return null;
}

const ENGINE = findEngine();
const SKIP = ENGINE ? false : `找不到引擎的 public/js/ui/extensions.js（设 SP_ENGINE_ROOT=<引擎根> 再跑；判据不放松）`;

/** 极小 DOM：只实现引擎注册点与我方面板真正用到的那几件事。 */
function makeDoc() {
  const el = (tag) => {
    const node = {
      tag, children: [], attrs: {}, className: '', textContent: '', type: '', value: '', parentNode: null, ownerDocument: null,
      appendChild(c) { c.parentNode = node; node.children.push(c); return c; },
      removeChild(c) { node.children = node.children.filter((x) => x !== c); c.parentNode = null; return c; },
      setAttribute(k, v) { node.attrs[k] = String(v); },
      getAttribute(k) { return k in node.attrs ? node.attrs[k] : null; },
      addEventListener(ev, fn) { (node.listeners ||= {})[ev] = fn; },
      querySelector(sel) { const want = sel.replace('.', ''); const go = (n) => { for (const c of n.children) { if (c.className === want || (c.className || '').split(' ').includes(want)) return c; const r = go(c); if (r) return r; } return null; }; return go(node); },
      click() { node.listeners?.click?.({}); },
      input(v) { node.value = v; node.listeners?.input?.({}); },
    };
    return node;
  };
  const doc = { createElement: (t) => { const n = el(t); n.ownerDocument = doc; return n; }, body: el('body'), head: el('head') };
  doc.body.ownerDocument = doc; doc.head.ownerDocument = doc;
  return { doc, html: el('html') };
}

test('走引擎注册点：面板被收下、挂载、零拒绝，点击真发 pack.msg', { skip: SKIP }, async () => {
  const { createPanelRegistry } = await import(pathToFileURL(path.join(ENGINE, 'public/js/ui/extensions.js')).href);
  const { doc, html } = makeDoc();
  const store = { get: () => ({}), subscribe: () => () => { }, patch: () => { } };
  const out = [];            // 注入的 net 收到的出站帧
  const subs = [];           // 面板订阅进来的回调（用来喂引擎帧）
  const net = {
    send: (msg) => { out.push(msg); return true; },
    on: (type, fn) => { subs.push({ type, fn }); return () => { const i = subs.findIndex((s) => s.fn === fn); if (i >= 0) subs.splice(i, 1); }; },
    sendResourceMessage: (msg) => { out.push(msg); return true; },
    snapshot: () => ({ connected: true }),
  };
  const emit = (type, msg) => { for (const s of subs.filter((x) => x.type === type)) s.fn(msg); };

  const registry = createPanelRegistry({
    store, net,
    createElement: (t) => doc.createElement(t),
    styleHost: () => doc.head,
    themeHost: () => html,
    slotHosts: () => [],
    slotHost: () => { const n = doc.createElement('div'); n.setAttribute('data-mod-slot', 'screen.game.aside'); doc.body.appendChild(n); return n; },
    data: null,
    importModule: (url) => import(pathToFileURL(path.join(PACK_DIR, url.split('?')[0].replace(/^\/workshop-panels\/[^/]+\//, ''))).href),
    log: { info() { }, warn() { }, error() { } },
  });

  const declared = JSON.parse(fs.readFileSync(path.join(PACK_DIR, 'pack.json'), 'utf8'));
  const panel = declared.client.panels[0];
  const accepted = registry.apply([{
    id: panel.id, pack: declared.id, slot: panel.slot, module: panel.module,
    url: `/workshop-panels/${declared.id}/${panel.module}?v=test`, order: panel.order, messages: panel.messages,
  }]).accepted;

  assert.equal(accepted, 1, '面板必须被引擎收下');
  await new Promise((r) => setImmediate(r));
  assert.deepEqual(registry.refusals(), [], `有一条拒绝就是「装了没反应」：${JSON.stringify(registry.refusals())}`);
  assert.deepEqual(registry.mounted(), ['duel-mode/duel-mode']);

  emit('welcome', { playerId: 'me', version: 1 });
  emit('m.public', { phase: 'COMBAT', players: [{ playerId: 'p1', name: '一', lp: 3 }, { playerId: 'p2', name: '二', lp: 1 }] });

  const host = doc.body.children.find((n) => n.getAttribute('data-mod-slot') === 'screen.game.aside');
  const panelHost = host && host.children[0];
  assert.equal(panelHost && panelHost.className, 'mod-panel', '引擎给面板的挂载容器');
  const find = (root, cls) => { for (const c of root.children || []) { if (c.className === cls) return c; const r = find(c, cls); if (r) return r; } return null; };
  const seat = find(panelHost, 'duel-mode__seat');
  assert.ok(seat, '席位行由真注册点这条路径渲染出来');
  seat.children.find((c) => c.className === 'duel-mode__btn').click();

  const sent = out.at(-1);
  assert.deepEqual(sent, { t: 'pack.msg', pack: 'duel-mode', channel: 'bets', data: { on: 'p1', amount: 1 } },
    '点击发出的必须是 pack.msg，且 pack 字段就是本包 id');

  // 同房来的一条下注帧要落到面板视图里（on 的订阅走的是引擎那条 pack.msg 分发）
  emit('pack.msg', { t: 'pack.msg', pack: 'duel-mode', channel: 'bets', from: 'p2', data: { on: 'p1', amount: 2 } });
  const feed = find(panelHost, 'duel-mode__feed');
  assert.ok(feed.children.some((c) => /2/.test(c.textContent || '')), JSON.stringify(feed.children.map((c) => c.textContent)));
});
