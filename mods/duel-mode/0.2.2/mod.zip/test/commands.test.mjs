// duel-mode/test/commands.test.mjs — 真对局闭环：真服务器 + 真房间 + 真 WS + 真 Match。
//
// 为什么单独一个文件：这一组需要引擎根才能跑。找不到就**显式 skip**（不静默通过）。
//   SP_ENGINE_ROOT=C:/path/to/Stronghold-Protocol-Forge node --test test/commands.test.mjs
// 不写 SP_ENGINE_ROOT 时，本脚本会从包目录逐级上探（引擎仓自带的 packs/ 里跑时能命中）。
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL, fileURLToPath } from 'node:url';

const PACK_DIR = path.dirname(path.dirname(fileURLToPath(import.meta.url)));

/** 逐级上探引擎根：先认 SP_ENGINE_ROOT，再认「本包正躺在引擎树的 packs/ 下」这一种布局。 */
function findEngine() {
  const env = process.env.SP_ENGINE_ROOT;
  if (env && fs.existsSync(path.join(env, 'server/index.js'))) return env;
  let dir = path.resolve(PACK_DIR, '..', '..');
  for (let i = 0; i < 6; i++) {
    if (fs.existsSync(path.join(dir, 'server/index.js')) && fs.existsSync(path.join(dir, 'test/helpers/wsClient.js'))) return dir;
    const up = path.dirname(dir);
    if (up === dir) break;
    dir = up;
  }
  return null;
}

const ENGINE = findEngine();
const here = ENGINE ? test : (name, fn) => test(name, { skip: '没有引擎根（设 SP_ENGINE_ROOT 指向 Stronghold-Protocol-Forge 再来）' }, fn);

let srv, stateDir;
const clients = [];
const log = { info: () => {}, warn: () => {}, error: (m) => { log.errors.push(String(m)); }, debug: () => {}, errors: [] };

before(async () => {
  if (!ENGINE) return;
  const { startServer } = await import(pathToFileURL(path.join(ENGINE, 'server/index.js')).href);
  stateDir = fs.mkdtempSync(path.join(tmpdir(), 'duel-mode-state-'));
  process.env.SP_STATE_DIR = stateDir;
  srv = await startServer({ port: 0, host: '127.0.0.1', workshopDir: path.dirname(PACK_DIR), log });
});

after(async () => {
  for (const c of clients) { try { await c.close(); } catch { /* 已关 */ } }
  if (srv) await srv.close();
  if (stateDir) fs.rmSync(stateDir, { recursive: true, force: true });
});

async function startedRoom() {
  const { TestClient } = await import(pathToFileURL(path.join(ENGINE, 'test/helpers/wsClient.js')).href);
  const wsUrl = srv.url.replace('http', 'ws') + '/ws';
  const digest = srv.lobby.welcomeInfo().mods.digest;
  const human = async (name) => { const c = await TestClient.connect(wsUrl); clients.push(c); const w = await c.hello(name); return { c, playerId: w.playerId }; };
  const A = await human('AAA');
  assert.equal((await A.c.request({ t: 'room.create', mode: 'coop', difficulty: 'NORMAL', mods: digest })).t, 'ok');
  const st = await A.c.waitFor('room.state');
  const B = await human('BBB');
  assert.equal((await B.c.request({ t: 'room.join', code: st.code, mods: digest })).t, 'ok');
  assert.equal((await B.c.request({ t: 'room.ready', ready: true })).t, 'ok');
  assert.equal((await A.c.request({ t: 'room.ready', ready: true })).t, 'ok');
  assert.equal((await A.c.request({ t: 'room.start' })).t, 'ok');
  await A.c.waitFor('m.public', (p) => p.phase === 'INFO_CHECK');
  await B.c.waitFor('m.public', (p) => p.phase === 'INFO_CHECK');
  A.c.clearInbox(); B.c.clearInbox();
  return { A, B, room: srv.lobby.getRoom(st.code) };
}

const board = async () => (await (await fetch(srv.url + '/mod/duel-mode/standings.json')).json()).standings;
const route = async () => (await (await fetch(srv.url + '/mod/duel-mode/standings.json')).json());
const hz = async () => (await (await fetch(srv.url + '/healthz')).json()).modHealth?.['duel-mode'];

test('包真被装载，且它的 Match 子类带 handlePackMsg（否则下面全是空转）', async () => {
  if (!ENGINE) return;
  const ids = srv.lobby.welcomeInfo().mods.packs.map((p) => p.id);
  assert.ok(ids.includes('duel-mode'), `duel-mode 必须在已加载集合里：${JSON.stringify(ids)}`);
  const { A, B, room } = await startedRoom();
  await A.c.close(); await B.c.close(); clients.length = 0;
  assert.equal(typeof room.match.handlePackMsg, 'function', '§28.14 的那条钩子必须挂在真 Match 上');
});

test('下注：同房另一人收到转发帧，命令计数 +1；别的包的同名通道不进本包', async () => {
  if (!ENGINE) return;
  const { A, B, room } = await startedRoom();
  const before = await hz();
  A.c.send({ t: 'pack.msg', pack: 'duel-mode', channel: 'bets', data: { on: B.playerId, amount: 5 } });
  const got = await B.c.waitFor('pack.msg');
  assert.deepEqual(got, { t: 'pack.msg', pack: 'duel-mode', channel: 'bets', from: A.playerId, data: { on: B.playerId, amount: 5 } });
  const after = await hz();
  assert.equal(after.duelModeCommands, before.duelModeCommands + 1, '钩子真的被调到');
  // 归属判据：引擎把任何包的 pack.msg 都送进所有包装器，这里直接喂一条别的包的
  room.match.handlePackMsg('someone', { t: 'pack.msg', pack: 'another-pack', channel: 'bets', data: { on: 'x', amount: 5 } });
  assert.equal((await hz()).duelModeCommands, after.duelModeCommands, '别的包的同名通道一次都不该被计入');
});

test('坏载荷被消费：同房看不到它，refused 计数 +1（不是静默丢弃）', async () => {
  if (!ENGINE) return;
  const { A, B } = await startedRoom();
  const before = await hz();
  A.c.send({ t: 'pack.msg', pack: 'duel-mode', channel: 'bets', data: { on: B.playerId, amount: 999999 } });
  await B.c.expectNone('pack.msg', () => true, 300);
  const after = await hz();
  assert.equal(after.duelModeRefused, before.duelModeRefused + 1);
});

test('借干员：request→accept 成交，grants +1；没有 pending 的应答被拒', async () => {
  if (!ENGINE) return;
  const { A, B } = await startedRoom();
  A.c.send({ t: 'pack.msg', pack: 'duel-mode', channel: 'borrow', data: { op: 'request', unit: 'op_probe', from: A.playerId, to: B.playerId } });
  await B.c.waitFor('pack.msg');
  B.c.send({ t: 'pack.msg', pack: 'duel-mode', channel: 'borrow', data: { op: 'accept', unit: 'op_probe', from: A.playerId } });
  await A.c.waitFor('pack.msg');
  assert.equal((await hz()).duelModeBorrowGrants, 1, `成交要能读出来：${JSON.stringify(await hz())}`);
  const r = await route();
  assert.equal(r.borrowGrants, 1, '同一件事在只读端点上也得是 1');
  B.c.send({ t: 'pack.msg', pack: 'duel-mode', channel: 'borrow', data: { op: 'accept', unit: '没有请求过的那一笔', from: A.playerId } });
});

test('真结算记上账（v0.1 在这一条是结构性 0 条）：席位、名次、波次、押注净额都可读', async () => {
  if (!ENGINE) return;
  const { A, B, room } = await startedRoom();
  const ids = [A.playerId, B.playerId];
  A.c.send({ t: 'pack.msg', pack: 'duel-mode', channel: 'bets', data: { on: B.playerId, amount: 5 } });
  await B.c.waitFor('pack.msg');
  room.match.settle(null, null);                       // 真 Match、真子类；plan/uniteResult 给空是引擎自己允许的
  const r = await route();
  const h = await hz();
  assert.equal(r.rounds, 1, `结算后必须记上一局：${JSON.stringify(r).slice(0, 300)}`);
  assert.equal(h.duelModeRounds, 1);
  const line = r.lastRound;
  assert.ok(ids.includes(line.scores[0].id) && ids.includes(line.scores[1].id), '记的是真 playerId，不是猜出来的名字');
  assert.equal(line.bets.length, 1);
  // 赔付按「被押者最终名次」算，名次由 LP→击杀→伤害→id 决定 ⇒ 不假设谁在前，只核对倍数表本身
  const targetRank = line.scores.find((s) => s.id === B.playerId).rank;
  const expect = { 1: 15, 2: 10, 3: 5 }[targetRank] ?? -5;
  const bettor = r.standings.find((s) => s.id === A.playerId);
  assert.equal(bettor.betGain, expect, `押 ${targetRank} 名应按倍数表落地：${JSON.stringify(r.standings)}`);
  assert.ok(line.scores.every((s) => s.base > 0 || s.rank > 15), '名次分来自查表');
  assert.equal(h.duelModeBetsSettled, 1);
  assert.equal(line.roomId.length, 4, '房号是真房号（Match.roomCode），不是占位符');
});

test('钩子不炸对局：坏通道与抛错路径都不产生点名日志', async () => {
  if (!ENGINE) return;
  const { A, B } = await startedRoom();
  const before = log.errors.length;
  A.c.send({ t: 'pack.msg', pack: 'duel-mode', channel: 'bets', data: null });
  await B.c.waitFor('pack.msg').catch(() => {});
  assert.equal(log.errors.slice(before).filter((l) => /handlePackMsg/.test(l)).length, 0, '本包的钩子不该在引擎里留下点名');
});
