// duel-mode/test/panel.test.mjs — 面板用假 DOM 与假 net 跑：不发真请求也能钉住它「按了才发、发的是哪条通道、退订真的撤掉」。
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { mount, unmount } from '../client/duelMode.js';

function fakeDoc() {
  const el = (tag) => {
    const node = {
      tag, children: [], className: '', textContent: '', type: '', value: '', parentNode: null,
      appendChild(c) { c.parentNode = node; node.children.push(c); return c; },
      removeChild(c) { node.children = node.children.filter((x) => x !== c); c.parentNode = null; return c; },
      addEventListener(ev, fn) { (node.listeners ||= {})[ev] = fn; },
      querySelector(sel) { return node.children.find((c) => sel === '.' + c.className) || null; },
      click() { node.listeners?.click?.({}); },
      input(v) { node.value = v; node.listeners?.input?.({}); },
    };
    return node;
  };
  return { createElement: el };
}

function fakeNet(opts = {}) {
  const sent = [];
  const subs = [];
  return {
    sent, subs,
    welcome: () => (opts.welcome ?? null),
    send: (channel, data) => { sent.push({ channel, data }); return opts.ok === false ? false : true; },
    on: (type, fn) => { subs.push({ type, fn }); return () => { const i = subs.findIndex((s) => s.fn === fn); if (i >= 0) subs.splice(i, 1); }; },
    emit(type, msg, data) { for (const s of subs.filter((x) => x.type === type)) s.fn(data ?? msg, msg); },
  };
}

const ctxOf = (net, doc) => {
  const host = fakeDoc().createElement('div');
  host.ownerDocument = doc;
  const logs = [];
  return { host, ctx: { host, net, log: { info: (m) => logs.push(String(m)) } }, logs };
};

/** 卡片是 host 的唯一子节点，元素都挂在卡片里 —— 用遍历找，不假设层级。 */
const find = (root, cls) => {
  for (const c of root.children || []) {
    if (c.className === cls) return c;
    const hit = find(c, cls);
    if (hit) return hit;
  }
  return null;
};

test('没有 ctx.net 时不假装能玩：只渲染说明，一个按钮都不产生', () => {
  const doc = fakeDoc();
  const { host, ctx } = ctxOf(null, doc);
  mount(ctx);
  assert.ok(find(host, 'duel-mode'), '卡片挂上了');
  assert.equal(find(host, 'duel-mode__seat'), null, '没有 net 就不该长出下注按钮');
  assert.ok(find(host, 'duel-mode__seats').children.some((c) => /没有网络面/.test(c.textContent || '')));
});

test('m.public 到 ⇒ 每席三个额度按钮 + 一个借；点按钮真的发到声明过的通道', () => {
  const doc = fakeDoc();
  const net = fakeNet({ welcome: { playerId: 'me' } });
  const { host, ctx } = ctxOf(net, doc);
  const h = mount(ctx);
  net.emit('m.public', { players: [{ playerId: 'p1', name: '一', lp: 4 }, { playerId: 'p2', name: '二', lp: 2 }] });
  const seats = find(host, 'duel-mode__seats');
  const lines = seats.children.filter((c) => c.className === 'duel-mode__seat');
  assert.equal(lines.length, 2, '两席两行');
  const btns = lines[0].children.filter((c) => c.className === 'duel-mode__btn');
  assert.equal(btns.length, 4, '押1/押5/押20 + 借');
  btns[1].click();                                    // 押 5
  assert.deepEqual(net.sent.at(-1), { channel: 'bets', data: { on: 'p1', amount: 5 } });
  // 借：没有合法单位 id ⇒ 不发，并把原因显示出来（不静默）
  const before = net.sent.length;
  btns[3].click();
  assert.equal(net.sent.length, before, '单位 id 为空时不发');
  const input = find(host, 'duel-mode__draft').children.find((c) => c.className === 'duel-mode__input');
  input.input('op_test');
  btns[3].click();
  assert.deepEqual(net.sent.at(-1).data, { op: 'request', unit: 'op_test', from: 'me', to: 'p1' });
  assert.ok(h && Array.isArray(h.offs) && h.offs.length >= 4, '订阅都记在退订表里');
});

test('收到同房的 bets / borrow 帧才写进台账视图；request 给自己时出现应答行', () => {
  const doc = fakeDoc();
  const net = fakeNet({ welcome: { playerId: 'me' } });
  const { host, ctx } = ctxOf(net, doc);
  mount(ctx);
  net.emit('bets', null, { on: 'x', amount: 3 });                       // 引擎把 (data, msg) 都给面板
  net.emit('borrow', { from: 'other' }, { op: 'request', unit: 'op_a', from: 'other', to: 'me' });
  const feed = find(host, 'duel-mode__feed');
  const texts = feed.children.map((c) => c.textContent);
  assert.ok(texts.some((t) => /3/.test(t)), JSON.stringify(texts));
  const ask = feed.children.find((c) => c.className === 'duel-mode__ask');
  assert.ok(ask, '被点名借我 ⇒ 要有应答行');
  const yes = ask.children.find((c) => c.textContent === '同意');
  yes.click();
  assert.deepEqual(net.sent.at(-1), { channel: 'borrow', data: { op: 'accept', unit: 'op_a', from: 'other' } });
});

test('send 被引擎拒绝时如实显示（CLIENT_CHANNEL_UNDECLARED 那一侧的可见性）', () => {
  const doc = fakeDoc();
  const net = fakeNet({ welcome: { playerId: 'me' }, ok: false });
  const { host, ctx } = ctxOf(net, doc);
  mount(ctx);
  net.emit('m.public', { players: [{ playerId: 'p1', name: '一', lp: 1 }] });
  const seat = find(host, 'duel-mode__seat');
  seat.children.find((c) => c.className === 'duel-mode__btn').click();
  assert.match(find(host, 'duel-mode__status').textContent, /被拒/, '状态行要写出「被拒」，不能显示成已发');
});

test('unmount 把卡片摘掉', () => {
  const doc = fakeDoc();
  const net = fakeNet({ welcome: { playerId: 'me' } });
  const { host, ctx } = ctxOf(net, doc);
  mount(ctx);
  assert.ok(host.children.length >= 1);
  unmount(ctx);
  assert.equal(host.children.length, 0);
});
