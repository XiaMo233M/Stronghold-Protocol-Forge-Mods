// duel-mode/server/core.mjs — 争锋分叠加层 + 玩家主动命令（服务端驱动）。
//
// 两个面都用**已合并**的引擎能力，不依赖任何在审 PR：
//   · uses:["matchClass"] + combat:true ⇒ 子类上的 settle() 与 handlePackMsg(playerId, msg)（DESIGN §28.14）
//   · client.panels[].messages          ⇒ 通道名由包定，线上只有一种类型 pack.msg（WORKSHOP §1.9.6）
//   · uses:["route"] / ["healthz"]      ⇒ GET /mod/duel-mode/standings.json 与 /healthz 的只读标量
//
// 更正记录（v0.1 写错的两条，站侧 5a8f399c75a2 点名，源码复核后确认）：
//   1) v0.1 说「玩家主动命令要 server.modules[].channels + 上游 PR #2」—— 错。引擎 0.16.0 有
//      pack.msg + client.panels[].messages + Match.handlePackMsg（test/packMatchMsg.test.js 本机 9/9 pass）。
//   2) v0.1 的 settle(plan, uniteResult) 把 uniteResult 当「每席一条的数组」—— 错。它是**联防结果**
//      （server/match/match/settle.js），所以榜单结构性不会触发。真输入是 this.round 与 this.order 上的 lp/stats。

export const BASIC_SCORES = [30, 32, 34, 36, 38, 40, 42, 44, 46, 50];
export const EXTRA_SCORES = {"multiOperationMatch":{"modeId":"multiOperationMatch","data":[{"rankMin":1,"rankMax":1,"tokenNum":100},{"rankMin":2,"rankMax":2,"tokenNum":70},{"rankMin":3,"rankMax":3,"tokenNum":50},{"rankMin":4,"rankMax":5,"tokenNum":35},{"rankMin":6,"rankMax":8,"tokenNum":20}]},"multiStandMatch":{"modeId":"multiStandMatch","data":[{"rankMin":1,"rankMax":1,"tokenNum":120},{"rankMin":2,"rankMax":2,"tokenNum":100},{"rankMin":3,"rankMax":3,"tokenNum":80},{"rankMin":4,"rankMax":10,"tokenNum":60},{"rankMin":11,"rankMax":15,"tokenNum":50},{"rankMin":16,"rankMax":20,"tokenNum":35},{"rankMin":21,"rankMax":30,"tokenNum":20}]}};

/** 本包用的名次表：联机房是「同一名次赛」——这是**我的映射**，不是上游写的。 */
export const RANK_TABLE = 'multiStandMatch';

/** 跨局历史封顶：一条无上限的榜就是本机 duel-sync-gate 抓到的那类毛病，一开始就封顶。 */
export const MAX_RECORDS = 50;
/** 每房下注封顶（房内的，随房销毁）。 */
export const MAX_BETS_PER_ROOM = 64;
/** 单笔下注额度：载荷大小由引擎卡（4096 B），额度由包自己卡。 */
export const BET_MIN = 1;
export const BET_MAX = 50;
/** 押进前三的赔付倍数（名次 1/2/3），押空则扣额。 */
export const BET_MULTIPLIER = { 1: 3, 2: 2, 3: 1 };
/** 本包的 id：pack.json 的 id、路由命名空间、通道归属判据都必须是它。 */
export const PACK_ID = 'duel-mode';

/** 本包声明的包通道（必须与 pack.json 的 client.panels[].messages 逐字相同）。 */
export const CHANNELS = ['bets', 'borrow'];

/**
 * 房间集合自门控。`matchClass` 是**进程级**的（server/index.js:294 把已装载包的包装器层层套上，不分房间），
 * 所以每个覆写先看 `this.mods`：没选本包的房间一个分支都不进，与上游逐字节相同。
 * 判据形状照抄维护方给 mod-xie 写的 `isXieRoom`（mods.packs[].id）。
 * @param {{ digest?: string, packs?: Array<{ id?: string }>|null }|null} mods
 */
export function isDuelRoom(mods) {
  return !!(mods && Array.isArray(mods.packs) && mods.packs.some((p) => p && p.id === PACK_ID));
}

/** 把分发进玩家正式奖励（钱/资源）关着：那是数值裁决，改了要重打包。 */
export const APPLY_TO_REWARDS = false;

/**
 * 一房内的人 → 名次。排序键：剩余 LP 降序 → 击杀降序 → 伤害降序 → playerId 字典序（可重现）。
 * 「谁排第几」是本包的映射，不冒充引擎口径；机器人照实参与，因为它也占席位。
 * @param {Array<{ playerId?: string, name?: string, lp?: number, stats?: { kills?: number, dmgDealt?: number } }>} seats
 * @returns {Array<{ id: string, name: string, rank: number, lp: number, kills: number, dmg: number }>}
 */
export function rankSeats(seats) {
  const list = (Array.isArray(seats) ? seats : []).map((s, i) => ({
    id: typeof s?.playerId === 'string' && s.playerId ? s.playerId : 'seat-' + i,
    name: typeof s?.name === 'string' ? s.name : '',
    lp: Number.isFinite(s?.lp) ? s.lp : 0,
    kills: Number.isFinite(s?.stats?.kills) ? s.stats.kills : 0,
    dmg: Number.isFinite(s?.stats?.dmgDealt) ? s.stats.dmgDealt : 0,
  }));
  return list
    .sort((a, b) => (b.lp - a.lp) || (b.kills - a.kills) || (b.dmg - a.dmg) || String(a.id).localeCompare(String(b.id)))
    .map((s, i) => ({ ...s, rank: i + 1 }));
}

/**
 * 一局的席位 → 争锋分。查表，不解释、不外推。
 * `round` 是引擎的波次计数（Match.round）；BASIC_SCORES 按「第 n 期 → 下标 n-1」用 —— 这条映射是本包定的。
 * @param {Array<{ id: string, rank: number }>} ranked
 * @param {number} round
 */
export function scoreRound(ranked, round) {
  const table = EXTRA_SCORES[RANK_TABLE].data;
  const n = Number.isFinite(round) ? round : 0;
  return (Array.isArray(ranked) ? ranked : []).map((s) => {
    const hit = table.find((r) => s.rank >= r.rankMin && s.rank <= r.rankMax);
    return {
      id: s.id, rank: s.rank, round: n,
      base: hit ? Number(hit.tokenNum) || 0 : 0,
      bonus: n > 0 && n <= BASIC_SCORES.length ? Number(BASIC_SCORES[n - 1]) || 0 : 0,
      bets: 0,
    };
  });
}

/**
 * 下注结算：押的人若押中前三，按倍数得分；押空扣等额。纯函数，输入全给。
 * @param {Array<{ by: string, on: string, amount: number }>} bets
 * @param {Array<{ id: string, rank: number }>} ranked
 * @returns {{ deltas: Array<{ by: string, gain: number, won: boolean }>, settled: number }}
 */
export function settleBets(bets, ranked) {
  const byId = new Map((ranked || []).map((r) => [r.id, r.rank]));
  const gain = new Map();
  let settled = 0;
  for (const b of Array.isArray(bets) ? bets : []) {
    if (!b || typeof b.by !== 'string' || typeof b.on !== 'string') continue;
    const rank = byId.get(b.on);
    if (!Number.isFinite(rank)) continue;               // 押的人这局不在席上 ⇒ 不结算（不猜）
    const mult = BET_MULTIPLIER[rank];
    const delta = mult === undefined ? -b.amount : b.amount * mult;
    gain.set(b.by, (gain.get(b.by) || 0) + delta);
    settled += 1;
  }
  return {
    deltas: [...gain.entries()].map(([by, g]) => ({ by, gain: g, won: g > 0 })),
    settled,
  };
}

/** 多条记录 → 榜单：累计分降序、同分按 id。 */
export function standings(records) {
  const byId = new Map();
  for (const r of records || []) {
    for (const line of r.scores || []) {
      const cur = byId.get(line.id) || { id: line.id, total: 0, rounds: 0, best: 0, betGain: 0 };
      cur.total += line.base + line.bonus + (line.bets || 0);
      cur.betGain += line.bets || 0;
      cur.rounds += 1;
      const t = line.base + line.bonus + (line.bets || 0);
      if (t > cur.best) cur.best = t;
      byId.set(line.id, cur);
    }
  }
  return [...byId.values()].sort((a, b) => (b.total - a.total) || String(a.id).localeCompare(String(a.id)));
}

/** 下注载荷判据：形状不对整条拒收（拒收计数进 /healthz，不静默吞）。 */
export function betOf(data) {
  if (!data || typeof data !== 'object') return null;
  const on = typeof data.on === 'string' && data.on ? data.on : null;
  const amount = Number(data.amount);
  if (!on || !Number.isInteger(amount) || amount < BET_MIN || amount > BET_MAX) return null;
  return { on, amount };
}

/** 借干员载荷判据：只认 request / accept / decline 三种动作 + 一个单位 id（request 还要点名向谁借）。 */
export function borrowOf(data) {
  if (!data || typeof data !== 'object') return null;
  const op = data.op;
  if (op !== 'request' && op !== 'accept' && op !== 'decline') return null;
  const unit = typeof data.unit === 'string' && /^[A-Za-z0-9_.:-]{1,48}$/.test(data.unit) ? data.unit : null;
  if (!unit) return null;
  const from = typeof data.from === 'string' && data.from ? data.from : null;
  const to = typeof data.to === 'string' && data.to ? data.to : null;
  if (op === 'request' && !to) return null;             // 没人被点名 ⇒ 这条请求无处应答
  if (op !== 'request' && !from) return null;           // 应答必须点名是谁借的，否则键对不上
  return { op, unit, from, to };
}

/**
 * 借干员的**协商与记账**：request 挂到 pending，accept/decline 由被借的人回，成交进 grants。
 * 台账的键是「谁借 → 向谁借 → 借什么」：request 的发送者就是借的人（playerId = from），
 * 而被点名的人由 data.to 给出；accept/decline 的发送者才是被借的人（playerId = to）。
 * 刻意不动队伍：把单位真的搬进别人阵型要改 Match 内部状态，那是玩法裁决，不随包默认生效。
 */
export function applyBorrow(state, playerId, cmd) {
  if (cmd.op === 'request') {
    const k = String(playerId) + '→' + String(cmd.to) + '→' + cmd.unit;
    if (!state.pending.includes(k) && state.pending.length < MAX_BETS_PER_ROOM) state.pending.push(k);
    state.requests += 1;
    return 'forward';
  }
  const k = String(cmd.from || '?') + '→' + String(playerId) + '→' + cmd.unit;
  if (!state.pending.includes(k)) { state.refused += 1; return 'refused'; }
  state.pending = state.pending.filter((x) => x !== k);
  if (cmd.op === 'accept') {
    if (state.grants.length < MAX_BETS_PER_ROOM) state.grants.push({ at: Date.now(), key: k, unit: cmd.unit, from: cmd.from, to: String(playerId) });
    state.forwarded += 1;
    return 'granted';
  }
  state.forwarded += 1;
  return 'declined';
}

export function registerServer(host) {
  /** @type {Array<{ at: number, roomId: string, round: number, scores: any[], bets: any[] }>} */
  const records = [];
  const counters = { commands: 0, refused: 0, betsSettled: 0, borrowGrants: 0 };

  host.matchClass((Base) => class DuelModeMatch extends Base {
    // 房内的命令台账挂在 Match 实例上 ⇒ 随房销毁，不留全局无界状态。
    __duel() {
      if (!this.__duelState) this.__duelState = { bets: [], pending: [], grants: [], requests: 0, forwarded: 0, refused: 0 };
      return this.__duelState;
    }

    handlePackMsg(playerId, msg) {
      // 归属判据：引擎把**任何包**的 pack.msg 都送进所有包装器，通道名不是命名空间 ⇒ 先认包。
      if (!msg || msg.pack !== PACK_ID) return undefined;
      // 房间没选本包 ⇒ 一个字都不动（不消费、不计数），转发照上游。
      if (!isDuelRoom(this.mods)) return undefined;
      counters.commands += 1;
      const st = this.__duel();
      if (msg.channel === 'bets') {
        const bet = betOf(msg.data);
        if (!bet) { counters.refused += 1; st.refused += 1; return true; }   // 坏载荷不外溢给同房
        if (st.bets.length >= MAX_BETS_PER_ROOM) { counters.refused += 1; st.refused += 1; return true; }
        st.bets.push({ at: Date.now(), by: String(playerId), on: bet.on, amount: bet.amount });
        return undefined;                                  // 不消费：同房都要看到这一注
      }
      if (msg.channel === 'borrow') {
        const cmd = borrowOf(msg.data);
        if (!cmd) { counters.refused += 1; st.refused += 1; return true; }
        const out = applyBorrow(st, String(playerId), cmd);
        if (out === 'granted') counters.borrowGrants += 1;
        if (out === 'refused') counters.refused += 1;
        return undefined;                                // 协商内容要让对方看到，不消费
      }
      return undefined;
    }

    settle(plan, uniteResult) {
      const st = this.__duel();
      const out = super.settle(plan, uniteResult);
      if (!isDuelRoom(this.mods)) return out;           // 没选本包的房间：不记账，结算返回值原样交还
      try {
        const ranked = rankSeats(this.order);
        const scores = scoreRound(ranked, this.round);
        if (scores.length) {
          const bet = settleBets(st.bets, ranked);
          counters.betsSettled += bet.settled;
          for (const line of scores) {
            const d = bet.deltas.find((x) => x.by === line.id);
            if (d) line.bets = d.gain;
          }
          records.push({ at: Date.now(), roomId: String(this.roomCode ?? '-'), round: Number(this.round) || 0, scores, bets: st.bets.slice() });
          while (records.length > MAX_RECORDS) records.shift();
        }
        st.bets = [];
      } catch { /* 记不上榜不影响结算：super 已经走完 */ }
      return out;
    }
  });

  host.route('/mod/duel-mode/standings.json', () => {
    const top = standings(records)[0];
    return {
      pack: 'duel-mode',
      appliedToRewards: APPLY_TO_REWARDS,
      rounds: records.length,
      channels: CHANNELS.slice(),
      scoring: {
        mode: '本包映射：联机房按名次赛（' + RANK_TABLE + '）查表；名次 = 剩余 LP → 击杀 → 伤害 → id',
        basicScoresRounds: BASIC_SCORES.length,
        extraScore: EXTRA_SCORES,
        betMultiplier: BET_MULTIPLIER,
        betRange: [BET_MIN, BET_MAX],
      },
      standings: standings(records),
      lastRound: records.length ? records[records.length - 1] : null,
      borrowGrants: counters.borrowGrants,
      leader: top ? top.id : null,
    };
  });

  host.healthz(() => {
    const top = standings(records)[0];
    return {
      duelModeRounds: records.length,
      duelModeLeader: top ? String(top.id) : null,
      duelModeCommands: counters.commands,
      duelModeRefused: counters.refused,
      duelModeBetsSettled: counters.betsSettled,
      duelModeBorrowGrants: counters.borrowGrants,
    };
  });
}
