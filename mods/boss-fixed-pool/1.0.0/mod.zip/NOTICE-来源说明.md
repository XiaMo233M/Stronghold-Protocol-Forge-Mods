# NOTICE-来源说明

## 原件是什么、从哪来

- **规则原件**：`jingjiangze/stronghold-server`（fork of sganggs/Stronghold-Protocol）此前的
  **固定血量**口径 —— 合并上游前（commit `9a8127d~1`）`data/config.json` 的全局
  `bossHpScale = { perPlayer:false, aliveScaling:true, coop:1, solo:0.25, aliveFull:4 }`：
  协战总池 `bloodPoint × min(alive,4)/4`、单人 `×0.25`。仓库：<https://github.com/jingjiangze/stronghold-server>
- **数据原件**：管理器（Forge）自己的 `data/bosses.json`（10 名领袖的 `bloodPoint` 四档数值，
  即上游口径的基数）。本包不改这份文件，只做**按字段覆盖**（`overrides`）。

## 它改了什么

**没有改引擎，只覆盖了一组数值。** 新口径（`perPlayer:true, solo:1`）把总池改成
`bloodPoint × alive`；本包把每个领袖的 `bloodPoint` 四档全部 ÷4，于是新口径的乘积与旧口径
`bloodPoint × alive/4`（单人 ×0.25）**逐点相同**（推导见 README）。实现方式：

| 件 | 说明 |
|---|---|
| `bosses.json` | 10 条**差量补丁**记录：只写 `bloodPoint`（其余字段不写、原样保留） |
| `pack.json` | `content: ["bosses"]` + `overrides: ["bosses:boss_1", …]`（覆盖官方记录必须显式声明）；`combat: true`（它改对局结果，必须让玩家知情） |

## 做不了的部分

- **改 `config` 里的 `bossHpScale` 开关本身**：`config` 被包格式刻意排除（改的是规则而不是内容）。
  本包不改开关，只改被开关乘的基数 —— 在「跟随上游」的引擎上得到的就是旧口径的总池。
- **只按存活人数动态缩放且保留上游基数的第三口径**：那需要引擎加一格开关，不是数据包能表达的
  （数据包给的是静态数值）。
- **普通敌人 / 隐藏核心 LP / 超时扣血**：不在 `bosses.json` 的这张表内，本包不碰。
- **对局内动态调整**：包不改运行中的对局；改的是开局读表时的基数。

## 素材从哪来

**没有任何素材。** 没有图标、音频、字体、解包数据；只有数字与说明文档。

## 许可

- 本包 **GPL-3.0-or-later**（与 fork / 管理器同族）。
- 《明日方舟》及其素材版权归鹰角网络 / Yostar 所有；本包不含、也不主张任何此类素材。
