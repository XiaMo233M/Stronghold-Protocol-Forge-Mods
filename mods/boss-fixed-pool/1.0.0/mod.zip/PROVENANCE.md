# 署名与来源 · PROVENANCE

> 原作者与兼容改写者**分开列出，不抹掉任何一方**。原件未署名的一律写**「原件未署名」**，不代填；
> 许可照实抄自包内 `pack.json` 的 `license` 字段，未改动。

## 包

| 项 | 值 |
|---|---|
| 包 id | `boss-fixed-pool` |
| 版本 | `1.0.0` |
| 名称 | 领袖固定血量（0.1.x 口径） |
| 目录名 = 包 id | 是 |
| 顶层目录 | `boss-fixed-pool/` |
| 声明 | `combat: true` · `content: ["bosses"]` · `api: ">=1 <2"` · `game: "0.2.x"` |

## 原作者

**`jingjiangze`** —— 见包内 `pack.json` 的 `author` 字段；`NOTICE-来源说明.md` 另把规则原件署名给
`jingjiangze/stronghold-server`（fork of `sganggs/Stronghold-Protocol`）。这两处署名照实抄下，
本次适配**没有改动**。除这两处外，包内没有别的署名（`README.md` 不署名）。

## 许可

`GPL-3.0-or-later`（包内 `pack.json.license` 原文；`NOTICE-来源说明.md` 的「许可」节同）。

## 兼容改写者

`Mo233`

## 来源

站点投稿 `e22986f98b4a`（「领袖固定血量（0.1.x 口径）」）。原件 zip **4,685 字节**，4 个条目，
解压后 7,430 字节，sha256（zip）`311cc34df1d7908181941af651097a20badc372f72eac5ed07e4c79f6bab0585`
（源文件全程只读，未改动一个字节）。

## 改了什么

**原件一个字节都没改。** 4 个文件逐字节相同（哈希见文末），本次适配只补了本文件
（`PROVENANCE.md`），并确认包根形状。

1. **包根形状**：装载器按 `<workshop 根>/<包 id>/pack.json` 找包，所以发布时包必须落在
   `boss-fixed-pool/` 这一层（顶层目录 = 包 id）。`pack.json` 本来就在包根，无需改动。
2. **补 `PROVENANCE.md`**：本文件。
3. **契约核对**：`api` 已是 `">=1 <2"`，与引擎 `MOD_API_VERSION = 1` 相符；`game: "0.2.x"` 相符。
   两项都无需改动。

## 告知义务（`combat: true`，会改对局结果）

**包内已经标清楚了，我们没有改作者的文件。** 原文逐字如下：

- `README.md` 第 3–4 行：「**这是一个真功能的包**：装上它，「最终攻势／隐藏核心」的共享领袖总生命回到
  **0.1.x 的固定血量口径** —— 领袖不随存活人数线性膨胀，人少了领袖就弱。**它会改变对局结果**
  （`combat: true`），装了它的房间不能与官方口径逐帧比较。」
- `NOTICE-来源说明.md` 的表格里也写了 `combat: true`（它改对局结果，必须让玩家知情）。

结论：**「会影响对局结果」已在包内明示，无需补写**；本节只是把我们这一侧的告知记录成文（写在**我们自己的**
`PROVENANCE.md` 里，作者文件一字未动）。

## 数值核对（本次实测，引擎 `0.15.0` / `MOD_API_VERSION 1`）

判定口径取自引擎自己：`server/match/gamedata.js` 的 `bossPoolShareOf()` 与 `bossPoolHp()`
（后者 = `Math.max(1, Math.round(base * share))`，取整**只有一处**，发生在乘完 `share` 之后）。

- `data/bosses.json` 恰 **10 条**记录（`boss_1`…`boss_10`），包的 `overrides` 恰是这 10 条，
  每条**只写 `bloodPoint` 一个字段** ⇒ 其余字段（`bossId`/`enemyKey`/`name`/`sortId`/`weight`/
  `hidden`/`lpr`/`templates`/`escortsByTemplate`/`parts`/`abilities`）由字段级合并原样保留。
- **40 个 `bloodPoint` 值（10 领袖 × 4 档）实测全部 = 上游值 ÷4，无一处例外。**
- **取整点**：协战 `N = min(存活, 4)` 人时，本包 `round((base/4) × N)` 与旧口径 `round(base × N/4)`
  在 N=1..4、10 领袖 × 4 档共 160 个组合上**逐一相同**；单人 `round((base/4) × 1)` 与旧口径
  `round(base × 0.25)` 同样逐一相同。（`/4` 与 `× 0.25` 都是二进制精确运算，`base`、`base × N` 均为
  `< 2^53` 的整数或 .5，两侧都是同一条有理数，不存在第二个取整点。）
- **两处非整数商**：`boss_3`、`boss_4` 的 `NORMAL` = `708750 / 4 = 177187.5`（上游 708750）。
  小数**原样保留**，引擎读到的是 177187.5，不是先取整的 177188 —— 这正是取整点一致的前提。
- **只改这一组数**：合并前后逐字段 diff，除 `bloodPoint` 外无任何字段变化；`data/*.json` 磁盘文件一个字节不改。

## 删包即回上游口径（机制）

包的覆盖是**装载期叠加**，不落盘：`server/data.js` 的 `loadData(dir, { workshopDir })` 在读取
`data/*.json` 之后，才把工坊包里声明过 `overrides` 的记录按字段合并进内存。因此删掉
`workshop/boss-fixed-pool/`（或从房间包集合里去掉）后，下一次 `loadData` 拿到的就是上游
`bosses.json` 原值与全局 `config.bossHpScale = { perPlayer: true, coop: 1, solo: 1, aliveFull: 4 }`
的按人头口径 —— **「删包回上游」是装载器本身的性质，不需要卸载脚本，也不需要还原备份**。
（引擎的 `config.bossHpScale.formula` 字段自己写着 `perPlayer: false` 即 0.1.x 的「保持固定血量」；
本包不改开关，只改被开关乘的基数。）

## 自带素材来源

**无。** 包内只有数字与说明文档，没有任何图片 / 音频 / 字体 / 解包数据。

## 校验用哈希（改动前 = 原件 / 改动后）

| 文件 | 字节 | 改动前 sha256（= 原件） | 改动后 sha256 |
|---|---|---|---|
| `pack.json` | 1062 | `aef1157d1b34c71964edc3643d4dc3926139e27b9e6a95e45aadb180c88c7f7c` | **同左（未改）** |
| `bosses.json` | 1185 | `464d8d930ea0865e5eba2b7b3aac61204ffe77c4135458e7bb5047245b5160f6` | **同左（未改）** |
| `README.md` | 2831 | `2da1ed1be3c07e5aa59d5c1450051aa0737c931eb49d875cf0a1da494d76736b` | **同左（未改）** |
| `NOTICE-来源说明.md` | 2352 | `8d0de05817009ae3fa79a115500f5c362e5ffb95235c0e73da2788bf9841e72e` | **同左（未改）** |

`PROVENANCE.md` 是本次新增（不参与上表）。成品 zip 自己的字节数与 sha256 **刻意不写进包里**：
包里文本一变，包含它的那个 zip 的摘要就跟着变，写进去必然自相矛盾 —— 那两个数记在交付索引
`../CHECKSUMS.txt`。
