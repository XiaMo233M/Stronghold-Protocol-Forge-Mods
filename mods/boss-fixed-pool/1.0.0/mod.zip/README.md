# 领袖固定血量（0.1.x 口径）

**这是一个真功能的包**：装上它，「最终攻势／隐藏核心」的共享领袖总生命回到 **0.1.x 的固定血量口径** ——
领袖不随存活人数线性膨胀，人少了领袖就弱。**它会改变对局结果**（`combat: true`），装了它的房间不能与官方口径逐帧比较。

## 它改了哪一处（只有一个数）

对官方 `bosses.json` 的 10 名领袖做**按字段覆盖**：`bloodPoint` 的四档难度（FUNNY/NORMAL/HARD/ABYSS）
全部 **÷4**（4 = `aliveFull`）。其余一切字段（`templates` / `lpr` / `weight` …）原样保留，技能、时序、
赏金、结算一律不动。

## 为什么这一除就等于旧口径（可核对）

| 口径 | 总池公式（协战，`coop: 1`） | 单人 |
|---|---|---|
| 0.1.x「保持固定血量」（fork 合并上游前：`perPlayer:false, aliveScaling:true, solo:0.25`） | `bloodPoint × min(alive,4) / 4` | `bloodPoint × 0.25` |
| 上游新口径（`perPlayer:true, solo:1`） | `bloodPoint × alive`（≤4） | `bloodPoint × 1` |
| **本包**（新口径引擎 × 补丁后的 `bloodPoint/4`） | `(bloodPoint/4) × alive` = `bloodPoint × alive/4` | `(bloodPoint/4) × 1 = 0.25 × bloodPoint` |

两列逐点相同；引擎在总池处做 `Math.round(base × share)`，取整点相同 ⇒ 逐局结果一致。
两处非整数商（`boss_3`/`boss_4` 的 NORMAL：`708750/4 = 177187.5`）故意保留小数 —— 取整发生在乘完
存活数之后，`Math.round(177187.5 × N)` 与旧链 `Math.round(708750 × N / 4)` 是同一条表达式。

## 为什么用「覆盖包」而不是改配置

这条规则的开关在 `data/config.json` 的 `bossHpScale`（引擎配置），而 **`config` 被工坊包格式刻意排除**
（`docs/WORKSHOP.md` §1.1：能改写经济的包改的是规则而不是内容）。覆盖 `bosses.json` 的记录字段是包格式里
唯一能合法、显式地把这组数值带进对局的通道 —— 所以这是「提供另一种口径」的诚实做法，而不是绕开审查。

## 边界

- **只对最终领袖池生效**：普通敌人不读这张表；`enemyScale`、隐藏核心 LP、超时扣血不在覆盖范围内。
- **上游默认**：删掉本包即回到 `aliveFull` 的按人头口径，数据即时还原（磁盘上的 `data/*.json` 一个字节不改）。
- **同房间两端一致**：包字节进房间摘要，房间声明了集合时只有双方持有同一份时才能开局 —— 不存在「只有一半人装了」。

## 安装

拷进管理器的工坊目录（`workshop/boss-fixed-pool/`）并重启；或在包管理里导入 zip。
装没装上，可在开局前用房间的包集合摘要核对；对局里看领袖开场总生命（4 人满编时与旧版一致，2–3 人时明显更低）。
