# 署名与来源 · PROVENANCE

> 本文件由**交付流程**在拆包时生成，随包分发。原作者与改写者**分开显示，不抹掉任何一方**。
> 原件未署名的一律写**「原件未署名」**，不代填名字；许可**照实抄**，包括非 SPDX 的值。

## 包

| 项 | 值 |
|---|---|
| 包 id | `mod-xie` |
| 版本 | `2.0.0` |
| 名称 | 促融共竞 · 协同共竞 |
| 目录名 = 包 id | 是（引擎逐包判 `PACK_ID_MISMATCH`，不一致会被拒） |
| 本包实测规模 | 13 个文件 / 182585 字节（不含本文件） |

## 原作者 / 上游

**jingjiangze** —— 原件 `pack.json.author` 原文，照实抄录。

- 上游：促融共竞经济玩法

## 许可（照实抄）

原件 `pack.json.license` 原文，逐字抄录：`GPL-3.0-or-later`

## 责任人

| 角色 | 是谁 |
|---|---|
| 原作者 | jingjiangze |
| 本版兼容改写者 | Mo233（工坊包通道改写 / 按中间层重写；本包具体改写点见下节） |
| 本包交付 | 第三方 mod 兼容交付流程，2026-10-11 |

## 来源

- 原件：E:\destop\mod\5ab25ef07906-促融共竞经济玩法.zip
- 交付形态：工坊包（workshop pack）· 包契约 **MOD_API_VERSION 1**（据此判能否装载）· 打包时工作树 `3396438a` 的 APP_VERSION 为 0.14.0（该号只表示发行版，不参与包兼容判定；交付后 HEAD 已推进到 `d46cfdaa` / APP_VERSION 0.15.0，MOD_API_VERSION 仍为 1，本轮已在该 HEAD 上复测通过）

## 改了什么

- 原件**装不上**的原因：原件在 `server.modules[0]` 里写了 `"channels": [...]`，而引擎的模块字段是**闭集** `id / entry / uses / write` ⇒ 判 `MODULES_UNKNOWN_FIELD` 并**点名拒绝整包**（实测）。
- 改写：删掉那条引擎不认识的 `channels` 声明；`server/mod.mjs` 3 行调整；`README.md` 与 `test/module.test.mjs` 改写。
- **13 个文件里 9 个与原件逐字节相同**（含 `client/econ.js`、`data/` 全部、`server/` 其余 5 个）。

## 自带素材来源

- **不带任何素材。**

## 备注 / 边界

- **必须点名的功能缺口**：本包的玩法价值依赖「服务端模块 → 客户端面板」的**任意通道投递**。引擎目前只有 `client.panels[].messages` 的**声明位**，没有让服务端模块投递任意通道的接口（`server/mod.mjs` 自己的注释写着「引擎也不会投」）。所以**包能装载、面板声明合法，但借调 / 救援 / 后勤项目这五个通道的业务消息能否真的送达面板，是引擎侧待补的接口**。删掉的 `channels` 是引擎不认识的重复声明 —— 源码里 `XIE_CHANNELS` 常量仍在。

## 包内其它署名 / 来源文件

- `README.md`（改写说明与边界）
- `docs/economy.md`（原件经济玩法文档）

## 校验

- 本包**单独**装载于干净的 workshop 根（根内只有这一个包）：见交付索引 `../../INDEX.md` 的 8 条原始输出。
- 校验器：`node tools/workshop-validate.mjs`；装载器：`server/workshop.js loadWorkshop`。

---

*English summary: this pack is a compatibility conversion delivered for Mo233. The original
author and the compatibility rewriter are listed separately above; where the original was uncredited it is
stated as "原件未署名 (uncredited original)" rather than being invented. The licence text is copied verbatim
from the original. See the Chinese sections above for the exact source, the list of changes, and the origin
of any bundled assets.*
