// mod-xie/test/module.test.mjs — 包的服务端那一半：房间自门控、规则派生、通道 → 对局（借用/应答/债务）、
// 以及本轮审计 P2 那三条规则修正。
//
// 怎么跑：在**管理器树**里 `node --test mod-xie/test/module.test.mjs`（本文件用相对路径导入引擎的 shared/，
// 因为规则解析器住在那里；包本身不 import 引擎，test 可以）。
//
// 用**假对局**（一个最小宿主）而不是真 Match：这一层要断言的是「接缝挂上了没有、通道映射对不对、状态改没改」，
// 真 Match 的回合调度会把这三件事淹掉。真服务的端到端在 mod-xie 的装载验收（test/modxiePackLoads）与
// 管理器侧 test/modMatchChannels.test.mjs 里。
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { registerServer, isXieRoom, XIE_CHANNELS, PACK_ID } from '../server/mod.mjs';
import { rulesForDifficulty, teamEconomyOf, revivalOf } from '../server/rules.mjs';

/** 一条本包通道消息的最小形状（平台转发的原样载荷：`pack` + `channel` + 可选 `data`）。 */
const packet = (channel, data) => ({ pack: PACK_ID, channel, ...(data === undefined ? {} : { data }) });

/** 装上包装器并拿到子类（registrar 是同步的：host.matchClass(fn) 立刻把 fn(Base) 交回来）。 */
function subclassOf(Base) {
  let cls = null;
  registerServer({ matchClass: (fn) => { cls = fn(Base); } });
  return cls;
}

/** 最小宿主：假 Base 提供（虚拟的）引擎面，够经济与救援的法律路径跑起来。 */
function makeHost({ modRoom = true } = {}) {
  class FakeBase {
    constructor(opts) {
      this.mods = opts.mods || null;
      this.difficulty = opts.difficulty || 'NORMAL';
      this.seed = 1234;
      this.round = 1;
      this.phase = 'PREP';
      this.order = [];
      this.players = new Map();
      this.lastResults = new Map();
      this.uniteResultView = null;
      this.disposed = false;
      this.ended = false;
      this.gd = { lpCapPerRound: 3, leftoverKeptBands: [], lastRound: 14, bossRound: 8, hiddenRound: 15, income: (r) => 5 + Math.max(0, Number(r) || 1) };
      this.toasts = [];
      this.timers = [];
      this.sched = { now: () => 1000 };
      this.uid = 0;
    }
    // ---- 引擎面（虚拟）
    alivePlayers() { return [...this.players.values()].filter((p) => p.alive); }
    toast(ps, kind, text) { this.toasts.push({ playerId: ps && ps.playerId, kind, text }); return { ok: true }; }
    tickerText(text) { return { ok: true, text }; }
    later(fn, ms) { this.timers.push({ fn, ms }); return this.timers.length; }
    cancel() { return true; }
    markPrivate() { return true; }
    markPublic() { return true; }
    flush() { return true; }
    reportError(where, e) { this.reported = this.reported || []; this.reported.push({ where, message: e && e.message }); }
    nextUid() { return `u${++this.uid}`; }
    start() { this.started = true; return { ok: true }; }
    startRound(r) { this.superRounds = (this.superRounds || []).concat(r); return { ok: true }; }
    endPrep() { return { ok: true }; }
    settle(plan, res) { return { ok: true }; }
    afterSettle() { return { ok: true }; }
    handle() { return { ok: true }; }
    _quit() { return { ok: true }; }
    scheduleBotPrep() { return { ok: true }; }
    publicView() { return { players: [...this.players.keys()].map((playerId) => ({ playerId })) }; }
    addFunds() { return true; }
    // ---- 工具
    seat(playerId, funds = 5, extra = {}) {
      const match = this;
      const ps = {
        playerId, name: playerId, m: match, gd: match.gd,
        alive: true, left: false, isBot: false, ready: false,
        funds, pendingFunds: 0, lp: 10, bandId: null, deployCount: 0,
        shop: { level: 1, freeRefreshes: 0 },
        addFunds(n) { this.funds += n; },
        dirty() { return true; },
        privateView() { return { t: 'm.private', playerId: this.playerId }; },
        eliminate() { this.eliminated = true; return { ok: true }; },
        setReady(on) { this.ready = !!on; return { ok: true }; },
        ...extra,
      };
      this.players.set(playerId, ps);
      this.order.push(ps);
      return ps;
    }
  }
  const Sub = subclassOf(FakeBase);
  const match = new Sub({ difficulty: 'NORMAL', mods: { digest: 'x'.repeat(64), packs: modRoom ? [{ id: 'mod-xie' }] : [{ id: 'other' }] } });
  return { match, Sub };
}

test('房间自门控：普通房间（集合里没有本包）一个分支都不进', () => {
  const { match } = makeHost({ modRoom: false });
  assert.equal(isXieRoom(match.mods), false);
  match.start();
  assert.equal(match.__xieReady, false, '没有武装');
  assert.equal(match.teamEcon ?? null, null, '没有经济规则集');
  match.seat('p1');
  match.startRound(1);
  assert.deepEqual(match.superRounds, [1], '直通 super');
  match.handlePackMsg('p1', packet('borrow', { to: 'p2', amount: 1 }));
  assert.equal(match.econRequests ?? null, null, '通道消息不进（没有经济容器）');
});

test('促融共竞房间：规则从难度派生（官方记录不复制），席位被包装', () => {
  const { match } = makeHost();
  match.seat('p1').ready = false;
  match.seat('p2');
  match.start();
  assert.equal(match.__xieReady, true);
  assert.equal(match.teamEcon.transfer.maxPerRequest, 1, '规则块到达解析器');
  assert.equal(match.teamEcon.transfer.requestsPerRound, 4);
  assert.equal(match.teamEcon.transfer.teamCapPerRound, 8);
  assert.deepEqual(Object.keys(match.teamEcon.projects).sort(), ['logistics', 'storehouse'], '这个模式只开这两个项目');
  assert.equal(match.revivalRuleInit.minDonorLp >= 2, true, '救援规则集解析出来了');
  assert.equal(typeof match.econInit, 'function', '经济容器装上了（子类原型）');
  assert.equal(typeof match.revivalInit, 'function');
  assert.equal(match.players.get('p1').eliminate.__xieWrapped ?? true, true);
  assert.equal(match.players.get('p1').__xieWrapped, true, '席位被包装（淘汰/私有视图/…）');
  const priv = match.players.get('p1').privateView();
  assert.ok(priv.econ, '私有视图带 econ（HUD 的能力探针）');
  const pub = match.publicView();
  assert.ok('econ' in pub && 'revival' in pub, '公开视图带两个探针键');
});

test('通道 → 对局：借钱（borrow）与应答（answer）真的改资金、落下债务', () => {
  const { match } = makeHost();
  match.seat('p1', 1);
  match.seat('p2', 9);
  match.start();
  match.startRound(1);                                   // arm + 还债（第一回合没有债务）

  match.handlePackMsg('p1', packet('borrow', { to: 'p2', amount: 1 }));
  assert.equal(match.econRequests.size, 1, '请求落在对局里');
  const [id, req] = [...match.econRequests.entries()][0];
  assert.equal(req.from, 'p1');
  assert.equal(req.to, 'p2');
  assert.equal(req.amount, 1);

  match.handlePackMsg('p2', packet('answer', { id, approve: true }));
  assert.equal(match.players.get('p1').funds, 2, '借到的钱到了借款人手里');
  assert.equal(match.players.get('p2').funds, 8, '出借人扣了 1');
  const debts = match.econDebts.get('p1') || [];
  assert.equal(debts.length, 1, '债务账本记了这笔（方案 B：下一回合收入里还）');
  assert.equal(match.econRequests.size, 0, '请求消费掉就不在了');
  assert.equal(match.econCoverRate('p1'), 0, '兜底分红在包化第一版恒为 0（shim；账本不受影响）');

  // 还债：下一回合的 startRound 末尾把债务清掉
  match.round = 2;
  match.startRound(2);
  assert.equal((match.econDebts.get('p1') || []).length, 0, '收入到手即还款');
  assert.ok(match.players.get('p2').funds >= 9, '出借人拿回了钱');
});

test('没声明的通道与守卫：不改状态、不抛异常', () => {
  const { match } = makeHost();
  match.seat('p1');
  match.seat('p2');
  match.start();
  match.handlePackMsg('p1', packet('nope', {}));
  match.handlePackMsg('p1', packet('revive', { round: 1, playerId: 'p2' }));  // 窗口没开 → 规则拒绝，不抛
  match.handlePackMsg('p2', packet('borrow', { to: 'p1', amount: 1 }));       // p2 是真实席位，合法
  assert.equal(match.reported ?? null, null, `不该有 reportError（${JSON.stringify(match.reported)}）`);
  assert.deepEqual(XIE_CHANNELS.length, 5);
});

test('别的包的通道消息不认领（钩子是进程级的）', () => {
  const { match } = makeHost();
  match.seat('p1', 1);
  match.seat('p2', 9);
  match.start();
  match.startRound(1);
  // 另一个包声明了同名通道（`client.panels[].messages` 只查名字，不查跨包唯一）——
  // 平台会把它投到这里，但 `pack` 不是本包 ⇒ 不消费、也不改任何状态。
  const other = { pack: 'someone-else', channel: 'borrow', data: { to: 'p2', amount: 1 } };
  assert.notEqual(match.handlePackMsg('p1', other), true, '别的包的消息：原样放行（false ⇒ 平台照常转发）');
  assert.equal(match.econRequests.size, 0, '且不改状态');
  // 没有 `pack` 字段的消息同样不认领（真平台总会填，这条守的是「判据在包自己手里」）。
  assert.notEqual(match.handlePackMsg('p1', { channel: 'borrow', data: { to: 'p2', amount: 1 } }), true);
  assert.equal(match.econRequests.size, 0);
});

test('命令通道被消费（不再广播），身份只认平台给的 playerId', () => {
  const { match } = makeHost();
  match.seat('p1', 1);
  match.seat('p2', 9);
  match.start();
  match.startRound(1);

  // 载荷里自称的身份不作数：from / seat / playerId 全是伪造值，请求的 from 仍是 ps.playerId
  const consumed = match.handlePackMsg('p1', packet('borrow', { to: 'p2', amount: 1, from: 'p2', seat: 3, playerId: 'p2' }));
  assert.equal(consumed, true, '命令通道返回 true = 平台不广播');
  const [, req] = [...match.econRequests.entries()][0];
  assert.equal(req.from, 'p1', '发起人来自平台给的 playerId（伪造的 from 不作数）');
  assert.equal(req.to, 'p2');

  // 观战者：不在 players 里 ⇒ 消费掉但什么也不做
  const before = match.econRequests.size;
  assert.equal(match.handlePackMsg('spec1', packet('borrow', { to: 'p2', amount: 1 })), true, '观战者的命令同样消费');
  assert.equal(match.econRequests.size, before, '且不改状态');

  // 没声明的通道：不自称消费（平台层本来就会拒它）
  assert.notEqual(match.handlePackMsg('p1', packet('nope', {})), true);
});

test('审计 P2 的规则修正：空 projects 块 = 一个都不开；救援成本钳到 minDonorLp - 1', () => {
  const withEmpty = teamEconomyOf({ mode: { teamEconomy: { enabled: true, projects: {} } } });
  assert.deepEqual(Object.keys(withEmpty.projects), [], '显式的空块不再回落成默认集');
  const noBlock = teamEconomyOf({ mode: { teamEconomy: { enabled: true } } });
  assert.ok(Object.keys(noBlock.projects).length > 0, '整个键缺席才用默认集');

  const clamped = revivalOf({ mode: { revival: { enabled: true, cost: 30, minDonorLp: 11 } } });
  assert.equal(clamped.minDonorLp, 11);
  assert.equal(clamped.cost, 10, 'cost >= minDonorLp 的配置被确定性钳制，捐赠后至少留 1 LP');
  const normal = revivalOf({ mode: { revival: { enabled: true, cost: 10, minDonorLp: 11 } } });
  assert.equal(normal.cost, 10, '合法配置原样通过');

  for (const d of ['FUNNY', 'NORMAL', 'HARD', 'ABYSS']) {
    const r = rulesForDifficulty(d);
    assert.equal(typeof r.transferDesc, 'string', `${d}: 展示文案由同一份数字生成（audit P2）`);
    assert.match(r.transferDesc, new RegExp(`最多借调 ${r.teamEconomy.transfer.maxPerRequest} 资金`));
  }
});
