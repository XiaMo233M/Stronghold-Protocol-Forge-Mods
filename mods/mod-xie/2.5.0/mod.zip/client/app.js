// mod-xie/client/app.js —— 促融共竞的**首页入口**（「未做 mod 兼容」那一版的按钮 + 开房页）。
//
// 业主 2026-10-13：「先不加入 mod 管理器，仅保留促融共竞（还原之前未做 mod 兼容包的首页按钮）」。
// 所以这里只放**入口**：标题屏 / 协议选择屏上的「协同共竞」按钮 + 它的开房页（四档难度 / 创建房间 / 加入同盟）。
// 逐段搬自 `C:\DDDD\Agent Work\stronghold-mod-xie\client\{runtime.mjs,xieRoom.js,mod.css}`（v1）。
//
// **局内经济 UI 不在这里** —— 它装在**引擎**里（`public/js/ui/borrowPlate.js` / `revivePlate.js` / `econBar.js`
// / `shopBar.js` 的 `EconStrip`，与 fork master-play 逐字相同），由 `screens/game.js` 挂进 HUD。
//
// 这个文件同时是**包通道的登记处**：服务端只放行「某个面板的 `messages` 声明过」的通道
// （`server/workshop.js` 的 `MODULES_UNKNOWN_CHANNEL` 判据），而 `pack.msg` 是界面与对局之间唯一的入口。
//
// 装载：`pack.json.client.panels[]` 声明本文件为 `root.overlays` 面板 —— 那只是**加载钩子**（`/workshop-panels/`
// 是一张白名单 map，只有登记过的 URL 可服务）；界面画在包自己的 `#modxie-root`（body 级 fixed 层）。

import { render } from 'preact';
import { useState } from 'preact/hooks';
import { html, Button, MicroLabel, Panel, TextField, Spinner } from '/js/ui/components.js';
import { store, useStore, selectRoute } from '/js/store.js';
import { net } from '/js/net.js';
import * as roomMods from '/js/roomMods.js';
import { DIFFICULTIES, DIFFICULTY_NAMES, ROOM_CODE_LEN } from '/shared/constants.js';
import { t } from '/shared/i18n.js';

/** 本包 id（`pack.msg` 的 `pack` 字段）。 */
const PACK_ID = 'mod-xie';

/** 本包在用的通道（与 `pack.json.client.panels[].messages`、`server/mod.mjs` 的 `XIE_CHANNELS` 逐字一致）。 */
export const CHANNELS = Object.freeze(['borrow', 'answer', 'project', 'vote', 'relief', 'revive']);

const CODE_RE = new RegExp(`^[A-Z0-9]{${ROOM_CODE_LEN}}$`);
const normalizeCode = (v) => String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, ROOM_CODE_LEN);

/** Leave the MOD's page (back to the title / lobby). */
export const closeXie = () => store.set((s) => ({ ui: { ...s.ui, xieRoom: false } }));

/**
 * 建房载荷：v1 发的是 `{ mode:'coop', difficulty, variant:'xie' }` —— `variant` 在今天的协议里**不存在**，
 * 房间「跑不跑促融共竞」由**房间集合**决定（`room.create.modIds`，`server/mod.mjs` 的 `isXieRoom`）。
 * 所以改调引擎自己的 `roomMods.buildCreatePayload`（与大厅那颗建房按钮同一个函数），再保证 `mod-xie` 在集合里。
 * 界面（难度档、按钮、文案）一字未动。
 */
function createFields(difficulty) {
  const base = typeof roomMods.buildCreatePayload === 'function'
    ? roomMods.buildCreatePayload('coop', difficulty)
    : { mode: 'coop', difficulty };
  const ids = Array.isArray(base.modIds) ? base.modIds.slice() : null;
  if (ids && !ids.includes(PACK_ID)) ids.push(PACK_ID);
  return ids ? { ...base, modIds: ids } : base;
}

/** 协同共竞's entry on the title screen — a DOM node of the MOD's own. */
function TitleEntry() {
  return html`<button type="button" class="modxie-entry" onClick=${() => store.set((s) => ({ ui: { ...s.ui, xieRoom: true } }))}>
    ${t('协同共竞')}
  </button>`;
}

/** 开房页（v1 `client/xieRoom.js`，逐字搬运）。 */
function XieRoom({ online }) {
  const [difficulty, setDifficulty] = useState('NORMAL');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(null);
  const [note, setNote] = useState(null);

  const run = async (kind, fn) => {
    if (busy) return;
    setBusy(kind); setNote(null);
    try { await fn(); } catch (e) { setNote(String((e && (e.detail || e.message)) || t('操作被拒绝'))); }
    finally { setBusy(null); }
  };
  const create = () => run('create', () => net.request('room.create', createFields(difficulty)));
  const join = () => {
    const k = normalizeCode(code);
    if (!CODE_RE.test(k)) { setNote(t('同盟密钥为 {n} 位字母或数字', { n: ROOM_CODE_LEN })); return; }
    run('join', () => net.request('room.join', { code: k }));
  };

  return html`<div class="modxie">
    <div class="modxie__panel">
      <div class="modxie__head">
        <b>${t('协同共竞')}</b>
        <button type="button" class="modxie__x" aria-label=${t('返回')} onClick=${closeXie}>×</button>
      </div>
      <p class="modxie__note">${t('同盟模拟之上加入「借钱」：休整期可与队友借调资金，其余规则与原版完全一致。')}</p>

      <div class="modxie__label">${t('模拟难度')}<${MicroLabel}>DIFFICULTY<//></div>
      <div class="modxie__diffs">
        ${DIFFICULTIES.map((d) => html`<button key=${d} type="button"
          class=${`modxie__diff${difficulty === d ? ' is-on' : ''}`} onClick=${() => setDifficulty(d)}>${t(DIFFICULTY_NAMES[d])}</button>`)}
      </div>

      <${Button} variant="primary" size="lg" block=${true} loading=${busy === 'create'} disabled=${!online} onClick=${create}>
        ${t('创建房间')}
      <//>

      <div class="modxie__label">${t('加入同盟')}<${MicroLabel}>JOIN WITH ALLIANCE KEY<//></div>
      <${Panel} class="modxie__join">
        <div class="modxie__row">
          <${TextField} size="code" value=${code} placeholder=${t('输入同盟密钥 / 粘贴邀请链接')}
            transform=${normalizeCode} onInput=${(v) => setCode(normalizeCode(v))} onEnter=${join} />
          <${Button} variant="amber" size="lg" loading=${busy === 'join'} disabled=${!CODE_RE.test(code) || !online} onClick=${join}>${t('加入同盟')}<//>
        </div>
      </${Panel}>
      ${note ? html`<div class="modxie__err">${note}</div>` : null}
      ${online ? null : html`<div class="modxie__err"><${Spinner} size="sm" /> ${t('正在连接服务器…')}</div>`}
    </div>
  </div>`;
}

function ModApp() {
  const route = useStore((s) => selectRoute(s));
  const xie = useStore((s) => !!s.ui?.xieRoom);
  const online = useStore((s) => s.connection?.status === 'online');
  if (xie) return html`<${XieRoom} online=${online} />`;
  // 标题屏 / 协议选择屏都有入口（回来的人第一屏是「选择模拟协议」= lobby）。
  if (route === 'title' || route === 'lobby') return html`<${TitleEntry} />`;
  return null;
}

/** v1 `client/mod.css` 里入口与开房页那一段（逐字搬运；局内那一段现在归引擎的 game-shop.css）。 */
const CSS = `
#modxie-root { position: fixed; inset: 0; pointer-events: none; z-index: 200; }
#modxie-root > * { pointer-events: auto; }
.modxie-entry { position: absolute; left: 50%; bottom: 0.9rem; transform: translateX(-50%); padding: .08rem .28rem;
  border: 1px solid #f6a329; border-radius: .1rem; background: rgba(8, 11, 10, .9); color: #f6a329;
  font-size: .2rem; letter-spacing: .16em; cursor: pointer; }
.modxie-entry:hover { background: rgba(246, 163, 41, .16); }
.modxie { position: absolute; inset: 0; display: grid; place-items: center; background: rgba(6, 9, 8, .88); }
.modxie__panel { width: min(7.2rem, 92vw); max-height: 88vh; overflow: auto; padding: .28rem .32rem; display: flex; flex-direction: column; gap: .14rem;
  background: linear-gradient(180deg, rgba(20, 26, 24, .98), rgba(10, 14, 12, .98)); border: 1px solid var(--line-2, #3a4a44); border-radius: .12rem; }
.modxie__head { display: flex; align-items: center; justify-content: space-between; font-size: .24rem; color: #f6a329; letter-spacing: .16em; }
.modxie__x { border: 0; background: none; color: #8fa29a; font-size: .3rem; cursor: pointer; line-height: 1; }
.modxie__note { margin: 0; font-size: .16rem; line-height: 1.5; color: #a9b8b2; }
.modxie__label { display: flex; align-items: baseline; gap: .1rem; color: #dfe7e4; font-size: .18rem; }
.modxie__diffs { display: grid; grid-template-columns: repeat(4, 1fr); gap: .1rem; }
.modxie__diff { padding: .1rem 0; border: 1px solid var(--line-2, #3a4a44); border-radius: .08rem; background: none; color: #dfe7e4; font-size: .18rem; cursor: pointer; }
.modxie__diff.is-on { border-color: #f6a329; color: #f6a329; }
.modxie__join { padding: .16rem; }
.modxie__row { display: flex; gap: .12rem; align-items: center; }
.modxie__err { font-size: .16rem; color: #ff8a6b; }
`;

function injectCss(doc) {
  if (!doc || doc.getElementById('modxie-css')) return;
  const st = doc.createElement('style');
  st.id = 'modxie-css';
  st.textContent = CSS;
  (doc.head || doc.documentElement).appendChild(st);
}

/**
 * 面板挂载点。声明它的**唯一**目的是让引擎把这份代码加载进来（见文件头）；界面画在包自己的 `#modxie-root` 上。
 * @param {{ host: any, log?: any }} ctx
 */
export function mount(ctx) {
  const doc = ctx?.host?.ownerDocument || globalThis.document;
  if (!doc || !doc.body) return null;
  injectCss(doc);
  let root = doc.getElementById('modxie-root');
  if (!root) {
    root = doc.createElement('div');
    root.id = 'modxie-root';
    doc.body.appendChild(root);
  }
  render(html`<${ModApp} />`, root);
  // leaving the MOD's page when a room is actually entered (so the page does not sit over the room screen)
  const off = store.subscribe((s) => { if (s.ui?.xieRoom && s.room) closeXie(); });
  return {
    unmount() {
      try { if (typeof off === 'function') off(); } catch { /* 收摊不该抛 */ }
      try { render(null, root); } catch { /* 已经拆了 */ }
      root.remove();
    },
  };
}
