# 来源与署名（PROVENANCE）

## 原件叫什么、从哪来
- **服务器**：`https://wei.isomer319.xyz/` 与 `https://sp.isomer319.xyz/`（卫戍协议：盟约 · 社区节点，app 0.2.5，build `65d466263d53` / `af19a581bee4`）
- **原件证据**：两节点的 `/healthz` 响应里都带一段引擎没有的 `node` 节：
  ```json
  "node":{"observedAt":1791836598060,"cpuPercent":8,"memoryPercent":68,
          "loopLagMs":0,"pressure":"low","voice":true}
  ```
- **客户端读者**：`_v024/shared/serverSelection.js`（`normalizeNodeStatus` / `pressureLevel` / `recommendNode`）
- **取证时间**：2026-10-13

## 原作者是谁
- 上游：`sganggs/Stronghold-Protocol`（GPL-3.0-or-later）
- isomer 节点维护者：目录站 `wei.isomer319.xyz/api/servers` 标注 **Wiš'adel**（一服）/ **凑鹈鹕**（四服）
- 打包：jingjiangze

## 原件的许可
GPL-3.0-or-later（随上游）。本包**不照抄其代码**，只按同一套阈值判据重写为工坊包形状。

## 它改了什么
| 能力 | 来源 | 本包实现 |
|---|---|---|
| `pressure` 三档阈值 | isomer `shared/serverSelection.js:15-20` | `pressureLevel()` 逐字复刻同一套阈值 |
| `cpuPercent` / `memoryPercent` / `loopLagMs` | isomer 服务端自采 | **不自己采**，取引擎 `hostMetrics` 快照（包拿不到 `process`） |
| `voice` 标记 | isomer 服务端配置 | **不搬**（那是节点运营方的开关，与负载无关） |
| 只读指标端点 | isomer 无对应端点（新增） | `GET /mod/node-metrics-healthz/node.json` |

## 自带素材是哪来的
**无素材**。

## 已知不兼容 / 边界（必读）
1. **`memoryPercent` 不是系统内存占用**。引擎的 `hostMetrics` 不给总内存，所以本包用 `heapUsed / rss` 的比例当「堆占用比」。它与 isomer 那个数字**同向不同义**，不要拿两个服的数直接比大小。
2. **`cpuPercent` 取自 `elu`（事件循环利用率，[0,1] 累积值）× 100**，不是 OS 的 CPU 占用率。语义比 isomer 的窄，但同向。
3. **`loopLagMs` 取 p95 分位**（isomer 用单值）。p95 比 p50 更能反映卡顿，又不像 max 那样被一次 GC 尖刺长期带偏。
4. **采样关闭时**：`hostMetrics` 的 `state` 会是 `disabled`，此时 `loop*` 为 `null`、`pressure` 为 `unknown` —— 如实报「不知道」，不假装低负载。
5. `/healthz` 一个包最多贡献 12 个字段 / 2048 字节（引擎 `HEALTHZ_LIMITS`）。本包贡献 6 个字段，在上限内。
6. **零对局影响**：`healthz` / `metrics` / `route` 三个挂载点都改不了对局，所以 `combat: false`（引擎对这三项的判据就是「能力而不是意图」）。
