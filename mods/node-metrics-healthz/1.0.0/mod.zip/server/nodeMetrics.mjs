// 节点负载读数 —— 把 isomer 社区节点 /healthz 里那一段 `node` 节搬进工坊包。
//
// 出处：wei.isomer319.xyz 与 sp.isomer319.xyz 的 /healthz 都带一段引擎没有的负载读数：
//   "node":{"observedAt":1791836598060,"cpuPercent":8,"memoryPercent":68,"loopLagMs":0,
//            "pressure":"low","voice":true}
// 客户端读它的是 `_v024/shared/serverSelection.js`（`normalizeNodeStatus` / `pressureLevel` /
// `recommendNode`）。本模块复刻同一套判据，但**数值不自己采** —— 一律取引擎 `hostMetrics` 的快照，
// 因为包拿不到 `process`（源码静态扫描禁它），而引擎恰好提供了同一件事的正当替代路径。
//
// 为什么 combat: false：这个包只往 `/healthz` 加字段、加一个只读 GET 端点。它进不了对局进程，
// 也改不了任何一局的输入输出。`shared/workshop.js` 对 `healthz` / `metrics` / `route` 三个挂载点的
// 判据就是「能力而不是意图」—— 这三项都改不了对局，所以不要求 combat 标记。

/** isomer `pressureLevel` 的同一套阈值（逐字对照 shared/serverSelection.js:15-20）。 */
const BUSY = Object.freeze({ cpu: 85, memory: 90, loop: 120 });
const MODERATE = Object.freeze({ cpu: 60, memory: 80, loop: 50 });

/**
 * 负载分档。三项里**任何一项**越界就升档 —— 与 isomer 的 `||` 语义一致，不是取平均。
 * @param {{ cpuPercent?: number|null, memoryPercent?: number|null, loopLagMs?: number|null }} m
 * @returns {'unknown'|'low'|'moderate'|'busy'}
 */
export function pressureLevel(m) {
  const cpu = m && Number.isFinite(m.cpuPercent) ? m.cpuPercent : null;
  const memory = m && Number.isFinite(m.memoryPercent) ? m.memoryPercent : null;
  const loop = m && Number.isFinite(m.loopLagMs) ? m.loopLagMs : null;
  if (cpu === null && memory === null && loop === null) return 'unknown';
  if (cpu >= BUSY.cpu || memory >= BUSY.memory || loop >= BUSY.loop) return 'busy';
  if (cpu >= MODERATE.cpu || memory >= MODERATE.memory || loop >= MODERATE.loop) return 'moderate';
  return 'low';
}

/**
 * `loopLagMs` 取哪一个分位。isomer 用 `loopLagMs` 单值，引擎快照给的是四个分位。
 * 取 **p95**：它比 p50 更能反映「玩家此刻会不会觉得卡」，又不像 max 那样被一次 GC 尖刺长期带偏。
 */
const LAG_KEY = 'loopP95';

/**
 * 从引擎的 hostMetrics 快照推出一份扁平读数。
 *
 * `memoryPercent` 由 rss 与 heapUsed 之外的第三个量推不出来（引擎不给总内存），所以这里用
 * **heapUsed / rss** 的比例当「堆占用比」—— 它是一个真实的、可对比的负载信号，但不是 isomer 那个
 * 「系统内存百分比」。备注与 README 里必须写明这一句，不能让它冒充系统内存占用。
 *
 * @param {ReturnType<import('node:perf_hooks').performance.eventLoopUtilization> extends never ? never : any} m
 * @returns {{ observedAt: number, cpuPercent: number|null, memoryPercent: number|null,
 *            loopLagMs: number|null, pressure: string, voice: boolean, sampleState: string }}
 */
export function readNode(m) {
  const rss = m && Number.isFinite(m.rss) ? m.rss : null;
  const heapUsed = m && Number.isFinite(m.heapUsed) ? m.heapUsed : null;
  const elu = m && Number.isFinite(m.elu) ? m.elu : null;
  const lag = m && Number.isFinite(m[LAG_KEY]) ? m[LAG_KEY] : null;
  // elu 是 [0,1] 的利用率，乘 100 才是百分数；它是累积值，不是瞬时值 —— 与 isomer 的 cpuPercent 同向不同义。
  const cpuPercent = elu === null ? null : Math.round(elu * 1000) / 10;
  const memoryPercent = rss && heapUsed ? Math.round((heapUsed / rss) * 1000) / 10 : null;
  const pressure = pressureLevel({ cpuPercent, memoryPercent, loopLagMs: lag });
  return {
    observedAt: Date.now(),
    cpuPercent,
    memoryPercent,
    loopLagMs: lag,
    pressure,
    voice: false,
    sampleState: (m && m.state) || 'unknown',
  };
}

/** `/healthz` 只收扁平标量，`observedAt` 之外把 pressure 一并给出去（目录站按它排序）。 */
export function healthzFields(m) {
  const r = readNode(m);
  return {
    nodeCpuPercent: r.cpuPercent,
    nodeMemoryPercent: r.memoryPercent,
    nodeLoopLagMs: r.loopLagMs,
    nodePressure: r.pressure,
    nodeSampleState: r.sampleState,
  };
}

export default function install(host) {
  const say = (what) => host.log.warn(`node-metrics: "${what}" was not declared in uses[]`);
  const metrics = typeof host.metrics === 'function' ? host.metrics : null;
  if (!metrics) {
    say('metrics');
    return;
  }
  // `/healthz` 的 node 节：五个扁平字段 + 一个采样状态，共 6 个，上限 12。
  if (typeof host.healthz === 'function') {
    host.healthz(() => healthzFields(metrics()));
  } else {
    say('healthz');
  }
  // 只读端点：完整形状（含 observedAt），给目录站 / 运维脚本用。
  if (typeof host.route === 'function') {
    host.route('/mod/node-metrics-healthz/node.json', () => ({
      ok: true,
      node: readNode(metrics()),
    }));
  } else {
    say('route');
  }
}
