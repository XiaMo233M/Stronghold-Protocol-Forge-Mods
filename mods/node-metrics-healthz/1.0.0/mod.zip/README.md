# 节点负载读数（/healthz 加 node 节 + 只读指标端点）

把 isomer 社区节点 `/healthz` 里那一段引擎没有的 `node` 负载读数搬过来。

## 装上之后
- `GET /healthz` 多出 6 个字段：`nodeCpuPercent` / `nodeMemoryPercent` / `nodeLoopLagMs` / `nodePressure` / `nodeSampleState`
- 新增只读端点：`GET /mod/node-metrics-healthz/node.json`（含 `observedAt` 的完整形状）
- `nodePressure` 取 `low` / `moderate` / `busy` / `unknown` 四档，阈值与 isomer 逐字一致

## 不兼容 / 边界（重要）
- **`nodeMemoryPercent` 是堆占用比（heapUsed/rss），不是系统内存百分比** —— 与 isomer 的数字同向不同义，别跨服直接比大小
- **`nodeCpuPercent` 取自事件循环利用率（elu），不是 OS CPU 占用率**
- **`nodeLoopLagMs` 取 p95 分位**（isomer 用单值）
- 采样被引擎关掉时，`loop*` 为 `null`、`pressure` 为 `unknown`（如实报「不知道」）
- `voice` 标记**没有搬**（那是节点运营方的开关，与负载无关）
- 零对局影响，故 `combat: false`
- 来源与许可见 `PROVENANCE.md`
