# PROVENANCE — 署名、许可与改动范围

本目录是**格式转换产物**，不是原创作品。它把社区 mod「灵巧盟约装备」（`fanpack-skillful-mod`）改写成
《卫戍协议：盟约》（本项目 Stronghold-Protocol）的创意工坊包格式。包内记录的数值**一个字节都没有改**。

## 1 六项

| # | 项 | 值 |
|---|---|---|
| ① | 原作者 | **原件未署名**（原件的 `README.md` / `manifest.json` / `files.json` / 内容包 `pack.json` 里都没有作者名或个人标识；`manifest.json` 只有 `mod` / `name` / `version` / `app` / `pack` / `upstream` / `generator` / `builtAt`）。**不代填名字。** |
| ② | 许可 | 照抄原件内容包 `pack.json` 的 `credits` 原文，一字未改：`非商业同人作品；《明日方舟》及其素材版权归鹰角网络所有。` |
| ③ | 兼容改写者 | 本仓库维护者（格式转换与包契约），与原作者**分开列** |
| ④ | 来源 | 上传站投稿 **8919d4c42c6b**；`mod.zip` 459,165 B，sha256 `dcf7626bcf8af5a9dbee1fc6c7151277befcc66388a4dad96012ff1754190ca1`；顶层目录 `fanpack-skillful-mod/`。内层来源：`payload/packs/fanpack-skillful/records.json` sha256 `4577f6b099d3c0ae07098a009b613f38842fb47315437aba59493154996e2363`、`payload/packs/fanpack-skillful/pack.json` sha256 `2126c5980315afeb697f058e7baaae1bb8ef9c96e4f3c15d7a19c3bb59306321`、`README.md` sha256 `853f3fda32389b97c4f913e217c60a72e75535dd16e28b38f603eb004898a839`。原件自述针对上游 **v0.2.2**。 |
| ⑤ | 改了什么 | 见第 2 节，逐条。 |
| ⑥ | 自带素材 | `assets/trap_c_06.png`（175,087 B，sha256 `c68a20f6a73840720cf3ff99edcca6827ba7b6cd86775cc6685aa8ec2b761dcc`）—— **原件自带**、逐字节复制、未重编码。**不是**从游戏里解包出来的素材：原件 `asset-additions.json` 的 `files` 为空数组，且其自述「the mod itself redistributes no game asset」。 |

## 2 逐条：原做法 → 我们的做法 → 为什么

| # | 原做法 | 我们的做法 | 为什么 |
|---|---|---|---|
| 1 | `install.mjs`（45,829 B）整文件覆盖引擎的 `server/*`、`shared/*`、`public/js/*`，并按 `manifest.json` 逐个核对 sha256 | **完全不采用**；改为一个数据包：`items.json` + `pack.json` 的 `content` / `itemIcons` 声明 | 安装器是**任意代码执行面**（`fs.copyFileSync` 覆盖、`rmSync` 删除、`fetch` 拉第三方镜像、`spawnSync` 跑目标脚本），是红线；而这两件装备本身是**纯数据**，引擎已有声明通道 |
| 2 | 两件装备写在 `payload/packs/fanpack-skillful/records.json` 的 `items` 节里 | 原样搬进 `items.json` 的 `{ "<id>": 记录 }` | 引擎的 `content: ["items"]` 读的就是这个形状；记录**逐字节保留**（36 个键、键序与官方 `data/items.json` 的记录完全一致） |
| 3 | 图标经 `art/index.json` 的 `key → 文件` 映射 + `install.mjs --assets` 复制进 `public/assets/pack/` | 译成 `pack.json.itemIcons: { "trap_c_06": "trap_c_06.png" }`，图进包的 `assets/` | 引擎的装备图标通道：装载时叠加进 `assets.items`，URL 走 `/workshop-assets` 路由，客户端零改动 |
| 4 | 原件 `pack.json` 用 `type` / `englishName` / `app` / `files` 描述自己 | 只写引擎认识的键（`id` / `name` / `version` / `author` / `license` / `description` / `game` / `api` / `combat` / `content` / `itemIcons`） | 引擎的顶层键是**闭集**：多写一个不认识的键会**整包被拒**（`PACK_UNKNOWN_FIELD`），不是静默忽略 |
| 5 | 内容包 `pack.json` 的 `credits` 是唯一的署名/许可文字 | 逐字搬进本包 `pack.json` 的 `license` | 有 `assets/` 的包**必须**声明 `license`（`ASSETS_NEED_LICENSE`）；同时这也保证原作者的那句话随包走 |

## 3 ⚠️ 包内哪一节已与实现不符（**保持原样未改**）

**原件 `README.md` 的「商店装备位的盟约偏向」一节与引擎实现不符 —— 该节保持原样未改，此事实记在这里。**

- 原件 README 写：「按【灵巧】层数参与**商店装备位的盟约偏向**——堆灵巧时更容易刷到它（与官方 9 件签名装备同一套规则）」。
- 事实：本引擎里**没有**这套机制 —— 服务端代码里不存在任何偏向字段（`server/` 全目录搜 `bias`：**0 命中**），
  官方 14 件盟约签名装备**一件都没有**带这个概念。
- 引擎**故意**堵住了两条路：写进记录 ⇒ `UNKNOWN_OVERRIDE_FIELD`；写成 `pack.json` 顶层键 ⇒ `PACK_UNKNOWN_FIELD`
  （依据：`docs/WORKSHOP.md` §1.2 那一节）。而且不能「凑合」：只写 `giveBondId` 在**本引擎**的语义是「**授予**盟约」，
  与原作的「只偏置、不授予」**相反** —— 宁可少一个特性，也不制造一个语义相反的假实现。
- 要有这条特性，正确做法是**维护者在引擎里**新增一个开关（商店池 + 记录层读取点，并新开一个 `PACK_FIELDS` 字段）。
  该事项已由业主裁定为**独立立项**，**不在本包范围**。
- 本包因此**如实不实现**它，原件 README 的这一句**原样保留**（见 `NOTICE-原件-README.md`）。

**本包真正实现、且经引擎校验为真的那条：** 两件装备带 `giveBondId: "skillfulShip"` 且 `canGiveBond: false`，
所以与官方「变形同构体」（`chess_item_6_09_e_a`，`canGiveBond: true`）同装时，携带者**视为【灵巧】成员**
（依据：`server/match/bondsMeta.js` 的配对规则）。这条是原件 README 的第二个卖点，**数据层就能真表达**，不靠引擎改动。

## 4 `combat: true` 的依据（告知义务）

本包声明 `combat: true`，理由：**它把两件新装备送进商店池**（`itemType: EQUIP`、`hideInShop: false`、
`shopExcluded: false`、整数 `tier` ⇒ 引擎的 `isShopItem` 为真）⇒ **商店能刷到什么变了**，玩家可以买到并装备它们
⇒ **会改变对局结果**。按纪律，**能改结果就必须标 `combat: true`**；不标就是**静默**改结果。

引擎只在挂 `server.meta` / `server.battle` / 带 `matchClass` 的 `server.modules` 时**强制**要求这个字段
（`META_NEEDS_COMBAT` / `BATTLE_NEEDS_COMBAT` / `MODULES_NEED_COMBAT`）；数据包不被强制 ——
**所以这条是本包自愿、如实的标注**，而不是被闸门逼出来的。

## 5 已知限制（不写 `i18n`，如实记在这里）

本包**不带** `i18n` 声明，因为**它对装备名无效**：

- 包的 `i18n` 只并进**界面**字符串（引擎读 `public/i18n/<code>.json`）；
- 游戏数据译文住在 `data/i18n/<code>.json` 的 `files.items["<id>"].name` 里，**没有包通道**；
- 两件装备的 `name` / `desc` 是记录本身的中文字段，客户端直接显示记录字段。

⇒ **结论：非中文界面（en / ja / ko / zh-TW）里，「灵巧钩索」这个名字会显示为中文。**
这是当前包格式的结构性限制，不是本包可以绕过的。其余文案（描述、flavor）同理。

## 6 没有带过来的东西（一句话版）

原件是「A 内容 + B 服务端逻辑 + C 客户端界面」三样都有的覆盖式 mod。本包只带了 **A 内容**那一半
（两件装备记录 + 一张图标）。**B 层**（`install.mjs` 覆盖的引擎文件、商店盟约偏向）与
**C 层**（`public/i18n/*`、`public/js/ui/*` 的改动）没有接口可以落，或按纪律**不采用**，逐条见第 2 节与第 3 节。

## 7 自检

- 干净根装载：`node tools/workshop-validate.mjs --workshop <一根一包>` ⇒ **0 error(s), 0 warning(s)**（原始输出见交付说明）。
- 记录保真：两件装备记录与原件 `records.json` **逐字节相同**（36 个键、键序一致），只去掉了不可执行的 `_doc` 说明键。
- `data/*.json` **一个字节都没有改**（官方数据 115 条装备，本包以 **additive** 方式新增 2 条 id，两个 id 官方都不存在）。
