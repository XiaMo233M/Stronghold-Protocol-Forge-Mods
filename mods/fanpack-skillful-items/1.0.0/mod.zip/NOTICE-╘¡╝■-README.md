灵巧盟约装备（fanpack-skillful-mod 1.0.0，为上游 v0.2.2 制作）
================================================================

给「卫戍协议：盟约」的附加盟约 **【灵巧】** 补上它的盟约装备 **灵巧钩索**：2 阶、购买价格 2，攻速 +25（进阶 +50）。
官方的九件盟约签名装备里没有【灵巧】那一件，这件的正文写在本内容包的 `packs/fanpack/records.json` 里。

拆分包之一（仓库 docs/MOD.md §6）：只装这一件装备（连它进数据、进商店、参与盟约偏向所需的代码），不带名册、
图鉴、时装、语音或口径开关，也不和「罗德岛盟约mod」「卡兹戴尔盟约mod」抢同一批数据。

装了什么
--------
* **灵巧钩索**（普通 / 进阶两件记录，共用一张图标）：攻击速度 +25 / +50，商店可售（2 阶，价格 2），按【灵巧】
  层数参与**商店装备位的盟约偏向**——堆灵巧时更容易刷到它（与官方 9 件签名装备同一套规则）。
* **变形同构体适配**：它带 `giveBondId: skillfulShip` 且**不是**「仅供偏向」那种（没有 `giveBondBiasOnly`），
  所以与官方「变形同构体」（缪尔赛思 / 机变发的 `chess_item_6_09_e_a`）同装时，携带者**视为【灵巧】成员**，
  一起数进灵巧的层数（与官方维式重锤→维多利亚、天师古鼎→炎同一套配对规则）。
* 让它成立所需的代码：内容包加载（`packs/fanpack`、`server/data.js`、`shared/customContent.js`…）、商店装备位的
  盟约偏向（`server/match/{pool,bondsMeta,player/economy}.js`，`server/match/gamedata.js` 的 `shopBondBias`）与
  `/packs/*`、`/data/*` 的合并服务。载荷里**不带** `public/js/ui/detailPanel.js`：0.2.2 自带的详情面板对任何带
  `giveBondId` 的装备都会画「与变形同构体一同装备时…」那一行，这件装备不需要额外的前端改动。

不装：盟约名册与干员（罗德岛 / 卡兹戴尔两个内容包）、装备总览 / 盟约与策略图鉴、干员特质区块、口径开关。

装到上游项目
------------
先把上游 checkout（0.2.2）用 `npm ci` 装好依赖 —— git 克隆的仓库、或者**官方发布包**（Releases 里那个
zip，解压出来带 MANIFEST.json、没有 .git）都可以。**不需要** `--assets`：图标随 mod 一起来。

  cd /d 这个文件夹
  node fanpack-skillful-mod\install.mjs <上游项目目录>             装（先备份每个被覆盖的文件）
  node fanpack-skillful-mod\install.mjs <上游项目目录> --dry-run   只看要做什么，不写文件
  node fanpack-skillful-mod\install.mjs <上游项目目录> --verify    校验已装好的目标
  node fanpack-skillful-mod\install.mjs <上游项目目录> --uninstall 还原成装之前的样子

装完**重启上游服务**（npm start）后在商店的装备位里就能刷到它；堆【灵巧】时它会优先出现，
与变形同构体同装时商店 / 详情里的【灵巧】成员数会 +1。

注意
----
* 只适用于 0.2.2：mod 里的服务端是整份文件覆盖（`server/data.js`、`server/index.js`…），换版本要先等适配。
* **一次只装一个**：本包和内容包、图鉴包、开关包都换同一批服务端文件，第二个装上去会被安装器的
  「目标不是 release 原文」检查拦住。
* 装到「已经装过这个 mod」的目录上是**修复**；`--uninstall` 会还原被覆盖的文件、删掉新增的（内容包目录等）。
