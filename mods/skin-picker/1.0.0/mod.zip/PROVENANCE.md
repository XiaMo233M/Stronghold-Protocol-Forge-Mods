# 署名与来源 · PROVENANCE

> 本文件由**交付流程**在拆包时生成，随包分发。原作者与改写者**分开显示，不抹掉任何一方**。
> 原件未署名的一律写**「原件未署名」**，不代填名字；许可**照实抄**，包括非 SPDX 的值。

## 包

| 项 | 值 |
|---|---|
| 包 id | `skin-picker` |
| 版本 | `1.0.0` |
| 名称 | 皮肤选择器（换装） |
| 目录名 = 包 id | 是（引擎逐包判 `PACK_ID_MISMATCH`，不一致会被拒） |
| 本包实测规模 | 5 个文件 / 57331 字节（不含本文件） |

## 原作者 / 上游

**jingjiangze** —— 原件 `pack.json.author` 原文，照实抄录；本包 `README.md`「我方改写说明」也写明「原作者署名一处未改。原作者：`jingjiangze`」。

- 上游：皮肤选择器（换装）

## 许可（照实抄）

原件 `pack.json.license` 原文，逐字抄录：`GPL-3.0-or-later`

## 责任人

| 角色 | 是谁 |
|---|---|
| 原作者 | jingjiangze |
| 本版兼容改写者 | Mo233（工坊包通道改写 / 按中间层重写；本包具体改写点见下节） |
| 本包交付 | 第三方 mod 兼容交付流程，2026-10-11 |

## 来源

- 原件：E:\destop\mod\a7159a57cb91-皮肤选择器（换装）.zip
- 交付形态：工坊包（workshop pack）· 包契约 **MOD_API_VERSION 1**（据此判能否装载）· 打包时工作树 `3396438a` 的 APP_VERSION 为 0.14.0（该号只表示发行版，不参与包兼容判定；交付后 HEAD 已推进到 `d46cfdaa` / APP_VERSION 0.15.0，MOD_API_VERSION 仍为 1，本轮已在该 HEAD 上复测通过）

## 改了什么

- 原件**装不上 / 没效果**的原因：① `pack.json` 同上的根目录问题（实测两条 `pack.json is missing`）；② 原件的换装**只在包内记偏好、不参与立绘解析** —— 实测选了之后 `lookup` 仍返回 `null`，画面不变。
- 改写：归位为 `skin-picker/` 目录；`pack.json` 新增 `"api": ">=1 <2"`（**其余字段与原件逐字节相同**）；`client/picker.js` + `client/picker.css` 改写为在引擎外观解析链上**注册提供者**，并接上总开关与单调用点否决（`opts.skins=false`）；`README.md` 与 test 改写。
- **包 id、面板键、广播形状与原作者署名一处未改。**

## 自带素材来源

- **不带任何素材。**

## 备注 / 边界

- 边界（与原作者 README「边界」一节一致）：**改不了上场后的战斗模型**。本次改写让「换装」生效的范围是**立绘与头像**（解析链覆盖的九处渲染路径）；Spine / 战斗渲染依旧改不了。
- 本包与 `skin-catalogue` 是一对，**两个都要装**换装才真的生效。

## 包内其它署名 / 来源文件

- `README.md`（含「我方改写说明」一节，文末写明原作者与许可）

## 校验

- 本包**单独**装载于干净的 workshop 根（根内只有这一个包）：见交付索引 `../../INDEX.md` 的 8 条原始输出。
- 校验器：`node tools/workshop-validate.mjs`；装载器：`server/workshop.js loadWorkshop`。

---

*English summary: this pack is a compatibility conversion delivered for Mo233. The original
author and the compatibility rewriter are listed separately above; where the original was uncredited it is
stated as "原件未署名 (uncredited original)" rather than being invented. The licence text is copied verbatim
from the original. See the Chinese sections above for the exact source, the list of changes, and the origin
of any bundled assets.*
