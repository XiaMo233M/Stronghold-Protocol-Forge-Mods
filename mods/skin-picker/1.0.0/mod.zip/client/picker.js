// skin-picker/client/picker.js — 皮肤选择器（换装）的**行为层**。
//
// 管理器把皮肤刻意切成两半（CHANGELOG 0.13.0「数据在包里声明，行为在 mod 里」）：
//   * 数据：各包的 `pack.json.skins` 在装载期合并进
//     `assets.skins[charId] = [{ pack, id, name, series?, desc?, art?, voices? }, …]`，
//     `art` 里的路径已经转成 `/workshop-assets/<包>/<路径>` 的绝对 URL（`shared/workshop.js mergeWorkshopSkins`）；
//   * 行为：本文件。三件事 ——
//       1) `appearance(ctx)`：注册**外观提供者**，把「本机偏好里选的那套时装」（没有偏好时退回复核传进来的 id）
//          解析成**这一条 kind 的那一张图**（`{ portrait }` 或 `{ avatar }` —— 「立绘与头像分开受控」就是
//          从这里进来的：链按 kind 各问一次、我们按 kind 各记一格），接进 `public/js/ui/portraitChain.js`
//          那条立绘/头像解析链的**步骤 0「提供者先说话」**（进程内最多一个提供者，第二个被引擎点名拒绝）；
//       2) `mount(ctx)`：在 `screen.loadout.detail` 里画「立绘/头像分段 + 默认外观 + 每一套」列表；
//       3) 点击 = 写**这一条 kind** 的本机偏好（`ctx.session.setPref`，键按 `<包id>/` 前缀分区，值只收标量）
//          + 向同房广播（`ctx.session.send('room.appearance', …)`，`PANEL_SEND_TYPES` 闭枚举里唯一的展示消息）。
//
// 边界（DESIGN §28.8）：没有 store、没有对局对象、没有渲染器。所以**本包改不了上场单位画什么模型** ——
// 「选择的时装生效到战斗渲染」是引擎侧还没接的一环（`shared/workshop.js` SKIN_ID_RE 注释里的
// `settings.skinByChar` 设计口径），见 README「完成度」。本包能做到的是：列表、选择、广播，以及让**立绘与头像**
// 真的按玩家选的那一套解析（提供者读本机偏好后回答链 —— 见 `appearance` 的注释）。
//
// 宿主：`screen.loadout.detail` 由 `ui/detailPanel.js` 渲染，`data-mod-slot-key` = 当前棋子的 chessId，
// 或（替补/自选原型时）干员 charId。宿主键会随玩家点开的干员变化，而注册表**只在新的挂载键上挂**
// （`extensions.js` 按 `<面板键>#<宿主键>` 记账、不摘旧键那一份）—— 所以 mount 先清掉同一容器里属于本包、
// 其它宿主键留下的兄弟节点，保证同一时刻只有一份界面。

/** 偏好键（引擎写入时再前置 `<包id>/`，所以这里只管短名）。**两条 kind 各一格**：见下面的 `KINDS`。 */
export const PREF_PREFIX = 'skin:';

/**
 * 立绘与头像**分开受控**：两条 kind 各存一份偏好、各问各的答案。
 *
 * 为什么偏好要按 kind 分开：解析链按 kind 问提供者一次（`lookup('portrait'|'avatar', charId, id)`），
 * 而一套时装的 `art` 常常**只有 `avatar`** —— 一条偏好管两条 kind 会让「选了装」把立绘也画成那张头像。
 * 链那一侧已经按 kind 各问各的，提供者这一侧就得按 kind 各记各的，否则「分开受控」没有落点。
 *
 * 键：`skin:<kind>:<charId>`（例如 `skin:portrait:char_002_amiya`）。**旧键 `skin:<charId>` 仍然读**
 * （老玩家的选择不丢），但只作为两条 kind 都没有各自选择时的公共退路；新写入一律写 kind 那一格。
 */
export const KINDS = Object.freeze(['portrait', 'avatar']);

/** kind 归一化：不认识的一律 `null`（链只送这两个值；不认识的 kind 不猜）。 */
const normKind = (kind) => (KINDS.includes(kind) ? kind : null);

/** kind 的偏好短名（`<包id>/` 前缀由引擎写入时前置）。 */
export const prefKey = (kind, charId) => `${PREF_PREFIX}${kind}:${charId}`;

/** 旧键（这一版之前写的选择都在这里）：读得到、不再写。 */
export const legacyPrefKey = (charId) => `${PREF_PREFIX}${charId}`;

/** 试读一个键：只收标量字符串，读不到 / 读抛错 ⇒ null。 */
function readKey(ctx, key) {
  try {
    const v = ctx.session.getPref(key, null);
    return typeof v === 'string' && v ? v : null;
  } catch {
    return null;
  }
}

/** 这套是不是当前选择（`current` 是偏好里的指针，`entry` 是合并列里的一条）。 */
function isChosen(entry, current) {
  const ref = parsePointer(current);
  if (!ref || ref.id !== entry.id) return false;
  return !ref.pack || ref.pack === entry.pack;
}

/**
 * 本机偏好：这名干员在**这一条 kind** 上当前选的指针（没选过 → null）。
 * 老的 `skin:<charId>` 作为公共退路（两条 kind 都没各自选择时才看它）。
 */
export function readChoice(ctx, charId, kind = 'portrait') {
  const k = normKind(kind);
  if (!k || typeof charId !== 'string' || !charId) return null;
  return readKey(ctx, prefKey(k, charId)) || readKey(ctx, legacyPrefKey(charId));
}

/**
 * 写本机偏好（null / 空串 = 这一条 kind 回到默认外观）。@returns {boolean} 引擎是否写入
 * `kind` 不认识时**不写**（返回 false）：宁可不生效，也不要把选择写到别人的那一格上。
 */
export function writeChoice(ctx, charId, value, kind = 'portrait') {
  const k = normKind(kind);
  if (!k || typeof charId !== 'string' || !charId) return false;
  try {
    return ctx.session.setPref(prefKey(k, charId), value || null);
  } catch {
    return false;
  }
}

/** `room.appearance.picks` 一项里 `skinId` 的字符集（与 `shared/protocol.js isId` 同一档，冒号是包指针用的）。 */
const SKIN_ID_SHAPE = /^[A-Za-z0-9][A-Za-z0-9_\-.:]{0,63}$/;

/** `<包id>:<皮肤id>` 指针（`shared/workshop.js` SKIN_ID_RE 那行注释里记的设计口径）。 */
export function pointer(pack, id) {
  return `${pack}:${id}`;
}

/**
 * 解析一个指针；**裸 id 也接受**（`room.appearance` 线上带的是裸 id：接收方去自己的 `assets.skins[charId]` 里找）。
 * @returns {{ pack: string|null, id: string } | null}
 */
export function parsePointer(value) {
  if (typeof value !== 'string' || !value) return null;
  const i = value.indexOf(':');
  if (i < 0) return { pack: null, id: value };
  const pack = value.slice(0, i);
  const id = value.slice(i + 1);
  if (!pack || !id) return null;
  return { pack, id };
}

/** 合并清单里这名干员的时装列（不是数组时给空数组：调用方只面对一种形状）。 */
export function entriesFor(assetsTable, charId) {
  const skins = assetsTable && typeof assetsTable === 'object' ? assetsTable.skins : null;
  const list = skins && typeof skins === 'object' && charId ? skins[charId] : null;
  return Array.isArray(list) ? list.filter((e) => e && typeof e.id === 'string' && e.id) : [];
}

/** 在列里找一套：带包前缀的指针要求 (pack,id) 双命中，裸 id 命中即可（同 id 在合并期已按包序去重）。 */
export function resolveSkin(assetsTable, charId, idOrPointer) {
  const ref = parsePointer(idOrPointer);
  if (!ref) return null;
  const list = entriesFor(assetsTable, charId);
  if (ref.pack) return list.find((e) => e.id === ref.id && e.pack === ref.pack) || null;
  return list.find((e) => e.id === ref.id) || null;
}

/** 解析链要的形状：`{ portrait, portraitE2, avatar, avatarE2 }` 里存在的那几个；一个都没有时给 null。 */
export function artFor(entry) {
  const art = entry && entry.art;
  if (!art || typeof art !== 'object') return null;
  const out = {};
  for (const field of ['portrait', 'portraitE2', 'avatar', 'avatarE2']) {
    if (typeof art[field] === 'string' && art[field]) out[field] = art[field];
  }
  return Object.keys(out).length ? out : null;
}

/** 广播消息（`room.appearance` 的形状；`ctx.session.send` 发出前引擎还会用 `validateC2S` 再判一次）。 */
export function pickMessage(charId, skinId) {
  if (typeof charId !== 'string' || !charId) return null;
  if (typeof skinId !== 'string' || !SKIN_ID_SHAPE.test(skinId)) return null;
  return { picks: { [charId]: { skinId } } };
}

/** 宿主键 → 干员 id：先查 chess 表（正常路径是 chessId），替补/原型路径本来就是 charId。 */
export function charIdFor(chessTable, hostKey) {
  if (typeof hostKey !== 'string' || !hostKey) return null;
  const rec = chessTable && typeof chessTable === 'object' ? chessTable[hostKey] : null;
  if (rec && typeof rec.charId === 'string' && rec.charId) return rec.charId;
  return hostKey.startsWith('char_') ? hostKey : null;
}

/**
 * **外观提供者**（皮肤层第 0 步「提供者先说话」）：模块导出这个函数，引擎在 import 之后、mount 之前把它接进解析链。
 * 它拿到的 `ctx` 与面板同一份（同样没有 store / 对局对象）——所以只用 `ctx.data` 与 `ctx.session` 的偏好面。
 *
 * 签名 `lookup(kind, charId, id)`，`kind` 是 `'portrait'` / `'avatar'`：**立绘与头像分开受控**就是从这里进来的
 * ——链按 kind 各问一次，我们按 kind 各答各的、按 kind 各记各的偏好（见文件头的 `KINDS`）。
 *
 * 语义：链在**每一步之前**先问我们一句，而**这里传进来的 `id` 是本机当前那个原版 id**（例如
 * `char_002_amiya_1`），不是「玩家选的那套时装 id」。两套引擎的口径不同，这是本文件最要紧的一句：
 *
 *   * 原作者那套引擎会把「已选时装 id」写进 `chess.assets.portrait`，于是链拿着**那个 id**来问，
 *     提供者只要 `resolveSkin(assets, charId, id)` 就能答；
 *   * 本引擎不写 `chess.assets.portrait`（那是引擎自己的数据形状，包改不了），链**永远**拿着原版 id 来问。
 *     只按 id 解析 ⇒ 每问必不命中 ⇒ 换装对画面无感。
 *
 * 所以先查**本机偏好**（**这一条 kind 的那一格**，老键作为公共退路）：选中某套时装且**这一条 kind 有图** ⇒
 * 返回 `{ [kind]: url }`；没有偏好、那套解析不到、或**那套只有另一条 kind 的图** ⇒ 再按传进来的 `id` 解析
 * （原作者的口径，一并保留，另一套引擎下走的正是那条路）；都不行 ⇒ null，链自己回落原版。
 * **只回答这一条 kind 的字段**：一份只有 `avatar` 图的时装在 `portrait` 这一问上必须如实说「我不知道」，
 * 让链回落官方立绘 —— 拿头像去顶立绘那个位，就是「选了装之后头像也变成时装那张」那个错的另一半。
 * **不抛错、不改返回形状**：null 的语义仍然是「我不知道」。
 */
export function appearance(ctx) {
  const lookup = (kind, charId, id) => {
    const k = normKind(kind);
    if (!k || typeof charId !== 'string' || typeof id !== 'string') return null;
    try {
      const assets = ctx.data.get('assets');
      // 1) 这一条 kind 的本机偏好先行：链问的是原版 id，光按 id 解析永远拿不到玩家选的那一套
      const choice = readChoice(ctx, charId, k);
      if (choice) {
        const url = artFor(resolveSkin(assets, charId, choice))?.[k];
        if (url) return { [k]: url };
      }
      // 2) 原作者口径：传进来的 id 本身就是本服声明的一套时装时，照旧回答（同样只答这一条 kind）
      const byId = artFor(resolveSkin(assets, charId, id))?.[k];
      return byId ? { [k]: byId } : null;
    } catch {
      return null; // 坏数据不外溢：链自己有回落，一次查询失败不该让立绘整片消失
    }
  };
  return { lookup };
}

/**
 * 面板：在详情卡里画换装列表。返回 `{ unmount }`。
 */
export function mount(ctx) {
  const doc = ctx.host.ownerDocument;
  const assets = ctx.data.get('assets');
  const chessTable = ctx.data.get('chess');
  const charId = charIdFor(chessTable, ctx.hostKey);
  /** 面板当前在改哪一条 kind（分段选择；见 `segment()`）。默认立绘。 */
  let kind = 'portrait';

  // 宿主键换人时注册表不会摘旧的那一份（见文件头），先清掉同一容器里属于本包、别的宿主键留下的兄弟节点。
  const container = ctx.host.parentElement;
  const myPrefix = `${ctx.pack}/${ctx.id}#`;
  if (container && typeof container.children !== 'undefined') {
    for (const el of [...container.children]) {
      if (el === ctx.host) continue;
      const tag = el && typeof el.getAttribute === 'function' ? el.getAttribute('data-mod-panel') : null;
      if (typeof tag === 'string' && tag.startsWith(myPrefix)) el.remove();
    }
  }

  const box = doc.createElement('section');
  box.className = 'skin-picker';
  box.setAttribute('aria-label', '外观');
  ctx.host.appendChild(box);

  const heading = (text) => {
    const h = doc.createElement('h3');
    h.className = 'skin-picker__title';
    h.textContent = text;
    box.appendChild(h);
    return h;
  };
  const hint = (text) => {
    const p = doc.createElement('p');
    p.className = 'skin-picker__hint';
    p.textContent = text;
    box.appendChild(p);
    return p;
  };

  function thumb(src, label) {
    const wrap = doc.createElement('span');
    wrap.className = 'skin-picker__thumb';
    const initial = () => { wrap.textContent = [...label][0] || '?'; };
    if (src) {
      const img = doc.createElement('img');
      img.src = src;
      img.alt = '';
      img.loading = 'lazy';
      // 图挂了（404 / 断网）就退回首字：包声明了但素材没导入时应该看得见「这套还没有图」，而不是一个破图标。
      img.addEventListener('error', () => { img.remove(); initial(); });
      wrap.appendChild(img);
    } else {
      initial();
    }
    return wrap;
  }

  function option(entry, current, kind) {
    const btn = doc.createElement('button');
    btn.type = 'button';
    btn.className = 'skin-picker__option';
    const chosen = isChosen(entry, current);
    btn.setAttribute('aria-pressed', chosen ? 'true' : 'false');
    if (chosen) btn.classList.add('is-current');
    btn.appendChild(thumb(entry.art && (entry.art[kind] || entry.art.portrait || entry.art.avatar), entry.name));
    const text = doc.createElement('span');
    text.className = 'skin-picker__text';
    const name = doc.createElement('b');
    name.textContent = entry.name;
    text.appendChild(name);
    if (entry.series) {
      const series = doc.createElement('small');
      series.textContent = entry.series;
      text.appendChild(series);
    }
    btn.appendChild(text);
    btn.addEventListener('click', () => choose(pointer(entry.pack, entry.id), entry.id, kind));
    return btn;
  }

  function defaultOption(current, kind) {
    const btn = doc.createElement('button');
    btn.type = 'button';
    btn.className = 'skin-picker__option skin-picker__option--default';
    btn.setAttribute('aria-pressed', current ? 'false' : 'true');
    if (!current) btn.classList.add('is-current');
    const chars = assets && assets.chars && typeof assets.chars === 'object' ? assets.chars[charId] : null;
    btn.appendChild(thumb(chars && (chars[kind] || chars.avatar || chars.portrait), '默认'));
    const text = doc.createElement('span');
    text.className = 'skin-picker__text';
    const name = doc.createElement('b');
    name.textContent = '默认外观';
    text.appendChild(name);
    btn.appendChild(text);
    btn.addEventListener('click', () => choose(null, null, kind));
    return btn;
  }

  /** 写入**这一条 kind** 的本机偏好 + 广播。`broadcast` 是裸皮肤 id（接收方去自己的 `assets.skins[charId]` 里找）。 */
  function choose(value, broadcastId, kind) {
    if (writeChoice(ctx, charId, value, kind)) {
      const msg = broadcastId ? pickMessage(charId, broadcastId) : null;
      if (msg) {
        const sent = ctx.session.send('room.appearance', msg);
        ctx.log.info(`外观：${charId} ${kind} → ${broadcastId}（本机已记；广播${sent ? '已发' : '未发'}）`);
      } else {
        // 协议没有「清除」语义（CHANGELOG 0.13.0 记录的同一条边界）：换回默认只清本机，已广播的那一项留在同房视图里。
        ctx.log.info(`外观：${charId} ${kind} → 默认（本机已记；广播没有清除语义，不动）`);
      }
      render();
    }
  }

  /**
   * 立绘 / 头像分段选择（面板这一层的那一半「分开受控」）。
   *
   * 选中的那一段决定**下面点一套时写哪一格偏好**（`skin:portrait:<charId>` / `skin:avatar:<charId>`）。
   * 默认停在立绘：与「只有一条偏好」的旧行为最接近 —— 老玩家的 `skin:<charId>` 在两条 kind 上都是退路，
   * 所以升级后两面都还是他选的那套，直到他在某一条 kind 上单独改过。
   */
  function segment() {
    const row = doc.createElement('div');
    row.className = 'skin-picker__segment';
    row.setAttribute('role', 'group');
    row.setAttribute('aria-label', '分开设置');
    for (const [k, label] of [['portrait', '立绘'], ['avatar', '头像']]) {
      const btn = doc.createElement('button');
      btn.type = 'button';
      btn.className = 'skin-picker__mode';
      btn.textContent = label;
      btn.setAttribute('data-kind', k);
      btn.setAttribute('aria-pressed', kind === k ? 'true' : 'false');
      if (kind === k) btn.classList.add('is-current');
      btn.addEventListener('click', () => { kind = k; render(); });
      row.appendChild(btn);
    }
    return row;
  }

  function render() {
    box.textContent = '';
    heading('外观');
    if (!charId) {
      hint('打开一名干员的详情卡后，在这里换装。');
      return;
    }
    const entries = entriesFor(assets, charId);
    const hasManifest = !!assets && typeof assets === 'object';
    if (!entries.length) {
      hint(hasManifest
        ? '本服还没有为这名干员声明时装 —— 安装一个时装包（例如 skin-catalogue 导入素材之后）就会出现。'
        : '本服没有素材清单（assets.json），时装数据还读不到。');
      return;
    }
    box.appendChild(segment());
    const current = readChoice(ctx, charId, kind);
    const list = doc.createElement('div');
    list.className = 'skin-picker__list';
    list.appendChild(defaultOption(current, kind));
    for (const entry of entries) list.appendChild(option(entry, current, kind));
    box.appendChild(list);
    const note = hint('立绘与头像分开记：上面选哪一项，点一套就改哪一项；两条互不影响。选择只记在这台机器，'
      + '并会向同房广播（广播不区分立绘 / 头像）；这一项用「默认外观」清除。');
    note.classList.add('skin-picker__note');
  }

  render();

  return {
    unmount() {
      box.remove();
    },
  };
}
