# skin-picker · 皮肤选择器（换装）

管理器 **0.13.0 皮肤层**的**行为**那一半（「数据在包里声明，行为在 mod 里」——见管理器 `CHANGELOG.md` 0.13.0）。
本包**不带素材、不带数据**：列表来自本服其它包声明的时装（例如 [skin-catalogue](../skin-catalogue/README.md)）。

## 下载

- 工坊 mod 站（投稿 / 已上线列表）：`http://47.103.14.217:25570/`（列表在 [`/mods`](http://47.103.14.217:25570/mods)）
- 源码：`https://github.com/jingjiangze/Stronghold-Protocol-Forge`（分支 `feat/stardust-mods`）

## 它做什么

1. **换装面板**：挂在 `screen.loadout.detail`（干员详情卡里的一节）。列出「默认外观 + 本服声明的每一套」；
   点击 → 写**本机偏好**（`ctx.session.setPref`，按包前缀分区）并向**同房广播**
   （`ctx.session.send('room.appearance')`，引擎闭枚举里唯一的展示消息）。
2. **外观提供者**（`appearance(ctx)`）：**先读本机偏好**，把「玩家选的那一套」解析成
   这一条 kind 的那一张图（`{ portrait }` 或 `{ avatar }`），接进管理器唯一的立绘/头像解析链
   （`public/js/ui/portraitChain.js` 的**步骤 0「提供者先说话」**）。没有它，链不认识 `pack.json.skins` 里的 id，
   只会画回落图 —— 但**只按传进来的 id 解析也不够**：本引擎的链传的是原版 id，所以必须先看偏好
   （详见文末「我方改写说明」第 1 条）。
   **立绘与头像分开记**：偏好分 `skin:portrait:<charId>` / `skin:avatar:<charId>` 两格，面板上方那一段
   「立绘 / 头像」决定点一套时改哪一格（见文末第 4 条）。

## 安装

```bash
node tools/workshop-pack.mjs import "皮肤选择器（换装）.zip"    # 或把 skin-picker/ 目录复制进 workshop/
# 重启游戏服务器（包的装载是进程级的）
```

与本包装在一起的时装包（skin-catalogue 等）提供数据；**只装本包**时面板会显示「本服还没有为这名干员声明时装」。

## 边界（先知道再装）

- **改不了上场后的战斗模型。** 面板能改的是立绘/头像（解析链）与广播；「选了这套，场上就画这套 Spine 模型」
  需要引擎侧接线（管理器把皮肤 id 写在 `settings.skinByChar` 的设计口径已经在源码注释里，但还没落地）。
  见 `sp-stardust-mods/AUDIT-stardust-to-mod-manager.md` §6 PENDING-1。
- **「默认外观」清不掉已经广播出去的那一项**：`room.appearance` 只有 `{ skinId }` / `{ avatar }` 两种形状，
  没有「清除」语义（管理器自己记录的同一条接口边界）。本机偏好会立刻回到默认。
- 广播的对象是**同房的人**；服务端只做形状校验与转发（不判定 skinId 存在与否）。

## 开发/验收

```bash
node --test skin-picker/test/picker.test.mjs      # 15 条：指针/查找/提供者（含按 kind 分开的偏好）/面板交互/偏好（迷你 DOM）
node --test test/stardustPacks.test.mjs           # 装载验收（与本仓库的其它测试一起跑）
node tools/workshop-validate.mjs --workshop <装好的根>   # 作者侧校验器
```

跑测试时给引擎根目录（下面「我方改写说明」第 2 条解释了为什么现在需要它）：

```powershell
$env:SP_ENGINE_ROOT = "<引擎仓库根>"; node --test skin-picker/test/picker.test.mjs
```

---

## 我方改写说明（Stronghold-Protocol 引擎维护方，2026-10）

**只有 `client/picker.js` 的 `appearance()`（加几行）与 `test/picker.test.mjs`（改路径解析）被动过；
包 id、面板键、`pack.json` 的 `api: ">=1 <2"`、广播形状与原作者署名一处未改。原作者：`jingjiangze`。**

1. **`lookup` 先读本机偏好 —— 这是「换装对画面生效」的唯一原因。**
   原作者注释（`client/picker.js` 里那段）是按**另一套引擎**的口径写的：那套引擎会把「已选时装 id」写进
   `chess.assets.portrait`，链于是拿着**那个时装 id**来问，`resolveSkin(assets, charId, id)` 就能答。
   本引擎**不写** `chess.assets.portrait`（那是引擎自己的数据形状，包改不了），它的解析链
   （`public/js/ui/portraitChain.js`）有一步**「提供者先说话」**，在步骤 2 之前问提供者一次，
   而**传进去的 `id` 是本机当前那个原版 id**（例如 `char_002_amiya_1`）。于是原来那句 `resolveSkin` 每问必不命中，
   提供者永远返回 null，链回落原版 ⇒ 界面换了装、画面纹丝不动。
   现在 `lookup` 先 `readChoice(ctx, charId)`（这个函数原作者已经写好，且 `ctx` 就在作用域里）：
   偏好里选了某套 ⇒ 返回那套的 `art`；没选、或那套解析不到（含「声明了但没有 art」）⇒ 再按传进来的 `id`
   解析（保留原作者口径，另一套引擎下走的正是那条路）；都不行 ⇒ 返回 `null`。
   **既有契约没变**：null 仍是「我不知道」，链自己回落；不抛错、返回形状不变（见第 4 条：形状从
   「整套 art」收窄成「这一条 kind 的一张图」，但仍是对象、仍只由提供者自己决定内容）。
2. **包内测试不再假设仓库布局。** 原 `test/picker.test.mjs` 写死 `import … from '../../shared/protocol.js'`，
   那是「包位于引擎仓库的 `workshop/` 下」这一条假设：把包放到别处（例如本仓库外的 `_up/mod-rewrites/时装/`）
   就报 `ERR_MODULE_NOT_FOUND` —— 是测试脚本的路径问题，不是包内容的问题。
   现在按 `SP_ENGINE_ROOT` 环境变量 → 从测试文件往上逐级探 → 同级 `_engine/`、`engine/` 的顺序找引擎；
   找不到就**明确 skip 并打印原因**。**判据没放松**：广播形状那一半仍然只认引擎那份 `validateC2S`
   （抄一份 spec 自证清白才是真的削弱），所以宁可 skip。
3. **`skin-catalogue/test/catalogue.test.mjs` 同一处毛病一并修了**（同样的 `../../shared/…` 假设），
   理由与做法与第 2 条逐字相同 —— 那是**检查**脚本的路径，不是校验规则。
4. **【本轮新增】立绘与头像分开受控**（业主裁决：`lookup` 的 `kind` 从「历史的 `'chars'`」改成
   真实的 `'portrait'` / `'avatar'`）：
   * **只回答被问的那一条 kind**：`lookup('portrait', …)` 返回 `{ portrait }`、`lookup('avatar', …)`
     返回 `{ avatar }`；这一条 kind 没有图 ⇒ `null`（链自己回落官方），**不拿另一条 kind 的图顶上**。
     这就是业主实测撞到的那个错（一份只有 `avatar` 图的时装让头像与立绘都变成那张图）的修法。
     反过来，链也只在**调用方没有点名版本**时问提供者 —— 于是「别人明确要精锐立绘
     （`_2` / `isGolden`）」不会再被一份只有一张图的时装盖掉（引擎侧改动，见管理器
     `docs/design/mod-layer.md` §28.28）。
   * **偏好按 kind 分开**：键 `skin:portrait:<charId>` / `skin:avatar:<charId>` 各一格。旧键
     `skin:<charId>` **仍然读**，只作两条 kind 都没有各自选择时的公共退路 —— 老玩家的选择一个不丢，
     也不改写旧键。
   * **面板加了「立绘 / 头像」分段**（`skin-picker__segment`，默认停在立绘）：点一套写哪一格由它决定；
     广播形状与广播时机一字未改（`room.appearance` 仍然只有 `{ skinId }`，不区分 kind）。不加分段的话
     两条 kind 的偏好就没有入口 —— 而只加一格 UI、键格式不动又等于没分开，所以两者的取舍是「老选择靠
     退路保住」。
   * 测试从 11 条加到 **15 条**（不许放松：原有的断言只改了「拿哪种 kind 问」这一处，另外新增按 kind
     分开、只有一张图的时装在另一条 kind 上如实回落、面板分段各写各的用例）。

**本包仍然做不到的**（与原作者 README「边界」一节一致，未因本次改写而改变）：改了装，**上场单位画什么模型**
（Spine / 战斗渲染）依旧改不了。本次改写让「换装」生效的范围是**立绘与头像**（解析链覆盖的九处渲染路径：
详情页 / 手牌 / 结算页 / 商店卡等，含精锐 `E2` 字段），两条 kind 各自独立。

许可证：代码 GPL-3.0-or-later；本包不含任何游戏素材。原作者署名：`jingjiangze`。
