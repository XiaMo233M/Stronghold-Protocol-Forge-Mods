// skin-picker/test/picker.test.mjs — 面板模块的两半（外观提供者 / 换装面板）的纯逻辑验收。
//
// 怎么跑：`node --test skin-picker/test/picker.test.mjs`（**不要求**把包放进引擎的 `workshop/` 下）。
// 本文件可以 import 引擎的 shared/（包本身不 import 引擎；test 是作者侧的，这条与 mod-xie 的 pack 测试同一约定）：
//   * `validateC2S` —— 广播消息的**形状判据必须与服务端同一份实现**，不能拿一份抄的 spec 自证清白；
//   * 迷你 DOM（本文件里的小 stub）—— mount 的宿主交互（点击 → 偏好 + 广播）在没有 Chrome 的本机也能跑。
//
// 【我方改写说明】原文件写死 `import { validateC2S } from '../../shared/protocol.js'`，那是「包位于引擎仓库的
// `workshop/` 下」这一条**仓库布局假设**：改写产物放在 `_up/mod-rewrites/时装/skin-picker/` 时它报
// ERR_MODULE_NOT_FOUND —— 是测试脚本的路径问题，不是包内容的问题。现在按下面的顺序找引擎，找不到就**明确
// skip 并打印原因**；**判据一条没放松**（形状那一半只有拿真引擎校验器才算数，所以宁可 skip 也不抄假判据）：
//   1. `SP_ENGINE_ROOT` 环境变量（指向引擎仓库根；本轮所有命令都用它）；
//   2. 从本文件往上逐级探 `shared/protocol.js`（覆盖原布局 `workshop/skin-picker/test/`，也覆盖包放在引擎根下）；
//   3. `SP_WORKSHOP_ROOT` 的同级 `_engine/` / `engine/`（改写布局：`_up/mod-rewrites/时装/` 与 `_up/mod-rewrites/_engine/`）。
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

import {
  PREF_PREFIX, KINDS, prefKey, legacyPrefKey, pointer, parsePointer, entriesFor, resolveSkin, artFor,
  pickMessage, charIdFor, readChoice, writeChoice, appearance, mount,
} from '../client/picker.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));

/** 找一个「根目录」，它下面 relative 指的那些文件都存在（都找到才算）。 */
function probe(candidates, relative) {
  for (const dir of candidates) {
    if (!dir) continue;
    const root = path.resolve(dir);
    if (relative.every((rel) => fs.existsSync(path.join(root, rel)))) return root;
  }
  return null;
}

function resolveEngineRoot() {
  const ancestors = [];
  for (let dir = HERE; ; ) {
    ancestors.push(dir);
    const up = path.dirname(dir);
    if (up === dir) break;
    dir = up;
  }
  const siblings = [];
  for (const dir of ancestors) {
    const base = path.dirname(dir);
    siblings.push(path.join(base, '_engine'), path.join(base, 'engine'));
  }
  return probe([
    process.env.SP_ENGINE_ROOT,
    ...ancestors,
    ...siblings,
  ], [path.join('shared', 'protocol.js')]);
}

const ENGINE_ROOT = resolveEngineRoot();
let validateC2S = null;
let engineSkipReason = '';

if (ENGINE_ROOT) {
  // pathToFileURL：Windows 绝对路径直接 import 会被当成协议名
  const mod = await import(pathToFileURL(path.join(ENGINE_ROOT, 'shared', 'protocol.js')).href);
  validateC2S = mod.validateC2S;
  if (typeof validateC2S !== 'function') {
    engineSkipReason = `引擎模块 ${ENGINE_ROOT}/shared/protocol.js 没有导出 validateC2S`;
    validateC2S = null;
  }
} else {
  engineSkipReason = `找不到引擎的 shared/protocol.js（试过 SP_ENGINE_ROOT=${process.env.SP_ENGINE_ROOT || '<未设置>'}，并从 ${HERE} 往上逐级探过）`;
}

/** 广播形状那些断言的**前置**：只在真引擎校验器就位时跑；否则点名 skip（不抄一份假判据代替）。 */
function needEngine(t) {
  if (validateC2S) return true;
  console.error(`[skin-picker/test] SKIP：${engineSkipReason}；设 SP_ENGINE_ROOT=<引擎仓库根> 再跑（判据不放松）`);
  if (t && typeof t.skip === 'function') t.skip(`需要引擎校验器：${engineSkipReason}`);
  return false;
}

// ---- 迷你 DOM：只实现 mount 用到的那几个成员（不用 jsdom，本机没有浏览器也跑得动） ----
function makeEl(tag) {
  const el = {
    tagName: tag, children: [], attrs: {}, listeners: {},
    className: '', src: '', alt: '', loading: '', type: '',
    classList: {
      add(c) { el.className = `${el.className} ${c}`.trim(); },
      contains(c) { return el.className.split(/\s+/).includes(c); },
    },
    setAttribute(k, v) { el.attrs[k] = String(v); },
    getAttribute(k) { return k in el.attrs ? el.attrs[k] : null; },
    appendChild(child) { el.children.push(child); child.parentElement = el; return child; },
    addEventListener(type, fn) { el.listeners[type] = fn; },
    remove() {
      if (el.parentElement) el.parentElement.children = el.parentElement.children.filter((c) => c !== el);
      el.parentElement = null;
    },
  };
  Object.defineProperty(el, 'textContent', {
    get: () => el._text || '',
    set: (v) => { el._text = String(v); if (v === '') el.children = []; },
  });
  return el;
}
const doc = { createElement: makeEl };

/** 假注入面：与引擎给面板的那一份同形（只有 data / session / log / host / hostKey / pack / id）。 */
function makeCtx({ hostKey = null, assets = null, chess = null, prefs = new Map(), sent = [] } = {}) {
  const host = makeEl('div');
  host.ownerDocument = doc;
  if (hostKey) host.setAttribute('data-mod-slot-key', hostKey);
  host.setAttribute('data-mod-panel', `skin-picker/skins#${hostKey}`);
  const container = makeEl('div');
  container.appendChild(host);
  const ctx = {
    pack: 'skin-picker', id: 'skins', host, hostKey,
    data: { get: (n) => (n === 'assets' ? assets : n === 'chess' ? chess : null) },
    session: {
      getPref: (k, d) => (prefs.has(k) ? prefs.get(k) : d),
      setPref: (k, v) => { prefs.set(k, v); return true; },
      send: (t, f) => { sent.push({ t, ...f }); return true; },
    },
    log: { info() {}, warn() {}, error() {} },
  };
  return { ctx, host, container, prefs, sent };
}

/** 合并后的 assets 表的一小截（形状照 `mergeWorkshopSkins` 的产物：按 charId 分组、art 是绝对 URL）。 */
const ASSETS = {
  chars: {
    char_103_angel: { avatar: '/assets/char/avatar/char_103_angel.png', portrait: '/assets/char/portrait/char_103_angel_1.png' },
  },
  skins: {
    char_103_angel: [
      {
        pack: 'skin-catalogue', id: 'char_103_angel_wild_1', name: '野地秘行', series: '生命之地',
        art: { avatar: '/workshop-assets/skin-catalogue/skins/char_103_angel_wild_1/avatar.png', portrait: '/workshop-assets/skin-catalogue/skins/char_103_angel_wild_1/portrait.png' },
      },
      // 只有头像图的时装：业主实测撞到的那个形状 —— 立绘这一条 kind 上它必须如实回落
      { pack: 'skin-catalogue', id: 'avatar_only_1', name: '只有头像', art: { avatar: '/w/avatar-only/avatar.png' } },
      { pack: 'skin-catalogue', id: 'no-art_1', name: '无图时装' },
    ],
  },
};

test('指针：<包id>:<皮肤id> 与裸 id 两种写法', () => {
  assert.equal(pointer('skin-catalogue', 'wild_1'), 'skin-catalogue:wild_1');
  assert.deepEqual(parsePointer('skin-catalogue:wild_1'), { pack: 'skin-catalogue', id: 'wild_1' });
  assert.deepEqual(parsePointer('wild_1'), { pack: null, id: 'wild_1' });
  for (const bad of [null, undefined, '', 5, ':x', 'x:', {}]) assert.equal(parsePointer(bad), null, `bad: ${String(bad)}`);
});

test('列与查找：按干员分组、指针要双命中、裸 id 命中即可', () => {
  assert.equal(entriesFor(ASSETS, 'char_103_angel').length, 3, '两套有图 + 一套只有头像图的');
  assert.equal(entriesFor(ASSETS, 'char_none').length, 0);
  assert.equal(entriesFor(null, 'char_103_angel').length, 0);
  assert.equal(resolveSkin(ASSETS, 'char_103_angel', 'skin-catalogue:char_103_angel_wild_1').name, '野地秘行');
  assert.equal(resolveSkin(ASSETS, 'char_103_angel', 'char_103_angel_wild_1').name, '野地秘行');
  assert.equal(resolveSkin(ASSETS, 'char_103_angel', 'other-pack:char_103_angel_wild_1'), null, '包前缀不命中就不该命中');
  assert.equal(resolveSkin(ASSETS, 'char_other', 'char_103_angel_wild_1'), null, '不能跨干员借外观');
  assert.equal(resolveSkin(ASSETS, 'char_103_angel', 'missing'), null);
});

test('artFor：只取链要的四个字段；没有图给 null', () => {
  assert.deepEqual(artFor(resolveSkin(ASSETS, 'char_103_angel', 'char_103_angel_wild_1')),
    { avatar: '/workshop-assets/skin-catalogue/skins/char_103_angel_wild_1/avatar.png', portrait: '/workshop-assets/skin-catalogue/skins/char_103_angel_wild_1/portrait.png' });
  assert.equal(artFor(resolveSkin(ASSETS, 'char_103_angel', 'no-art_1')), null);
  assert.equal(artFor(null), null);
});

test('广播消息：形状必须过引擎的 validateC2S（服务端同一份判据）', (t) => {
  if (!needEngine()) return t.skip(engineSkipReason);
  const msg = { t: 'room.appearance', ...pickMessage('char_103_angel', 'char_103_angel_wild_1') };
  assert.equal(validateC2S(msg), null, '引擎校验器要接受它');
  assert.deepEqual(msg.picks, { char_103_angel: { skinId: 'char_103_angel_wild_1' } });
  assert.equal(pickMessage('char_103_angel', ''), null);
  assert.equal(pickMessage('', 'x'), null);
  assert.equal(pickMessage('char_103_angel', { bad: 1 }), null);
  // 包指针也合法（协议 isId 的字符集含冒号）
  assert.equal(validateC2S({ t: 'room.appearance', ...pickMessage('char_103_angel', 'skin-catalogue:x') }), null);
});

test('宿主键 → 干员 id：chess 表优先，charId 形状直接接受，其余 null', () => {
  const chess = { chess_char_103_angel_a: { chessId: 'chess_char_103_angel_a', charId: 'char_103_angel' } };
  assert.equal(charIdFor(chess, 'chess_char_103_angel_a'), 'char_103_angel');
  assert.equal(charIdFor(chess, 'char_103_angel'), 'char_103_angel', '替补路径本来就是 charId');
  assert.equal(charIdFor(chess, 'chess_unknown'), null);
  assert.equal(charIdFor(chess, null), null);
});

const WILD_AVATAR = '/workshop-assets/skin-catalogue/skins/char_103_angel_wild_1/avatar.png';
const WILD_PORTRAIT = '/workshop-assets/skin-catalogue/skins/char_103_angel_wild_1/portrait.png';

test('外观提供者：包声明的时装 id 解析成 art，而且**只回答被问的那一条 kind**', () => {
  const { ctx } = makeCtx({ assets: ASSETS });
  const provider = appearance(ctx);
  // 原作者口径（拿时装 id 来问）照旧，但形状从「整套 art」收窄成「这一条 kind 的一张图」
  assert.deepEqual(provider.lookup('portrait', 'char_103_angel', 'char_103_angel_wild_1'), { portrait: WILD_PORTRAIT });
  assert.deepEqual(provider.lookup('avatar', 'char_103_angel', 'char_103_angel_wild_1'), { avatar: WILD_AVATAR });
  assert.equal(provider.lookup('portrait', 'char_103_angel', 'no-art_1'), null, '声明了但没有图 → 回落');
  assert.equal(provider.lookup('portrait', 'char_103_angel', 'char_103_angel_1'), null, '官方后缀 id 不归提供者管');
  assert.equal(provider.lookup('portrait', 'char_other', 'char_103_angel_wild_1'), null, '不能串到别的干员');
  assert.equal(provider.lookup('chars', 'char_103_angel', 'char_103_angel_wild_1'), null, 'kind 不是立绘/头像 → 不回答（旧口径不再被接受）');
  assert.equal(provider.lookup(undefined, 'char_103_angel', 'char_103_angel_wild_1'), null, '没有 kind → 不回答');
  const empty = appearance(makeCtx({ assets: null }).ctx);
  assert.equal(empty.lookup('portrait', 'char_103_angel', 'char_103_angel_wild_1'), null, '没有清单 → 不抛、回落');
});

// 这一条是【我方改写说明】里那个改动的验收：本引擎的链**永远拿着原版 id 来问**（它不把「玩家选的那套」
// 写进 `chess.assets.portrait`），所以提供者必须自己先读本机偏好 —— 否则换装对画面无感。
test('外观提供者：本机偏好里选了某套 ⇒ 拿原版 id 来问也返回那套的 art；没选 ⇒ null（链回落）', () => {
  const prefs = new Map();
  const { ctx } = makeCtx({ assets: ASSETS, prefs });
  const provider = appearance(ctx);

  // 没选过：链问的是原版 id，我们不认识它 → null
  assert.equal(provider.lookup('portrait', 'char_103_angel', 'char_103_angel_1'), null);

  // 选了：同一句查询现在返回那套的 art —— 画面因此改变
  writeChoice(ctx, 'char_103_angel', 'skin-catalogue:char_103_angel_wild_1', 'portrait');
  assert.deepEqual(provider.lookup('portrait', 'char_103_angel', 'char_103_angel_1'), { portrait: WILD_PORTRAIT });
  assert.deepEqual(provider.lookup('portrait', 'char_103_angel', 'char_103_angel_wild_1'), { portrait: WILD_PORTRAIT },
    '原作者口径（拿时装 id 问）照旧');
  // 头像这一条 kind 各记各的：给头像也选同一套 ⇒ 它答的是这一套的**头像**图
  writeChoice(ctx, 'char_103_angel', 'skin-catalogue:char_103_angel_wild_1', 'avatar');
  assert.deepEqual(provider.lookup('avatar', 'char_103_angel', 'char_103_angel_1'), { avatar: WILD_AVATAR });
  // 头像没选过时：不拿立绘那一格的心意作答（那正是「分开受控」）
  writeChoice(ctx, 'char_103_angel', null, 'avatar');
  assert.equal(provider.lookup('avatar', 'char_103_angel', 'char_103_angel_1'), null, '头像这一格空着 ⇒ 我不知道');

  // 选了但那一套没有图：回落（不能假装有图、也不能顺手画别的）
  writeChoice(ctx, 'char_103_angel', 'no-art_1', 'portrait');
  assert.equal(provider.lookup('portrait', 'char_103_angel', 'char_103_angel_1'), null);

  // 偏好只认这名干员的：别人的偏好不外溢
  writeChoice(ctx, 'char_103_angel', 'skin-catalogue:char_103_angel_wild_1', 'portrait');
  assert.equal(provider.lookup('portrait', 'char_other', 'char_103_angel_1'), null, '不能串到别的干员');

  // 清除偏好 = 回到默认外观
  writeChoice(ctx, 'char_103_angel', null, 'portrait');
  assert.equal(provider.lookup('portrait', 'char_103_angel', 'char_103_angel_1'), null);
});

// ---------------------------------------------------------------------------------------------------
// 【本次改动】立绘与头像**分开受控**（业主裁决）：两条 kind 各存一份偏好、各答各的图，
// 一份只有一张图的时装在另一条 kind 上**如实回落**而不是硬顶。
// ---------------------------------------------------------------------------------------------------
test('偏好按 kind 分开：两条 kind 各写各的键，互不影响；旧键仍然读（老玩家不丢选择）', () => {
  const prefs = new Map();
  const { ctx } = makeCtx({ assets: ASSETS, prefs });
  assert.deepEqual([...KINDS], ['portrait', 'avatar'], '两条 kind 就是这两个值');
  assert.equal(prefKey('portrait', 'char_103_angel'), `${PREF_PREFIX}portrait:char_103_angel`);
  assert.equal(prefKey('avatar', 'char_103_angel'), `${PREF_PREFIX}avatar:char_103_angel`);
  assert.equal(legacyPrefKey('char_103_angel'), `${PREF_PREFIX}char_103_angel`);

  // 只给立绘选：头像这一条 kind 不受影响
  assert.equal(writeChoice(ctx, 'char_103_angel', 'skin-catalogue:char_103_angel_wild_1', 'portrait'), true);
  assert.equal(prefs.get(prefKey('portrait', 'char_103_angel')), 'skin-catalogue:char_103_angel_wild_1');
  assert.equal(prefs.has(prefKey('avatar', 'char_103_angel')), false, '不许顺手写别人那一格');
  assert.equal(readChoice(ctx, 'char_103_angel', 'portrait'), 'skin-catalogue:char_103_angel_wild_1');
  assert.equal(readChoice(ctx, 'char_103_angel', 'avatar'), null, '头像还是没选过');

  // 再给头像选另一套：两条并存
  assert.equal(writeChoice(ctx, 'char_103_angel', 'avatar_only_1', 'avatar'), true);
  assert.equal(readChoice(ctx, 'char_103_angel', 'portrait'), 'skin-catalogue:char_103_angel_wild_1');
  assert.equal(readChoice(ctx, 'char_103_angel', 'avatar'), 'avatar_only_1');

  // 清掉一条不影响另一条
  assert.equal(writeChoice(ctx, 'char_103_angel', null, 'avatar'), true);
  assert.equal(readChoice(ctx, 'char_103_angel', 'avatar'), null);
  assert.equal(readChoice(ctx, 'char_103_angel', 'portrait'), 'skin-catalogue:char_103_angel_wild_1', '另一格原样');

  // 不认识的 kind（`'chars'` 是旧口径）/ 坏 charId 一律不写（宁可不生效，也不要把选择写到别人的那一格上）
  assert.equal(writeChoice(ctx, 'char_103_angel', 'x', 'chars'), false);
  assert.equal(prefs.has('skin:chars:char_103_angel'), false, '不认识的 kind 连键都不落');
  assert.equal(readChoice(ctx, 'char_103_angel', 'chars'), null);
  assert.equal(writeChoice(ctx, '', 'x', 'portrait'), false);
  // 省略 kind ⇒ 'portrait'（参数默认值，旧调用点照旧）
  assert.equal(writeChoice(ctx, 'char_103_angel', 'skin-catalogue:char_103_angel_wild_1'), true);
});

test('旧键（`skin:<charId>`）作为公共退路：两条 kind 都没各自选择时仍然生效', () => {
  const prefs = new Map([[legacyPrefKey('char_103_angel'), 'skin-catalogue:char_103_angel_wild_1']]);
  const { ctx } = makeCtx({ assets: ASSETS, prefs });
  const provider = appearance(ctx);
  assert.equal(readChoice(ctx, 'char_103_angel', 'portrait'), 'skin-catalogue:char_103_angel_wild_1');
  assert.equal(readChoice(ctx, 'char_103_angel', 'avatar'), 'skin-catalogue:char_103_angel_wild_1', '旧选择两面都还是它');
  assert.deepEqual(provider.lookup('portrait', 'char_103_angel', 'char_103_angel_1'), { portrait: WILD_PORTRAIT });
  assert.deepEqual(provider.lookup('avatar', 'char_103_angel', 'char_103_angel_1'), { avatar: WILD_AVATAR });

  // 只给立绘单独改了之后：立绘看新键，头像继续走旧键（老选择不丢）
  writeChoice(ctx, 'char_103_angel', 'avatar_only_1', 'portrait');
  assert.equal(readChoice(ctx, 'char_103_angel', 'portrait'), 'avatar_only_1');
  assert.equal(readChoice(ctx, 'char_103_angel', 'avatar'), 'skin-catalogue:char_103_angel_wild_1');
  assert.equal(prefs.get(legacyPrefKey('char_103_angel')), 'skin-catalogue:char_103_angel_wild_1', '旧键不被改写');
});

test('一份**只有头像图**的时装：头像这一条 kind 用它，立绘这一条 kind 如实给 null（链回落官方）', () => {
  const prefs = new Map();
  const { ctx } = makeCtx({ assets: ASSETS, prefs });
  const provider = appearance(ctx);
  // 两条 kind 都选这一套「只有头像」的时装 —— 答案必须不同：头像有图、立绘没有
  writeChoice(ctx, 'char_103_angel', 'avatar_only_1', 'portrait');
  writeChoice(ctx, 'char_103_angel', 'avatar_only_1', 'avatar');

  assert.equal(provider.lookup('portrait', 'char_103_angel', 'char_103_angel_1'), null,
    '立绘这一问：这一套没有立绘图 ⇒ 「我不知道」，让链回落官方立绘（不许拿头像顶上）');
  assert.deepEqual(provider.lookup('avatar', 'char_103_angel', 'char_103_angel_1'), { avatar: '/w/avatar-only/avatar.png' },
    '头像这一问：有图 ⇒ 用它');
});

test('面板：没有干员键时给空态提示，不抛', () => {
  const { ctx } = makeCtx({ hostKey: null, assets: ASSETS });
  const handle = mount(ctx);
  assert.equal(ctx.host.children.length, 1);
  const text = JSON.stringify(ctx.host.children[0], (k, v) => (k === 'parentElement' ? undefined : v));
  assert.match(text, /打开一名干员/);
  handle.unmount();
  assert.equal(ctx.host.children.length, 0);
});

test('面板：列出「默认 + 每一套」，点击写偏好并广播（换回默认只清本机）', () => {
  const prefs = new Map();
  const sent = [];
  const chess = { chess_char_103_angel_a: { charId: 'char_103_angel' } };
  const { ctx, host } = makeCtx({ hostKey: 'chess_char_103_angel_a', assets: ASSETS, chess, prefs, sent });
  const handle = mount(ctx);

  const box = host.children[0];
  /** 列表节点按类名找（选了之后列表**后面**还有一行提示，`.at(-1)` 会拿到那一行）。 */
  const listOf = (b) => b.children.find((c) => typeof c.className === 'string' && c.className.includes('skin-picker__list'));
  /** 分段选择里那一个按钮（立绘 / 头像）。 */
  const modeAt = (b, kind) => b.children
    .find((c) => typeof c.className === 'string' && c.className.includes('skin-picker__segment'))
    .children.find((c) => c.getAttribute('data-kind') === kind);
  const list = listOf(box);
  assert.equal(list.children.length, 4, '默认 + 三套');
  assert.equal(list.children[0].className.includes('is-current'), true, '还没选 → 默认是当前');
  assert.equal(modeAt(box, 'portrait').getAttribute('aria-pressed'), 'true', '默认在「立绘」这一段');

  // 点第一套（默认那一段是立绘 ⇒ 写立绘那一格）
  list.children[1].listeners.click();
  assert.equal(prefs.get(`${PREF_PREFIX}portrait:char_103_angel`), 'skin-catalogue:char_103_angel_wild_1');
  assert.equal(sent.length, 1);
  // 引擎校验器那一句只在它真的在时跑（面板交互本身与它无关；README「我方改写说明」里点名这条）
  if (validateC2S) assert.equal(validateC2S(sent[0]), null, '发出去的每一条都要过引擎的校验器');
  assert.deepEqual(sent[0].picks, { char_103_angel: { skinId: 'char_103_angel_wild_1' } });

  // 重画之后：那一条是当前
  const list2 = listOf(host.children[0]);
  assert.equal(list2.children[1].className.includes('is-current'), true);
  assert.equal(list2.children[0].className.includes('is-current'), false);

  // 点「默认外观」：清本机偏好；协议没有清除语义 → 不发消息
  list2.children[0].listeners.click();
  assert.equal(prefs.get(`${PREF_PREFIX}portrait:char_103_angel`), null);
  assert.equal(sent.length, 1, '不回发消息（没有清除语义）');
  assert.equal(readChoice(ctx, 'char_103_angel', 'portrait'), null);

  handle.unmount();
});

// 【本次改动】面板那一半的「分开受控」：切到「头像」再点一套，写的是头像那一格，立绘那一格一字不动。
test('面板：立绘 / 头像两段各写各的偏好，互不影响', () => {
  const prefs = new Map();
  const sent = [];
  const chess = { chess_char_103_angel_a: { charId: 'char_103_angel' } };
  const { ctx, host } = makeCtx({ hostKey: 'chess_char_103_angel_a', assets: ASSETS, chess, prefs, sent });
  const handle = mount(ctx);

  const boxOf = () => host.children[0];
  const listOf = (b) => b.children.find((c) => typeof c.className === 'string' && c.className.includes('skin-picker__list'));
  const modeAt = (b, kind) => b.children
    .find((c) => typeof c.className === 'string' && c.className.includes('skin-picker__segment'))
    .children.find((c) => c.getAttribute('data-kind') === kind);

  // 立绘：点「野地秘行」（列表第 1 项）
  listOf(boxOf()).children[1].listeners.click();
  assert.equal(readChoice(ctx, 'char_103_angel', 'portrait'), 'skin-catalogue:char_103_angel_wild_1');
  assert.equal(readChoice(ctx, 'char_103_angel', 'avatar'), null, '头像这一格还没被碰过');

  // 切到「头像」：当前选择是「默认」（因为头像那一条 kind 上还没选过）
  modeAt(boxOf(), 'avatar').listeners.click();
  const after = boxOf();
  assert.equal(modeAt(after, 'avatar').getAttribute('aria-pressed'), 'true', '切过去之后那一段是当前');
  assert.equal(modeAt(after, 'portrait').getAttribute('aria-pressed'), 'false');
  assert.equal(listOf(after).children[0].className.includes('is-current'), true, '头像还没选 → 默认是当前');
  assert.equal(listOf(after).children[1].className.includes('is-current'), false, '立绘的选择不算在头像上');

  // 头像：点「只有头像」（列表第 2 项）
  listOf(after).children[2].listeners.click();
  assert.equal(readChoice(ctx, 'char_103_angel', 'avatar'), 'skin-catalogue:avatar_only_1');
  assert.equal(readChoice(ctx, 'char_103_angel', 'portrait'), 'skin-catalogue:char_103_angel_wild_1', '立绘那一格原样');
  assert.equal(sent.length, 2, '每次选择各广播一条');

  // 切回立绘：那一段的当前选择还是原来那一套
  modeAt(boxOf(), 'portrait').listeners.click();
  const back = boxOf();
  assert.equal(listOf(back).children[1].className.includes('is-current'), true, '立绘那一段仍是野地秘行');
  assert.equal(listOf(back).children[2].className.includes('is-current'), false);
  handle.unmount();
});

test('面板：宿主换人时清掉自己上一份（注册表不摘旧挂载）；没有时装时给提示', () => {
  const prefs = new Map();
  const sent = [];
  const chess = { chess_char_103_angel_a: { charId: 'char_103_angel' } };
  const first = makeCtx({ hostKey: 'chess_char_103_angel_a', assets: ASSETS, chess, prefs, sent });
  mount(first.ctx);
  const stale = makeEl('div');
  stale.setAttribute('data-mod-panel', 'skin-picker/skins#chess_char_103_angel_a');
  first.container.appendChild(stale);

  // 同一容器里换到另一名干员：新挂载先清掉属于本包、别的宿主键的兄弟节点
  const second = makeCtx({ hostKey: 'chess_char_103_angel_a', assets: ASSETS, chess, prefs, sent });
  first.container.children = first.container.children.filter((c) => c !== second.host);
  first.container.appendChild(second.host);
  mount(second.ctx);
  assert.equal(first.container.children.some((c) => c === stale), false, '旧键那一份要被清掉');

  // 没有时装声明的干员：提示，不抛
  const third = makeCtx({ hostKey: 'chess_char_003_kalts_a', assets: ASSETS, chess: { chess_char_003_kalts_a: { charId: 'char_003_kalts' } } });
  mount(third.ctx);
  const text = JSON.stringify(third.host.children[0], (k, v) => (k === 'parentElement' ? undefined : v));
  assert.match(text, /还没有为这名干员声明时装/);
});

test('偏好：读写只走 ctx.session；引擎拒绝写入时报 false 也不抛', () => {
  const { ctx } = makeCtx({ assets: ASSETS });
  assert.equal(writeChoice(ctx, 'char_103_angel', 'skin-catalogue:wild_1'), true);
  assert.equal(readChoice(ctx, 'char_103_angel'), 'skin-catalogue:wild_1');
  assert.equal(writeChoice(ctx, 'char_103_angel', null), true);
  assert.equal(readChoice(ctx, 'char_103_angel'), null);
  const hostile = { session: { getPref() { throw new Error('boom'); }, setPref() { throw new Error('boom'); } } };
  assert.equal(readChoice(hostile, 'char_x'), null);
  assert.equal(writeChoice(hostile, 'char_x', 'a:b'), false);
});
