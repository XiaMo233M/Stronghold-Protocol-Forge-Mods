// panel/card.js —— 「卫戍协议UI·选择性安装包」收录说明浮层卡。
//
// 挂载点 `root.overlays`（十格之一，注册点按需创建容器，`public/js/ui/extensions.js:90-94` / `:117`）。
// 它只碰这套包模型今天真的给包的那几样东西：
//   * `ctx.host`   —— 属于这次挂载的 <div>（`extensions.js:1209-1219`）；
//   * `ctx.data`   —— 只读冻结快照，只读声明过的表（`extensions.js:1151-1172`）；
//   * `ctx.session.setPref / getPref` —— 这一格的偏好口（`extensions.js:716-738`）；
//   * `t()`        —— 站点上的 i18n 模块（WORKSHOP.md:1169 明说面板模块可以直接 import 引擎模块）。
// 没有 store、没有 match、没有 runner、没有 audio —— 这张卡也不需要它们。
//
// ⚠️ 一处必须写明的读数限制：`ctx.data.get(name)` 把**第一次**读到的值（哪怕是 `null`）缓存下来
// （`extensions.js:1163-1168`：`dataSnapshots.set(name, raw === null ? null : …)`，之后只看 `has(name)`）。
// 而 `/data/notices.json` 是玩家打开一次「公告」才抓的（`public/js/ui/notices.js` 的 `useData('notices')`），
// 所以挂载那一刻多半还没到 —— 那一段就**不画**，不做假占位。公告那半条另有出口：本包的 `pack.json.notices`
// 会被引擎自己的「公告 / 鸣谢」面板读到，与这张卡无关。

import { t } from '/shared/i18n.js';

/** 写进偏好的键（引擎会加 `<包 id>/` 前缀，`extensions.js:730`）。 */
const DISMISSED = 'dismissed';

/** 一条「标签：正文」行。 */
function line(doc, label, body) {
  const p = doc.createElement('p');
  p.className = 'uisc__line';
  const b = doc.createElement('b');
  b.textContent = label;
  p.appendChild(b);
  p.appendChild(doc.createTextNode(body));
  return p;
}

/** 一个按钮。 */
function button(doc, label, extra) {
  const el = doc.createElement('button');
  el.type = 'button';
  el.className = extra ? 'uisc__btn uisc__btn--ghost' : 'uisc__btn';
  el.textContent = label;
  return el;
}

/**
 * @param {any} ctx 面板上下文（`extensions.js:1173-1183` 的闭集）
 * @returns {{ unmount(): void } | Record<string, never>}
 */
export function mount(ctx) {
  const host = ctx && ctx.host;
  if (!host || !host.ownerDocument) return {};
  // 「知道了，不再显示」是**这台机器上这个包**的一格偏好，不是对局状态，也不进任何摘要。
  if (ctx.session.getPref(DISMISSED, false) === true) return {};

  const doc = host.ownerDocument;
  const card = doc.createElement('section');
  card.className = 'uisc';
  card.setAttribute('role', 'note');
  card.setAttribute('aria-label', t('收录说明'));

  const head = doc.createElement('header');
  head.className = 'uisc__head';
  const title = doc.createElement('h2');
  title.className = 'uisc__title';
  title.textContent = t('卫戍协议UI · 选择性安装包');
  const badge = doc.createElement('span');
  badge.className = 'uisc__badge';
  badge.textContent = t('收录件 · 需直装');
  head.appendChild(title);
  head.appendChild(badge);

  const body = doc.createElement('div');
  body.className = 'uisc__body';
  body.appendChild(line(doc, t('装法：'), t('整文件覆盖客户端 / 非一键包 / 须按包内 AGENTS.md 直装 / 会覆盖目标客户端改动')));
  body.appendChild(line(doc, t('来源：'), t('stronghold-ui-20261014（MANIFEST: package=stronghold-ui-20261014 / basedOn=Stronghold Protocol 0.2.6 定制部署）')));
  body.appendChild(line(doc, t('授权：'), t('包内 README / AGENTS.md / MANIFEST / 安装说明均未声明许可证与作者 ⇒ 收录按站点惯例标注来源，再分发前请与作者确认')));

  // 合并公告里属于本包的那一条 —— 到达了才画（见文件头的读数限制）。
  let mine = null;
  try {
    const notices = ctx.data.get('notices');
    if (notices && Array.isArray(notices.announcements)) {
      mine = notices.announcements.find((a) => a && a.pack === ctx.pack) || null;
    }
  } catch { mine = null; }
  if (mine && typeof mine.summary === 'string' && mine.summary) {
    body.appendChild(line(doc, `${mine.version} · `, mine.summary));
  }

  const foot = doc.createElement('footer');
  foot.className = 'uisc__foot';
  const ok = button(doc, t('知道了，不再显示'), false);
  const close = button(doc, t('关闭'), true);
  foot.appendChild(ok);
  foot.appendChild(close);

  card.appendChild(head);
  card.appendChild(body);
  card.appendChild(foot);
  host.appendChild(card);

  const hide = () => { if (card.parentNode) card.parentNode.removeChild(card); };
  ok.addEventListener('click', () => { ctx.session.setPref(DISMISSED, true); hide(); });
  close.addEventListener('click', hide);

  return { unmount: hide };
}
