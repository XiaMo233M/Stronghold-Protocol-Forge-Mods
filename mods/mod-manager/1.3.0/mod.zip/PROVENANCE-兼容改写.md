# PROVENANCE — mod-manager（模组管理）1.3.0 · 兼容改写说明

本文件由**兼容改写者**添加。**原作者的署名与版本号原样保留**（`pack.json` 的 `author` = `the mod-manager mod`，
`version` = `1.3.0`），下面逐条写清这次改了什么、为什么、以及哪些东西一字未动。

## 1. 原作者

**`the mod-manager mod`** —— 原包作者署名原文，未改写。
原包的设计口径（下面第 5 项逐条列出）全部沿用，只换了落地方式。

## 2. 许可

原包 `pack.json` 的 `license` 字段未声明（原件只有 `id` / `name` / `version` / `author` / `description` / `client`）。
**本包不含任何素材**（无图片 / 音频 / 字体 / Spine / `.spresources`），全部内容是：
`pack.json`、`ui/manager.js`、`ui/manager.css`、`README.md` 与本文件。
不改写原作者对这份代码的任何权利主张；本仓库与改写者不主张额外权利，仅供非商业的学习与个人娱乐使用。

## 3. 兼容改写者

Stronghold-Protocol-Forge-Mods 维护者（本站）。

## 4. 来源

站上待审记录 `81ee31e68515`（作者提交的 `mod-manager` **1.3.0**，0.02 MB）。
原件在本引擎（`UPSTREAM_VERSION = 0.3.1`、`MOD_API_VERSION = 1`）下装不上：

```
CLIENT_WRAP_UNKNOWN_COMPONENT: client.panels["manager"].wraps: "lobby.modManager" is not a named engine component
（合法值：game.bondStrip / game.hud.topBar / game.shopCard / loadout.detail）
```

## 5. 改了什么（换落地方式，不换口径）

| 原件 | 本包 | 为什么 |
|---|---|---|
| 三条 `wraps`：`lobby.modManager`、`lobby.modPicker`、`room.modManager` | **全部去掉**；面板挂 `root.overlays`（引擎按需创建的全屏浮层，闭枚举里的第一个槽位） | 本引擎的**具名组件**只有四个，那三个不存在 ⇒ 整包被 `CLIENT_WRAP_UNKNOWN_COMPONENT` 拒。加这三个 wrap 点需要引擎同时提供对应的组件与 props 契约，而 `lobby.modManager` 在本引擎里**没有对应组件**（大厅只有 `ModPicker`，props 是 `{selected, onToggle}`，与原件期望的 `{available, selected, onSet}` 不一致）⇒ 直接注册也只会渲染出 `undefined`。与其猜一个契约，不如换一条引擎已经支持、且**面板明确允许**的路。 |
| 状态由 wrap 链的 `props` 注入（`available` / `selected` / `onSet`） | 读 `ctx.me.room.mods`（只读会话态，`null` = 全部启用）；写 `ctx.send('room.mods', { modIds })`（`PANEL_SEND_TYPES` 的两条之一，服务端另过房主校验） | 这两格是引擎**已经对外承诺**的面板读写面：前者是 `§28.8` 的「一格只读会话态」，后者是「面板能主动发的引擎消息」闭枚举。不需要引擎新增任何表面。 |
| 顶栏方图标按钮（`lobby.modManager` 那个落点） | 屏幕右下角的独立按钮（`.mod-host-inner`），浮层向上展开 | 顶栏那个落点不存在；右下角是浮层里最不挡操作、且不依赖任何屏布局的位置。 |
| `lobby.modPicker` 那条「把创建框里的旧列表收走」 | **不需要做**：本引擎的大厅创建框里本来就没有那张列表（`ModPicker` 是房间里的、且只显示本房间的集合） | 那条链是为了消除重复入口；本引擎没有那个入口，所以这一条自然消失，不是丢了功能。 |
| `room.modManager` 那条「房间里只读清单」 | 浮层在房间里显示为**只读**（非房主时开关禁用并给出提示） | 与原口径一致：集合在 `room.create` 那一刻定死，局内没有改集合的消息。 |

**沿用原作者的四条口径，逐条对应到本包的实现**：

1. **空集合 = 全选** —— `selected()` 返回 `null` 时开关全亮；`expanded()` 把「全部 id」展开，所以每一次点击
   都是字面上的意思（而不是把「全选」误读成「全不选」）。
2. **不列出自己** —— 列表过滤掉 `ctx.pack`；但写回时用 `normalise()` 永远把自己并进清单（关掉本包 =
   关掉这套界面，那不该是「点一下开关」能造成的结果）。
3. **「全部停用」= 只点名自己** —— `sendMods([selfId])`；它不贡献任何数据，所以等于「其余模组一律不生效」。
4. **四格锁定** —— `LOCKED = ['dev-ext','skin-picker','skin-supplement','operator-conflict']` 不列出、但永远写进
   清单。判据是**包 id**（改显示名不该把锁解掉），与原包一致。

**没有做的**：不改原作者的 CSS 观感（`manager.css` 的 `.mm*` 规则全部保留，只追加了「独立面板」这一档的
定位规则）；不新增任何服务端代码；不改引擎。

## 6. 包自带素材的来源

**不含素材**。见第 2 项。

## 验证

```
引擎：Stronghold-Protocol（UPSTREAM_VERSION 0.3.1 · MOD_API_VERSION 1）
loadWorkshop → packsLoaded = ['mod-manager'] · errors = 0
```
