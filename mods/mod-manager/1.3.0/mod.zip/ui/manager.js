// 模组管理（mod-manager）—— 客户端面板模块【兼容改写版】
//
// ⚠️ 原包 `the mod-manager mod` 1.3.0 用三条 `wraps` 链改写引擎组件
// （`lobby.modManager` / `lobby.modPicker` / `room.modManager`），但本引擎的具名组件闭枚举只有
// `game.bondStrip` / `game.hud.topBar` / `game.shopCard` / `loadout.detail` —— 它要的那三个不存在，
// 整个包因此装不上。原作者的界面与口径是好的，所以这里**换一条走得通的路**：同一套界面做成
// `root.overlays` 上的**独立面板**，只用一个引擎已有、且面板允许的读写面：
//
//   读 `ctx.me.room.mods`  （只读会话态；`null` = 本房间没点名集合 = 全部启用）
//   写 `ctx.send('room.mods', { modIds })`（`PANEL_SEND_TYPES` 的两条之一，服务端另过房主校验）
//   名字 `GET /mods/catalog.json`（服务器发布的包目录），取不到就回落包 id
//
// 原作者的四条口径原样保留：
//   ① 空 `mods` = 全选（「没声明集合」与「声明了全部」在服务端是同一件事）⇒ 开关默认全亮，
//      要关某一个先把整份展开，于是每次点击都是字面上的意思。
//   ② 不列出自己：关掉本包就是把这套界面一起关掉，所以它只参与状态判定与整份写入。
//   ③ 「全部停用」= 只点名自己一个包（它不贡献任何数据），其余模组一律不生效。
//   ④ 四格不列出（原包口径，2026-10-18）：`dev-ext` / `skin-picker` / `skin-supplement` /
//      `operator-conflict` —— 关掉它们等于把那份功能一起关掉，所以永远写进清单、不占开关。
//
// 样式沿用原包的 `manager.css`（`.mm*` 那一套），本文件只负责结构。

const CLS = 'mm';
const LOCKED = Object.freeze(['dev-ext', 'skin-picker', 'skin-supplement', 'operator-conflict']);
const CATALOG_URL = '/mods/catalog.json';

/**
 * @param {{ host: HTMLElement, pack?: string, me?: object, send?: Function,
 *           session?: { getPref?: Function, setPref?: Function },
 *           log?: { warn?: Function } }} ctx
 * @returns {(() => void) | undefined}
 */
export function mount(ctx) {
  const host = ctx?.host;
  if (!host || typeof host.appendChild !== 'function') return undefined;

  const selfId = typeof ctx.pack === 'string' ? ctx.pack : '';
  const prefs = ctx.session || {};
  let open = prefs.getPref ? prefs.getPref('open', false) === true : false;
  /** @type {Array<{ id: string, name: string }>} */
  let catalog = [];
  let catalogFailed = false;
  let timer = null;

  const root = document.createElement('div');
  root.className = `${CLS} ${CLS}--tools mod-host-inner`;
  host.appendChild(root);

  /** 本房间点名的集合；`null` = 全部启用。 */
  const selected = () => {
    const room = ctx.me && ctx.me.room ? ctx.me.room : null;
    return room && Array.isArray(room.mods) ? room.mods : null;
  };
  /** 只有房主能改（座位表第 0 位是房主）。 */
  const isHost = () => {
    const room = ctx.me && ctx.me.room ? ctx.me.room : null;
    return !!(room && room.mySeat === 0);
  };
  const nameOf = (id) => {
    const hit = catalog.find((x) => x.id === id);
    return hit && hit.name ? hit.name : id;
  };
  /** ① 空 = 全选 ⇒ 展开成「当前所有 id」。 */
  const expanded = () => (selected() ? [...selected()] : catalog.map((x) => x.id));
  /** ② ③ ④ 写回去：自己与四格永远在清单里。 */
  const normalise = (ids) => {
    const out = new Set(ids.filter((x) => typeof x === 'string' && x));
    if (selfId) out.add(selfId);
    for (const id of LOCKED) out.add(id);
    return [...out];
  };
  const sendMods = (ids) => {
    if (!isHost() || typeof ctx.send !== 'function') return false;
    return ctx.send('room.mods', { modIds: normalise(ids) }) !== false;
  };

  function draw() {
    const cur = selected();
    const on = (id) => (cur ? cur.includes(id) : true);
    const listable = catalog.filter((x) => x.id !== selfId && !LOCKED.includes(x.id));
    const onCount = listable.filter((x) => on(x.id)).length;
    const host_ = isHost();

    root.textContent = '';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `${CLS}__btn`;
    btn.title = '模组管理';
    btn.setAttribute('aria-label', '模组管理');
    btn.textContent = `模组 ${onCount}/${listable.length}`;
    btn.addEventListener('click', () => {
      open = !open;
      if (prefs.setPref) prefs.setPref('open', open);
      draw();
    });
    root.appendChild(btn);

    if (!open) return;

    const pop = document.createElement('div');
    pop.className = `${CLS}__pop panel brackets`;

    const head = document.createElement('div');
    head.className = 'panel__head';
    const title = document.createElement('b');
    title.textContent = '本房间使用的模组';
    head.appendChild(title);
    const actions = document.createElement('span');
    actions.className = 'panel__actions';
    for (const [label, fn] of [
      ['全部启用', () => { sendMods(catalog.map((x) => x.id)); draw(); }],
      ['全部停用', () => { sendMods([selfId]); draw(); }],
    ]) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = `${CLS}__master-label`;
      b.textContent = label;
      b.disabled = !host_;
      b.addEventListener('click', fn);
      actions.appendChild(b);
    }
    head.appendChild(actions);
    pop.appendChild(head);

    const body = document.createElement('div');
    body.className = 'panel__body';
    if (!host_) body.appendChild(note('只有房主能改；下面是本房间现在跑的那几个。'));
    if (catalogFailed) body.appendChild(note('取不到服务器包目录，暂时只显示包 id。'));

    const list = document.createElement('div');
    list.className = `${CLS}__list`;
    if (!listable.length) list.appendChild(note('这台服务器没有声明其它模组。'));
    for (const item of listable) {
      const isOn = on(item.id);
      const row = document.createElement('div');
      row.className = `${CLS}__row${isOn ? ' is-on' : ''}`;
      row.title = item.id; // ④ 名字上屏、id 留在 title

      const text = document.createElement('div');
      text.className = `${CLS}__text`;
      const idEl = document.createElement('span');
      idEl.className = `${CLS}__id`;
      idEl.textContent = nameOf(item.id);
      text.appendChild(idEl);
      row.appendChild(text);

      const sw = document.createElement('button');
      sw.type = 'button';
      sw.className = `${CLS}__switch${isOn ? ' is-on' : ''}`;
      sw.disabled = !host_;
      sw.setAttribute('role', 'switch');
      sw.setAttribute('aria-checked', String(isOn));
      const track = document.createElement('span');
      track.className = `${CLS}__track`;
      const knob = document.createElement('span');
      knob.className = `${CLS}__knob`;
      track.appendChild(knob);
      sw.appendChild(track);
      sw.addEventListener('click', () => {
        const next = expanded().filter((x) => x !== item.id);
        if (!isOn) next.push(item.id);
        sendMods(next);
        draw();
      });
      row.appendChild(sw);

      const state = document.createElement('span');
      state.className = `${CLS}__state`;
      state.textContent = isOn ? '启用' : '停用';
      row.appendChild(state);

      list.appendChild(row);
    }
    body.appendChild(list);
    pop.appendChild(body);
    root.appendChild(pop);
  }

  const note = (text) => {
    const p = document.createElement('p');
    p.className = `${CLS}__note`;
    p.textContent = text;
    return p;
  };

  const loadCatalog = async () => {
    try {
      const res = await fetch(CATALOG_URL, { credentials: 'same-origin' });
      if (!res.ok) throw new Error(String(res.status));
      const body = await res.json();
      const packs = Array.isArray(body?.packs) ? body.packs : (Array.isArray(body) ? body : []);
      catalog = packs
        .map((p) => (typeof p === 'string' ? { id: p, name: p } : { id: p?.id || '', name: p?.name || p?.id || '' }))
        .filter((p) => p.id);
    } catch (err) {
      catalogFailed = true;
      ctx.log?.warn?.(`[mod-manager] 取不到 ${CATALOG_URL}`, err);
    }
    draw();
  };

  draw();
  loadCatalog();
  // 浮层打开时轻量重画：房间集合可能被别人改，而本层读不到 store 的变更事件。
  timer = setInterval(() => { if (open) draw(); }, 2000);

  return () => {
    if (timer) clearInterval(timer);
    timer = null;
    if (root.parentNode) root.parentNode.removeChild(root);
  };
}
