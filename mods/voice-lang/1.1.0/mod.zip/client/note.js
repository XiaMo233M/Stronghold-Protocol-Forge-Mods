// voice-lang/client/note.js — 语音语种说明面板（`screen.loadout.detail` 槽位）。
//
// ## ⚠️ 更正（第二次投稿的原因）
//
// 本包第一版写的是「Forge 默认语种是 cn，改不了」。**这是错的**，实测后更正：
//
//   shared/constants.js:77-78   VOICE_LANGS = ['cn','jp','en','kr']；DEFAULT_VOICE_LANG = 'jp'
//                               （注释原文：`jp` is the default **since 0.9.0**）
//   public/js/ui/gameLogic/settings.js:30   DEFAULT_SETTINGS.voiceLang = DEFAULT_VOICE_LANG  → 'jp'
//   public/js/ui/gameLogic/settings.js:86   voiceLangFor(s, charId)：逐干员覆盖 → 全局 → 默认
//
// 也就是说 Paper-Yuan 那两条语音改动，Forge **原生就已经是了**：
//
//   ①「默认切到日语」       →  Already true。DEFAULT_VOICE_LANG = 'jp'，出厂即日语。
//   ②「加了『自定义』档位」  →  语义原生就有。voiceLangFor 的解析顺序是
//      voiceLangByChar[charId] → voiceLang → DEFAULT_VOICE_LANG，
//      正是「调过的按调的播、没调的自动播日语」。Forge 没有叫「自定义」的那颗单选按钮，
//      但把全局设为 jp 再逐干员覆盖，得到的就是同一个结果 —— 差的是 UI 上有没有那颗按钮。
//
// ⇒ 这一项**不需要 mod**，引擎已经做了。本包不提供任何功能，只把这个结论摆出来。
//
// ## 那包能改的那一半还剩什么
//
// 只有「给包自己带一份非默认语种的台词」：`voiceLangs` + `voices`（包内素材或作者自备 https CDN，
// 见 docs/MOD-SURFACE.md §28.13 / §28.36）。但**默认语种不能写进 `voiceLangs`** ——
// shared/workshop.js:1829 会返回 `VOICE_LANG_DEFAULT`，**整包拒**。
// 理由（shared/workshop.js:181）：同一批台词有两个写法的话，「客户端到底读哪一份」
// 就成了作者猜不出来的事。
//
// 本包不含任何音频文件，也不试图改任何播放行为 —— 上面的结论是「引擎已经做了」，
// 再补一份台词反而是把「到底读哪一份」变回二义。

/** 四句说明（面板显示；与上文的结论逐条对应）。 */
export const FACTS = Object.freeze([
  '默认语种：Forge 出厂就是日语（DEFAULT_VOICE_LANG = "jp"，自 0.9.0 起），不用改。',
  '「自定义」档位：语义原生就有 —— 解析顺序是 逐干员覆盖 → 全局 → 默认，没单独调的自动播日语。',
  '所以这一项不需要 mod。UI 上少的是那颗叫「自定义」的单选按钮，不是这个能力。',
  '包能做的只有自带非默认语种台词（voiceLangs）；把默认语种写进 voiceLangs 会整包拒（VOICE_LANG_DEFAULT）。',
]);

export function mount(ctx) {
  const host = ctx.host;
  const box = document.createElement('div');
  box.className = 'vlang';

  const title = document.createElement('div');
  title.className = 'vlang__title';
  title.textContent = '语音语种：引擎已原生支持，无需 mod';
  box.appendChild(title);

  const ul = document.createElement('ul');
  ul.className = 'vlang__list';
  for (const f of FACTS) {
    const li = document.createElement('li');
    li.textContent = f;
    ul.appendChild(li);
  }
  box.appendChild(ul);

  host.appendChild(box);

  return {
    unmount() { if (box.parentNode) box.parentNode.removeChild(box); },
  };
}
