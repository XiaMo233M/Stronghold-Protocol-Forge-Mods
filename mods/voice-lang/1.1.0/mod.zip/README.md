# 语音语种 —— **引擎已经做了，这一项不需要 mod**

作者：**纸鸢干机**（不是我做的 —— 灵感来自 Paper-Yuan 0.2.4，结论基于 Forge 0.16.0 实测）

## ⚠️ 本包第一版写错了，这是更正后的第二版

第一版写的是「Forge 默认语种是 `cn`，改不了」。**这是错的**。实测 `main`（0.16.0）：

```js
// shared/constants.js:77-78
export const VOICE_LANGS = Object.freeze(['cn', 'jp', 'en', 'kr']);
export const DEFAULT_VOICE_LANG = 'jp';   // 注释原文：`jp` is the default **since 0.9.0**

// public/js/ui/gameLogic/settings.js:30
export const DEFAULT_SETTINGS = Object.freeze({ … voiceLang: DEFAULT_VOICE_LANG, voiceLangByChar: … });

// public/js/ui/gameLogic/settings.js:86-89
export function voiceLangFor(s, charId) {
  const per = … s?.voiceLangByChar?.[charId] : null;
  if (VOICE_LANGS.includes(per)) return per;                       // ① 逐干员覆盖
  return VOICE_LANGS.includes(s?.voiceLang) ? s.voiceLang           // ② 全局
       : DEFAULT_VOICE_LANG;                                       // ③ 默认
}
```

## 对照 Paper-Yuan 那两条改动

| Paper-Yuan 0.2.4 | Forge 0.16.0 | 结论 |
|---|---|---|
| 语音默认切到日语 | `DEFAULT_VOICE_LANG = 'jp'`，**自 0.9.0 起**就是这样 | **早就有了** |
| 加「自定义」档位：调过的照常、没调的自动播日语 | `voiceLangFor` 的解析顺序 = 覆盖 → 全局 → 默认 | **语义原生就有** |
| — | 设置面板 `VoiceLangRow`（`public/js/ui/settings.js:300`）是四选一单选组 + 逐干员覆盖 | **UI 也有** |

差别只有一处：Forge 没有一颗**字面叫「自定义」**的单选按钮 —— 但把全局设为 `jp`、
再给个别干员单独覆盖，得到的就是同一个结果。**差的是按钮名字，不是能力。**

⇒ **这一项不需要做成 mod，引擎已经做了。**

## 那包在这一块还能做什么

只剩「给包自己带一份**非默认语种**的台词」：`voiceLangs` + `voices`
（包内素材或作者自备 https CDN，见 `docs/MOD-SURFACE.md` §28.13 / §28.36）。

**但默认语种不能写进 `voiceLangs`** —— `shared/workshop.js:1829` 返回
`VOICE_LANG_DEFAULT`，**整包拒**。理由写在同一处（`shared/workshop.js:181`）：

> 同一批台词有两个写法的话，「客户端到底读哪一份」就成了作者猜不出来的事。

本包**不含任何音频文件**，也不试图改任何播放行为 —— 结论是「引擎已经做了」，
再补一份台词反而是把「到底读哪一份」变回二义。

## 那这一包实际是什么

一个说明面板，把上面这些摆出来。装了它你会看到「引擎已原生支持，无需 mod」，
而不是装了个空包以为生效了 —— 这是它唯一的价值。
