# NOTICE — strawberry-ui 1.0.0

## 这是什么

Forge 的**纯 CSS 美化包**。全部视觉效果在 `ui/panel.css`，由 `client.panels[].styles` 注入。
它只改外观：布局、间距、配色、圆角、阴影、动效、徽标位置。**不改任何对局逻辑，不改协议，
不抬 `MOD_API_VERSION`，不改战果（`pack.json` 里 `combat: false`）。**

## 为什么一个「纯 CSS 包」里有一个 `.js` 文件

`ui/panel.js` 是一个**装载管道用的空壳**，不是业务逻辑。原因在引擎的形状层：

1. `client.panels[]` 的每一条**必须**有 `module`，且必须是以 `/workshop-panels/` 开头、`.js` 结尾的 URL
   （`public/js/ui/extensions.js` 对形状的硬校验，坏形状 = 整块面板被点名丢掉）。
2. 这个模块**必须导出 `mount`**（或 default 导出一个函数）。没有工厂函数的模块会被
   `CLIENT_PANEL_NO_MOUNT` 点名拒绝，而**样式表根本不会注入** —— 注入发生在工厂函数那一步之前，
   但要先过工厂函数这一关。
3. 这是引擎自己的参考写法：自带测试 `test/modClientStyles.test.js` 里的 `style-pack` 就是
   `export function mount() { return {}; }`。

所以这一个文件是**装载入口**，不要删。它刻意不读 store、不建 DOM、不发消息、不碰任何引擎对象。
（引擎另有一条「只提供外观、不挂界面」的模块路径 —— 导出 `appearance` 而没有 `mount` 也合法 ——
但那个通道全进程只允许一个提供者，本包用不起，也不该用它去占坑。）

## 素材

**本包不含任何图片、字体、语音、Spine 或官方解包资源字节。**
`ui/panel.css` 只**引用**引擎本地客户端已有的 `/assets/ui/...` 路径（例如
`/assets/ui/hudPanel/frame_mid_normal.png`），这些文件由玩家自己的客户端资源提供，不随本包分发。
每条背景都写成「纯色打底 + 图叠在上层」，资源缺失时退化成一个有边框的色块，而不是一片空白。

## 许可

`GPL-3.0-or-later`（与原件及 Forge 引擎 `package.json` 的声明一致）。
本包是投稿 `0e55a71ade93` 的兼容改写作品；原作的著作权归原作者，见 `PROVENANCE.md`。

完整许可文本随本包提供：`LICENSE`（GNU GPL v3 全文，35,149 字节，取自
https://www.gnu.org/licenses/gpl-3.0.txt ，sha256 `3972dc9744f6499f0f9b2dbf76696f2ae7ad8af9b23dde66d6af86c9dfb36986`）。
Forge 引擎仓库根目录的 `LICENSE` 是同一份文本。

## 与原件的关系

原件是一个**源码补丁**（`changes.patch`），不是可安装的包。它有两半：
能用样式表表达的一半（本包承接），和必须改渲染器的一半（部署动作、慢网补播、部署语音、
Pixi/Spine 视图的区域迁移）—— 后者属引擎侧，本包**不做**，且原件自己也不建议用面板接口去冒充它。
逐项分工见 `PROVENANCE.md`。