/**
 * 装载管道用的空壳模块 —— 不是业务逻辑，不要删。
 *
 * 引擎要求 `client.panels[]` 每一条都必须有 `module`（`public/js/ui/extensions.js` 里对
 * `/workshop-panels/<包>/<模块>.js` 形状的硬校验），并且这个模块必须导出 `mount`（或 default 导出一个函数）；
 * 否则整块面板被 `CLIENT_PANEL_NO_MOUNT` 点名拒绝，而**样式表根本不会注入**（注入发生在 mount 之前，
 * 但要先通过工厂函数这一关）。引擎自带的参考包 `style-pack` 用的就是同样的写法
 * （`test/modClientStyles.test.js`：`export function mount() { return {}; }`）。
 *
 * 所以本包虽是"纯 CSS"，也必须带这一个文件：它是装载管道的入口，不是界面逻辑。
 * 这里刻意不读 store、不建 DOM、不发消息、不碰任何引擎对象 —— 全部视觉效果在 ui/panel.css。
 */
export function mount() {
  return {};
}