# PROVENANCE — strawberry-ui 1.0.0

六项来源，逐字取自投稿 `0e55a71ade93` 的 `SOURCE.md` 原件（同名条目见站点 `meta.json`）。
取证方式：只读取 `/var/lib/sp-modsite/submissions/0e55a71ade93/mod.zip` 内的 `SOURCE.md`（2364 字节）。
**未 apply 任何补丁、未改任何仓库文件。**

## 1. 原作者

**Leiothrix**（出处：`SOURCE.md` 原文「差异代码作者：Leiothrix（NeoPecos 分支）」；
`meta.json` 的 `note` 同样写「差异代码作者 Leiothrix」）。

> 逐字引用：`差异代码作者：Leiothrix（NeoPecos 分支）；基础游戏的作者和贡献者见两仓库 Git 历史。`

原件没有单独声明「美化包」这一作品署名的个人，只有上面这一句对**差异代码**作者的署名。
本包是那份差异的兼容改写，故原作者记为该句所指的 Leiothrix。

## 2. 许可

**GPL-3.0-or-later**（出处：`SOURCE.md` 原文「代码许可：GPL-3.0-or-later。原游戏素材版权不随代码许可转移。」）
与 Forge 引擎 `package.json` 的 `"license": "GPL-3.0-or-later"` 一致。

> 逐字引用：`代码许可：GPL-3.0-or-later。原游戏素材版权不随代码许可转移。`

## 3. 兼容改写者

**Mo233**（Forge 兼容改写：把原件中能用样式表表达的那一半重写为 `client.panels[].styles` 纯 CSS 包）。

## 4. 来源

- 投稿 id：`0e55a71ade93`（站点区段 `normal`）
- 投稿包 `mod.zip` 的 sha256：`0eba2ff224bdd67be480ce642ea0046f0c7c722c089db1d4cf4c35c798613751`
- 补丁：包内 `changes.patch`，**119,832 字节**，sha256 `9ba820edc7ca88bbc6352d55caa3ade587e7ea157669c6ecf027ee9febe50abe`
  （与本地 `_sp9\0e55a71ade93.patch` 逐字节相同）· 19 文件 `+753/−325`
- 原件仓（`SOURCE.md` 逐字）：`原件：https://github.com/NeoPecos/Stronghold-Protocol/tree/2cadc618`
- 对比基线（`SOURCE.md` 逐字）：`对比基线：https://github.com/sganggs/Stronghold-Protocol/tree/bc50cac0`
- Forge 侧兼容目标（`SOURCE.md` 逐字）：`Forge 0.15.1 的 client.panels[].styles、screen.game.hud、screen.game.bondStrip 等接口…`

## 5. 改了什么

**只取原件补丁中「能用样式表表达」的那一半。** 原件 `SOURCE.md` 自己给出的边界：

> 逐字引用：`Forge 0.15.1 的 client.panels[].styles、screen.game.hud、screen.game.bondStrip 等接口可承接一部分界面样式；但部署动作涉及 Pixi/Spine 视图的区域迁移、模型加载与语音调用，现有只读面板接口不能安全替换渲染器。`
> 逐字引用：`不要使用私有属性或运行时篡改引擎对象来冒充兼容。`

### 本包承接（纯 CSS，共 9 组，全部锚定在比赛屏根 `.gm` 下）

| 组 | 内容 | 源 hunk |
| --- | --- | --- |
| 1 | 战场压暗减淡（上下渐变 + 暗角露出棋盘） | `public/css/screens/game.css` `@@ -12,9 +12,9 @@` |
| 2 | 顶部回合条定宽 9.32/11.32rem、阶段胶囊叠 `bg_battle/bg_rest/bg_boss`、回合数字叠 `bg_round`、首领条 120ms | `game.css` `@@ -47,14 +47,24 @@`、`@@ -112,18 +122,16 @@`、`@@ -147,11 +155,15 @@` |
| 3 | 商店栏底板透明 + 冻结/刷新按钮改官方底图 + 免费徽标抬到按钮上沿 | `public/css/screens/game-shop.css` `@@ -16,42 +16,43 @@` |
| 4 | 商店卡透明、价格/免费徽标上移出卡、立绘与水印裁剪 | `game-shop.css` `@@ -87,29 +88,30 @@`、`@@ -137,7 +139,7 @@` |
| 5 | 资金卡改官方底图 + 六边形金额条 + 收起按钮 | `game-shop.css` `@@ -161,19 +163,21 @@` |
| 6 | 盟约条改居中定宽 6.4rem + 横向滚动列表 | `game.css` `@@ -235,25 +247,17 @@`、`@@ -687,7 +695,7 @@` |
| 7 | 队伍面板间距、信息条渐变、头像边框与自选/观战/展开的阴影 | `game.css` `@@ -292,8 +296,9 @@`、`@@ -321,8 +326,8 @@`、`@@ -335,7 +340,7 @@`、`@@ -346,7 +351,7 @@` |
| 8 | 朝向轮象限低 alpha 提示色、chevron 放大 1.45 | `public/css/screens/game-panels.css` `@@ -523,12 +523,18 @@` |
| 9 | 倒地费用盒右下定位、准备按钮边框与阴影 | `game.css` `@@ -470,12 +475,13 @@`、`@@ -216,9 +228,9 @@` |

### 本包**不做**（属引擎侧，须单独立项）

原件里必须改渲染器 / 音频 / HUD 逻辑的那一半，**逐项列明，均未进入本包**：

| 原件能力 | 引擎侧落点 |
| --- | --- |
| 准备阶段落格触发干员 `Start` 部署动作与落地反馈（含慢网补播入场时间） | `public/js/render/app.js`、`public/js/render/units.js` |
| 落格触发部署语音（独立通道、不被部署音效节流吞掉、无素材静默回退） | `public/js/audio.js`（`prepDeploy` / `voice` / `setVoiceLang`） |
| 战斗中头顶只显示血量与技能条、等级装备留在准备阶段、细条移到脚下 | `public/js/render/units.js` |
| 顶部回合/首领条、费用图标、准备刷新冻结、商店卡与人物信息排布的**逻辑**部分 | `public/js/ui/hud.js`、`public/js/ui/shopBar.js`、`public/js/ui/teamPanel.js`、`public/js/screens/game.js` |
| 朝向轮 chevron 独立命中圈（`touch-action` 影响命中判定） | `public/js/ui/facingWheel.js` |
| 商店「免费」徽标的功能面（何时为免费） | `public/js/ui/shopBar.js` |

### 明确未采纳的两项（包只能加不能删）

- `.ui-dropdown*`（`components.css` `@@ -474,6 +474,14 @@`）：原件新增但**补丁内没有任何文件使用它**，属死 CSS，不抄。
- `components.css` `@@ -1030,43 +1038,14 @@` 的 29 行**删除**（`.topbar__tools`、`.me-chip--btn`、`.lobby-screen .topbar` 等）：
  样式包只能追加规则、不能删引擎的规则，硬覆盖会连带改掉大厅布局。要还原须走引擎侧立项。

## 6. 自带素材

**无。** 本包不含任何图片、字体、语音、Spine 或官方解包资源字节。

> 逐字引用（原件 `SOURCE.md`）：`本 ZIP 不含图片、字体、语音、Spine、官方解包资源或玩家数据。部分 CSS 源码引用原游戏已有的 /assets/ui/... 路径，只作适配线索；若目标引擎没有该资源，应使用合法自制图形或无图 fallback，不能从本投稿取得素材。`

本包沿用**引用**（不打包）的做法：`ui/panel.css` 引用的 14 条 `/assets/ui/...` 路径全部指向
引擎本地客户端已有资源，且每条背景都写了纯色打底，资源缺失时退化为有边框的色块。

## 包内文件

| 文件 | 说明 |
| --- | --- |
| `pack.json` | 声明 `client.panels[0] = { slot: screen.game.hud, module: ui/panel.js, styles: [ui/panel.css] }` |
| `ui/panel.js` | 装载管道空壳（引擎要求 `module` 导出 `mount`，见 `NOTICE.md`） |
| `ui/panel.css` | 全部视觉规则，锚定 `.gm`，无 `!important` |
| `NOTICE.md` | 空壳模块的理由、素材声明、许可指引 |
| `LICENSE` | GNU GPL v3 全文（35,149 字节，gnu.org canonical，sha256 `3972dc9744f6499f0f9b2dbf76696f2ae7ad8af9b23dde66d6af86c9dfb36986`） |
| `PROVENANCE.md` | 本文件 |