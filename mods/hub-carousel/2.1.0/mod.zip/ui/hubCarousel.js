import { h, render } from 'preact';
import { useEffect, useMemo, useRef, useState } from 'preact/hooks';
import { loadPref, savePref } from '/js/store.js';
import { toast } from '/js/ui/toasts.js';
import htm from 'htm';

/* ======== inlined: pictureFile.js ======== */
// ui/pictureFile.js — 与 `mod-hubcarousel` 的同一份文件**逐字相同**（纯函数、无状态、无引擎依赖）。
// One picked picture, made small enough to keep in this browser: decode it, downscale it to a longest edge and
// re-encode as JPEG. Shared by the hub's single custom backdrop (ui/hubBackdrop.js) and its slideshow
// (ui/hubCarousel.js) — a pure helper with no state, so neither module depends on the other for it.

/** A picked file is a picture when the browser says so (older Safari reports nothing for HEIC). */
export function isImageFile(f) {
  return !!f && typeof f.type === 'string' && f.type.slice(0, 6) === 'image/';
}

/**
 * Decode `file` and re-encode it as a JPEG whose longest edge is at most `maxEdge`.
 * @param {File|Blob} file @param {number} maxEdge @param {number} quality 0..1
 * @returns {Promise<Blob>} @throws when the file is not a decodable picture
 */
export function shrinkPicture(file, maxEdge, quality) {
  const url = URL.createObjectURL(file);
  return decodeImage(url).then((img) => {
    const k = Math.min(1, maxEdge / Math.max(img.naturalWidth, img.naturalHeight, 1));
    const w = Math.max(1, Math.round(img.naturalWidth * k));
    const h = Math.max(1, Math.round(img.naturalHeight * k));
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const g = c.getContext('2d');
    g.fillStyle = '#0b1110'; g.fillRect(0, 0, w, h); // a transparent PNG gets the hub's ground colour
    g.drawImage(img, 0, 0, w, h);
    return new Promise((resolve, reject) => c.toBlob((b) => (b ? resolve(b) : reject(new Error('encode'))), 'image/jpeg', quality));
  }).finally(() => URL.revokeObjectURL(url));
}

function decodeImage(url) {
  return new Promise((resolve, reject) => {
    const im = new Image();
    im.onload = () => resolve(im);
    im.onerror = () => reject(new Error('decode'));
    im.src = url;
  });
}

/* ======== inlined: hubCarousel.js ======== */
// ui/hubCarousel.js — 大厅轮播图（创意工坊包 hub-carousel v2.1 的客户端面板模块），基于 `mod-hubcarousel` v2.0.1。
//
// 与原版（覆盖式安装器）**唯一的差别在接线**：原版把轮播图组合进引擎的 ui/hubBackdrop.js（舞台进 `.hub-bg`、
// 面板进「大厅背景」对话框），因此必须覆盖两个引擎文件；本包一个引擎文件都不改，把同一份轮播模块挂成
// `client.panels` 的一个面板：
//
//   * 舞台：本包自己造一个 div 插进引擎的 `.hub-bg`（Preact 只画它自己那一棵，不碰引擎的树），
//     轮播开启时给 `.hub-bg` 打上 `data-sp-car="on"`，由本包样式表把引擎的程序化背景收走；
//   * 面板：`root.overlays` 槽位只当**挂载点**（没有可见界面）；设置（**逐字未改**的 `CarouselPanel`）连同
//     「单张背景 / 轮播图」两个页签，嵌进引擎「大厅背景」对话框里本包自己造的嵌入块（`.spcar-embed`）。
//
// 下面这份轮播模块本身（pref、IndexedDB、16 种转场、6 个预设、舞台与面板）**与原版逐字相同**，只换了
// import 的来源：`preact` / `preact/hooks` / `htm` 走 import map，`/js/store.js` 与 `/js/ui/toasts.js` 走绝对 URL。

// 轮播图 — a standalone module: up to CAROUSEL_MAX pictures, 6 轮播预设 and 16 转场效果, the two-layer stage,
// its page indicator, and the whole 轮播 panel of the 大厅背景 dialog. Nothing here knows about the hub's procedural
// skyline or its single custom picture: the slideshow keeps its own IndexedDB database ('sp-hub-carousel') and its
// own localStorage pref ('hub.carousel'), and it is driven by the caller, so it can be mounted anywhere —
// ui/hubBackdrop.js simply imports useCarousel / CarouselStage / CarouselPanel and composes them into the lobby.
//
// Pictures never leave the device: each picked file is downscaled in this browser and stored as a Blob; only the
// order (a list of ids) and the settings go into the pref.



// 引擎自己的偏好读写（`sp.pref.<key>`）与提示条：**绝对 URL**，因为本模块是从 /workshop-panels/<包>/… 送出去的，
// 相对路径到不了引擎的树。两者都是引擎的一部分，永远在。




/**
 * htm 会把**全静态**子树的 vnode 缓存进模板对象里，而 Preact 挂载时会把 DOM 节点与父链写进那个共享 vnode ——
 * 屏幕卸载之后模块级缓存还指着旧 DOM。`this[0] = 3` 是 htm 的 opt-out（与引擎 `components.js` 的 `hFresh` 同一条）。
 */
const hFresh = function (type, props, ...children) {
  if (this && typeof this === 'object') this[0] = 3;
  return h(type, props, ...children);
};
const html = htm.bind(hFresh);

/** 首次使用提示的 localStorage 键（`sp.pref.` 前缀与引擎一致，但这是本包自己的格子）。 */
const HINT_KEY = 'hub.carousel.hinted';
/** 提示过没有？读不到 localStorage（隐私模式）时按「提示过」算，免得每次刷新都弹。 */
function hintAlreadyShown() {
  try { return globalThis.localStorage?.getItem('sp.pref.' + HINT_KEY) === '1'; } catch { return true; }
}
function markHintShown() {
  try { globalThis.localStorage?.setItem('sp.pref.' + HINT_KEY, '1'); } catch { /* private mode / quota */ }
}

export const CAROUSEL_MAX = 20;
const CAR_EDGE = 1920; // a slideshow never needs more than this on the hub's own canvas
const CAR_FILE = 30 * 1024 * 1024; // per picked file
const CAR_BYTES = 2.4 * 1024 * 1024; // above this the re-encode gets harder, so 20 slides stay a sane size on disk
const CAR_ID_CHARS = '0123456789abcdefghijklmnopqrstuvwxyz';
export const CAROUSEL_MODES = ['single', 'carousel'];
const PREF_KEY = 'hub.carousel';

const num = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

/** The 转场效果 of the slideshow; hint is what the panel says about the one you picked. */
export const CAROUSEL_TRANSITIONS = [
  { id: 'fade', name: '淡入淡出', en: 'FADE', hint: '上一张留在原地，下一张淡入压上来 —— 最稳妥的转场。' },
  { id: 'slide', name: '横向推移', en: 'SLIDE', hint: '两张一起横向推过去，方向随上一张 / 下一张。' },
  { id: 'slidev', name: '纵向推移', en: 'PUSH UP', hint: '两张一起向上推，适合竖构图或风景组。' },
  { id: 'cover', name: '覆盖滑入', en: 'COVER', hint: '下一张带一道边缘光，压在上一张上面滑进来。' },
  { id: 'zoomin', name: '放大淡入', en: 'ZOOM IN', hint: '下一张由小放大淡入。' },
  { id: 'zoomout', name: '收缩落位', en: 'ZOOM OUT', hint: '下一张从放大状态收缩到位。' },
  { id: 'ken', name: '电影运镜', en: 'KEN BURNS', hint: '配合「缓慢推近」：图片边播边慢慢推近，静态图也有运镜感。' },
  { id: 'blur', name: '模糊溶解', en: 'BLUR DISSOLVE', hint: '由虚到实溶解进来，可以和「模糊」滑杆叠加。' },
  { id: 'flip', name: '翻转', en: 'FLIP', hint: '绕竖轴转过来，像翻一张卡片。' },
  { id: 'cube', name: '立方旋转', en: 'CUBE', hint: '两张像立方体的两个相邻面一起转。' },
  { id: 'wipe', name: '斜切擦除', en: 'DIAGONAL WIPE', hint: '一道斜线从左到右擦出下一张。' },
  { id: 'shutter', name: '百叶窗', en: 'SHUTTER', hint: '八条竖幅依次展开，把下一张拼出来。' },
  { id: 'split', name: '中心展开', en: 'CENTER REVEAL', hint: '下一张从画面正中向外展开。' },
  { id: 'glitch', name: '战术干扰', en: 'GLITCH', hint: '错位闪切，和大厅的扫描线、雷达同一味道。' },
  { id: 'none', name: '直接切换', en: 'CUT', hint: '不做动画，到时间就换下一张。' },
  { id: 'random', name: '随机转场', en: 'RANDOM', hint: '每换一张随机挑一种效果（不会挑到「直接切换」）；同一张在重绘时保持同样的选择。' },
];
const TRANS_IDS = CAROUSEL_TRANSITIONS.map((x) => x.id);

/** 轮播预设: one click sets the transition, its length, the interval and the slow zoom together. */
export const CAROUSEL_PRESETS = [
  { id: 'soft', name: '柔和', en: 'SOFT', to: { transition: { id: 'fade', dur: 1600, zoom: true, zoomLevel: 1.08 }, carousel: { interval: 16, shuffle: false } } },
  { id: 'film', name: '电影', en: 'CINEMA', to: { transition: { id: 'ken', dur: 1800, zoom: true, zoomLevel: 1.18 }, carousel: { interval: 12, shuffle: false } } },
  { id: 'flow', name: '流畅', en: 'FLOW', to: { transition: { id: 'slide', dur: 900, zoom: false }, carousel: { interval: 9, shuffle: false } } },
  { id: 'tact', name: '战术', en: 'TACTICAL', to: { transition: { id: 'glitch', dur: 700, zoom: false }, carousel: { interval: 8, shuffle: false } } },
  { id: 'show', name: '炫技', en: 'SHOWY', to: { transition: { id: 'cube', dur: 1100, zoom: false }, carousel: { interval: 7, shuffle: true } } },
  { id: 'snap', name: '快切', en: 'SNAP', to: { transition: { id: 'none', dur: 300, zoom: false }, carousel: { interval: 3, shuffle: true } } },
];
const PRESET_IDS = CAROUSEL_PRESETS.map((x) => x.id);

/** The pool 随机转场 picks from: every effect except itself and 直接切换. */
const RANDOM_POOL = TRANS_IDS.filter((id) => id !== 'random' && id !== 'none');
/** A stable pick for one slide: the same picture keeps the same effect across re-renders, a new page rolls again. */
function pickRandomTrans(ids, pos) {
  const key = String(ids[pos % Math.max(1, ids.length)] || '') + ':' + pos + ':sp';
  let h = 2166136261;
  for (let i = 0; i < key.length; i++) h = Math.imul(h ^ key.charCodeAt(i), 16777619) >>> 0;
  return RANDOM_POOL[h % RANDOM_POOL.length];
}
const transName = (id) => (CAROUSEL_TRANSITIONS.find((x) => x.id === id) || CAROUSEL_TRANSITIONS[0]).name;

/** The slideshow's own pref, sanitised — a device that never used it simply gets the defaults. */
export function loadCarouselPref() {
  const raw = loadPref(PREF_KEY, null);
  const o = raw && typeof raw === 'object' ? raw : {};
  const tr = o.transition && typeof o.transition === 'object' ? o.transition : {};
  const list = Array.isArray(o.list) ? o.list.filter((x) => x && typeof x.id === 'string').slice(0, CAROUSEL_MAX) : [];
  return {
    mode: CAROUSEL_MODES.includes(o.mode) ? o.mode : 'single',
    list: list.map((x) => ({ id: x.id, name: typeof x.name === 'string' ? x.name.slice(0, 60) : '' })),
    interval: clamp(num(o.interval, 12), 2, 120),
    shuffle: o.shuffle === true,
    loop: o.loop !== false,
    paused: o.paused === true,
    transition: {
      id: TRANS_IDS.includes(tr.id) ? tr.id : 'fade',
      dur: clamp(num(tr.dur, 1200), 200, 4000),
      zoom: tr.zoom !== false,
      zoomLevel: clamp(num(tr.zoomLevel, 1.16), 1.02, 1.5),
    },
    preset: PRESET_IDS.includes(o.preset) ? o.preset : null,
  };
}

/**
 * One-time move off the first cut, which kept the slideshow inside the backdrop's own pref ('hub.backdrop') and
 * inside its database ('sp-hub-backdrop', store 'carousel'). Runs before anything reads the new pref, and is a
 * no-op on a device that only ever used this module.
 */
function migrateLegacyPrefs() {
  try {
    if (globalThis.localStorage?.getItem('sp.pref.' + PREF_KEY) != null) return;
    const raw = globalThis.localStorage?.getItem('sp.pref.hub.backdrop');
    if (!raw) return;
    const o = JSON.parse(raw);
    if (!o || typeof o !== 'object' || (!o.carousel && !o.transition && o.mode === undefined)) return;
    const car = o.carousel && typeof o.carousel === 'object' ? o.carousel : {};
    savePref(PREF_KEY, {
      mode: o.mode, list: car.list, interval: car.interval, shuffle: car.shuffle, loop: car.loop, paused: car.paused,
      transition: o.transition, preset: o.preset,
    });
    delete o.mode; delete o.carousel; delete o.transition; delete o.preset;
    savePref('hub.backdrop', o);
  } catch { /* a pref we cannot read is simply left alone */ }
}
migrateLegacyPrefs();

// ---- the slide store: this module's own IndexedDB (Blobs, no base64 bloat, no localStorage quota) ----------------
const DB_NAME = 'sp-hub-carousel';
const DB_VERSION = 1;
const SLIDES = 'slides';
// the first cut kept the slides inside the backdrop's database; migrateLegacySlides() moves them out of it
const LEGACY_DB = 'sp-hub-backdrop';
const LEGACY_VERSION = 2;
const LEGACY_STORE = 'carousel';

function openDb(name, version, store, keyPath) {
  return new Promise((resolve, reject) => {
    if (!globalThis.indexedDB) { reject(new Error('no indexedDB')); return; }
    const open = indexedDB.open(name, version);
    open.onupgradeneeded = () => {
      const db = open.result;
      if (!db.objectStoreNames.contains(store)) db.createObjectStore(store, keyPath ? { keyPath } : undefined);
    };
    open.onerror = () => reject(open.error);
    open.onsuccess = () => resolve(open.result);
  });
}
function withStore(mode, fn) {
  return openDb(DB_NAME, DB_VERSION, SLIDES, 'id').then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction(SLIDES, mode);
    const rq = fn(tx.objectStore(SLIDES));
    tx.oncomplete = () => { db.close(); resolve(rq ? rq.result : undefined); };
    tx.onerror = tx.onabort = () => { db.close(); reject(tx.error); };
  }));
}
const getAll = () => withStore('readonly', (s) => s.getAll());
const putRow = (row) => withStore('readwrite', (s) => s.put(row));
const delRow = (id) => withStore('readwrite', (s) => s.delete(id));
const clearAll = () => withStore('readwrite', (s) => s.clear());

/** A short plain-text id for a slide (it also lives in the localStorage pref, so no odd characters). */
function slideId() {
  let s = '';
  for (let i = 0; i < 12; i++) s += CAR_ID_CHARS[(Math.random() * CAR_ID_CHARS.length) | 0];
  return Date.now().toString(36) + s;
}

/**
 * Move the slides out of the backdrop's database (the first cut kept them in a store named 'carousel' there).
 * Silent when there is nothing to move, which is the case on any device that only ever used this module.
 */
async function migrateLegacySlides() {
  let rows = null;
  try {
    const db = await openDb(LEGACY_DB, LEGACY_VERSION, LEGACY_STORE, 'id');
    rows = await new Promise((resolve, reject) => {
      if (!db.objectStoreNames.contains(LEGACY_STORE)) { db.close(); resolve(null); return; }
      const tx = db.transaction(LEGACY_STORE, 'readonly');
      const rq = tx.objectStore(LEGACY_STORE).getAll();
      tx.oncomplete = () => { db.close(); resolve(rq.result); };
      tx.onerror = tx.onabort = () => { db.close(); reject(tx.error); };
    });
  } catch { return; }
  if (!Array.isArray(rows) || !rows.length) return;
  try {
    for (const r of rows) if (r && typeof r.id === 'string' && r.blob instanceof Blob) await putRow(r);
    // the copies are in: empty the legacy store so the pictures are not kept twice
    const db = await openDb(LEGACY_DB, LEGACY_VERSION, LEGACY_STORE, 'id');
    await new Promise((resolve, reject) => {
      const tx = db.transaction(LEGACY_STORE, 'readwrite');
      tx.objectStore(LEGACY_STORE).clear();
      tx.oncomplete = () => { db.close(); resolve(); };
      tx.onerror = tx.onabort = () => { db.close(); reject(tx.error); };
    });
  } catch { /* the originals stay where they are; the next visit tries again */ }
}

/** A slide's Blob: downscaled for a slideshow, and re-encoded harder when the file is a monster. */
const shrinkSlide = (file) => shrinkPicture(file, CAR_EDGE, file.size > CAR_BYTES ? 0.72 : 0.84);

/**
 * The slideshow runner: which slide is on screen, which way it came from, when the next one is due, the transition to
 * play and the transport (a click on the exposed backdrop, arrow keys and Space). The caller's 'shuffle' setting
 * permutes the order from the slide ids, so a reload keeps the same run.
 */
function useCarouselRunner(pref, n, ids, update, motion) {
  const [pos, setPos] = useState(0);
  const [dir, setDir] = useState(1);
  const order = useMemo(() => {
    const a = Array.from({ length: n }, (_, i) => i);
    if (!pref.shuffle || n < 2) return a;
    let h = 2166136261;
    for (const x of pref.list) for (let i = 0; i < x.id.length; i++) h = Math.imul(h ^ x.id.charCodeAt(i), 16777619) >>> 0;
    const rnd = shuffleRng(h || 1);
    for (let i = a.length - 1; i > 0; i--) { const j = (rnd() * (i + 1)) | 0; const t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }, [n, pref.shuffle, pref.list]);
  const at = n ? clamp(pos, 0, n - 1) : 0;
  const rowIdx = n ? order[at] : -1;
  const prevIdx = n ? order[(at - dir + n) % n] : -1;
  const intervalMs = clamp(num(pref.interval, 12), 2, 120) * 1000;
  const playing = pref.mode === 'carousel' && n > 1 && !pref.paused && pref.loop;
  useEffect(() => {
    if (!playing) return undefined;
    const t = setTimeout(() => { setDir(1); setPos((p) => (clamp(p, 0, n - 1) + 1) % n); }, intervalMs);
    return () => clearTimeout(t);
  }, [playing, at, n, intervalMs]);
  const go = (step) => { if (!n) return; setDir(step > 0 ? 1 : -1); setPos((p) => (clamp(p, 0, n - 1) + step + n) % n); };
  // 切到指定下标（点缩略图用）：背景不再响应点击，只有设置面板里的缩略图能切换，避免误触翻页。
  const goTo = (target) => {
    if (!n || target == null) return;
    const t = clamp(target, 0, n - 1);
    const step = (t - at + n) % n;
    if (!step) return;
    setDir(step > n / 2 ? -1 : 1);
    setPos(t);
  };
  // ArrowLeft / ArrowRight turn the pages and Space pauses, with the dialog closed and no field focused
  useEffect(() => {
    if (pref.mode !== 'carousel' || n < 1) return undefined;
    const onKey = (e) => {
      if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight' && e.key !== ' ' && e.code !== 'Space') return;
      const el = e.target;
      const tag = el && el.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || (el && el.isContentEditable)) return;
      if (document.body && document.body.classList.contains('hub-dialog-open')) return;
      e.preventDefault();
      if (e.key === 'ArrowLeft') go(-1);
      else if (e.key === 'ArrowRight') go(1);
      else update({ paused: !pref.paused });
    };
    addEventListener('keydown', onKey);
    return () => removeEventListener('keydown', onKey);
  }, [pref.mode, n, pref.paused]);
  const paused = pref.mode === 'carousel' && n > 1 && !!pref.paused;
  const want = motion ? pref.transition.id : 'none';
  // 随机转场 resolves to one concrete effect per slide, so the CSS only ever sees a real name
  const resolved = want === 'random' ? pickRandomTrans(ids, at) : want;
  return {
    order, pos: at, n, rowIdx, prevIdx, dir, playing, paused, go, goTo,
    setPaused: (v) => update({ paused: !!v }),
    intervalMs,
    transId: resolved, wantRandom: pref.transition.id === 'random',
    dur: motion ? clamp(num(pref.transition.dur, 1200), 200, 4000) : 0,
    zoom: motion && pref.transition.zoom,
    zoomLevel: clamp(num(pref.transition.zoomLevel, 1.16), 1.02, 1.5),
  };
}
/** A tiny deterministic generator for the shuffle order (no Math.random: a reload keeps the same run). */
function shuffleRng(seed) {
  let s = seed >>> 0;
  return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 2 ** 32);
}

/**
 * The slideshow's public hook — this is all a caller needs.
 * @param {{ motion?: boolean }} [options] motion: the host's 动态效果 switch; off collapses every 转场 to a cut.
 * @returns {{ pref: object, update: Function, ready: boolean, stored: {id,name}[], urls: string[],
 *             add: Function, remove: Function, move: Function, clear: Function, car: object }}
 */
export function useCarousel(options = {}) {
  const motion = options.motion !== false;
  const [pref, setPref] = useState(loadCarouselPref);
  /** patch is a whole-pref object or a function of the latest pref: every write goes through here. */
  const update = (patch) => setPref((p) => {
    const next = typeof patch === 'function' ? { ...p, ...patch(p) } : { ...p, ...patch };
    savePref(PREF_KEY, next);
    return next;
  });

  const [blobs, setBlobs] = useState(() => new Map()); // slide id -> Blob (the pref only keeps the order)
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let dead = false;
    (async () => {
      await migrateLegacySlides();
      try {
        const rows = await getAll();
        if (dead || !Array.isArray(rows)) return;
        const m = new Map();
        for (const r of rows) if (r && typeof r.id === 'string' && r.blob instanceof Blob) m.set(r.id, r.blob);
        setBlobs(m);
      } catch { /* nothing readable: the slideshow simply starts empty */ }
      finally { if (!dead) setReady(true); }
    })();
    return () => { dead = true; };
  }, []);

  const stored = useMemo(() => pref.list.filter((x) => blobs.has(x.id)), [pref.list, blobs]);
  /** Object URLs of the slides, keyed by id — state, so a slide that just arrived repaints the stage. */
  const [urlMap, setUrlMap] = useState(() => new Map());
  useEffect(() => {
    setUrlMap((m) => {
      let next = null;
      for (const x of stored) if (!m.has(x.id) && blobs.has(x.id)) {
        next = next || new Map(m);
        next.set(x.id, URL.createObjectURL(blobs.get(x.id)));
      }
      return next || m;
    });
  }, [stored, blobs]);
  // a slide that left the list for good: its URL is revoked once the outgoing layer had time to fade away
  useEffect(() => {
    const live = new Set(stored.map((x) => x.id));
    const gone = [...urlMap.keys()].filter((id) => !live.has(id));
    if (!gone.length) return undefined;
    const t = setTimeout(() => setUrlMap((m) => {
      const next = new Map(m);
      for (const id of gone) if (next.has(id)) { URL.revokeObjectURL(next.get(id)); next.delete(id); }
      return next;
    }), 8000);
    return () => clearTimeout(t);
  }, [stored, urlMap]);
  /** Index-aligned with stored: a slide whose URL is not ready yet holds its place with an empty string. */
  const urls = useMemo(() => stored.map((x) => urlMap.get(x.id) || ''), [stored, urlMap]);

  /** @returns {Promise<{added:number, failed:number, dropped:number}>} */
  const add = async (files) => {
    const picked = files.slice(0, Math.max(0, CAROUSEL_MAX - pref.list.length));
    let added = 0; let failed = 0;
    const rows = [];
    for (const f of picked) {
      try {
        const id = slideId();
        const blob = await shrinkSlide(f);
        try { await putRow({ id, blob, name: String(f.name || '').slice(0, 60), added: Date.now() }); }
        catch { await delRow(id).catch(() => {}); failed += 1; continue; }
        setBlobs((m) => { const n = new Map(m); n.set(id, blob); return n; });
        rows.push({ id, name: String(f.name || '').slice(0, 60) });
        added += 1;
      } catch { failed += 1; }
    }
    if (rows.length) update((p) => ({ list: [...p.list, ...rows].slice(0, CAROUSEL_MAX) }));
    return { added, failed, dropped: files.length - picked.length };
  };
  const remove = async (id) => {
    try { await delRow(id); } catch { /* nothing stored */ }
    update((p) => ({ list: p.list.filter((x) => x.id !== id) }));
  };
  /** Move a slide one slot forward / back: a reorder never touches the bytes. */
  const move = (id, by) => update((p) => {
    const i = p.list.findIndex((x) => x.id === id);
    const j = i + by;
    if (i < 0 || j < 0 || j >= p.list.length) return {};
    const list = [...p.list];
    list.splice(j, 0, list.splice(i, 1)[0]);
    return { list };
  });
  const clear = async () => {
    try { await clearAll(); } catch { /* nothing stored */ }
    setBlobs(new Map());
    update({ list: [] });
  };
  const ids = useMemo(() => pref.list.map((x) => x.id), [pref.list]);
  const car = useCarouselRunner(pref, stored.length, ids, update, motion);
  return { pref, update, ready, stored, urls, add, remove, move, clear, car };
}

/** The picture rides on the inner element, so a transition owns the outer layer untouched. */
const picVars = (url, blur) => '--car-img:' + (url ? 'url("' + url + '")' : 'none') + ';--car-blur:' + (blur || 0) + 'px';

/**
 * The slideshow: two stacked layers (the outgoing one and the incoming one) and a page indicator.
 * Every 转场 is a CSS animation on the incoming layer, keyed by the slide, so it restarts on each change; the
 * outgoing layer freezes at the end of its own animation, which is exactly what it looked like a moment ago.
 * The layer itself never takes a click (whatever is stacked above it stays usable): the runner turns the page on a
 * click that belonged to no control.
 */
export function CarouselStage({ car, urls, blur = 0, dim = 0, overlay = false }) {
  const { n, rowIdx, prevIdx } = car;
  if (!n || !urls.length) return null;
  const cur = urls[Math.min(rowIdx, urls.length - 1)] || null;
  const prev = n > 1 ? (urls[Math.min(prevIdx, urls.length - 1)] || null) : null;
  const vars = '--car-dur:' + car.dur + 'ms;--car-int:' + car.intervalMs + 'ms;--car-zoom:' + car.zoomLevel;
  return html`<div class="hub-bg__car" data-trans=${car.transId} data-dir=${car.dir > 0 ? 'next' : 'prev'}
      data-motion=${car.dur ? 'on' : 'off'} data-zoom=${car.zoom ? 'on' : 'off'} data-play=${car.playing ? 'on' : 'off'}
      data-pages=${n > 1 ? 'on' : 'off'} style=${vars} aria-hidden="true">
    ${prev && cur && prev !== cur ? html`<div key=${'out' + prevIdx} class="hub-bg__slide is-out"><i style=${picVars(prev, blur)}></i></div>` : null}
    <div key=${'in' + rowIdx} class="hub-bg__slide is-in" data-blank=${cur ? 'no' : 'yes'}><i style=${picVars(cur || '', blur)}></i>
      ${car.transId === 'shutter' && car.dur ? html`<span class="hub-bg__louvers">${Array.from({ length: 8 }, (_, i) => html`<b key=${i} style=${'--lv:' + i}></b>`)}</span>` : null}
    </div>
    <div class="hub-bg__shade" style=${'opacity:' + dim / 100}></div>
    ${overlay ? html`<div class="hub-bg__grid"></div><div class="hub-bg__dots"></div>` : null}
    ${n > 1 ? html`<div class="hub-car">
      <span class="hub-car__n num">${car.pos + 1}/${n}</span>
      <span class="hub-car__dots" aria-hidden="true">${Array.from({ length: n }, (_, i) => html`<i key=${i} class=${i === car.pos ? 'is-on' : ''}></i>`)}</span>
      <span class="hub-car__bar" aria-hidden="true"><b key=${'bar' + car.pos}></b></span>
      <span class="hub-car__hint num">${car.paused ? '已暂停 · 空格继续' : '点设置里的缩略图切换 · ← → 换页 · 空格暂停'}</span>
      ${car.wantRandom ? html`<span class="hub-car__trans">${transName(car.transId)}</span>` : null}
    </div>` : null}
  </div>`;
}

/** The slideshow glyph of the 单张 / 轮播 switch: three stacked frames. */
export function CarouselGlyph() {
  return html`<svg class="bgset__modeicon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
    <path fill="currentColor" d="M3 6h13v12H3zm14.4 1.8h2.6v8.4h-2.6zM1.6 8.4h1v7.2h-1z" />
    <path fill="currentColor" fill-rule="evenodd" d="M5 8h9v8H5zm2.2 2v4l3.8-2z" />
  </svg>`;
}

/**
 * The 轮播图 settings panel: the slide strip and its CRUD, the transport, the 轮播预设, the 转场效果 (including
 * 随机转场) and the rhythm switches. It is self-contained — pass it what useCarousel() returned:
 *
 *   const slideshow = useCarousel({ motion: pref.motion });
 *   ... html`<${CarouselPanel} slideshow=${slideshow} />`
 *
 * The host's own look (dim / blur / overlay) stays with the host: this panel only edits the slideshow.
 */
export function CarouselPanel({ slideshow }) {
  const { pref, update, stored, urls, add, remove, move, clear, car } = slideshow;
  const manyRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const browseMany = () => manyRef.current?.click();
  const onMany = async (e) => {
    const input = e.currentTarget;
    const all = [...(input.files || [])];
    input.value = '';
    if (!all.length) return;
    const pics = all.filter(isImageFile);
    const tooBig = pics.filter((f) => f.size > CAR_FILE).length;
    const ok = pics.filter((f) => f.size <= CAR_FILE);
    if (!ok.length) { toast(all.length > pics.length ? '所选文件里没有图片' : '这些图片都太大（单张上限 30MB）', 'warn'); return; }
    setBusy(true);
    try {
      const r = await add(ok);
      const bits = [];
      if (r.added) bits.push('已加入 ' + r.added + ' 张');
      if (r.dropped) bits.push('超出 ' + CAROUSEL_MAX + ' 张上限，忽略 ' + r.dropped + ' 张');
      if (r.failed + tooBig) bits.push((r.failed + tooBig) + ' 张没能加入');
      if (r.added) {
        if (pref.mode !== 'carousel') update({ mode: 'carousel' });
        toast(bits.join('；'), 'info');
      } else toast(bits.join('；') || '没有图片被加入', 'warn');
    } finally {
      setBusy(false);
    }
  };
  /** A 预设 sets transition + length + interval + zoom at once; picking it again re-applies it. */
  const applyPreset = (p) => {
    update({ mode: 'carousel', preset: p.id, transition: { ...pref.transition, ...p.to.transition }, ...p.to.carousel });
    toast('已套用「' + p.name + '」预设', 'info');
  };
  const setTr = (patch) => update({ preset: null, transition: { ...pref.transition, ...patch } });
  const tr = pref.transition;
  const hint = (CAROUSEL_TRANSITIONS.find((x) => x.id === tr.id) || CAROUSEL_TRANSITIONS[0]).hint;
  const missing = pref.list.length - stored.length;
  return html`<div class="bgset__panel bgset__panel--car">
    <input ref=${manyRef} type="file" accept="image/*" multiple hidden onChange=${onMany} />
    <div class="bgset__carhead">
      <span class="bgset__count"><b class="num">${stored.length}</b><span>/${CAROUSEL_MAX} 张</span>
        ${missing > 0 ? html`<span class="bgset__warn">（${missing} 张在本浏览器里找不到了）</span>` : null}
      </span>
      <span class="bgset__row">
        <button type="button" class="btn btn--secondary btn--sm" disabled=${busy} onClick=${browseMany}>
          <span class="btn__label">${busy ? '处理中…' : '添加图片'}</span></button>
        <button type="button" class="btn btn--ghost btn--sm" disabled=${busy || !stored.length} onClick=${() => clear()}>
          <span class="btn__label">清空</span></button>
      </span>
    </div>
    ${stored.length ? html`<div class="bgset__strip" role="list" aria-label="轮播图片顺序">
      ${stored.map((x, i) => html`<div key=${x.id} role="listitem" title=${x.name || ''} onClick=${() => car.goTo(i)}
          class=${'bgset__thumb' + (car.order[car.pos] === i ? ' is-playing' : '')}
          style=${'background-image:url("' + (urls[i] || '') + '")'}>
        <span class="bgset__thumb-n num">${i + 1}</span>
        <span class="bgset__thumb-acts">
          <button type="button" title="前移" disabled=${i === 0} onClick=${(e) => { e.stopPropagation(); move(x.id, -1); }}>◀</button>
          <button type="button" title="后移" disabled=${i === stored.length - 1} onClick=${(e) => { e.stopPropagation(); move(x.id, 1); }}>▶</button>
          <button type="button" title="移除这张" onClick=${(e) => { e.stopPropagation(); remove(x.id); }}>×</button>
        </span>
      </div>`)}
    </div>` : html`<button type="button" class="bgset__drop" onClick=${browseMany}>
      <span class="bgset__plus">+</span><span>添加图片（可一次多选，最多 ${CAROUSEL_MAX} 张）</span>
    </button>`}

    ${stored.length > 1 ? html`<div class="bgset__transport">
      <button type="button" class="btn btn--ghost btn--sm" onClick=${() => car.go(-1)}><span class="btn__label">◀ 上一张</span></button>
      <button type="button" class="btn btn--secondary btn--sm" onClick=${() => car.setPaused(!car.paused)}>
        <span class="btn__label">${car.paused ? '继续播放' : '暂停轮播'}</span></button>
      <button type="button" class="btn btn--ghost btn--sm" onClick=${() => car.go(1)}><span class="btn__label">下一张 ▶</span></button>
    </div>` : null}

    <div class="bgset__group" role="radiogroup" aria-label="轮播预设">
      <span class="bgset__label">轮播预设</span>
      <div class="bgset__presetrow">
        ${CAROUSEL_PRESETS.map((p) => html`<button key=${p.id} type="button" role="radio" aria-checked=${pref.preset === p.id ? 'true' : 'false'}
            class=${'bgset__preset' + (pref.preset === p.id ? ' is-selected' : '')} onClick=${() => applyPreset(p)}>
          <span class="bgset__tname">${p.name}</span><span class="bgset__ten">${p.en}</span>
        </button>`)}
      </div>
    </div>

    <div class="bgset__group" role="radiogroup" aria-label="转场效果">
      <span class="bgset__label">转场效果${car.dur ? '' : '（动态效果已关闭）'}</span>
      <div class="bgset__transgrid">
        ${CAROUSEL_TRANSITIONS.map((x) => html`<button key=${x.id} type="button" role="radio" aria-checked=${tr.id === x.id ? 'true' : 'false'}
            class=${'bgset__transbtn' + (tr.id === x.id ? ' is-selected' : '')}
            onClick=${() => { setTr({ id: x.id }); if (car.n > 1) car.go(1); }}>
          <span class="bgset__tname">${x.name}</span><span class="bgset__ten">${x.en}</span>
        </button>`)}
      </div>
      <p class="bgset__note">${hint}${tr.id === 'random' && car.n > 0 ? '（本次：' + transName(car.transId) + '）' : ''}</p>
    </div>

    <label class="bgset__slider"><span>间隔</span>
      <input type="range" min="2" max="120" step="1" value=${pref.interval}
        onInput=${(e) => update({ interval: Number(e.currentTarget.value) })} />
      <b class="num">${pref.interval}s</b></label>
    <label class="bgset__slider"><span>转场时长</span>
      <input type="range" min="200" max="4000" step="100" value=${tr.dur}
        onInput=${(e) => setTr({ dur: Number(e.currentTarget.value) })} />
      <b class="num">${(tr.dur / 1000).toFixed(1)}s</b></label>
    <label class="bgset__check"><input type="checkbox" checked=${pref.loop}
      onChange=${(e) => update({ loop: e.currentTarget.checked })} /><span>自动轮播（关闭后停在当前这张）</span></label>
    <label class="bgset__check"><input type="checkbox" checked=${pref.shuffle}
      onChange=${(e) => update({ preset: null, shuffle: e.currentTarget.checked })} /><span>随机顺序</span></label>
    <label class="bgset__check"><input type="checkbox" checked=${tr.zoom}
      onChange=${(e) => setTr({ zoom: e.currentTarget.checked })} /><span>缓慢推近（Ken Burns）</span></label>
    ${tr.zoom ? html`<label class="bgset__slider"><span>推近</span>
      <input type="range" min="1.02" max="1.5" step="0.01" value=${tr.zoomLevel}
        onInput=${(e) => setTr({ zoomLevel: Number(e.currentTarget.value) })} />
      <b class="num">${Math.round((tr.zoomLevel - 1) * 100)}%</b></label>` : null}
  </div>`;
}

// ====================================================================================================================
// 工坊接线：把 CarouselStage 画进大厅背景层；把设置（页签 + CarouselPanel）嵌进引擎的「大厅背景」对话框。
// 轮播模块本身一个字没改 —— 这一段只负责「舞台挂在哪、设置嵌在哪、什么时候算开启」。
//
// 嵌入机制（2026-10-15 在真实 Chrome 里用探针实测）：Preact 只管理自己 vnode 对应的节点、**不碰**外来节点 ——
// 在对话框的 `.bgset` 里插入的元素（当首个子节点）与挂在它上面的自定义属性，都活过了全部重渲染路径
// （点主题 / 上传自定义背景 / 拖滑杆 / 条件块出现消失）；只有对话框关闭时整棵子树一起销毁，由
// MutationObserver 在重开时重新挂。引擎文件依旧一个字节不改。
// ====================================================================================================================

/** 面板的根 id（一页一个；第二次 mount 复用同一份宿主）。 */
export const PANEL_ID = 'sp-car-panel';

const numOr = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);
const clampN = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

/**
 * 引擎「大厅背景」对话框写的那一份 pref（`sp.pref.hub.backdrop`）：轮播图沿用它的**动态效果 / 暗化 / 模糊 /
 * 叠加战术网格**，所以两种背景模式看起来是同一套观感。读不到就回到引擎自己的缺省值。
 * 直接读 localStorage 而不是 import 引擎的 ui/hubBackdrop.js：包的模块不该依赖引擎文件的路径。
 */
export function readBackdropLook() {
  let o = null;
  try { o = JSON.parse(globalThis.localStorage?.getItem('sp.pref.hub.backdrop') || 'null'); } catch { o = null; }
  const src = o && typeof o === 'object' ? o : {};
  return {
    motion: src.motion !== false,
    dim: clampN(numOr(src.dim, 45), 0, 85),
    blur: clampN(numOr(src.blur, 0), 0, 16),
    overlay: src.overlay !== false,
  };
}

/**
 * 舞台：一个**属于本包**的 div，插进引擎的 `.hub-bg`（Preact 的 `render` 只画它自己那一棵，不碰引擎的树）。
 *
 * 轮播开启时给 `.hub-bg` 打 `data-sp-car="on"`，本包的样式表据此把引擎的程序化背景收走、只留扫描线与暗角
 * （它们与轮播是同一套观感）。关闭时把属性摘掉，大厅立刻回到引擎自己画的那一套。
 *
 * 大厅挂载 / 卸载会重建 `.hub-bg`，Preact 也可能在重画背景时把我们插进去的节点挤掉 —— 与「大厅栏位开关」的
 * 把手同一条路子：用 MutationObserver 检查**存在性**，而不是只等挂载那一刻。
 * @param {Document} doc
 */
export function createStage(doc) {
  let root = null;
  let snapshot = null;
  let observer = null;
  let disposed = false;

  const bgEl = () => doc.querySelector?.('.hub-bg') || null;

  const ensureRoot = () => {
    const bg = bgEl();
    if (!bg) {
      if (root && root.parentNode) root.parentNode.removeChild(root);
      return null;
    }
    if (!root) {
      root = doc.createElement('div');
      root.className = 'sp-car-root';
      root.setAttribute('aria-hidden', 'true');
    }
    if (root.parentNode !== bg) bg.insertBefore(root, bg.firstChild);
    return bg;
  };

  const paint = () => {
    if (disposed) return;
    const bg = ensureRoot();
    const on = !!(snapshot && snapshot.active);
    if (bg) bg.setAttribute('data-sp-car', on ? 'on' : 'off');
    if (!root) return;
    if (!on) { render(null, root); return; }
    render(html`<${CarouselStage} car=${snapshot.car} urls=${snapshot.urls}
      blur=${snapshot.blur} dim=${snapshot.dim} overlay=${snapshot.overlay} />`, root);
  };

  const MO = globalThis.MutationObserver;
  if (doc.body && typeof MO === 'function') {
    observer = new MO(() => { if (disposed) return; if (root && root.parentNode !== bgEl()) paint(); });
    observer.observe(doc.body, { childList: true, subtree: true });
  }

  return {
    /** @param {{active:boolean, car:any, urls:string[], blur:number, dim:number, overlay:boolean}} next */
    publish(next) { snapshot = next; paint(); },
    destroy() {
      disposed = true;
      try { observer?.disconnect(); } catch { /* already gone */ }
      if (root) { render(null, root); root.parentNode?.removeChild(root); root = null; }
      const bg = bgEl();
      if (bg) bg.removeAttribute('data-sp-car');
    },
  };
}

/** 「单张背景」那个图标（三个层叠的框），与引擎 ui/hubBackdrop.js 的 BackdropGlyph 同形但**自带**，不 import 引擎文件。 */
function SingleGlyph() {
  return html`<svg class="btn__icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
    <path fill="currentColor" fill-rule="evenodd" d="M2 4h20v16H2zm2 2v9.6l4.6-4.8 3.6 3.7 2.6-2.6L20 17V6zm13 1.6a1.8 1.8 0 1 1 0 3.6 1.8 1.8 0 0 1 0-3.6z" />
  </svg>`;
}

/**
 * 面板本体（**无可见界面**）：这一棵是轮播图的**唯一状态源** ——
 *   * 驱动舞台：每次渲染把快照推给 `.hub-bg` 里的舞台（`createStage`）；
 *   * 驱动设置：把「单张背景 / 轮播图」两个页签与 `CarouselPanel`（**逐字未改**）通过一个小型「传送门」
 *     画进引擎「大厅背景」对话框里的嵌入块（`createDialogEmbed`）。
 *
 * 为什么必须是同一棵：`useCarousel` 是**实例内**的状态、不是全局单例，两个实例互不同步 —— 所以对话框
 * 那一棵不自己建状态，事件回调直接操作这里的 `slideshow`；本节点每次渲染都会重画嵌入块，回调里拿到的
 * 因此永远是最新一份。
 * @param {{ stage: ReturnType<typeof createStage> }} props
 */
function CarouselApp({ stage }) {
  const [look, setLook] = useState(readBackdropLook);
  const slideshow = useCarousel({ motion: look.motion });
  const dlgRef = useRef(null);
  const n = slideshow.stored.length;
  const on = slideshow.pref.mode === 'carousel' && n > 0;

  // 重读引擎那份背景 pref（暗化 / 模糊 / 战术网格 / 动态效果）。只在字段真的变了时才写 state：
  // 每次都造一个新对象会让 useState 永远判定「变了」，直接变成渲染死循环。
  const refreshLook = () => setLook((prev) => {
    const next = readBackdropLook();
    return next.motion === prev.motion && next.dim === prev.dim && next.blur === prev.blur && next.overlay === prev.overlay
      ? prev : next;
  });

  // 首次使用提示（本包自己加的，不属于原版）：装好后**一张图都没有**时，画面不会有任何动静 ——
  // 玩家很容易以为「装了这个 mod 什么都没变」。所以只提示一次：等大厅真的画出来之后，用引擎的 toast
  // 指一下去哪开；提示过就写一格 localStorage，以后不再打扰。
  // `n` 是**异步**来的（IndexedDB 读完才知道有几张图），所以轮询里要读最新的值：挂载那一刻 n 恒为 0，
  // 拿它当判据会给「本来就有图」的玩家也弹一次。
  const nRef = useRef(n);
  nRef.current = n;
  useEffect(() => {
    if (hintAlreadyShown()) return undefined;
    let tries = 0;
    const timer = setInterval(() => {
      tries += 1;
      if (nRef.current > 0) { clearInterval(timer); return; }   // 已经有图了：什么都不用说
      const doc = globalThis.document;
      if (doc?.querySelector?.('.lobby-hub') || doc?.querySelector?.('.lobby-screen')) {
        clearInterval(timer);
        markHintShown();
        toast('大厅轮播图：打开「大厅背景」→ 选「轮播图」，添加图片（最多 20 张，只存在本机）', 'info', { ttl: 8000 });
      } else if (tries > 60) { clearInterval(timer); }
    }, 500);
    return () => clearInterval(timer);
  }, []);

  // 每一次渲染都把这一帧的快照推给舞台那一棵。舞台自己是幂等的（同一份快照重画不会改变画面语义，
  // 转场由 key 决定），所以这里不需要依赖数组。
  useEffect(() => {
    stage.publish({ active: on, car: slideshow.car, urls: slideshow.urls, blur: look.blur, dim: look.dim, overlay: look.overlay });
  });

  // 对话框嵌入块：挂载时建一次；此后每次渲染同步一次（把最新 `slideshow` 送过去，对话框开着的话顺带重画；
  // 对话框开着期间还会每秒轻量重读一次引擎 pref —— 玩家在对话框里拨「动态效果」，轮播这边立刻跟上）。
  useEffect(() => {
    const doc = globalThis.document;
    if (!doc) return undefined;
    const embed = createDialogEmbed(doc, { onTick: refreshLook });
    dlgRef.current = embed;
    embed.sync(slideshow);
    return () => { dlgRef.current = null; embed.destroy(); };
  }, []);
  useEffect(() => { dlgRef.current?.sync(slideshow); });

  // 没有可见输出：设置界面全在对话框的嵌入块里，舞台全在 `.hub-bg` 里。
  return null;
}

/**
 * 「大厅背景」对话框里的嵌入块管理器。三件事：
 *   1. **存在性**：对话框（`.hub-dialog__body .bgset`）出现时，把 `.spcar-embed` 挂在它的**首位**；
 *      对话框关闭时整棵子树由引擎销毁，这里收尾（`render(null)`），重开时由 MutationObserver 重新挂。
 *   2. **重画**：把最新的 `slideshow`（与舞台**同一份**状态）用 `render()` 画进嵌入块。
 *   3. **模式属性**：在 `.bgset` 上挂 `data-spcar-mode`（single / carousel）——本包样式表据此在轮播模式下
 *      把引擎自己的内容（主题格、自定义块、底部说明）收走、「动态效果」那一格留着（它管的是轮播的动效）。
 *
 * 为什么插入的节点与属性不会被引擎的重渲染冲掉：Preact 只管理自己 vnode 对应的节点，外来节点与自定义
 * 属性不在它的 diff 里 —— 2026-10-15 在真实 Chrome 里用探针把全部重渲染路径跑了一遍，全部存活
 * （探针与结论见 `work/e2e-browser/`）。
 * @param {Document} doc
 * @param {{ onTick?: () => void }} [hooks] 对话框开着期间每秒一次的轻量回调（跟随引擎 pref 的变化）
 */
function createDialogEmbed(doc, hooks = {}) {
  let embed = null;      // 我们的容器（.spcar-embed）；对话框关闭时随引擎子树一起消失
  let latest = null;     // 最近一次的 slideshow 引用
  let observer = null;
  let ticker = null;
  let disposed = false;

  const bgsetEl = () => doc.querySelector?.('.hub-dialog__body .bgset') || null;

  const stopTicker = () => { if (ticker) { clearInterval(ticker); ticker = null; } };
  const startTicker = () => {
    if (ticker || disposed || !hooks.onTick) return;
    try { ticker = setInterval(() => { if (!disposed) hooks.onTick(); }, 1000); } catch { /* 没有计时器可用就算了（私有模式等） */ }
  };

  /** 确保容器在对话框里的位置；对话框不在时收尾并返回 null。 */
  const place = () => {
    const bgset = bgsetEl();
    if (!bgset) {
      stopTicker();
      if (embed) { render(null, embed); embed = null; }
      return null;
    }
    if (!embed) {
      embed = doc.createElement('div');
      embed.className = 'spcar-embed';
    }
    if (embed.parentNode !== bgset) bgset.insertBefore(embed, bgset.firstChild);
    return bgset;
  };

  const draw = () => {
    if (disposed) return;
    const bgset = place();
    if (!bgset) return;
    startTicker();
    if (latest) render(html`<${DialogCarousel} slideshow=${latest} />`, embed);
    bgset.setAttribute('data-spcar-mode', latest && latest.pref.mode === 'carousel' ? 'carousel' : 'single');
  };

  const MO = globalThis.MutationObserver;
  if (doc.body && typeof MO === 'function') {
    observer = new MO(() => {
      if (disposed) return;
      // 热点路径：页面任何一处 DOM 变动都会走到这里，一切就位时必须立刻返回。
      const bgset = bgsetEl();
      if (bgset) {
        if (embed && embed.parentNode === bgset) return;
        draw();
      } else if (embed) {
        draw();   // 对话框关掉了：place() 收尾
      }
    });
    observer.observe(doc.body, { childList: true, subtree: true });
  }

  return {
    /** 每次渲染同步一次：更新 latest 并重画（对话框不在时是一条廉价空路）。 */
    sync(slideshow) { latest = slideshow; draw(); },
    destroy() {
      disposed = true;
      stopTicker();
      try { observer?.disconnect(); } catch { /* already gone */ }
      if (embed) { render(null, embed); embed.parentNode?.removeChild(embed); embed = null; }
      const bgset = bgsetEl();
      if (bgset) bgset.removeAttribute('data-spcar-mode');
    },
  };
}

/**
 * 嵌入块里画的东西：「单张背景 / 轮播图」两个页签 + 轮播模式下的 `CarouselPanel`（逐字未改）+ 说明。
 * **纯视图**：状态全在传进来的 `slideshow` 里（与舞台同一份）。
 * @param {{ slideshow: ReturnType<typeof useCarousel> }} props
 */
function DialogCarousel({ slideshow }) {
  const { pref, update, stored } = slideshow;
  const n = stored.length;
  const carousel = pref.mode === 'carousel';
  return html`<div class="spcar-embed__in">
    <div class="bgset__modes" role="radiogroup" aria-label="背景方式">
      <button type="button" role="radio" aria-checked=${carousel ? 'false' : 'true'}
          class=${'bgset__mode' + (carousel ? '' : ' is-selected')} onClick=${() => update({ mode: 'single' })}>
        <span class="bgset__modeicon"><${SingleGlyph} /></span>
        <span class="bgset__name">单张背景</span><span class="bgset__en">SINGLE</span>
      </button>
      <button type="button" role="radio" aria-checked=${carousel ? 'true' : 'false'}
          class=${'bgset__mode' + (carousel ? ' is-selected' : '')} onClick=${() => update({ mode: 'carousel' })}>
        <span class="bgset__modeicon"><${CarouselGlyph} /></span>
        <span class="bgset__name">轮播图</span><span class="bgset__en">CAROUSEL ${n}/${CAROUSEL_MAX}</span>
      </button>
    </div>
    ${carousel ? html`<${CarouselPanel} slideshow=${slideshow} />
      <p class="spcar__note">轮播图只替换大厅的**背景**：引擎自己画的那一套（夜巡 / 霜原 / 自定义图片 / 视频）
        在你切回「单张背景」时原样回来。暗化、模糊与动态效果沿用本对话框里的设置。
        图片只存在本机浏览器（IndexedDB），不上传服务器；最多 ${CAROUSEL_MAX} 张，横版图片效果最好。</p>` : null}
  </div>`;
}

/**
 * 工坊面板的挂载点（`pack.json.client.panels[].module` 的 `mount(ctx)`）。
 * 宿主本身**没有可见内容**（设置界面在「大厅背景」对话框里，由 CarouselApp 的嵌入块负责）。
 * @param {{ host: any }} ctx 引擎给的注入面（这里只用到 `host`）
 * @returns {{ unmount?: () => void }}
 */
export function mount(ctx) {
  const host = ctx && ctx.host;
  const doc = (host && host.ownerDocument) || globalThis.document;
  if (!host || !doc) return {};

  const rootEl = doc.createElement('div');
  rootEl.className = 'spcar-host';
  rootEl.id = PANEL_ID;
  host.appendChild(rootEl);

  const stage = createStage(doc);
  render(html`<${CarouselApp} stage=${stage} />`, rootEl);

  return {
    unmount() {
      render(null, rootEl);
      rootEl.remove();
      stage.destroy();
    },
  };
}

export default mount;
