# 来源与署名（PROVENANCE）

## 原件叫什么、从哪来
- **服务器**：`http://183.66.27.19:20522/`（星空之下服 · 卫戍协议：盟约社区服，app **0.4.0**，build `69b1c68e7a5c`）
- **原件数据**：该服 `/data/chess.json`
- **取证时间**：2026-10-13；全量差集扫描 `_tmp/server-mods-2026-10-13/wave3/datadiff.json`
- **目录描述**：B站「d星空之下」自建；国内直连正常，边缘出口 403

## 原作者是谁
- 上游：`sganggs/Stronghold-Protocol`（GPL-3.0-or-later）
- 该服维护者：**d星空之下**（isomer 社区目录 / dl 清单标注）
- 打包：jingjiangze

## 原件的许可
GPL-3.0-or-later（随上游）。**角色设定与美术版权属鹰角网络 / Yostar**。本包只含数值记录（stats / skill / talents 的 bb），**不含任何素材字节**。

## 它改了什么
从该服 `chess.json` 提取引擎没有、且未被其它包或其它服务器占用的 **12 条**棋子记录（chess_char_*）。

**逐条核验**：profession 在引擎 8 值内、`skill.durationType` 为 `NONE`/`AMMO` 且非缺失、`skills[]` 内无非法枚举、与已上传的 `clemntia-chess` / `s8-chess-extras` 及其它服务器零 id 冲突。

## 自带素材是哪来的
**无素材**（用户明确要求）。`assets` 字段指向的图标 / 立绘 / Spine 模型均未随包分发。

## 已知不兼容 / 边界（必读）
1. **⚠️ 会影响对局结果** —— 新增可上场单位就是改对局内容，故 `pack.json` 已标 `combat: true`。
2. **图标与立绘是占位**：本包不含素材。
3. **kit 覆盖**：记录的 `charId` 命中引擎 kit 注册表的那部分正常复用引擎技能逻辑；未命中的落通用 kit（技能效果简化，非完整实现）。
4. **同 id 时按包 id 字典序裁决**（引擎规则，非本包可控）。
