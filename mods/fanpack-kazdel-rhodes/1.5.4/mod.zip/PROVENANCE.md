# PROVENANCE — 这份包是怎么来的

**它不是作者原件，是站方把原件的「内容部分」重打成的标准工坊包。**

| | |
|---|---|
| 原投稿 | `c26a6ed4c1e7`「卡兹戴尔罗德岛盟约多功能mod-v1.5.4-适配最新UI和上流0.2.5」 |
| 原件 sha256 | `b0ad28245eb4060063dff8c494256231d6f49663b6ac508cecf0d364c4a6e703` |
| 原作者 | B站@伊佐那邪_ · https://github.com/yznx09/Stronghold-Protocol-Rhodes-Kazdel-Mod |
| 原件形态 | 一键安装包（`install.mjs` 48,231 B + `payload/**` 177 个文件） |
| 本包 | zip 根即 `pack.json`；引擎 `tools/workshop-validate.mjs` ⇒ **0 error / 84 warning** |

## 原件为什么不收

`install.mjs` 会把 `payload/**` 整份覆盖到引擎检出上（`data/chess.json`、`data/items.json`、`data/config.json`、
`server/match/builtinMeta.js`、`server/sim/content/kits/custom.js` 等），也就是「包改引擎源码」。本站不收这种形态。
**本包不采用、绝不执行 `install.mjs`**，只走引擎的声明面。

## 本包映射了什么（逐条可核）

| 原件的哪一块 | 本包里去哪 | 数量 |
|---|---|---|
| `payload/packs/fanpack/records.json` → `bonds` | `bonds.json` + `overrides`（与官方同 id 的 10 条） | 12（2 新增 / 10 覆盖） |
| 同上 → `items` | `items.json` | 12（全部新增） |
| 同上 → `garrisons` | `garrisons.json` + `overrides`（4 条） | 34（30 新增 / 4 覆盖） |
| 同上 → `assets`（图标 URL 表） | `pack.json.bondIcons` / `itemIcons` + 包内 `assets/*.png` | 2 + 5 张图 |
| `chess.json` → `chess` | `chess.json` + `overrides`（14 条） | 40（26 新增 / 14 覆盖） |
| `tokens.json` → `tokens` | `tokens.json` + `overrides`（1 条） | 4（3 新增 / 1 覆盖） |
| `variants.json` → `training` | `variants.json`（DESIGN §28.51 口径通道）+ `content:["variants"]` | **28 chess + 4 tokens** |

口径数值（满练度）**逐条无损**：把真包装进引擎自己的装载器（`server/data.js` 的 `loadData`），
32 条记录 / 作者写下的 **4019 个值**，差异 **0**；反向核 `chess_char_6_12_a`：官方 atk 616 → 装包后 676
（= 投稿 `variants.json` 写的那一个数）。

## 剥掉的键（引擎从不读，或不在闭集里）

* `pack.json` 的 `_doc` / `type` / `englishName` / `app` / `credits` / `files{}` —— 引擎的顶层键闭集是
  `PACK_FIELDS`，这些键会让装载期 `PACK_UNKNOWN_FIELD` **整包拒绝**。其中 `_doc` 在引擎仓与模组仓
  **两仓 grep 均无任何代码读它**（只出现在 `CHANGELOG.md` 的叙述里），所以删掉**行为不变**。
  作者想留的说明文字原样搬进本文件与 `pack.json.description`。
* 内容文件里的 `_doc` / `version` / `roster` —— 它们不是记录 id；留着会被当成一条非法记录。
* `variants.json` 的 `shipped` —— 安装器自己的开关，不是口径表。

## 两处必须写明的换算（数值一个没动）

1. **`{$: value}` 叶子 → 原生值**。原件的 patch 方言是 `{ $: v }`，引擎的 `mergeRecord` 要原生值。
2. **整块替换分支写成完整值**。原件安装器的 `applyPatch` 是**深层字段合并**，引擎的 `mergeRecord` 对
   `OVERRIDE_REPLACE_KEYS`（含 `skill`）与数组是**整块替换**。直接把半份 `skill` 交上去，合并后会丢
   `skillType` / `spType` / `initSp`，`workshop-validate` 实测报 6 个 `BAD_ENUM` / `BAD_NUMBER`。
   所以先按原件语义算出「想要的最终值」，再把那些分支写成完整值。

## ⚠️ 一处如实披露：8 条装备的 `params` 按引擎规则重推过

原件的 12 条装备里，有 8 条的 `params` 与它**自己的 `buffs`** 对不上（少 `bond` / `other_equip`，键序也不同）。
`params` 在引擎里是**派生量**：`shared/itemAuthoring.js` 的 `effectParams` 注释写着「Reproduces params for
all 115 shipped items」，校验器报 `STALE_DERIVED` 并写「re-derive it」；作者自己的
`payload/tools/build-data.mjs` 里有一份**逐字相同**的 `effectParams`。

* 重推前先证「作者写的每一个键值都还在」—— 本步只补齐、只改键序，**没有一个数字被覆盖**：
  `c_02_e_a/_b` 补 `bond`；`c_04_e_a/_b` 补 `bond`+`other_equip`；`c_05_e_a/_b` 补 `other_equip`；
  `c_03_e_a/_b` 仅键序。
* 补进去的这两个键在**记录层**没有被任何引擎代码读：`p.bond` 只在 `server/sim/content/items/meta.js:178`
  （天师古鼎 `chess_item_6_03_e` 那一条专属 handler）被读，`p.other_equip` 只在
  `server/sim/content/items/battle.js:64` 被读、而它的入参是**逐 buff** 的 `{...bb,...bbStr}`
  （`buffsOf`），不是记录的 `params`。战斗数值一律走 `buffsOf(rec)`，本包**一个 buff 都没改**。
  所以这一处是「把作者自己的构建工具会写出来的缓存补上」，不是行为改动。

## 没有搬进来的东西

* `install.mjs`、`manifest.json`、`files.json`、`asset-additions.json`、`asset-manifest-additions.json`
* `payload/server/**`、`payload/public/**`、`payload/tools/**`、`payload/data/**`、`payload/docs/**`
* 原件的 `.bat` 一键脚本（若原件含）—— 本包没有任何可执行物

## 素材

含从游戏《明日方舟》解包出的官方素材（官方干员头像 / 立绘 / 时装立绘与头像 / 官方 Spine 模型 / 官方语音）。
官方素材版权归鹰角网络 / Yostar；本站与改写者不主张任何权利，仅供非商业学习与个人娱乐，请勿用于任何商业场景。
本包自带的 7 张图是作者自制图标（2 张盟约图标 + 5 张装备图标）。

## 零删除

原投稿的记录与 `mod.zip` 一个字节都没删、没改。本包是**新增**的一条记录；原件转为 `superseded`（下架 ≠ 删除），
`replacedBy` 指向本包，随时可恢复。
