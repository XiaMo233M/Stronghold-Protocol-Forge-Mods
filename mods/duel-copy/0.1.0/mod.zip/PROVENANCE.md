# 署名与来源 · PROVENANCE

> 本文件随包分发。原作者与本版兼容改写者**分开显示，不抹掉任何一方**。
> 原件未署名的一律写**「原件未署名」**，不代填名字；许可**照实抄**（甲方声明什么就写什么，不替其断言真伪）。

## 一、原作者

**jingjiangze**（原件 `pack.json` 的 `author` 字段，如实照抄，不代填）。上游与拆分说明见第四节。

## 二、许可（照实抄）

原件 `pack.json` 声明 `AGPL-3.0-or-later`，**照实抄**，本版未改该字段。
作者在投稿正文里称：原件「代码与文档文字 AGPL-3.0-or-later」，美术素材版权归鹰角网络 / Yostar。
本次交付**未独立核对**上游 LICENSE 文件；许可文字按作者声明照实抄录，不代为断言真伪。

## 三、本版兼容改写者

| 角色 | 是谁 |
|---|---|
| 原作者 | jingjiangze（拆分与搬运） |
| 本版兼容改写者 | **Mo233**（Forge 兼容改写：包格式对齐 + 署名文件，改写点见第六节） |
| 本包交付 | 第三方 mod 兼容交付流程，2026-10-12 |

## 四、来源

| 项 | 值 |
|---|---|
| 站点 | sp-modsite（`http://47.103.14.217:25570/`）待审投稿 |
| 记录 id | `b1edce4883d6` |
| 原件 sha256 | `cf0daa0ee7fceca929ed7304885ddcd43791ba2fad6b03d7f15828e9227f37f2` |
| 上传时间 | `2026-10-11T17:39:52.595Z` |
| 上传来源 ip | `119.181.30.24` |
| 原件形态 | `mod.zip`（3（`pack.json` 在根） 个条目） |
- 作者声明的上游：**争锋频道 Duel-Channel（非官方同人复刻）** <https://github.com/Cloudnyco/Duel-Channel>
- 作者声明的取用点：`main@4d3b33be6c08b9c93e0c847b69e70e8bffbd2b77`（2026-10-11 的 304 文件树）
- 作者声明：原作者为 **Duel Channel contributors**；投稿人 `jingjiangze` 只做**拆分与搬运**，不宣称对原件的原创权
- ⚠️ 上述上游事实**来自作者投稿正文（`note`）的声明**。本次交付**无法联网核对**该仓库与 commit；**未**独立验证，
  也**没有**代填任何作者名字。

## 五、改了什么

本包在**原件形状上已合法**：原件单独装载即 `0 error(s), 0 warning(s)` / `VALID` —— 本版**一个声明都没改**。

本版只做打包形状对齐与署名：`pack.json`、`notice/announcement.json`、`notice/credits.json` **逐字节未改**，
新增 `PROVENANCE.md` 与 `NOTICE-来源说明.md`。

**未改什么**：`notices` 是**追加**语义（DESIGN §28.15）——两个包的公告不互相覆盖、也不顶掉引擎自己的公告，
所以作者把「不兼容清单」放进公告是**正确用格**，不需要任何形状改写。

## 六、自带素材

**无**。本包自带素材为零（无图片 / 音频 / Spine / 字体），只有纯 JSON 文字与数值 + 一份 panel JS/CSS。
原作者在投稿正文里明确：「本包不含任何美术字节」—— 本次交付独立复核：全包零命中美术扩展名与 base64。

## 校验

- 本包**单独**装载于干净的 workshop 根（根内只有这一个包）：`node tools/workshop-validate.mjs --workshop <root>`，结果见交付索引。
- 引擎版本：Stronghold-Protocol `0.15.2`（`cb684ee6`），`MOD_API_VERSION` 1。
- **数值一个字节未改**：本包不含任何 `data/*.json` 官方数值改写，`combat` 未声明（不改对局结果）。

---

*English summary: this pack is a compatibility conversion delivered for Stronghold-Protocol. The original author and
the compatibility rewriter are listed separately above; where the original was uncredited it is stated as
"原件未署名 (uncredited original)" rather than being invented. The licence text is copied verbatim from the original.
See the Chinese sections above for the exact source, the list of changes, and the origin of any bundled assets.*
