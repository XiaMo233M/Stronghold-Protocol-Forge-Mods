// workshop/egir-buff/battle/main.mjs — 【阿戈尔】盟约加强（pack.json.server.battle，docs/WORKSHOP.md §1.15）。
//
// 这个包只做两件官方 阿戈尔 没有的事；其余（HP 公式、吞噬本身、层数、5 名那一档的复活名额与复活本身）全部留给
// 官方的 `server/sim/content/bonds/core.js installEgir` —— 官方 installer 先跑、本模块随后跑，两边各管一段。
//
//   1. <战斗开始时> 所有【阿戈尔】干员获得「当前【阿戈尔】层数 × 0.5」的**基础面板攻击力**（固定加算 atkFlat，
//      直接加在基础面板上；100 层 = +50 点。与技能 / 其它盟约的「攻击力+X%」不是同一桶，不会被那些百分比放大）。
//      本模块的 `battleStart` 监听器排在官方那个（里面跑 devour）之后，所以读到的层数已经含本场吞噬叠加的那部分
//      —— 那正是「战斗开始时」的当前层数。只发一次，战斗中后续叠层不再追溯。
//   2. 5 名不同成员那一档：被官方复活逻辑真的救起来的那名干员，额外获得 +50 攻速（持续到战斗结束）。
//
// (2) 为什么要跟官方「算一遍」而不是读一个信号：引擎没有「单位复活」钩子 —— 官方核心实现只在复活成功时记一条
// **客户端事件**（`S.fxOn(battle, 'revive', u, 'bond:egirShip', 'respawn', { n })`，走 `battle._ev`，不是 `battle.on`）。
// 于是这里照官方那两段（战斗中当场复活 / 开局吞噬的 flush）各判一次，判据与官方逐字相同：
//   * 开局那段：官方在 `battleStart` 里按**版面位置**（更靠左、再更靠下）救 `batch` 里的人，本模块用同一个排序在
//     自己（更晚注册）的 `battleStart` 监听器里补 buff —— 那时官方已经救完了，`u.alive` 就是「有没有被救起来」。
//   * 战斗中：官方的 `death` 钩子是 priority 11，本模块用默认 0（更晚跑），所以轮到本模块时它已经复活完了，
//     `u.alive` 直接可读。
// 两段都只给**真的被救起来**的那名（`redeploy` 被挡住 / 名额用完的不给）。同一名干员只会被救一次（官方
// `knockedOut` 集合），所以不会重复加成。
import { bondActive, bondLayers, bondMembers, bondRecord, num, passiveBuff } from '@battle/index.js';

const BOND = 'egirShip';
/** 「当前层数 × 0.5 的基础面板攻击力」——固定加算，100 层 = +50 点。 */
const START_ATK_PER_LAYER = 0.5;
/** 「获得50攻速加成」——攻速是**点**（aspd），不是百分比。 */
const REVIVE_ASPD = 50;

/** 官方 `egirReviveScan`：按玩家自己看到的版面「更靠左、再更靠下」排序（右侧镜像玩家从场地右边数起）。 */
const boardCol = (battle, u) => ((battle.getPlayer(u.ownerId)?.mirror ? -1 : 1) * u.tileC);
const reviveScan = (battle) => (a, b) => boardCol(battle, a) - boardCol(battle, b) || a.tileR - b.tileR || a.id - b.id;

/** 每场战斗的额外安装（本模块的注册都在 install 里完成）。 */
export function install(battle) {
  if (!battle || !Array.isArray(battle.players)) return;
  for (const p of battle.players) {
    const pid = p.playerId;
    if (!bondActive(battle, pid, BOND)) continue;
    const members = bondMembers(battle, pid, BOND);
    if (!members.length) continue;

    // 1. 战斗开始时的攻击力（官方 devour 跑完之后的层数）。
    battle.on('battleStart', () => {
      const L = bondLayers(battle, pid, BOND);
      if (!(L > 0)) return;
      const amount = START_ATK_PER_LAYER * L;
      if (!(amount > 0)) return;
      // atkFlat：固定加算到基础面板攻击力上（100 层 → +50 点），不走「攻击力+X%」那一桶。
      for (const u of members) passiveBuff(battle, u, 'mod:egir:startAtk', { atkFlat: amount });
    }, { once: true });

    // 2. 5 名那一档的复活攻速。
    if (!(REVIVE_ASPD > 0)) continue;
    const max = Math.max(0, Math.floor(num(bondRecord(BOND)?.bb?.max_free_respawn_cnt, 3)));
    if (!(max > 0)) continue;
    const memberSet = new Set(members.filter((u) => u.kind === 'op'));
    const opening = [];    // 开局吞噬期间被击倒的成员：官方等所有吞噬跑完再按位置救
    const seen = new Set(); // 已计入的成员（官方「首次被击倒」只算一次）
    const grant = (u) => { if (u && u.alive && !u.removed) passiveBuff(battle, u, 'mod:egir:reviveAspd', { aspd: REVIVE_ASPD }); };
    // 开局那段：官方 flush 跑完之后（本模块的 battleStart 比官方那个晚注册），把真的站起来的按同一个顺序补 buff。
    battle.on('battleStart', () => {
      if (!opening.length) return;
      let slots = max;
      for (const u of opening.splice(0).sort(reviveScan(battle))) {
        if (slots <= 0) break;
        if (u.alive && !u.removed) { grant(u); slots--; }
      }
    }, { once: true });
    battle.on('death', (c) => {
      const u = c.unit;
      if (c.reason !== 'killed' || c.revivedBy || !memberSet.has(u) || seen.has(u)) return;
      seen.add(u);
      if (battle.time <= 0) { opening.push(u); return; }  // 开局吞噬的窗口：交给上面那个 battleStart 监听器
      grant(u);                                           // 战斗中：官方（priority 11）已经复活过了
    });
  }
}
