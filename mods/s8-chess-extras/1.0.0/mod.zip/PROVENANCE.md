# 来源与署名（PROVENANCE）

## 原件叫什么、从哪来
- **服务器**：`http://mc3.bbsmc.cn:11451/`（八服 · 卫戍协议：盟约社区服，app **0.2.1-fusion**，build `41e054e8c455`）
- **原件数据**：该服 `/data/chess.json`（**972 条**记录，引擎只有 266 条）
- **取证时间**：2026-10-13；本地副本 `_tmp/server-mods-2026-10-13/wave2/data/mc3_chess.json`
- 目录描述：`敌人更新 无尽模式 模组包 新盟约乌萨斯`；维护者 `牢大变女人喵`（isomer 目录标注）

## 原作者是谁
- 上游：`sganggs/Stronghold-Protocol`（GPL-3.0-or-later）
- 八服运营者：isomer 目录 `wei.isomer319.xyz/api/servers` 标注 **牢大变女人喵**
- 打包：jingjiangze

## 原件的许可
GPL-3.0-or-later（随上游）。**角色设定与美术版权属鹰角网络 / Yostar**。本包只含数值记录（stats / skill / talents 的 bb），**不含任何素材字节**。

## 它改了什么（差集实测）
八服 972 条 vs 引擎 266 条：

| 类别 | 条数 | 本包 |
|---|---|---|
| `chess_char_*` 新干员/新形态 | 52 | ✅ 收录 |
| `chess_rodos_*`（罗德岛分支） | 22 | ✅ 收录 |
| `chess_uam_*`（乌萨斯学生自治团分支） | 22 | ✅ 收录 |
| `chess_rainbow_*`（彩虹小队） | 16 | ✅ 收录 |
| `chess_babel_*`（巴别塔） | 14 | ✅ 收录 |
| `chess_rhine_*`（莱茵生命） | 12 | ✅ 收录 |
| `chess_kazdel_*`（卡兹戴尔） | 12 | ✅ 收录 |
| `chess_custom_*`（自选） | 10 | ✅ 收录 |
| `chess_chen3_*`（陈） | 2 | ✅ 收录 |
| **合计** | **162** | ✅ **全部收录** |
| `recruit_5_*` / `recruit_6_*`（招募池变体） | 548 | ❌ 不收录（见下） |
| 与引擎同 id 的 266 条 | — | ❌ 不收录（见下） |

**为什么不收录 548 条 `recruit_*`**：它们是**招募池变体**（字段带 `recruit: true` / `kitBaseId` / `recruitPresetId`），走的是另一套「从池里抽到哪个形态」的机制，引擎 0.16.0 的 `chess.json` 没有这套字段。硬塞会撞 `UNKNOWN_OVERRIDE_FIELD`。

**为什么不覆盖那 266 条同 id 记录**：逐字段核验过，八服对它们的改动**全部是删除** `potDown`（252 条）与 `talents[].potMin` / `potBelow`（223 条），**没有一条真的改数值**。而引擎的覆盖语义是「按字段打补丁」，**没有「删除一个已有字段」的表达能力** ⇒ 搬过去只会得到一份与官方逐字节相同的数据，零效果。故不收录（与 `clemntia-tokens` 撞的是同一堵墙，结论一致）。

### 逐轮剔除的 38 条（引擎会整包拒，不猜等价值）
差集原本 162 条，实测校验后**剔除 38 条**，保留 124 条。剔除原因全部是「八服用了引擎 0.16.0 不认识的枚举值」：

| 剔除数 | 原因 | 涉及 |
|---|---|---|
| 24 | `skill.durationType = "TIME"` | `chess_chen3_*`、`chess_rodos_{lava,hibisc,lava2,hbisc2,greyy2,kalts2}_*`、`chess_babel_{amiya,amiya2,amiya3,kalts}_*` |
| 6 | `profession = "VANGUARD"` | `chess_rodos_{fang,fang2,closure}_*` |
| 6 | `skills[]` 里某一条 `durationType = "TIME"` | `chess_rodos_flwr2_*`、`chess_babel_{hodrer,wisdel}_*` |
| 2 | 顶层 `skill.durationType` **缺失**（引擎对空值判 `BAD_ENUM`） | `chess_char_1037_amiya3_*`、`chess_char_1052_kalts2_*` |
| 2 | 同时命中上面两类 | `chess_rodos_closure_*` |

**为什么不猜一个等价值映射过去**：`durationType: TIME` 与 `AMMO` 是两套不同的技力机制（时限技 vs 弹药技），`VANGUARD` 与 `PIONEER` 是不同职业。硬映射等于制造一个语义相反的假实现 —— 宁可少 38 条，也不留一个装上去行为不对的单位。

## 自带素材是哪来的
**无素材**（用户明确要求）。`assets` 字段指向的图标 / 立绘 / Spine 模型均未随包分发。

## 已知不兼容 / 边界（必读）
1. **⚠️ 会影响对局结果** —— 新增 162 个可上场单位就是改对局内容，故 `pack.json` 已标 `combat: true`。
2. **图标与立绘是占位**：本包不含素材，界面会显示缺省图。
3. **80 / 162 能解析到引擎 kit，其余 82 个落通用 kit**。判定依据 = 记录的 `charId` 是否命中引擎 kit 注册表（`KITS`，210 键，含 `chess_char_*` 与 `char_*` 两种形态）。落通用 kit 的那些**技能效果会简化**（通用 kit 只覆盖攻击/光环类基础行为），不是完整实现。
4. **与 `clemntia-chess` 的关系**：`chess_char_4_27_a` / `_b` 在两服**是同一个角色**（克莱门莎，`char_4231_clemnt`，实测核验），因此本包**不含**这两条 —— 已由 `clemntia-chess` 提供，两边不会撞 id。
   ⚠️ 但**十一服**（`exastrisrestart.top`）的 `chess_char_4_27_a` 是**阿米娅（MEDIC，`char_1037_amiya3`）**，与上述两条**同 id 不同角色**。若将来做十一服的棋子包，必须先解决这个 id 冲突（引擎规则：包 id 字典序小的一方赢，另一方被 `PACK_ID_COLLISION` 拒）。
5. **盟约成员依赖**：本包含 `chess_uam_*`（乌萨斯学生自治团分支 22 条），但**不含**那个盟约本身（八服的 `ursusStudent` 7 个成员全是本包这种新棋子，效果又超出引擎通用盟约通路 ⇒ 单独装会得到一个永远凑不齐的盟约，故不做）（八服的 `ursusStudent` 效果超出引擎通用盟约通路的表达能力，详见 findings §8.4）。
