# 来源说明（PROVENANCE）· sp-skins-index v1.0.0

## 1 原作者
数据 / 立绘 / Spine / 语音的原始版权方为鹰角网络（Hypergryph）/ Yostar；线上构建未署名个人作者（原件未署名）。索引文本与切片：jingjiangze。

## 2 许可
本索引包自身 GPL-3.0-or-later；它所指向的数据与素材 © Hypergryph / Yostar（**含官方素材**，本包不主张任何权利）。仅供非商业学习与个人娱乐。

## 3 兼容改写者
jingjiangze（不存在二次改写他人 mod 的事；本批全部是从线上构建直接逆向切片）。

## 4 来源
线上构建 https://weishuxieyi.icu/_build/f638115c25cd-20/（build f638115c25cd-20 / app 0.2.1）。
逐表比对与分片脚本：`_tmp/reverse-weishu-2026-10-13/_packs/{delta,delta2,delta3,assets-diff,check4..6,build}.mjs`。

## 5 改了什么
- 本包只做索引：一份公告（notices 通道）+ 一份机读清单（routes 通道 `/sp-skins/index.json`，cache: public）。**零素材、零代码、不改对局**（combat: false）。
- 清单里逐片给：url（两个入口）/ urlAlt / zip 字节 / sha256 / 解后字节 / 条目数 / 覆盖的皮肤或记录 / 引擎单装校验结果 / 是否也已直接投站。
- 同时把「为什么不直接投站」与「为什么引擎侧不能只放链接」两条证据链写进 description、公告与 knownGaps（含 file:line）。

## 6 自带素材来源（逐条清点）
- 无。本包 `assets/` 目录不存在，随包只有 4 份 JSON（pack.json、cdn/index.json、notice/announcement.json、notice/credits.json）。
- 它所指向的字节清点在 `cdn/index.json` 的 pieces 数组里（7 片时装美术合计 183.7 MiB 的 zip，解后 347.1 MiB / 2175 个文件，全部来自线上构建 assets/cosmetics/，未裁剪、未转码、未重绘）。

---
非商业声明：本包与其指向的任何素材版权归鹰角网络 / Yostar 所有，本包与其无任何关联，不主张任何权利，仅供非商业的学习与个人娱乐使用，请勿用于任何商业场景。
