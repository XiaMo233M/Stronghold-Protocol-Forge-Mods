// test/panel.test.mjs — healthz-ext 面板的纯逻辑验收（作者侧；不需要引擎，不需要浏览器）。
//
// 怎么跑：`node --test healthz-ext/test/panel.test.mjs`。
// 覆盖：flattenFields（过滤坏项、映射三列）与 renderContract（标题 / 端点 / 表格行数 / 坏值不抛）。
import { test } from 'node:test';
import assert from 'node:assert/strict';

// renderContract 通过全局 document.createElement 造节点 —— 用迷你 DOM 顶上（模块本身不 import 引擎）。
function makeEl(tag) {
  const el = {
    tagName: tag, children: [], attrs: {}, className: '',
    setAttribute(k, v) { el.attrs[k] = String(v); },
    appendChild(child) { el.children.push(child); child.parentElement = el; return child; },
    remove() {
      if (el.parentElement) el.parentElement.children = el.parentElement.children.filter((c) => c !== el);
      el.parentElement = null;
    },
  };
  Object.defineProperty(el, 'textContent', {
    get: () => el._text || '',
    set: (v) => { el._text = String(v); if (v === '') el.children = []; },
  });
  return el;
}
globalThis.document = { createElement: makeEl };

const { flattenFields, renderContract } = await import('../ui/panel.js');

/** 收集一棵子树里的所有节点（含自身），按 tagName 找。 */
function collect(node, tag, out = []) {
  if (node.tagName === tag) out.push(node);
  for (const c of node.children || []) collect(c, tag, out);
  return out;
}

test('flattenFields：过滤坏项，只留 path 是字符串的，映射 path/type/what', () => {
  const rows = flattenFields([
    { path: 'ok', type: 'boolean', what: '健康位' },
    { path: 'a.b.c', type: 'number', what: '点路径' },
    { path: 'noType', what: '缺类型' },
    { what: '没有 path —— 丢掉' },
    null, 3, 'x',
  ]);
  assert.deepEqual(rows.map((r) => r.path), ['ok', 'a.b.c', 'noType']);
  assert.equal(rows[0].type, 'boolean');
  assert.equal(rows[2].type, '', '缺 type → 空串');
  assert.equal(rows[1].what, '点路径');
  assert.deepEqual(flattenFields(null), []);
  assert.deepEqual(flattenFields('nope'), []);
});

test('renderContract：标题 / 端点 / 来源 / 字段表 / packNote 都画出来', () => {
  const root = makeEl('div');
  renderContract(root, {
    title: 'T', what: 'W', endpoint: '/healthz', methods: 'GET / HEAD',
    source: { repo: 'r', rev: 'v' },
    fields: [{ path: 'ok', type: 'boolean', what: '健康位' }, { path: 'build', type: 'string|null', what: '构建' }],
    packNote: 'PN',
  });
  assert.equal(collect(root, 'h3')[0]._text, 'T');
  const endpoint = collect(root, 'p').find((p) => p.className === 'hze__endpoint');
  assert.ok(endpoint && endpoint._text.includes('/healthz'));
  const src = collect(root, 'p').find((p) => p.className === 'hze__src');
  assert.ok(src && src._text.includes('r') && src._text.includes('v'));
  const rows = collect(root, 'tr');
  assert.equal(rows.length, 3, '表头 1 行 + 数据 2 行');
  assert.equal(rows[0].children.length, 3, '三列：字段 / 类型 / 说明');
  assert.equal(rows[1].children[0]._text, 'ok');
  assert.equal(rows[2].children[0]._text, 'build');
  assert.equal(collect(root, 'p').find((p) => p.className === 'hze__note')._text, 'PN');
});

test('renderContract：空 / 坏数据不抛（只画标题，不画表）', () => {
  for (const bad of [null, undefined, {}, { fields: 'x' }, { fields: [] }]) {
    const root = makeEl('div');
    assert.doesNotThrow(() => renderContract(root, bad));
    assert.equal(collect(root, 'table').length, 0, '没有可画字段 → 不画表');
  }
});
