// ui/panel.js — 把本包的两条只读路由画成表（只读；不发任何网络消息）。
//
// 数据来自**本包自己的 routes**（pack.json.routes）：/mod/healthz-ext.json 与 /mod/client-build.json。
// 这两条路由真的被引擎的静态面服务（WORKSHOP §1.9.2：只 GET / HEAD、精确匹配、只服务包内 .json），
// 所以这块面板读得到、画得出 —— 这是本包「功能包」的那一半。
// 另一半（实时读数）不在包里：routes 只服务静态 .json，拿不到进程 / 监听器 / perf_hooks。面板只画契约。

const HEALTH_URL = '/mod/healthz-ext.json';
const BUILD_URL = '/mod/client-build.json';

function el(tag, cls, text) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text != null) node.textContent = text;
  return node;
}

/** 把 fields[]（可能带 a.b.c 点路径）拍成扁平行，供表格用。导出以便测试。 */
export function flattenFields(fields) {
  if (!Array.isArray(fields)) return [];
  return fields.filter((f) => f && typeof f === 'object' && typeof f.path === 'string')
    .map((f) => ({ path: f.path, type: typeof f.type === 'string' ? f.type : '', what: typeof f.what === 'string' ? f.what : '' }));
}

/** 画一份字段契约（title / endpoint / fields / example / packNote）。导出以便测试。 */
export function renderContract(root, data) {
  root.appendChild(el('h3', 'hze__title', (data && data.title) || '字段契约'));
  if (data && data.what) root.appendChild(el('p', 'hze__what', data.what));
  if (data && data.endpoint) root.appendChild(el('p', 'hze__endpoint', `端点：${data.endpoint}  ·  ${data.methods || 'GET / HEAD'}`));
  if (data && data.source) {
    const rev = data.source.rev ? `（${data.source.rev}）` : '';
    root.appendChild(el('p', 'hze__src', `来源：${data.source.repo || ''}${rev}`));
  }
  const rows = flattenFields(data && data.fields);
  if (rows.length) {
    const table = el('table', 'hze__table');
    const thead = el('thead');
    const hr = el('tr');
    for (const label of ['字段', '类型', '说明']) hr.appendChild(el('th', null, label));
    thead.appendChild(hr);
    table.appendChild(thead);
    const tbody = el('tbody');
    for (const r of rows) {
      const tr = el('tr');
      tr.appendChild(el('td', 'hze__path', r.path));
      tr.appendChild(el('td', 'hze__type', r.type));
      tr.appendChild(el('td', 'hze__desc', r.what));
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);
    root.appendChild(table);
  }
  if (data && data.packNote) root.appendChild(el('p', 'hze__note', data.packNote));
}

async function fetchJson(url) {
  const res = await fetch(url, { cache: 'no-cache' });
  if (!res.ok) throw new Error(`${url} HTTP ${res.status}`);
  return res.json();
}

export async function mount(ctx) {
  const root = ctx.host;
  const loading = el('p', 'hze__hint', '载入中…');
  root.appendChild(loading);
  let disposed = false;

  const results = await Promise.allSettled([fetchJson(HEALTH_URL), fetchJson(BUILD_URL)]);
  if (disposed) return {};
  loading.remove();

  results.forEach((r, i) => {
    const box = el('section', 'hze__block');
    if (r.status === 'fulfilled') {
      try {
        renderContract(box, r.value);
      } catch (err) {
        if (ctx.log && ctx.log.error) ctx.log.error('render failed', err);
        box.appendChild(el('p', 'hze__err', `渲染失败：${String((err && err.message) || err)}`));
      }
    } else {
      const url = i === 0 ? HEALTH_URL : BUILD_URL;
      box.appendChild(el('p', 'hze__err', `${url} 读取失败：${String((r.reason && r.reason.message) || r.reason)}`));
    }
    root.appendChild(box);
  });

  root.appendChild(el('p', 'hze__note', '只读：面板只读本包的两条 routes，不发送任何消息、不触达服务器原生 /healthz 或 /client-build。'));

  return { unmount() { disposed = true; } };
}

export default mount;
