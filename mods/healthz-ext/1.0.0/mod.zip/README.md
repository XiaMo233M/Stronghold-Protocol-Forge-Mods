# healthz-ext · 健康与构建只读接口

把 fork 的观测端点落成**真的能 GET** 的工坊只读路由：`/mod/healthz-ext.json` 与 `/mod/client-build.json`，
外加一块把它们画成表的面板。装到带工坊支持的引擎上，这两条路由会回字段契约与样例值。

> **这不是实时遥测。** 工坊包的 `routes` 只能服务包内静态 `.json`，拿不到进程 / 监听器 / perf_hooks。
> 真正的 `/healthz` 与 `/client-build` 仍是服务器自己的 HTTP 路由。本包是它们的**等价只读接口 + 字段说明书**。

## 它提供什么

| 路由 | 文件 | 内容 |
|---|---|---|
| `GET /mod/healthz-ext.json` | `data/healthz-ext.json` | `/healthz` 扩展段的字段契约（ok/version/app/build/sockets/sessions/rooms/matches/humans/bots/spectators/online/queued/maxRooms/combat/trial/performance…）+ 样例 + 负载状态折算阈值 |
| `GET /mod/client-build.json` | `data/client-build.json` | `GET /client-build` 的字段契约（`{ build }`）+ 构建输入树清单 + 样例 |

两条路由都只 `GET` / `HEAD`（其它动词 405，`Allow: GET, HEAD`）、精确匹配、无副作用（WORKSHOP §1.9.2）。

面板挂在 `root.guide`，把两条路由的内容画成字段表。

## 安装

```bash
node tools/workshop-pack.mjs import "健康与构建只读接口.zip"   # 或把 healthz-ext/ 复制进 workshop/
# 重启游戏服务器（包装载是进程级的）
```

## 边界（先知道再装）

- **契约，不是读数。** 路由回的是字段名 / 类型 / 语义 / 样例，不是这台机器此刻的状态。
- **不改服务器原生路由。** `/healthz` 与 `/client-build` 仍由 `server/http/routes.js` 回答；本包不碰它们。
- **面板只读。** 注入面只有 `host` 与 `fetch` 本包两条路由，没有 store / 对局对象，一次 `send` 都没有。
- **零素材。** 不含任何游戏素材。

## 开发/验收

```bash
node --test healthz-ext/test/panel.test.mjs        # 纯逻辑：flattenFields / renderContract（迷你 DOM）
node tools/workshop-validate.mjs --workshop <装好的根>
node tools/check-packs.mjs --engine <Forge 目录> --root packs
```

许可证：代码与 JSON GPL-3.0-or-later；本包不含任何游戏素材。
