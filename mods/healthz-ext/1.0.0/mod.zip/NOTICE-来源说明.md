# NOTICE-来源说明

## 原件名称与来源

- **原件**：`jingjiangze/stronghold-server`（fork of `sganggs/Stronghold-Protocol`）的 **R5** 改动：
  `/healthz` 增加 combat / trial / performance 三段诊断字段，并新增 `GET /client-build`。
  仓库：<https://github.com/jingjiangze/stronghold-server>（2026-10-11 快照）。
  落点文件（只读引用，未改动）：`server/http/routes.js`（`healthReport()` / `createRequestHandler`）、
  `server/http/buildTag.js`、`server/healthMetrics.js`、`server/lobby.js`（`stats()`）。
- 本包由**原作者本人**制作，不是第三方改写：把原件的**字段契约**搬进管理器（Forge）能表达的只读形态。

## 原作者

jingjiangze（本人）。

## 原件许可

GPL-3.0-or-later（与 fork / 管理器同族）。

## 改了什么

**没有改任何原件字节。** 包里是**新写**的两份契约 JSON、一块面板与一张样式表：

| 件 | 落点 | 说明 |
|---|---|---|
| `data/healthz-ext.json` | `routes` 声明的 `/mod/healthz-ext.json` | `/healthz` 扩展字段的契约 + 样例（本包自写） |
| `data/client-build.json` | `routes` 声明的 `/mod/client-build.json` | `/client-build` 字段契约 + 样例（本包自写） |
| `ui/panel.js` | `client.panels` 的 `root.guide` | 把两条路由画成表（只读；不发消息） |
| `ui/panel.css` | 同上 | 面板样式 |
| `README.md` | — | 用法与边界 |

**它真的做了什么（这一半是功能）**：本包声明了两条**真的能被 GET** 的工坊只读路由
（WORKSHOP §1.9.2：只 GET / HEAD、精确匹配、只服务包内 `.json`），面板读得到、画得出。装到
带工坊支持的引擎上，`GET /mod/healthz-ext.json` 与 `GET /mod/client-build.json` 会回这两份契约。

## 做不了的部分（**这一节是重点**）

**实时读数不在包里，也做不成包。**

- 工坊包的 `routes` 通道**只能服务包内静态 `.json`**（`.js` / `.html` 在读盘前就被拒），它拿不到
  `process` / `perf_hooks` / 监听器 / socket 计数 —— 所以本包的两条路由回的是**字段契约与样例值**，
  **不是**这台服务器此刻的真实读数。
- 真正的 `/healthz`（含 combat / trial / performance 三段）与 `/client-build` 是**服务器自己的 HTTP 路由**
  （`server/http/routes.js`，在静态面之前被处理），工坊包既不能收编、也不能占用既有路径。
- 面板的注入面（WORKSHOP §1.9.3）只有 `host` 与 `net.on('<S2C>')` 等，没有 HTTP 客户端；面板也不可能
  去 `fetch('/healthz')` 绕过——那样会把监控读数变成客户端行为，且与「只读契约」的定位不符。

因此：**本包是服务器原生 `/healthz` 与 `/client-build` 的等价只读接口与字段说明书，不是实时遥测。**
要看真读数，请部署带该功能的服务器（fork 及其部署树）后直接 `GET /healthz` 与 `/client-build`。

## 自带素材来源

**没有任何素材。** 没有图标、音频、字体、立绘、spine、解包数据。

## 许可

- 本包 **GPL-3.0-or-later**（JSON 与面板代码均为本包自写）。
- 《明日方舟》及其素材版权归鹰角网络 / Yostar 所有；本包不含、也不主张任何此类素材。
