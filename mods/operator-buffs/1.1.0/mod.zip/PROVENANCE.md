# 诸神黄昏 · 素材与数据出处

本文件由 `tools/build-workshop-mods.mjs` 从 `mods/operator-buffs/operators/*/PROVENANCE.md` 拼成, 不要手改。

## clemntia

# 来源与署名（PROVENANCE）

## 原件叫什么、从哪来
- **服务器**：`https://weishuxieyi.icu/`（卫戍协议：盟约 · 同人联机服，app 0.2.1）
- **原件数据**：该服 `/_build/f638115c25cd-20/data/bonds.json`（23 条盟约）
- **取证时间**：2026-10-13

## 原作者是谁
- 上游：`sganggs/Stronghold-Protocol`（GPL-3.0-or-later）
- 该同人服运营者：**未署名**
- 打包：jingjiangze

## 原件的许可
GPL-3.0-or-later（随上游）。无素材。

## 它改了什么
weishu 服的 `bonds.json` 与上游**同键（均 23 条）**，唯一差异是三条盟约的 `members` / `visibleMembers` 各追加了一个成员 `chess_char_4_27_a`（克莱门莎）：

| bondId | 名称 | members | visibleMembers |
|---|---|---|---|
| `egirShip` | 阿戈尔 | 9 → 10 | 9 → 10 |
| `swiftShip` | 迅捷 | 14 → 15 | 12 → 13 |
| `indomShip` | 不屈 | 9 → 10 | 7 → 8 |

本包只覆盖这两个数组字段，盟约的阈值、加成、权重、图标一律不动。

## 自带素材是哪来的
**无素材**。

## 已知不兼容 / 边界（必读）
1. **依赖 `clemntia-chess`**：只加成员 id 而池子里没有那个棋子，盟约弹窗会列出一个选不出来的名字。两个包请一起装。
2. 覆盖是**按字段打补丁**（`OVERRIDE_REPLACE_KEYS` + 数组整块替换），不是整条替换 —— 所以盟约其余字段原样保留。
3. `members` 与 `visibleMembers` 都是官方记录已有的字段（闭合世界校验通过），不会撞 `UNKNOWN_OVERRIDE_FIELD`。

## lemuen

# 蕾缪安补强 · 出处与判据

- **干员**：蕾缪安 `char_4193_lemuen`，棋记录 `chess_char_6_01_a`（普通）/ `chess_char_6_01_b`（精英），
  tier 6、SNIPER / longrange、`nationId: laterano`。数据未改动 —— 这条补强**只加行为**，不写任何数值。
- **弹药与技能**：三个技能都是弹药类（S1 `trigger_time 5` / S2 `6` / S3 `5`）—— 实际读的是
  `data/chess.json` 的 `attack@trigger_time`。引擎在每次消耗弹药时 `battle.emit('ammoUsed', { unit, left, skill })`
  （`server/sim/content/kits/ops/chess_char_6_01-lemuen.js`）。
- **轰炸口径参照她自己的 S3（礼炮·强制追思）**：同一文件里的 `bombard` / `blast`——
  `fx('bombardShell')` 飞行 `LEMUEN_SHELL_FLIGHT = 0.3 s` → `fx('bombard')` → `dealDamage` 用
  `type:'phys'` / `isSkill` / `isSplash` / `tags:['skill','bombard']`。S3 的 0.3 s 与 10 s 窗口是 PRTS 备注里
  才有的数（不在数据里），本补强只借「飞行时间」，不借那两个溅射半径。
- **反隐口径参照银灰的鹰眼视觉**：`server/sim/content/kits/ops/chess_char_4_22-svrash.js`
  （`chess_char_4_22_a` 的天赋 1 就是「鹰眼视觉」，bb 为空 —— 效果在 kit 里）：
  `whileDeployed(battle, unit, AURA, () => reveal(battle, enemiesOnRange(battle, unit)))`；
  `reveal` / `AURA` / `AURA_DUR` 在 `kits/shared/tier4.js`（0.2 s 刷一次、0.25 s 存活、buff 键 `aura:reveal`）。
- **拉特兰名单**：`data/chess.json` 里 `nationId === 'laterano'` 的记录（10 条，含蕾缪安普通 + 精英）。
- **不采信**：网上关于「轰炸溅射半径」的说法——业主的规则只写了「对…敌方单位」，所以按单目标实现并在
  README 里标了 `[ASSUMED]`。改这一条只需要改 `battle/main.mjs` 里 `BOMB_ATK_SCALE` 附近那一段。
