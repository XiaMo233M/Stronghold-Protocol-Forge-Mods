# 诸神黄昏

给**已有干员**做强度补强的包：一条补强一个目录（mods/operator-buffs/operators/<key>/）。数值类只写要改的字段（overrides 差分补丁）；引擎里本来没有的新规则才走 battle/main.mjs（pack.json.server.battle）。由 tools/build-workshop-mods.mjs 装配。首批：克莱门莎（三条盟约成员资格）、蕾缪安（弹药轰炸 + 拉特兰范围反隐）。

版本 1.1.0 · 层 B · 改动战斗结果

本文件由 `tools/build-workshop-mods.mjs` 生成, 不要手改; 改 `mods/operator-buffs/` 再重新构建。

## 内容

| 干员 key | 数据文件 | kits | 素材 |
|---|---|---|---|
| `clemntia` | bonds | — | — |
| `exusiai` | chess | — | — |
| `lemuen` | — | — | — |
| `muelsyse` | bonds | — | — |
| `qiubai` | chess | — | — |

覆盖官方记录: `bonds:egirShip`、`bonds:swiftShip`、`bonds:indomShip`、`chess:chess_char_6_13_a`、`chess:chess_char_6_13_b`、`bonds:maniShip`、`chess:chess_char_6_15_a`、`chess:chess_char_6_15_b`

## 装起来之后

- 服务端重启才生效(包在启动时装载一次), 只刷新页面不够。
- 房间要在 MODS 面板里勾上这个包(combat: true 的包进房间摘要闸门)。
