// mods/operator-buffs/battle/main.mjs — 干员强化的**战斗侧**逻辑（`pack.json.server.battle`，DESIGN §28.17）。
//
// 这一层只放「数据通道表达不了」的东西：一条补强要么是改数值（走 `overrides` 差分补丁，见 operators/*/），
// 要么是引擎里本来没有的一条新规则 —— 后者才轮到这里。当前两件事：
//
//   1. 蕾缪安（`chess_char_6_01`）：**技能期间每消耗三颗弹药，对场上生命值最高的敌人进行一次攻击力 300% 的
//      轰炸**。轰炸沿用她 S3 的两步 fx（`bombardShell` → `bombard`）与同一套伤害口径（物理 / 技能 / 溅射 /
//      `skill` 标签），炮弹飞行时间也取 S3 的 0.3 s。
//      落点用她 S3 的溅射：半径 dist_2、中心半径 dist_1 内取 300% 攻击力，中心外按 S3 两级倍率的比例衰减。
//      目标优先取**被通缉**的敌人（天赋一 lemuen:wanted），没有标记才退回「生命值最高」。
//   2. S3 特殊补强：按**已叠加的拉特兰层数**加快弹药消耗 —— 0 层 +20%、线性到 200 层 +100%（间隔 = aim / (1+加成)）。
//      引擎侧的读取点是 kits/ops/chess_char_6_01-lemuen.js 的 unit.mem.skillCadence（缺省 1 = 官方节奏）。
//   3. 天赋一补强：**拉特兰干员范围内的所有敌人失去隐匿效果**。判据照 银灰 的鹰眼视觉
//      （`kits/ops/chess_char_4_22-svrash.js`：`whileDeployed(AURA) → reveal(enemiesOnRange)`）：
//      把「她自己的范围」换成「每一名在场的拉特兰干员的范围」，反隐 buff 与引擎自己的反隐光环同一个键
//      （`aura:reveal`，`kits/shared/tier4.js` 的 `reveal`），所以多个来源只占一份。
//      拉特兰 = 棋记录的 `nationId === 'laterano'`（引擎 kits 的 `nationOf` 读的是同一格）。
//
// 纪律：确定性（没有 Math.random / 没有时钟 / 不读文件）、只碰 battle 的公开 API、不涉及房间层。

/** 蕾缪安的普通 / 精英两条棋记录（kit 按普通 id 注册，精英共享同一份实现）。 */
const LEMUEN = Object.freeze(new Set(['chess_char_6_01_a', 'chess_char_6_01_b']));
/** 拉特兰层数上限与两端的速度加成（业主 2026-10-20：0 层 +20% → 200 层 +100%，线性）。 */
const CADENCE_MAX_LAYERS = 200;
const CADENCE_MIN_SPEEDUP = 0.2;
const CADENCE_MAX_SPEEDUP = 1;

/** 圣聆初雪（chess_char_6_02）：技能未开启时受到的伤害再 x0.5；常驻 +1 技力/s。 */
const CHUXUE = Object.freeze(new Set(['chess_char_6_02_a', 'chess_char_6_02_b']));

/** 耀骑士临光（chess_char_6_17）：卡西米尔盟约已激活时，每次部署在落点造成 330% 攻击力真实伤害（半径 1.5 格）。 */
const NEARL = Object.freeze(new Set(['chess_char_6_17_a', 'chess_char_6_17_b']));
const NEARL_RADIUS = 1.5;
const NEARL_ATK_SCALE = 3.3;

/** 锏（chess_char_6_19）：每次释放技能后回 30 技力，已激活盟约各 +3 层（上限 30）。 */
const JIAN = Object.freeze(new Set(['chess_char_6_19_a', 'chess_char_6_19_b']));
const JIAN_SP = 30;
const JIAN_LAYERS = 3;
const JIAN_LAYER_CAP = 30;

/** 塑心（chess_char_6_09）：自身开技能时，场上我方弹药类技能立刻补满。 */
const SUXIN = Object.freeze(new Set(['chess_char_6_09_a', 'chess_char_6_09_b']));

/** 异客（chess_char_6_05）：每命中一名敌人回 2 技力；每次用技能使下次伤害 +10%，最多 +50%。 */
const YIKE = Object.freeze(new Set(['chess_char_6_05_a', 'chess_char_6_05_b']));
/** 仇白（chess_char_6_15）：攻击**被减速/束缚**的敌人时，给对方 20% 法术脆弱。 */
const QIUBAI = Object.freeze(new Set(['chess_char_6_15_a', 'chess_char_6_15_b']));
const QIUBAI_FRAGILE = 0.2;
const QIUBAI_DURATION = 3;

/** 荒芜拉普兰德（chess_char_6_18）：对同一目标连续造成伤害时，3 秒内线性递增到 160%（换目标清零）。 */
const LAPP2 = Object.freeze(new Set(['chess_char_6_18_a', 'chess_char_6_18_b']));
const LAPP2_RAMP = 0.6;
const LAPP2_WINDOW = 3;

/** 浊心斯卡蒂（chess_char_6_04）：额外获得场上最高生命干员的**生命上限**、最高攻击干员的**攻击力**（持续跟随，R1/Q3）。 */
const SKADI2 = Object.freeze(new Set(['chess_char_6_04_a', 'chess_char_6_04_b']));

/**
 * 焰影苇草（chess_char_6_08）：对敌方施加灼痕（引擎键 `reed2:scorch`）时，自身范围内的我方干员获得
 * 30% 庇护（`dmgTakenMul: 0.7`）与「每秒回复她 100% 攻击力」的生命（`hpRegen`），持续 2 秒。
 */
const REED2 = Object.freeze(new Set(['chess_char_6_08_a', 'chess_char_6_08_b']));
const REED2_SHELTER = 0.7;
const REED2_DURATION = 2;

/**
 * 维娜·维多利亚（chess_char_6_07）：维多利亚盟约的干员对**战栗**（引擎状态 `fear`）目标伤害 → 150%；
 * 维娜自己施加的战栗延长到 10 秒。
 */
const SIEGE2 = Object.freeze(new Set(['chess_char_6_07_a', 'chess_char_6_07_b']));
const FEAR_MUL = 1.5;
const FEAR_EXTEND = 10;

/** 流明（chess_char_6_14）：技能期间每 0.5 秒对范围内所有敌人造成 10% 攻击力的法术伤害。 */
const LUMEN = Object.freeze(new Set(['chess_char_6_14_a', 'chess_char_6_14_b']));
const LUMEN_TICK = 0.5;
const LUMEN_SCALE = 0.1;

/**
 * 溯光星源（chess_char_6_16）：自身造成的**停顿**（引擎状态 `sluggish` —— 见 chess_char_6_16-halo2.js:40）可叠加，
 * 上限 99%、不衰减。引擎的状态是同名覆盖，所以这里自己累计：每出现一个新的 `sluggish`（同一个敌人的、来自她自己的），
 * 就把它的 value 累进 `enemy.mem.halo2Sum`，再用一条自己的 buff 写 `moveMul = 1 - min(0.99, sum)`。
 */
const HALO2 = Object.freeze(new Set(['chess_char_6_16_a', 'chess_char_6_16_b']));
const HALO2_CAP = 0.99;

/**
 * 佩佩（chess_char_6_06）：**在场萨尔贡干员**的攻击范围都算她的攻击范围（普攻与技能都用）。
 * 引擎给了公开入口 `battle.refreshRange(unit)`（queries.js:318 注释：内容改了 `unit.rangeGrid` 之后调它重建），
 * 所以做法是：每拍按「她自己的范围 ∪ 在场萨尔贡干员的范围」写回 `u.rangeGrid`，变了才重建。
 */
const PEPE = Object.freeze(new Set(['chess_char_6_06_a', 'chess_char_6_06_b']));

/**
 * 迷迭香（chess_char_6_12）：场上有干员攻击命中敌人时，她对**被打的目标**追加一次普攻（全局 0.2 s CD）；
 * 并且她的 S3 取消「只能攻击被阻挡目标」（引擎读点 `unit.mem.rosmonAnyTarget`）。
 * 追加攻击按她 kit 里那条 extra hit 的形状结算（`chess_char_6_12-rosmon.js:26`：`type: 'arts'`、带 `aftershock` 标记，
 * 这样她自己的余震天赋会照常触发）。
 */
const ROSMON = Object.freeze(new Set(['chess_char_6_12_a', 'chess_char_6_12_b']));
const ROSMON_CD = 0.2;

/** 新约能天使（chess_char_6_13）：每消耗 1 颗弹药，自身攻速 +5（本回合内累计）。 */
const EXU2 = Object.freeze(new Set(['chess_char_6_13_a', 'chess_char_6_13_b']));
const EXU2_ASPD_PER_AMMO = 5;

/** 余（chess_char_6_03）：S3 期间把天赋一的庇护广播给全场我方（去掉「阻挡敌人时」的限制，Q3 已确认）。 */
const YU = Object.freeze(new Set(['chess_char_6_03_a', 'chess_char_6_03_b']));

const YIKE_STEP = 0.1;
const YIKE_MAX_STACKS = 5;

/** 纯烬艾雅法拉（chess_char_6_20）：给友方治疗时叠护盾 —— 上限 = 她攻击力 300%（快照）、可叠加、一次性免疫。 */
const EYJA2 = Object.freeze(new Set(['chess_char_6_20_a', 'chess_char_6_20_b']));
const EYJA2_SHIELD_SCALE = 3;

/** 每消耗这么多发弹药触发一次轰炸（业主规则：三颗）。 */
const AMMO_EVERY = 3;
/** 轰炸的伤害倍率（业主规则：攻击力的 300%）。 */
const BOMB_ATK_SCALE = 3;
/** 炮弹飞行时间：与蕾缪安 S3 同一个数（`kits/ops/chess_char_6_01-lemuen.js` 的 LEMUEN_SHELL_FLIGHT）。 */
const SHELL_FLIGHT = 0.3;
/** 光环刷新周期与存活期：与引擎 aura 口径相同（`kits/shared/tier4.js` 的 AURA / AURA_DUR）。 */
const AURA = 0.2;
const AURA_DUR = 0.25;
/** 反隐 buff 的键：与引擎自己的反隐光环共用一个（tier4.js `reveal`），多来源叠加时只占一份。 */
const REVEAL_KEY = 'aura:reveal';
/** 拉特兰的 nationId。 */
const NATION = 'laterano';

const idOf = (u) => String((u && (u.defId || (u.def && u.def.id))) || '');
const nationOf = (u) => (u && u.def && u.def.raw ? u.def.raw.nationId : null) || null;

/**
 * 场上「生命值最高」的敌人。跳过不在场 / 不可选中的（`untargetable`）：轰炸也算一次攻击，
 * 不该落在选不中的东西上。同值时取先出现的那个 —— 遍历顺序稳定，重放才一致。
 */

/** S3 溅射的两级半径与两级倍率的缺省值（她 S3 的黑板：dist_1 0.8 / dist_2 1.5 / 倍率 3.6 : 2.4）。 */
const BLAST_DEFAULTS = Object.freeze({ d1: 0.8, d2: 1.5, s1: 1, s2: 1 });
const num = (v, d) => (typeof v === 'number' && Number.isFinite(v) ? v : d);
const isUntargetable = (e) => !!(e.s && e.s.flags && e.s.flags.untargetable);

/** 溅射参数读她**当前技能**的黑板（`unit.skill.bb`），与 S3 的 `blast` 读的是同一格。 */
function blastParams(bb) {
  const b = bb || {};
  return {
    d1: Math.max(0, num(b['attack@dist_1'], BLAST_DEFAULTS.d1)),
    d2: Math.max(0, num(b['attack@dist_2'], num(b['attack@projectile_range'], BLAST_DEFAULTS.d2))),
    s1: Math.max(0, num(b['attack@proj_atk_scale_1'], BLAST_DEFAULTS.s1)),
    s2: Math.max(0, num(b['attack@proj_atk_scale_2'], BLAST_DEFAULTS.s2)),
  };
}

/**
 * 炸谁：**被通缉的优先**（`lemuen:wanted` = 天赋一「跨境追缉许可」给精英 / 领袖挂的那个标记），
 * 有标记时在标记里取生命值最高的；场上没有标记才退回「生命值最高」。
 */
function pickTarget(battle) {
  let marked = null;
  let best = null;
  for (const e of battle.enemies) {
    if (!e.alive || e.hidden || isUntargetable(e)) continue;
    if (!best || e.hp > best.hp) best = e;
    if (typeof e.findBuff === 'function' && e.findBuff('lemuen:wanted') && (!marked || e.hp > marked.hp)) marked = e;
  }
  return marked || best;
}

/**
 * 一次轰炸的落地结算，口径同她 S3 的 `blast`：光圈的半径 = S3 的 `dist_2`；圈内**中心半径 `dist_1`** 取
 * 这条补强的 300% 攻击力，中心之外按 S3 两级倍率的**比例**衰减（`s2 / s1`，她 S3 是 2.4 / 3.6 ≈ 2/3）。
 * 与 S3 的一点差别：S3 还会打「白铁的 铁钳号」这类友方目标（它的 kit 允许），这里只结算敌人。
 */
function blast(battle, unit, atk, x, y, p) {
  battle.fx('bombard', { x, y, id: unit.id, r: p.d2 });
  const core = atk * BOMB_ATK_SCALE;
  const outer = core * (p.s1 > 0 ? p.s2 / p.s1 : 1);
  const inner = new Set(battle.foesInColliderRadius(x, y, p.d1));
  for (const e of battle.foesInColliderRadius(x, y, p.d2)) {
    if (isUntargetable(e)) continue;
    battle.dealDamage(unit, e, {
      amount: inner.has(e) ? core : outer, type: 'phys', isSkill: true, isSplash: true, tags: ['skill', 'bombard', 'buff:lemuen'],
    });
  }
}

/** 炮弹先飞（两步 fx 与 S3 逐字一致），落地时在落点做一次 S3 同款溅射。 */
function bombard(battle, unit, target) {
  const atk = unit.s.atk;
  const p = blastParams(unit.skill && unit.skill.bb);
  const x = target.x;
  const y = target.y;
  battle.fx('bombardShell', { x, y, id: unit.id, r: p.d2, t: SHELL_FLIGHT, i: 0 });
  battle.after(SHELL_FLIGHT, () => blast(battle, unit, atk, x, y, p), { owner: unit });
}

/**
 * 拉特兰干员范围内的反隐：每名在场的拉特兰干员，把它**攻击范围**里仍带 `stealth` 的敌人刷上一层反隐
 * （`aura:reveal` 那个键）。`battle.unitsInGrid` 做的是引擎自己的范围判定（碰撞体压格子），
 * 所以这里不需要另抄一份 `bodyInRange`。
 */
function revealAround(battle) {
  // 阀门（业主 2026-10-21）：只有在场**有蕾缪安**时，拉特兰干员才享受这条反隐补强。
  // 之前没有这个判定，导致「没带蕾缪安也触发」。
  let lemuenOnField = false;
  for (const u of battle.units) {
    if (u && LEMUEN.has(idOf(u)) && u.alive && u.deployed) { lemuenOnField = true; break; }
  }
  if (!lemuenOnField) return;
  for (const u of battle.units) {
    if (!u || u.side !== 'ally' || !u.alive || !u.deployed || u.hidden) continue;
    if (nationOf(u) !== NATION) continue;
    const grid = u.rangeGrid || (u.def && u.def.rangeGrid);
    if (!Array.isArray(grid) || !grid.length) continue;
    for (const e of battle.unitsInGrid(u, grid, { side: 'enemy' })) {
      if (!e.alive) continue;
      // 反隐的目标**就是隐身敌人** —— 这里绝不能过滤 `e.hidden`（曾经这么写，整条补强永远是空转）。
      const stealthy = (e.s && e.s.flags && e.s.flags.stealth) || (e.def && e.def.stealth === true);
      if (!stealthy) continue;
      battle.addBuff(e, { key: REVEAL_KEY, duration: AURA_DUR, flags: { reveal: true }, source: u });
    }
  }
}

/**
 * 拉特兰层数（读 `battle.players[..].bonds.lateranoShip.layers`，与 SDK 的 `bondState` 同一格）。
 * 不用 `@battle/mod.js`：本模块保持**零导入** —— 试炼场/单测可以直接 import 它，不必先过装载器的重写。
 */
function lateranoLayers(battle, unit) {
  const b = bondRecord(battle, unit, 'lateranoShip');
  if (!b || typeof b !== 'object' || b.active !== true) return null;   // 未激活 => 这条补强不触发
  const tier = Math.floor(Number(b.tier) || 0);
  if (tier < 1) return null;
  const n = Number(b.layers);
  return Number.isFinite(n) && n > 0 ? n : 0;                          // 已激活但 0 层 => 仍给 +20%
}

/**
 * S3 特殊补强：按**已叠加的拉特兰层数**加快弹药消耗速度。
 * 规则（业主 2026-10-20）：0 层 +20%，线性递增到 200 层 +100%，递增幅度相同 ⇒
 * `speedup = 0.2 + 0.8 × min(layers, 200) / 200`，`cadence = 1 + speedup`（引擎那条读取点用它除锁定间隔）。
 * 技能不在跑 / 不在场时写回 1（= 官方节奏）。
 */
function applyCadence(battle) {
  for (const u of battle.units) {
    if (!u || !LEMUEN.has(idOf(u))) continue;
    if (!u.mem) continue;
    if (!u.alive || !u.deployed || !u.skill || !u.skill.active) { u.mem.skillCadence = 1; continue; }
    // 业主 2026-10-20：这条提速只在**拉特兰盟约已激活**时生效 —— 层数在未激活时也存在，不能只看 layers
    const bonded = lateranoLayers(battle, u);
    if (bonded === null) { u.mem.skillCadence = 1; continue; }
    const layers = Math.min(CADENCE_MAX_LAYERS, bonded);
    u.mem.skillCadence = 1 + (CADENCE_MIN_SPEEDUP
      + (CADENCE_MAX_SPEEDUP - CADENCE_MIN_SPEEDUP) * (layers / CADENCE_MAX_LAYERS));
  }
}

/**
 * 圣聆初雪的技力：常驻 +1/s（`mods.spRecoveryFlat`，与引擎 `aura:spRecovery` 同一格）。
 * 伤害那一半走事件钩子（见 install 里的 `damaged`）。
 */
function applyChuxue(battle) {
  for (const u of battle.units) {
    if (!u || !CHUXUE.has(idOf(u)) || !u.alive || !u.deployed) continue;
    // Q1（业主 2026-10-20）：技力 +1/s **同样只在技能未开启时**生效 —— 与减伤同一个条件。
    const want = !(u.skill && u.skill.active);
    const has = typeof u.findBuff === 'function' && !!u.findBuff('buff:chuxue:sp');
    if (want && !has) battle.addBuff(u, { key: 'buff:chuxue:sp', mods: { spRecoveryFlat: 1 }, persist: true });
    else if (!want && has && typeof battle.removeBuff === 'function') battle.removeBuff(u, 'buff:chuxue:sp');
  }
}

/** 一个单位身上的某条盟约记录（`{ active, tier, layers }`），没有就 null。 */
function bondRecord(battle, unit, bondId) {
  const pid = unit && unit.ownerId;
  const players = battle && battle.players;
  let p = null;
  if (Array.isArray(players)) p = players.find((x) => x && (x.id === pid || x.playerId === pid)) || (players.length === 1 ? players[0] : null);
  else if (players && typeof players === 'object') p = players[pid] || null;
  const b = p && p.bonds ? p.bonds[bondId] : null;
  return b && typeof b === 'object' ? b : null;
}

/** 耀骑士临光的部署落点真伤（Q 未涉；业主规则：卡西米尔已激活才有）。 */
function nearlImpact(battle, unit) {
  const b = bondRecord(battle, unit, 'kazimierzShip');
  if (!b || b.active !== true) return;
  const atk = unit.s.atk;
  const x = unit.x;
  const y = unit.y;
  battle.fx('bombard', { x, y, id: unit.id, r: NEARL_RADIUS });
  for (const e of battle.foesInColliderRadius(x, y, NEARL_RADIUS)) {
    if (e.s && e.s.flags && e.s.flags.untargetable) continue;
    battle.dealDamage(unit, e, { amount: atk * NEARL_ATK_SCALE, type: 'true', isSkill: true, tags: ['skill', 'buff:nearl'] });
  }
}

/** 玩家（bond 挂在玩家身上；认 playerId，单玩家时兜底）。 */
function playerOf(battle, unit) {
  const pid = unit && unit.ownerId;
  const players = battle && battle.players;
  if (Array.isArray(players)) return players.find((x) => x && (x.id === pid || x.playerId === pid)) || (players.length === 1 ? players[0] : null);
  if (players && typeof players === 'object') return players[pid] || null;
  return null;
}

/** 精锐（`_b` 档 / isGolden）—— 业主 2026-10-21 的全局规则：叠层类补强，精锐翻倍，有上限则上限也翻倍。 */
function isEliteUnit(unit) {
  if (!unit) return false;
  if (unit.def && unit.def.isGolden === true) return true;
  return /_b$/.test(idOf(unit));
}

/** 锏：技能结束后 +30 技力；已激活盟约各 +3 层（上限 30）—— 精锐按全局规则翻倍（+6 / 60）。 */
function jianAfterSkill(battle, unit) {
  if (unit.skill && typeof unit.skill.gainSp === 'function') unit.skill.gainSp(JIAN_SP, 'buff:jian');
  const p = playerOf(battle, unit);
  if (!p || !p.bonds) return;
  const mul = isEliteUnit(unit) ? 2 : 1;
  const gain = JIAN_LAYERS * mul;
  const cap = JIAN_LAYER_CAP * mul;
  for (const rec of Object.values(p.bonds)) {
    if (!rec || typeof rec !== 'object' || rec.active !== true) continue;
    rec.layers = Math.min(cap, (Number(rec.layers) || 0) + gain);
  }
}

/**
 * 塑心：我方所有弹药类技能补满弹药；**并按补上的弹药总数，给全场我方每人同等数量的「次数盾」**
 * （业主 2026-10-21：一打就破、可挡任何数值的伤害、可叠加）。
 * 次数盾用引擎 buff 的 `shieldHits`（受击次数）+ `shield: Infinity`（不限数值），叠层记在 `mem.suxinShieldHits`。
 */
function suxinRefill(battle) {
  let refilled = 0;
  for (const u of battle.units) {
    if (!u || u.side !== 'ally' || !u.skill || u.skill.kind !== 'ammo') continue;
    const max = Number(u.skill.ammo) || 0;
    if (max <= 0) continue;
    const cur = Number(u.skill.ammoLeft) || 0;
    if (max > cur) refilled += max - cur;
    u.skill.ammoLeft = max;
  }
  if (refilled <= 0) return;
  for (const u of battle.units) {
    if (!u || u.side !== 'ally' || !u.alive || !u.deployed || !u.mem) continue;
    const prev = Number(u.mem.suxinShieldHits) || 0;
    u.mem.suxinShieldHits = prev + refilled;
    // 只用 `shieldHits`（受击次数），**不能**给 `shield` 一个无穷值：damage.js 的第二个循环里
    // `shield > 0` 会一直吸收伤害，次数耗尽后 buff 也不会被移除 ⇒ 变成永久无敌。次数盾本来就是
    // 「一打就破、不按数值算」，所以 `shield` 留空（= 0），由第一个循环把整次伤害吃掉并 -1。
    battle.addBuff(u, { key: 'buff:suxin:hits', shieldHits: u.mem.suxinShieldHits, visible: true });
  }
}

/** 异客：叠层（0..5），每层让下一次伤害 +10%。 */
function yikeMul(unit) {
  const st = Math.min(YIKE_MAX_STACKS, Math.max(0, Number(unit.mem && unit.mem.yikeStacks) || 0));
  return st > 0 ? 1 + YIKE_STEP * st : 1;
}

/** 被减速 / 束缚 / 定身？引擎里 `slow` 落成 `moveMul`（→ `s.moveSpeed` 变小），`bind`/`stun`/`noMove` 是 flags。 */
function isSlowedOrBound(e) {
  if (!e || !e.alive) return false;
  const f = e.s && e.s.flags;
  if (f && (f.stun || f.bind || f.noMove)) return true;
  const base = e.def && e.def.moveSpeed;
  const now = e.s && e.s.moveSpeed;
  return Number.isFinite(base) && Number.isFinite(now) && now < base - 1e-9;
}

/**
 * 浊心斯卡蒂：每拍检索全场我方，取「最高生命上限」与「最高攻击力」，以 `hpFlat` / `atkFlat` 叠到她身上。
 * R1 的口径「她的上限 = 最高者的上限 + 她原本的上限」在 mods 语义下正好等于 `hpFlat = 最高者的上限`
 * （mods 是**绝对值**加在基础值上，同一 key 重复添加是替换而非累加，所以不会滚雪球）。
 */
function skadiStats(battle) {
  for (const u of battle.units) {
    if (!u || !SKADI2.has(idOf(u)) || !u.alive || !u.deployed || !u.mem) continue;
    let maxHp = 0;
    let maxAtk = 0;
    for (const o of battle.units) {
      if (!o || o === u || o.side !== 'ally' || !o.alive || !o.deployed) continue;
      const hp = Number(o.s && o.s.maxHp) || 0;
      const atk = Number(o.s && o.s.atk) || 0;
      if (hp > maxHp) maxHp = hp;
      if (atk > maxAtk) maxAtk = atk;
    }
    const prev = u.mem.skadi;
    if (prev && prev.hpFlat === maxHp && prev.atkFlat === maxAtk) continue;
    u.mem.skadi = { hpFlat: maxHp, atkFlat: maxAtk };
    battle.addBuff(u, { key: 'buff:skadi2:stats', mods: { hpFlat: maxHp, atkFlat: maxAtk }, persist: true, visible: true });
  }
}

/** 焰影苇草：新上一个「灼痕」→ 她范围内的我方获得 2 秒庇护 + 回血。 */
function reedShelter(battle) {
  for (const u of battle.units) {
    if (!u || !REED2.has(idOf(u)) || !u.alive || !u.deployed || !u.mem) continue;
    const grid = u.rangeGrid || (u.def && u.def.rangeGrid);
    if (!Array.isArray(grid) || !grid.length) continue;
    const seen = u.mem.reedScorched || (u.mem.reedScorched = new Set());
    for (const e of battle.unitsInGrid(u, grid, { side: 'enemy' })) {
      if (!e || !e.alive) continue;
      if (typeof e.findBuff !== 'function' || !e.findBuff('reed2:scorch')) continue;
      const key = e.id != null ? String(e.id) : String(e.defId || '');
      if (!key || seen.has(key)) continue;
      seen.add(key);
      const regen = Math.max(0, Number(u.s && u.s.atk) || 0);
      for (const a of battle.unitsInGrid(u, grid, { side: 'ally' })) {
        if (!a || !a.alive || !a.deployed) continue;
        battle.addBuff(a, {
          key: 'buff:reed2:shelter', duration: REED2_DURATION, visible: true, source: u,
          mods: { dmgTakenMul: REED2_SHELTER, hpRegen: regen },
        });
      }
    }
  }
}

/** 该单位是否属于某条盟约（盟约成员记在棋记录的 `bonds` 上）。 */
function inBond(unit, bondId) {
  const rec = unit && unit.def;
  const list = (rec && (rec.bonds || (rec.raw && rec.raw.bonds))) || [];
  return Array.isArray(list) && list.indexOf(bondId) >= 0;
}

/** 目标身上有没有「战栗」（`fear`）：看 flags，也看 buff 键。 */
function hasFear(e) {
  if (!e) return false;
  if (e.s && e.s.flags && e.s.flags.fear) return true;
  const list = Array.isArray(e.buffs) ? e.buffs : [];
  return list.some((b2) => b2 && typeof b2.key === 'string' && /fear/i.test(b2.key));
}

/** 维娜：把她自己施加的战栗拉长到 10 秒（每拍检查，只加长不缩短）。 */
function siegeFearExtend(battle) {
  for (const u of battle.units) {
    if (!u || !SIEGE2.has(idOf(u)) || !u.alive || !u.deployed) continue;
    for (const e of battle.units) {
      if (!e || e.side !== 'enemy' || !e.alive) continue;
      const list = Array.isArray(e.buffs) ? e.buffs : [];
      for (const b2 of list) {
        if (!b2 || typeof b2.key !== 'string' || !/fear/i.test(b2.key)) continue;
        if (b2.source !== u) continue;
        if (!(Number(b2.duration) >= FEAR_EXTEND)) b2.duration = FEAR_EXTEND;
      }
    }
  }
}

/**
 * 流明（chess_char_6_14）：**攻击范围内反隐，常态生效**（技能未开启也生效）。
 * 业主 2026-10-22 改版：原来那条「视作核心盟约」撤掉，换成这一条。
 */
function lumenReveal(battle) {
  for (const u of battle.units) {
    if (!u || !LUMEN.has(idOf(u)) || !u.alive || !u.deployed) continue;
    const grid = u.rangeGrid || (u.def && u.def.rangeGrid);
    if (!Array.isArray(grid) || !grid.length) continue;
    for (const e of battle.unitsInGrid(u, grid, { side: 'enemy' })) {
      if (!e || !e.alive) continue;
      const stealthy = (e.s && e.s.flags && e.s.flags.stealth) || (e.def && e.def.stealth === true) || e.hidden === true;
      if (!stealthy) continue;
      battle.addBuff(e, { key: REVEAL_KEY, duration: AURA_DUR, flags: { reveal: true }, source: u });
    }
  }
}

/** 流明：一次范围结算（技能期间每 0.5 s 一次）。 */
function lumenBlast(battle, u) {
  const grid = u.rangeGrid || (u.def && u.def.rangeGrid);
  if (!Array.isArray(grid) || !grid.length) return;
  const dmg = Math.max(0, Number(u.s && u.s.atk) || 0) * LUMEN_SCALE;
  if (dmg <= 0) return;
  for (const e of battle.unitsInGrid(u, grid, { side: 'enemy' })) {
    if (!e || !e.alive) continue;
    battle.dealDamage(u, e, { amount: dmg, type: 'arts', isSkill: true, tags: ['skill', 'buff:lumen'] });
  }
}

/**
 * 流明：技能开始 → 用**自己的 0.5 s 自排队计时器**结算（比挂在 0.2 s 光环上更准：0.2 s 的拍点只能凑出 0.4/0.6）。
 * 技能结束/被击倒/撤下时自然停（每拍检查一次），下次开技能重新起。
 */
function startLumenTicks(battle, u) {
  if (!u.mem || u.mem.lumenOn) return;
  u.mem.lumenOn = true;
  const step = () => {
    if (!u.alive || !u.deployed || !(u.skill && u.skill.active)) { u.mem.lumenOn = false; return; }
    lumenBlast(battle, u);
    battle.after(LUMEN_TICK, step);
  };
  battle.after(LUMEN_TICK, step);
}

/** 溯光星源：把她自己上的停顿累计成 99% 封顶的减速（`moveMul`）。 */
function halo2Slow(battle) {
  for (const u of battle.units) {
    if (!u || !HALO2.has(idOf(u)) || !u.alive || !u.deployed) continue;
    for (const e of battle.units) {
      if (!e || e.side !== 'enemy' || !e.alive) continue;
      const list = Array.isArray(e.buffs) ? e.buffs.filter((b2) => b2 && b2.key === 'sluggish' && b2.source === u) : [];
      if (!e.mem) continue;
      const seen = Number(e.mem.halo2Seen) || 0;
      if (list.length <= seen) continue;
      let sum = Number(e.mem.halo2Sum) || 0;
      for (let i = seen; i < list.length; i++) sum += Number(list[i].value) || 0;
      e.mem.halo2Seen = list.length;
      e.mem.halo2Sum = Math.min(HALO2_CAP, sum);
      battle.addBuff(e, { key: 'buff:halo2:slow', visible: true, source: u, mods: { moveMul: 1 - e.mem.halo2Sum } });
    }
  }
}

/** 佩佩：合并在场萨尔贡干员的攻击范围（相对格坐标取并集）。 */
function pepeRange(battle) {
  for (const u of battle.units) {
    if (!u || !PEPE.has(idOf(u)) || !u.alive || !u.deployed || !u.mem) continue;
    const base = Array.isArray(u.def && u.def.rangeGrid) ? u.def.rangeGrid : [[0, 0]];
    const map = new Map();
    for (const [dx, dy] of base) map.set(dx + ',' + dy, [dx, dy]);
    for (const o of battle.units) {
      if (!o || o === u || o.side !== 'ally' || !o.alive || !o.deployed) continue;
      if (!inBond(o, 'sargonShip')) continue;
      const g = o.def && o.def.rangeGrid;
      if (!Array.isArray(g)) continue;
      for (const [dx, dy] of g) map.set(dx + ',' + dy, [dx, dy]);
    }
    const grid = [...map.values()];
    const key = [...map.keys()].sort().join('|');
    if (u.mem.pepeKey === key) continue;
    u.mem.pepeKey = key;
    u.rangeGrid = grid;
    if (typeof battle.refreshRange === 'function') battle.refreshRange(u);
  }
}

/** 迷迭香：追加普攻（全局 0.2 s CD）。 */
function rosmontisExtra(battle, target) {
  for (const u of battle.units) {
    if (!u || !ROSMON.has(idOf(u)) || !u.alive || !u.deployed || !u.mem) continue;
    const now = Number(battle.time) || 0;
    if (u.mem.rosNext && now + 1e-9 < u.mem.rosNext) continue;
    u.mem.rosNext = now + ROSMON_CD;
    const atk = Math.max(0, Number(u.s && u.s.atk) || 0);
    if (atk <= 0) continue;
    battle.dealDamage(u, target, {
      amount: atk, type: 'arts', isSkill: true, tags: ['attack', 'aftershock', 'buff:rosmontis'],
    });
  }
}

/** 每个声明了这个包的房间，每场战斗装一次。 */
export function install(battle) {
  battle.on('ammoUsed', (ctx) => {
    const unit = ctx && ctx.unit;
    if (!unit || !LEMUEN.has(idOf(unit))) return;
    if (!unit.skill || !unit.skill.active) return;          // 只在**技能期间**（弹药本来就只属于弹药类技能）
    applyCadence(battle);                                   // 让下一发的锁定间隔立刻吃到当前层数
    const n = (unit.mem.buffAmmo = (unit.mem.buffAmmo || 0) + 1);
    if (n % AMMO_EVERY !== 0) return;
    const target = pickTarget(battle);
    if (target) bombard(battle, unit, target);
  });
  // 光环循环：**不能在 install() 里直接排期**。实测 `battle.every(...)` 与 install 期间登记的 `after(...)`
  // 都不会被执行（installer 早于战斗起跑，调度表在那之后重建），而事件回调里的 `after` 会跑（炮弹落地即是证据）。
  // 所以：等战斗里第一个信号（部署 / 技能开始 / 弹药 / 命中）再起循环，之后自排队。
  const loop = () => {
    revealAround(battle);
    applyCadence(battle);
    applyChuxue(battle);
    skadiStats(battle);
    // 浊心斯卡蒂：天赋一可使用的召唤物 +1（引擎读点 deployLimitBonus，缺省 0 不变）
    for (const u of battle.units) if (u && SKADI2.has(idOf(u)) && u.mem) u.mem.deployLimitBonus = 1;
    reedShelter(battle);
    lumenReveal(battle);
    siegeFearExtend(battle);
    halo2Slow(battle);
    pepeRange(battle);
    for (const u of battle.units) if (u && ROSMON.has(idOf(u)) && u.mem) u.mem.rosmonAnyTarget = true;
    // 余：打开「S3 期间天赋一广播给全场」的引擎读取点（kit 里缺省是关的）
    for (const u of battle.units) if (u && YU.has(idOf(u)) && u.mem) u.mem.yuBroadcast = true;
    // 新约能天使：S2 不再扣队友攻速（读点 exuNoSteal）
    for (const u of battle.units) if (u && EXU2.has(idOf(u)) && u.mem) u.mem.exuNoSteal = true;
    battle.after(AURA, loop);
  };
  const startLoop = () => {
    if (battle.__opbuffLoop) return;
    battle.__opbuffLoop = true;
    battle.after(AURA, loop);
  };
  for (const evt of ['deploy', 'skillStart', 'ammoUsed', 'hit']) battle.on(evt, startLoop);
  battle.on('deploy', (ctx) => {
    const unit = ctx && ctx.unit;
    if (!unit || !NEARL.has(idOf(unit))) return;
    nearlImpact(battle, unit);
  });
  // 锏：技能结束后回 30 技力 + 盟约层数 +3（上限 30）
  battle.on('skillEnd', (ctx) => {
    const unit = ctx && ctx.unit;
    if (!unit || !JIAN.has(idOf(unit))) return;
    jianAfterSkill(battle, unit);
  });
  // 流明：技能开始 → 0.5 s 一跳的范围法术伤害
  battle.on('skillStart', (ctx) => {
    const unit = ctx && ctx.unit;
    if (!unit || !LUMEN.has(idOf(unit))) return;
    startLumenTicks(battle, unit);
  });
  // 塑心：自身开技能时，全场我方弹药补满
  battle.on('skillStart', (ctx) => {
    const unit = ctx && ctx.unit;
    if (!unit || !SUXIN.has(idOf(unit))) return;
    suxinRefill(battle);
  });
  // 纯烬艾雅法拉：给友方治疗时给该干员叠一层护盾（上限 = 攻击力 300% 快照；可叠加、一次性免疫所有伤害）
  // 迷迭香：任何我方干员命中敌人 → 她对那个目标追加一次普攻（0.2 s 全局 CD；不响应自己的追加攻击）
  battle.on('hit', (ctx) => {
    const s = ctx && ctx.source, t2 = ctx && ctx.target;
    if (!s || s.side !== 'ally' || !t2 || t2.side !== 'enemy' || !ctx.dmg) return;
    if (Array.isArray(ctx.dmg.tags) && ctx.dmg.tags.includes('buff:rosmontis')) return;
    rosmontisExtra(battle, t2);
  });
  // 维娜·维多利亚：维多利亚盟约的干员打「战栗」目标 → 伤害 ×1.5
  battle.on('hit', (ctx) => {
    const s = ctx && ctx.source, t2 = ctx && ctx.target;
    if (!s || s.side !== 'ally' || !ctx.dmg) return;
    if (!t2 || t2.side !== 'enemy') return;
    if (!inBond(s, 'victoriaShip')) return;
    if (!hasFear(t2)) return;
    ctx.dmg.mul *= FEAR_MUL;
  });
  // 荒芜拉普兰德：对同一目标连续伤害，3 秒内线性 ×1.0 → ×1.6；换目标/中断即清零（业主 Q14/Q16）
  battle.on('hit', (ctx) => {
    const s = ctx && ctx.source, t2 = ctx && ctx.target;
    if (!s || s.side !== 'ally' || !LAPP2.has(idOf(s))) return;
    if (!t2 || t2.side !== 'enemy' || !ctx.dmg || !s.mem) return;
    const now = Number(battle.time) || 0;
    const st = s.mem.lapp2;
    // 业主 2026-10-21：采用「更强的那版」—— **换目标不清零**，只要连续开火（间隔 ≤ 3 s）就一直吃当前倍率；
    // 断火超过 3 s 才重新起算。
    if (!st || now - st.last > LAPP2_WINDOW) s.mem.lapp2 = { t0: now, last: now };
    else st.last = now;
    const el = Math.min(LAPP2_WINDOW, Math.max(0, now - s.mem.lapp2.t0));
    ctx.dmg.mul *= 1 + LAPP2_RAMP * (el / LAPP2_WINDOW);
  });
  // 仇白：打「被减速/束缚」的敌人 → 20% 法术脆弱（`artsFragile` 同口径：`artsTakenMul = 1.2`）
  battle.on('hit', (ctx) => {
    const s = ctx && ctx.source, t2 = ctx && ctx.target;
    if (!s || s.side !== 'ally' || !QIUBAI.has(idOf(s))) return;
    if (!t2 || t2.side !== 'enemy') return;
    if (!isSlowedOrBound(t2)) return;
    battle.addBuff(t2, {
      key: 'buff:qiubai:fragile', duration: QIUBAI_DURATION, visible: true, source: s,
      mods: { artsTakenMul: 1 + QIUBAI_FRAGILE },
    });
  });
  // 新约能天使：每消耗 1 颗弹药 → 攻速 +5（累计；buff 的 mods 是绝对值，同 key 覆盖不会滚雪球）
  battle.on('ammoUsed', (ctx) => {
    const unit = ctx && ctx.unit;
    if (!unit || !EXU2.has(idOf(unit)) || !unit.mem || !unit.alive || !unit.deployed) return;
    const n = (Number(unit.mem.exuAmmo) || 0) + 1;
    unit.mem.exuAmmo = n;
    battle.addBuff(unit, { key: 'buff:exu2:aspd', mods: { aspd: n * EXU2_ASPD_PER_AMMO }, persist: true, visible: true });
  });
  battle.on('heal', (ctx) => {
    const s = ctx && ctx.source, t2 = ctx && ctx.target;
    if (!s || s.side !== 'ally' || !EYJA2.has(idOf(s))) return;
    if (!t2 || t2.side !== 'ally' || !t2.mem) return;
    const cap = s.s.atk * EYJA2_SHIELD_SCALE;
    const cur = Number(t2.mem.eyjaShield) || 0;
    const next = Math.min(cap, cur + (Number(ctx.amount) || 0));
    if (next <= cur + 1e-9) return;
    t2.mem.eyjaShield = next;
    battle.addBuff(t2, { key: 'buff:eyja2:shield', shield: next, shieldHits: 1, persist: true, source: s });
  });
  // 异客：命中一名敌人回 2 技力；伤害吃叠层；技能结束 +1 层
  battle.on('hit', (ctx) => {
    const s = ctx && ctx.source, t2 = ctx && ctx.target;
    if (!s || s.side !== 'ally' || !t2 || t2.side !== 'enemy' || !YIKE.has(idOf(s))) return;
    if (ctx.dmg) {
      const m = yikeMul(s);
      if (m !== 1) ctx.dmg.mul *= m;
    }
    if (s.skill && typeof s.skill.gainSp === 'function') s.skill.gainSp(2, 'buff:yike');
  });
  battle.on('skillEnd', (ctx) => {
    const unit = ctx && ctx.unit;
    if (!unit || !YIKE.has(idOf(unit)) || !unit.mem) return;
    unit.mem.yikeStacks = Math.min(YIKE_MAX_STACKS, (Number(unit.mem.yikeStacks) || 0) + 1);
  });
  // 圣聆初雪：**技能未开启时**受到的伤害再 x0.5（`damaged` 钩子、`dmg.mul` 乘区，与 tier1.js 的写法一致）。
  // 注意顺序：这个乘区在「结算之后」叠加，与业主的「额外在结算之后再降低 50%」同义。
  battle.on('damaged', (ctx) => {
    const u = ctx && ctx.target;
    if (!u || !CHUXUE.has(idOf(u))) return;
    if (u.skill && u.skill.active) return;                 // 技能开启时不减
    if (ctx.dmg && typeof ctx.dmg.mul === 'number') ctx.dmg.mul *= 0.5;
  });
}
