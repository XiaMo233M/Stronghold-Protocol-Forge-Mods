// mods/operator-buffs/client/buffs.js — 干员详情页的「补强」块（`pack.json.client.panels`，
// slot = `screen.loadout.detail`，DESIGN §1.9 / §28.8）。
//
// 宿主（`public/js/ui/detailPanel.js`）在那个插槽上传两样东西：一个空容器 `ctx.host`，和
// `ctx.hostKey` —— 当前详情页正在看的那个干员（详情页给的是**棋 id**，如 `chess_char_6_01_a`；
// 没有棋记录时才是 charId）。所以换干员 = 宿主用新的 hostKey 重新 mount，这里不需要订阅任何状态。
//
// 数据就写在这张表里：它只描述「这个包给这个干员加了什么」，是给玩家看的文案；
// 真正的行为在 `../../battle/main.mjs`（服务端 / 浏览器各跑同一份）。改文案只改这里，别去动行为。
//
// 三种情况会被跳过：当前不是棋详情（hostKey 为空）、这个干员没有补强、容器不是 DOM。

/** 一个干员（按**棋 id 去掉 `_a`/`_b` 的那一段**或 charId 索引）的补强文案。 */
const BUFFS = Object.freeze({
  // 蕾缪安（char_4193_lemuen）—— 两条补强都在 battle/main.mjs 里实现。
  'chess_char_6_01': Object.freeze({
    charId: 'char_4193_lemuen',
    rows: Object.freeze([
      Object.freeze({
        title: '弹药轰炸',
        text: '技能期间每消耗 3 发弹药，对场上生命值最高的敌人（若有被通缉的敌人则优先）进行一次 '
          + '300% 攻击力的轰炸：中心 0.8 格内全额，1.5 格内按 2/3 衰减。',
      }),
      Object.freeze({
        title: 'S3 提速',
        text: '礼炮·强制追思进行期间，按已叠加的拉特兰层数加快弹药消耗：0 层快 20%，线性递增到 200 层快 100%（盟约未激活则不触发）。',
      }),
      Object.freeze({
        title: '拉特兰反隐',
        text: '拉特兰干员攻击范围内的敌人失去隐匿效果（等同于银灰的鹰眼视觉，且对全场拉特兰干员生效）。',
      }),
    ]),
  }),

  // ── 以下每条的行为都在 battle/main.mjs 里，这里只写文案 ─────────────────────────────────────
  'chess_char_6_02': Object.freeze({
    charId: 'char_4188_chuxue',
    rows: Object.freeze([
      Object.freeze({
        title: '未开技能时减伤',
        text: '技能未开启时，自身受到的所有伤害在结算后再降低 50%；技力恢复速度 +1/秒（同样只在技能未开启时生效）。',
      }),
    ]),
  }),
  'chess_char_6_03': Object.freeze({
    charId: 'char_2026_yu',
    rows: Object.freeze([
      Object.freeze({
        title: 'S3 庇护广播',
        text: '焰里泣霜开启期间，天赋一的庇护效果赋予全场我方干员，且不再要求「阻挡敌人时」。',
      }),
    ]),
  }),
  'chess_char_6_04': Object.freeze({
    charId: 'char_1511_skadi2',
    rows: Object.freeze([
      Object.freeze({
        title: '叠加全场最高属性',
        text: '额外获得场上生命上限最高的干员的生命上限、攻击力最高的干员的攻击力（持续跟随，随场上变化）。',
      }),
      Object.freeze({
        title: '召唤物 +1',
        text: '天赋一可同时使用的召唤物数量 +1（原本 1 个，补强后 2 个）。',
      }),
    ]),
  }),
  'chess_char_6_05': Object.freeze({
    charId: 'char_1806_yike',
    rows: Object.freeze([
      Object.freeze({
        title: '命中回技力 / 叠伤',
        text: '每攻击到一名敌人恢复 2 点技力；每使用一次技能，使下次技能的伤害提升 10%，最多提升 50%（同一回合内累计）。',
      }),
    ]),
  }),
  'chess_char_6_06': Object.freeze({
    charId: 'char_4214_pepe',
    rows: Object.freeze([
      Object.freeze({
        title: '萨尔贡范围共享',
        text: '在场萨尔贡干员的攻击范围都视为佩佩的攻击范围，她实际可以攻击到这些范围内的敌人。',
      }),
    ]),
  }),
  'chess_char_6_07': Object.freeze({
    charId: 'char_2048_siege2',
    rows: Object.freeze([
      Object.freeze({
        title: '战栗增伤 / 延长',
        text: '维多利亚盟约的干员对战栗目标造成的伤害提升至 150%；维娜自身触发的战栗延长至 10 秒。',
      }),
    ]),
  }),
  'chess_char_6_08': Object.freeze({
    charId: 'char_1020_reed2',
    rows: Object.freeze([
      Object.freeze({
        title: '灼痕庇护',
        text: '对敌方目标施加灼痕时，自身范围内的我方干员获得 30% 庇护，并每秒回复焰影苇草 100% 攻击力的生命，持续 2 秒。',
      }),
    ]),
  }),
  'chess_char_6_09': Object.freeze({
    charId: 'char_4202_suxin',
    rows: Object.freeze([
      Object.freeze({
        title: '弹药补满 + 次数盾',
        text: '自身释放技能时，场上所有我方弹药类技能立刻补满弹药；并按补上的弹药总数，给全场我方每人同等层数的次数盾'
          + '（一打就破，但可挡任何数值的伤害，可叠加）。',
      }),
    ]),
  }),
  'chess_char_6_11': Object.freeze({
    charId: 'char_249_mlyss',
    rows: Object.freeze([
      Object.freeze({
        title: '调和视作所有盟约',
        text: '调和激活后，其「激活人数 +1」不再只作用于核心盟约，而是作用于**所有盟约**（每个已有成员的盟约各 +1）；'
          + '缪尔赛思本人计入全部盟约，因此也能享受这些盟约的效果。',
      }),
    ]),
  }),
  'chess_char_6_12': Object.freeze({
    charId: 'char_4146_rosmontis',
    rows: Object.freeze([
      Object.freeze({
        title: '追加普攻',
        text: '场上有干员攻击命中敌方单位时，迷迭香对被命中的目标追加一次普通攻击（内置冷却 0.2 秒）。',
      }),
      Object.freeze({
        title: 'S3 取消阻挡限制',
        text: '三技能期间不再只能攻击被阻挡的敌人。',
      }),
    ]),
  }),
  'chess_char_6_13': Object.freeze({
    charId: 'char_1031_angel2',
    rows: Object.freeze([
      Object.freeze({
        title: '精准盟约',
        text: '追加盟约「精准」（若本局随机禁用了精准，则只显示、不激活）。',
      }),
      Object.freeze({
        title: '弹药攻速',
        text: '每消耗 1 颗弹药，自身攻击速度 +5（本回合内累计）。',
      }),
      Object.freeze({
        title: 'S2 不偷攻速',
        text: '二技能不再扣取队友的攻击速度（自身获得的攻速加成保留）。',
      }),
      Object.freeze({
        title: 'S3 信标发射',
        text: '三技能会往整备区发一枚投递坐标信标：玩家手动摆放它的位置与朝向；进入下一回合时，'
          + '整备区最靠前的地面干员会被自动发射到信标格（朝向跟随），不计入部署上限、全局最多 2 个，'
          + '战斗结束后自动回整备区；被发射的干员不触发自己的特质。',
      }),
    ]),
  }),
  'chess_char_6_14': Object.freeze({
    charId: 'char_4205_lumen',
    rows: Object.freeze([
      Object.freeze({
        title: '攻击范围反隐',
        text: '流明的攻击范围内的敌人失去隐匿效果（常态生效，技能未开启时也生效）。',
      }),
      Object.freeze({
        title: '技能期范围伤害',
        text: '技能期间，每 0.5 秒对范围内所有敌方单位造成一次相当于流明攻击力 10% 的法术伤害。',
      }),
    ]),
  }),
  'chess_char_6_15': Object.freeze({
    charId: 'char_4082_qiubai',
    rows: Object.freeze([
      Object.freeze({
        title: '奥术盟约 + 法术脆弱',
        text: '追加盟约「奥术」（若本局随机禁用了奥术，则只显示、不激活）；自身攻击被减速/束缚的敌人时，为该敌人施加 20% 的法术脆弱。',
      }),
    ]),
  }),
  'chess_char_6_16': Object.freeze({
    charId: 'char_4218_halo2',
    rows: Object.freeze([
      Object.freeze({
        title: '停顿叠加',
        text: '自身造成的停顿可以叠加，上限 99%（叠加不衰减）。',
      }),
    ]),
  }),
  'chess_char_6_17': Object.freeze({
    charId: 'char_2025_nearl2',
    rows: Object.freeze([
      Object.freeze({
        title: '部署落点真伤',
        text: '卡西米尔盟约已激活时，每次自身部署都在落点造成一次自身攻击力 330% 的真实伤害（半径 1.5 格）。',
      }),
    ]),
  }),
  'chess_char_6_18': Object.freeze({
    charId: 'char_4142_lappland2',
    rows: Object.freeze([
      Object.freeze({
        title: '连续输出递增',
        text: '对同一目标连续造成伤害时，伤害在 3 秒内递增至原伤害的 160%（换目标不清零，断火超过 3 秒重新起算）。',
      }),
    ]),
  }),
  'chess_char_6_19': Object.freeze({
    charId: 'char_4141_jian',
    rows: Object.freeze([
      Object.freeze({
        title: '技能后回技力 / 盟约加层',
        text: '每次释放技能后，自身回复 30 点技力，并使自身已激活盟约层数增加 3 层（上限 30 层）；精锐形态叠层与上限翻倍（+6 / 60）。',
      }),
    ]),
  }),
  'chess_char_6_20': Object.freeze({
    charId: 'char_1032_eyjafjalla2',
    rows: Object.freeze([
      Object.freeze({
        title: '治疗附护盾',
        text: '对友方干员施加治疗时，为该干员附加一层护盾（上限为她攻击力的 300%，一次性、可防御任何数值的伤害、可叠加）。',
      }),
    ]),
  }),
});

/** 棋 id 的基名（`chess_char_6_01_a` → `chess_char_6_01`）。 */
const baseOf = (id) => String(id || '').replace(/_[ab]$/, '');

/**
 * 某个详情页宿主键对应哪些补强（纯函数，测试直接调它）。
 * @param {string|null|undefined} hostKey 详情页给的棋 id（或 charId）
 * @returns {ReadonlyArray<{ title: string, text: string }>}
 */
export function buffRowsFor(hostKey) {
  const key = String(hostKey || '');
  if (!key) return [];
  const direct = BUFFS[key] || BUFFS[baseOf(key)];
  if (direct) return direct.rows;
  for (const entry of Object.values(BUFFS)) if (entry.charId === key) return entry.rows;
  return [];
}

const CLS = 'opbuff';
const STYLE_SHEET = `
.${CLS}{margin:0 0 8px;padding:8px 10px;border:1px solid rgba(255,255,255,.16);border-radius:6px;background:rgba(255,255,255,.04);font-size:12px;line-height:1.5}
.${CLS}__title{font-weight:600;letter-spacing:.04em;opacity:.85;margin-bottom:4px}
.${CLS}__row{margin:4px 0 0}
.${CLS}__name{font-weight:600;color:#8fd3ff}
.${CLS}__text{opacity:.85}
`;

/**
 * 面板入口（引擎的 `mount(ctx)` 契约：返回 `{ unmount }`；容器不是 DOM 就什么都不做）。
 * @param {{ host?: Element, hostKey?: string|null }} ctx
 */
export function mount(ctx) {
  const host = ctx && ctx.host;
  if (!host || typeof host.appendChild !== 'function') return {};

  const wrap = document.createElement('div');
  wrap.className = CLS;
  const style = document.createElement('style');
  style.textContent = STYLE_SHEET;
  wrap.appendChild(style);

  const title = document.createElement('div');
  title.className = `${CLS}__title`;
  title.textContent = '补强';
  wrap.appendChild(title);

  const body = document.createElement('div');
  wrap.appendChild(body);
  host.appendChild(wrap);

  // 干员切换时宿主元素会被**复用**（引擎只在挂载时给一次 hostKey），所以自己盯着
  // `data-mod-slot-key` 的变化重画，否则会一直显示第一个干员的文案。
  let curKey = null;
  const render = (key) => {
    curKey = key;
    body.textContent = '';
    const rows = buffRowsFor(key);
    wrap.style.display = rows.length ? '' : 'none';
    for (const row of rows) {
      const line = document.createElement('div');
      line.className = `${CLS}__row`;
      const name = document.createElement('span');
      name.className = `${CLS}__name`;
      name.textContent = `${row.title}：`;
      const text = document.createElement('span');
      text.className = `${CLS}__text`;
      text.textContent = row.text;
      line.appendChild(name);
      line.appendChild(text);
      body.appendChild(line);
    }
  };
  render(ctx.hostKey);

  // 观察**整棵树**上的 `data-mod-slot-key`：引擎每次换干员会换一个新的宿主节点，而我们的块挂在一个
  // 复用的容器里（实测块所在元素的父节点没有该属性），所以不能只盯最初那个 host。
  let obs = null;
  if (typeof MutationObserver === 'function' && typeof document !== 'undefined') {
    obs = new MutationObserver(() => {
      const h = document.querySelector('[data-mod-slot="screen.loadout.detail"]');
      const k = h && h.getAttribute('data-mod-slot-key');
      if (k && k !== curKey) render(k);
    });
    obs.observe(document.body || document.documentElement, {
      subtree: true, attributes: true, attributeFilter: ['data-mod-slot-key'],
    });
  }

  return {
    unmount() {
      if (obs) obs.disconnect();
      if (wrap.parentNode) wrap.parentNode.removeChild(wrap);
    },
  };
}
