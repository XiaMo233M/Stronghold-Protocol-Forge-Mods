# 诸神黄昏 · 补强作者指南

本包把「干员补强」写成**数据 + 一个 `server.battle` 模块**，不替换任何官方 kit。想给别的干员写补强，照下面抄。

## 结构

```
pack.json        layer / combat / server.battle.module / client.panels
bonds.json       盟约数据补丁（本包：克莱门莎的三条盟约）
battle/main.mjs  唯一行为入口：install(battle)，每场战斗装一次
client/buffs.js  详情页「补强」块（client.panels → screen.loadout.detail）
AUTHORING.md     本文件
```

## 可用钩子（本包实际用到的）

| 钩子 | 时机 | 用途 |
|---|---|---|
| `battle.on('hit', ctx)` | 伤害结算前，`ctx.dmg.mul` 可乘 | 增伤 / 脆弱 / 追加攻击 / 按目标叠层 |
| `battle.on('damaged', ctx)` | 己方受伤，`ctx.target` 是被打的人 | 减伤 |
| `battle.on('deploy', { unit })` | 部署 | 落点效果 |
| `battle.on('skillStart' / 'skillEnd', { unit })` | 技能开始 / 结束 | 周期伤害 / 层数 / 回技力 |
| `battle.on('ammoUsed', { unit, left })` | 弹药消耗一发 | 按弹药计数触发 |
| `battle.on('heal', { source, target, amount })` | 治疗结算 | 治疗附护盾 |
| `battle.after(秒, fn)` | 延迟 / 自排队计时器 | 光环循环、延迟落地 |
| `battle.addBuff(u, { key, mods, duration, shield, shieldHits })` | — | 属性 / 减伤 / 护盾 / 次数盾 |

> **坑**：不要在 `install()` 里直接 `battle.every(...)` —— installer 早于战斗起跑，排期会被丢弃。本包的做法：等第一个战斗事件（deploy / skillStart / ammoUsed / hit）再起一个自排队的 `after` 循环。
> **坑**：次数盾（一打就破、挡任何数值）只给 `shieldHits`，**不要**给 `shield: Infinity` —— 后者的 `shield > 0` 分支会永久吸伤。

## 本包 17 条补强

| 干员 | 规则 | 落点 |
|---|---|---|
| 蕾缪安 | 每 3 发弹药轰炸（S3 同款两圈、通缉优先）；S3 按拉特兰层数提速（需盟约激活）；拉特兰范围反隐 | `ammoUsed` + 读点 `unit.mem.skillCadence` + 光环 |
| 圣聆初雪 | 技能未开时受伤 ×0.5；技力 +1/s（同受限制） | `damaged` + `mods.spRecoveryFlat` |
| 余 | S3 期间天赋一庇护广播全场、去掉「阻挡时」 | 读点 `unit.mem.yuBroadcast` |
| 浊心斯卡蒂 | 跟随场上最高生命上限 / 攻击力 | 光环 → `mods.hpFlat / atkFlat` |
| 异客 | 命中回 2 技力；每技能后叠伤 +10%（≤ +50%） | `hit` + `skillEnd` |
| 佩佩 | 在场萨尔贡干员的攻击范围并入她的 | `unit.rangeGrid` + `battle.refreshRange(u)` |
| 维娜·维多利亚 | 维多利亚盟约干员打战栗目标 ×1.5；她的战栗 10 s | `hit` + 光环 |
| 焰影苇草 | 敌人被上灼痕 → 范围内我方 30% 庇护 + 100% 攻击力/s 回血 2 s | 光环（`reed2:scorch`） |
| 塑心 | 开技能全场我方弹药补满；补上的总量变全场次数盾 | `skillStart` + `shieldHits` |
| 迷迭香 | 任意我方命中 → 她对目标追加一次普攻（0.2 s 全局 CD）；S3 取消阻挡限制 | `hit` + 读点 `unit.mem.rosmonAnyTarget` |
| 流明 | 技能期间每 0.5 s 射程内敌人 10% 攻击力法术伤害 | `skillStart` + 自排队 `after` |
| 仇白 | 追加盟约「奥术」；打减速/束缚目标给 20% 法术脆弱 | `operators.bonds` + `hit` |
| 溯光星源 | 停顿可叠加至 99% | 光环累计 `sluggish` |
| 耀骑士临光 | 卡西米尔激活时部署落点 330% 真伤（r1.5） | `deploy` |
| 荒芜拉普兰德 | 连续输出 3 s 内递增到 160%（换目标不清零，断火 3 s 归零） | `hit` |
| 锏 | 每次技能后 +30 技力、盟约 +3 层（精锐翻倍、封顶也翻倍） | `skillEnd` |
| 纯烬艾雅法拉 | 治疗友方叠护盾（上限 300% 攻击力、一次性免疫、可叠加） | `heal` |

## 引擎读点（只有包内部分「装上即生效」）

三条补强需要引擎侧一行读取点（本仓库已含；**干净的 0.16.0 官方引擎没有**）：

| 读点 | 文件 | 缺省行为 |
|---|---|---|
| `unit.mem.skillCadence` | `kits/ops/chess_char_6_01-lemuen.js` | 缺省 1 ⇒ `aim/1 === aim`，逐字等价 |
| `unit.mem.rosmonAnyTarget` | `kits/ops/chess_char_6_12-rosmon.js` | 未设置 ⇒ 官方过滤照旧 |
| `unit.mem.yuBroadcast` | `kits/ops/chess_char_6_03-yu.js` | 未设置 ⇒ 官方分支照旧 |

在别人的服务器上：这三条会**静默不生效**（其余 14 条纯包内）。要全量生效，把三处 `=== true` 分支合进引擎即可，golden 不受影响。

## 自测

```
node tools/buff-selftest.mjs    # 28 条断言，覆盖每一条的关键不变量
```

新增补强：`battle/main.mjs` 里加常量 + 钩子，再到 `buff-selftest.mjs` 加一段断言。

## 现状（1.0.0）

- **17 条补强已实现并自验**：圣聆初雪、余（S3 庇护广播）、浊心斯卡蒂、异客、佩佩、维娜·维多利亚、焰影苇草、
  塑心（弹药 + 次数盾）、迷迭香（追加普攻 + S3 取消阻挡限制）、流明、仇白、溯光星源、耀骑士临光、荒芜拉普兰德、
  锏、纯烬艾雅法拉、缪尔赛思（视作全部盟约计数）。
- **2 条已知未实现**（需要维护者决定，详见 `NEXT.md`）：
  - **余 · 特质检索**「优先检索场上已存在两名（未精锐）的同名干员」—— 全库没有对应的特质机制（`trait` 里只有
    「阻挡三个敌人」这类描述，`trait.grantsBonds` 为 0），需要先定义这条特质指哪一条；
  - **新约能天使 · S3 发射**「从待部署区发射地面干员、不计部署上限、全局最多 2、回合结束返回、不触发其特质」——
    落点在 `server/match`（`ps.deployCap/deployCount`、预备干员池、回合边界），而工坊框架的 `server.battle` 与
    `server.meta`（只注册 `garrison/band/bond/item/choice/effect/global` 效果钩子）都够不着，需要引擎开口子。
- 三条补强依赖引擎读取点（`unit.mem.skillCadence` / `rosmonAnyTarget` / `yuBroadcast`），干净官方引擎里会静默不生效；
  其余纯包内生效。

## 追加一条补强的最短路径

1. `battle/main.mjs`：加一个 `Object.freeze(new Set(['chess_xxx_a','chess_xxx_b']))` 常量 + 一个钩子（或光环分支）；
2. 数据类（加/改盟约、改招募池）：`operators/<key>/part.json`；
3. `client/buffs.js`：在 `BUFFS` 表里加这个棋 id 的文案（不写就看不到，但行为照常）；
4. `tools/buff-selftest.mjs`：加一段断言；
5. `node tools/buff-selftest.mjs` + `node tools/build-workshop-mods.mjs --only operator-buffs` + `workshop:validate`；
6. 提交（一条补强一个提交，写清「怎么验的」）。