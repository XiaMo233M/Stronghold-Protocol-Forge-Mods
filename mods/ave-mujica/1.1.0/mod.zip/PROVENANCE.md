# 署名与来源 · PROVENANCE

> 本文件由**交付流程**在拆包时生成，随包分发。原作者与改写者**分开显示，不抹掉任何一方**。
> 原件未署名的一律写**「原件未署名」**，不代填名字；许可**照实抄**，包括非 SPDX 的值。

## 包

| 项 | 值 |
|---|---|
| 包 id | `ave-mujica` |
| 版本 | `1.1.0` |
| 名称 | 颂乐人偶 |
| 目录名 = 包 id | 是（引擎逐包判 `PACK_ID_MISMATCH`，不一致会被拒） |
| 本包实测规模 | 178 个文件 / 18743174 字节（不含本文件） |

## 原作者 / 上游

**the Ave Mujica mod** —— 这是**原件自己在 `pack.json` 里写的**作者字段原文，照实抄录，未替它改写。

- 上游：the Ave Mujica mod

## 许可（照实抄）

原件 `pack.json.license` 原文，逐字抄录：`GPL-3.0-or-later`

## 责任人

| 角色 | 是谁 |
|---|---|
| 原作者 | the Ave Mujica mod |
| 本版兼容改写者 | 无（原件逐字节副本） |
| 本包交付 | 第三方 mod 兼容交付流程，2026-10-11 |

## 来源

- 原件：E:\destop\mod\462b4f5fb4f5-【颂乐人偶】盟约拓展包.zip
- 交付形态：工坊包（workshop pack）· 包契约 **MOD_API_VERSION 1**（据此判能否装载）· 打包时工作树 `3396438a` 的 APP_VERSION 为 0.14.0（该号只表示发行版，不参与包兼容判定；交付后 HEAD 已推进到 `d46cfdaa` / APP_VERSION 0.15.0，MOD_API_VERSION 仍为 1，本轮已在该 HEAD 上复测通过）

## 改了什么

- **本包与原件逐字节相同**：178/178 个文件的 SHA-256 与原件 zip 全等（含 `pack.json`）。本版**没有改动任何一个字节**，也没有新增、删除或改名任何文件。
- 仅有的两个差异在**包外**：目录名归位为 `ave-mujica`（= 包 id，引擎逐包判 `PACK_ID_MISMATCH`），以及本文件 `PROVENANCE.md` 为本次拆包新增的署名说明。

## 自带素材来源

- 是，167 个素材文件：band 1 · bond 1 · char 20 · skill 11 · skin 37 · spine 27 · voice 70；另含 `kits/` 下 5 个 kit 脚本。
- 素材来源：《明日方舟》/ Ave Mujica 相关美术与语音，版权归**鹰角网络 / Yostar** 等权利人。**原件未逐项列出处**，本文件不替它补。

## 备注 / 边界

- 包内**没有**独立的署名 / 许可 / CREDITS 文件 —— 原件也没有。署名与许可只存在于 `pack.json` 的 `author` / `license` 两个字段。
- 本包**不应进入 git**：仓库红线（`AGENTS.md`「No game art in git」）禁止提交游戏素材。

## 包内其它署名 / 来源文件

- （包内没有独立的署名 / 许可文件 —— 原件也没有。本文件即为该包唯一的署名与来源说明。）

## 校验

- 本包**单独**装载于干净的 workshop 根（根内只有这一个包）：见交付索引 `../../INDEX.md` 的 8 条原始输出。
- 校验器：`node tools/workshop-validate.mjs`；装载器：`server/workshop.js loadWorkshop`。

---

*English summary: this pack is a compatibility conversion delivered for Stronghold-Protocol. The original
author and the compatibility rewriter are listed separately above; where the original was uncredited it is
stated as "原件未署名 (uncredited original)" rather than being invented. The licence text is copied verbatim
from the original. See the Chinese sections above for the exact source, the list of changes, and the origin
of any bundled assets.*
