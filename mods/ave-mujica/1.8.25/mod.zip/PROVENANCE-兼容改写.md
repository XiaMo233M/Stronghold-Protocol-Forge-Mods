# PROVENANCE — ave-mujica（颂乐人偶）1.8.25 · 兼容改写说明

本文件由**兼容改写者**添加，记录这次改写改了什么、为什么。**包内原作者的文件一字未改**。

## 1. 原作者

`pack.json` 的 `author` 原文：**the Ave Mujica mod**（原样保留，未改写）。

## 2. 许可

`pack.json` 的 `license` 原文：**GPL-3.0-or-later**（原样保留）。

包内 `assets/` 下的《明日方舟》游戏素材版权归**上海鹰角网络科技有限公司 / Yostar** 及其授权方，
**不在 GPL 范围内**，仅供**非商业**的学习与个人娱乐使用，请勿用于任何商业场景。
本包与改写者**不主张**这些素材的任何权利。

## 3. 兼容改写者

Stronghold-Protocol-Forge-Mods 维护者（本站）。

## 4. 来源

站上待审记录 `166e456b28f7`（作者提交的 `ave-mujica` **1.8.25**，17.17 MB）。
该原件在本引擎（`UPSTREAM_VERSION = 0.3.1`、`MOD_API_VERSION = 1`）下
`packsLoaded = []`、`errors = 2`，装不上。

## 5. 改了什么（两处，都只是删掉引擎里不存在的声明）

| 原件写法 | 本包写法 | 为什么 |
|---|---|---|
| `art.sfxUnits = { char_xxx: { attack, hit, skills, attacks, hits } }`（5 个单位条目，指向 `assets/sfx/**.mp3`） | **删掉这一格**（mp3 文件原样留在包里） | `ART_TABLES` 只有 `chars` / `enemies` / `tokens` / `skills` / `profSub` / `bonds` / `bands` 七张表，**没有 `sfxUnits`** ⇒ `ART_UNKNOWN_TABLE` 整包拒。`docs/ASSETS.md` 里的 `sfxUnits` 是 `data/assets.json` 的**统计计数名**，不是 art 表。**引擎目前没有「按单位声明攻击/受击/技能音效」这个表面**（`PACK_FIELDS` 里的音频类只有 `voices` / `voiceLangs`，那是语音），所以这部分**没有接口做**，按规矩如实写明而不是硬塞。 |
| `fx = { manifest: "fx/manifest.json" }` | **删掉整格** | `fx` 只认 `silentPhases` 一格（`FX_FIELDS = ['silentPhases']`）⇒ `FX_UNKNOWN_FIELD` 整包拒。而 `fx/manifest.json` **在包里根本不存在**（`fx/` 目录都没有），是一个悬空引用 —— 删掉不丢任何随包内容。`docs/design/vfx-format.md` 里的 `fx-manifest` 是一种**文件格式**，不是 `pack.json` 的字段。 |

除这两处外，**`pack.json` 的其余字段与包内全部文件（`chess.json` / `bonds.json` / `kits/` / `assets/` …）
一个字节都没动**。版本号保留作者的 `1.8.25`。

## 6. 包自带素材的来源

`assets/` 下：干员头像/立绘、Spine 模型（`.skel` / `.atlas`）、技能图标、皮肤图、BGM、
以及 `assets/sfx/**` 的战斗音效 —— 均来自《明日方舟》客户端解包，版权归**鹰角网络 / Yostar**。
`band/` / `bond/` 下的盟约与分队图标同为官方素材。
**仅供非商业的学习与个人娱乐使用**；本包与改写者不主张任何权利。

## 验证

```
引擎：Stronghold-Protocol（UPSTREAM_VERSION 0.3.1 · MOD_API_VERSION 1）
loadWorkshop → packsLoaded = ['ave-mujica'] · errors = 0
```
