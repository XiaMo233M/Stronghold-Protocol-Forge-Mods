// perf-lite 的面板模块：一个开关 —— 「一律归零」开着时，包自带的那份 `!important` 归零才生效。
//
// 【兼容适配 Mo233 改写 · 第二版】原件只有一份无条件的全局归零（`client/lite.css`，老版第 6-13 行），
// 用户没得选。现在这个开关把它变成可选项，机制**全部用引擎现成的东西**，没有新造协议、没有改引擎：
//
//   * 开关本身的 DOM：面板自己的挂载点（`client.panels[].module` = 本文件，`ctx.host` 就是容器里那个
//     `.mod-panel`）—— 这是面板模块本来就有的东西（`public/js/ui/extensions.js` 的挂载路径）。
//   * 开关的**状态存哪**：引擎既有的**面板偏好口** `ctx.session.setPref(key, value)` / `getPref(key, dflt)`
//     （同一个文件里那一格；键自动按 `<包 id>/` 分区，值只收标量，越界当场点名），不用自己碰 localStorage。
//   * 开关的**生效**怎么落地：把状态写成根元素上的一个属性 `<html data-perf-lite="hard">`，`client/lite.css`
//     那份归零规则只挂在这个属性底下 —— 属性在 = 一律归零；属性不在 = 一条规则都不生效，走引擎的
//     `prefers-reduced-motion` 通道（`public/css/theme.css:387-393`）。
//
// 默认值：**关**（挂载时 `session.getPref(PREF_KEY, false)` 的第二个实参就是那个默认值）。也就是默认尊重
// 平台 / 用户偏好，用户主动勾选才拿到原件那种强度。业主若要把默认反过来，把那一个 `false` 换成 `true` 就够了
// （见 PROVENANCE.md「默认值」那一节）。
//
// 看得见、可取消：面板上是一个 checkbox（视觉开关）加一行状态文字，状态文字与勾选都由同一处 `sync()` 写；
// 取消勾选不但移除属性，还会**立刻**回到引擎通道，不是「设了没反应」。

/** 开关落地的属性名与「一律归零」那个值。只在用户主动勾选时出现在 `<html>` 上。 */
export const HARD_ATTR = 'data-perf-lite';
export const HARD_ON = 'hard';

/** 开关状态在引擎面板偏好口里的键（引擎自己再前缀成 `perf-lite/<这个键>`）。 */
export const PREF_KEY = 'hardOff';

/**
 * 把状态写到根元素上（唯一一处写口）。`document` 可注入，Node 下的用例因此不需要真浏览器。
 * @param {boolean} hard @param {any} [doc]
 * @returns {any} 被写的根元素，或 `null`（没有 document 时静默跳过 —— 面板本来也挂不上）
 */
export function applyHard(hard, doc = globalThis.document) {
  const el = doc && doc.documentElement;
  if (!el || typeof el.setAttribute !== 'function') return null;
  if (hard) el.setAttribute(HARD_ATTR, HARD_ON);
  else if (typeof el.removeAttribute === 'function') el.removeAttribute(HARD_ATTR);
  return el;
}

/** 状态文字（同时是给眼睛看的那一份「现在在哪一边」）。 */
function statusText(hard) {
  return hard ? '一律归零：已开启（不管平台偏好）' : '引擎通道：尊重 prefers-reduced-motion';
}

/** 开关的 DOM：一个 checkbox + 一行状态 + 一行说明。用 createElement，不用 innerHTML 拼字符串。 */
function buildSwitch(doc, id) {
  const box = doc.createElement('label');
  box.className = 'perf-lite';
  const input = doc.createElement('input');
  input.type = 'checkbox';
  input.className = 'perf-lite__input';
  input.id = id;
  const text = doc.createElement('span');
  text.className = 'perf-lite__text';
  const title = doc.createElement('span');
  title.className = 'perf-lite__title';
  title.textContent = '低配优化：一律归零动画与过渡';
  const state = doc.createElement('span');
  state.className = 'perf-lite__state';
  text.appendChild(title);
  text.appendChild(state);
  box.appendChild(input);
  box.appendChild(text);
  return { box, input, state };
}

/**
 * 面板工厂（`client.panels[].module` 要的就是一个 `mount(ctx)`）。
 *
 * `ctx` 是引擎冻结给面板的那一份（`public/js/ui/extensions.js` panelContext）：`host` 是挂载点，
 * `session` 是那个偏好口，`log` 是带包名前缀的日志。`host` 或 `session` 缺失时**抛**：引擎会把
 * `CLIENT_PANEL_MOUNT_FAILED` 记下来并点名（「装了没反应」正是这一层最不愿留下的形态）。
 *
 * @param {{ host?: any, session?: { setPref?: Function, getPref?: Function }, log?: any }} ctx
 * @returns {{ state: () => boolean, unmount: () => void }} 状态读数（给测试 / 诊断）+ 取消挂载
 */
export function mount(ctx) {
  const host = ctx && ctx.host;
  const session = ctx && ctx.session;
  const log = ctx && ctx.log;
  if (!host || typeof host.appendChild !== 'function') throw new Error('perf-lite: ctx.host is missing — this panel needs its mount container');
  if (!session || typeof session.getPref !== 'function' || typeof session.setPref !== 'function') {
    throw new Error('perf-lite: ctx.session.setPref/getPref is missing — the switch stores its state through the engine preference slot');
  }
  const doc = host.ownerDocument || globalThis.document;
  if (!doc || typeof doc.createElement !== 'function') throw new Error('perf-lite: no document to build the switch in');

  const id = `perf-lite-hard-${Math.random().toString(36).slice(2, 8)}`;
  const { box, input, state } = buildSwitch(doc, id);
  input.checked = !!session.getPref(PREF_KEY, false);
  state.textContent = statusText(input.checked);

  /** 唯一一处「状态 → 界面 / 属性 / 偏好」的落地。 */
  function sync() {
    const hard = !!input.checked;
    state.textContent = statusText(hard);
    applyHard(hard, doc);
    session.setPref(PREF_KEY, hard);
    log?.info?.(`一律归零=${hard ? '开' : '关'}（${hard ? '不看平台偏好' : '尊重 prefers-reduced-motion'}）`);
  }

  input.addEventListener('change', sync);
  host.appendChild(box);
  sync(); // 挂上就用当前状态落一次地：属性、界面、偏好三者从第一帧起一致

  return {
    state: () => !!input.checked,
    unmount() {
      input.removeEventListener('change', sync);
      applyHard(false, doc); // 面板走了就不许留下「一律归零」这种全局副作用
    },
  };
}
