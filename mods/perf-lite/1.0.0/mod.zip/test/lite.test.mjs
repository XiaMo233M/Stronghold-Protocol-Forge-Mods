// perf-lite 自带测试 · 跑法（Node 24 内置 runner，不需要装任何东西）：
//
//   node --test test/lite.test.mjs
//
// 只读本包自己的文件，外加**引擎既有的**注册点 `public/js/ui/extensions.js`（面板真正被挂起来的那条路）。
// 两件事在这里被验：
//   ① 开关本身：默认哪一边、两种状态各把 `<html>` 写成什么、偏好有没有落进引擎那格偏好口、取消有没有立刻回退；
//   ② 装载面：包声明的面板 URL 能被真正的 `createPanelRegistry` 收下、真的 import 起来、`mount(ctx)` 不抛，
//      并且注册点自己的拒绝清单是空的（「装了没反应」在这里当场露馅）。
import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

import { mount, applyHard, HARD_ATTR, HARD_ON, PREF_KEY } from '../client/lite.js';

const HERE = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1'));
const PACK = path.dirname(HERE);

// ── 一份够用的假 DOM：只有引擎与包真的碰的那几个成员（createElement / appendChild / 属性 / 事件） ──────────
function fakeEl(tag) {
  const el = {
    tagName: String(tag).toUpperCase(),
    children: [],
    attributes: {},
    listeners: {},
    className: '',
    textContent: '',
    id: '',
    type: '',
    checked: false,
    style: {},
    ownerDocument: null,
    appendChild(c) { this.children.push(c); c.parentNode = this; return c; },
    removeChild(c) { this.children = this.children.filter((x) => x !== c); return c; },
    remove() { if (this.parentNode) this.parentNode.removeChild(this); },
    setAttribute(n, v) { this.attributes[n] = String(v); },
    getAttribute(n) { return Object.prototype.hasOwnProperty.call(this.attributes, n) ? this.attributes[n] : null; },
    removeAttribute(n) { delete this.attributes[n]; },
    addEventListener(t, fn) { (this.listeners[t] ||= []).push(fn); },
    removeEventListener(t, fn) { this.listeners[t] = (this.listeners[t] || []).filter((x) => x !== fn); },
    querySelectorAll() { return []; },
    /** 模拟用户的勾选（浏览器里就是这一条 change） */
    setChecked(v) { this.checked = !!v; for (const fn of this.listeners.change || []) fn({ target: this }); },
  };
  return el;
}

function envelope() {
  const html = fakeEl('html');
  const head = fakeEl('head');
  const body = fakeEl('body');
  const doc = {
    documentElement: html,
    head,
    body,
    createElement: (tag) => fakeEl(tag),
    querySelector: () => null,
    querySelectorAll: () => [],
  };
  html.ownerDocument = doc;
  head.ownerDocument = doc;
  body.ownerDocument = doc;
  return { doc, html, head, body };
}

/** 引擎那格面板偏好口（`ctx.session`）的替身：键带包前缀、值只收标量 —— 与引擎同一份判据的简化版。 */
function prefSlot() {
  const map = new Map();
  return {
    writes: [],
    setPref(k, v) { map.set(`perf-lite/${k}`, v); this.writes.push([k, v]); return true; },
    getPref(k, d) { return map.has(`perf-lite/${k}`) ? map.get(`perf-lite/${k}`) : d; },
  };
}

function hostEl(doc) {
  const host = fakeEl('div');
  host.className = 'mod-panel';
  host.ownerDocument = doc;
  return host;
}

// ── ① 开关：默认、两种状态、偏好、取消 ────────────────────────────────────────────────────────────
test('默认是引擎通道：不写属性、不勾选、偏好 = false', async () => {
  const { doc, html } = envelope();
  const session = prefSlot();
  const host = hostEl(doc);
  const lines = [];
  const panel = await mount({ host, session, log: { info: (m) => lines.push(m) } });
  assert.equal(html.getAttribute(HARD_ATTR), null, '默认不许写 data-perf-lite（写=一律归零，那是用户主动的事）');
  assert.equal(session.getPref(PREF_KEY, false), false, '挂载时就把当前状态落进偏好口');
  const label = host.children[0];
  assert.equal(label.className, 'perf-lite');
  const input = label.children[0];
  assert.equal(input.type, 'checkbox');
  assert.equal(input.checked, false, '默认关');
  assert.match(label.children[1].children[1].textContent, /引擎通道/, '状态文字必须写出「现在在哪一边」');
  assert.equal(panel.state(), false);
  assert.equal(lines.length, 1, '挂载时记一条日志（看得见的第二份状态）');
  assert.match(lines[0], /一律归零=关/);
});

test('拨到「一律归零」：写属性、偏好转 true、日志与状态文字跟着变', async () => {
  const { doc, html } = envelope();
  const session = prefSlot();
  const host = hostEl(doc);
  const lines = [];
  const panel = await mount({ host, session, log: { info: (m) => lines.push(m) } });
  host.children[0].children[0].setChecked(true);
  assert.equal(html.getAttribute(HARD_ATTR), HARD_ON, '归零规则挂在 :root[data-perf-lite="hard"] 底下');
  assert.equal(session.getPref(PREF_KEY, false), true);
  assert.equal(panel.state(), true);
  assert.match(host.children[0].children[1].children[1].textContent, /一律归零：已开启/);
  assert.match(lines[1], /一律归零=开/);
});

test('能关掉：再取消勾选就移除属性、回到引擎通道（不是「设了没反应」）', async () => {
  const { doc, html } = envelope();
  const session = prefSlot();
  const host = hostEl(doc);
  const panel = await mount({ host, session, log: { info() {} } });
  const input = host.children[0].children[0];
  input.setChecked(true);
  input.setChecked(false);
  assert.equal(html.getAttribute(HARD_ATTR), null);
  assert.equal(session.getPref(PREF_KEY, false), false);
  assert.equal(panel.state(), false);
});

test('偏好活过页面：上一次选了「一律归零」，再挂载就是开的', async () => {
  const { doc, html } = envelope();
  const session = prefSlot();
  const host = hostEl(doc);
  session.setPref(PREF_KEY, true);
  const panel = await mount({ host, session, log: { info() {} } });
  assert.equal(panel.state(), true);
  assert.equal(html.getAttribute(HARD_ATTR), HARD_ON, '挂载即落地：属性、界面、偏好三者一致');
});

test('取消挂载不留下全局副作用：属性一并撤掉', async () => {
  const { doc, html } = envelope();
  const session = prefSlot();
  const host = hostEl(doc);
  const panel = await mount({ host, session, log: { info() {} } });
  host.children[0].children[0].setChecked(true);
  panel.unmount();
  assert.equal(html.getAttribute(HARD_ATTR), null);
});

test('缺 ctx.host / ctx.session 时**抛**，不静默（引擎会记 CLIENT_PANEL_MOUNT_FAILED）', () => {
  assert.throws(() => mount({ session: prefSlot() }), /ctx\.host/);
  assert.throws(() => mount({ host: hostEl(envelope().doc) }), /ctx\.session/);
});

test('applyHard 在没有 document 时是 no-op（Node / 极小宿主）', () => {
  assert.equal(applyHard(true, null), null);
  assert.equal(applyHard(false, {}), null);
});

// ── ② 装载面：真的过一遍引擎的面板注册点 ────────────────────────────────────────────────────────
// 这一条要引引擎自己的注册点。**本机开发时只读引用**（不复制、不改）；拿不到那份 checkout 时跳过并写明，
// 不伪装成通过 —— 「跳过了」与「过了」是两件事。
const ENGINE_REGISTRY = 'E:/destop/harness_1/Stronghold-Protocol/public/js/ui/extensions.js';
const { existsSync } = await import('node:fs');

test('真的走一次引擎的 createPanelRegistry：面板被收下、import、mount，且零拒绝', { skip: !existsSync(ENGINE_REGISTRY) && `引擎 checkout 不在本机：${ENGINE_REGISTRY}` }, async () => {
  const { createPanelRegistry } = await import(pathToFileURL(ENGINE_REGISTRY).href);
  const { doc, html } = envelope();
  const store = { get: () => ({}), subscribe: () => () => {}, patch: () => {} };

  const createEl = (tag) => { const el = fakeEl(tag); el.ownerDocument = doc; return el; };
  const registry = createPanelRegistry({
    store,
    createElement: createEl,
    styleHost: () => doc.head,
    themeHost: () => html,
    slotHosts: () => [],
    slotHost: () => { const el = fakeEl('div'); el.setAttribute('data-mod-slot', 'root.overlays'); doc.body.appendChild(el); return el; },
    data: null,
    // 浏览器里引擎直接 import 那个 `/workshop-panels/...` URL；这里是 Node，同一个相对路径折回包自己的文件。
    importModule: (url) => import(pathToFileURL(path.join(PACK, url.split('?')[0].replace(/^\/workshop-panels\/[^/]+\//, ''))).href),
    log: { info() {}, warn() {}, error() {} },
  });

  const declared = JSON.parse(await (await import('node:fs/promises')).readFile(path.join(PACK, 'pack.json'), 'utf8'));
  const panelDecl = declared.client.panels[0];
  const accepted = registry.apply([{
    id: panelDecl.id,
    pack: declared.id,
    slot: panelDecl.slot,
    module: panelDecl.module,
    url: `/workshop-panels/${declared.id}/${panelDecl.module}?v=test`,
    order: panelDecl.order,
  }]).accepted;
  assert.equal(accepted, 1);

  await new Promise((r) => setImmediate(r));
  assert.deepEqual(registry.refusals(), [], '引擎这条路上零拒绝（有一条就是「装了没反应」）');
  assert.deepEqual(registry.mounted(), ['perf-lite/lite']);

  const container = doc.body.children.find((el) => el.getAttribute && el.getAttribute('data-mod-slot') === 'root.overlays');
  assert.ok(container, 'root.overlays 这个宿主被注册点按需创建了');
  const mountHost = container.children[0];
  assert.equal(mountHost && mountHost.className, 'mod-panel');
  assert.equal(mountHost.children[0].className, 'perf-lite', '开关真的挂进了那个 panel div');
  assert.equal(mountHost.children[0].children[0].checked, false, '默认仍是关（引擎通道）');

  // 用户在这一份真注册点上勾选一次：属性落到同一份 <html> 上
  mountHost.children[0].children[0].setChecked(true);
  assert.equal(html.getAttribute(HARD_ATTR), HARD_ON);

  registry.dispose();
  assert.deepEqual(registry.mounted(), []);
  assert.equal(html.getAttribute(HARD_ATTR), null, 'dispose 时面板的 unmount 被调用，全局副作用一并收回');
});
