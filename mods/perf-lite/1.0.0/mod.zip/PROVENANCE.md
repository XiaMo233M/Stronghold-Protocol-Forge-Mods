# 署名与来源 · PROVENANCE

> 原作者与兼容改写者**分开列出，不抹掉任何一方**。原件未署名的一律写「原件未署名」，不代填；
> 许可照实抄自包内 `pack.json` 的 `license` 字段，未改动。
>
> **本文件是本轮（第二版）重写的**：上一版（第一版适配）的全文在 `../87a0325e4e65-perf-lite-v1.zip`
> 里逐字保留，成品也另存了一份 `-v1`，没有静默覆盖掉任何证据。

## 包

| 项 | 值 |
|---|---|
| 包 id | `perf-lite` |
| 版本 | `1.0.0`（**包格式版本未动**：本轮只改包内文件，`pack.json.version` 照旧） |
| 名称 | 低配优化（关动画与过渡） |
| 目录名 = 包 id | 是 |
| 顶层目录 | `perf-lite/` |

## 原作者

`jingjiangze` —— 见包内 `pack.json` 的 `author` 字段。包内**没有别的署名**，也没有上游仓库链接。

## 许可

`GPL-3.0-or-later`（包内 `pack.json.license` 原文）。

## 兼容改写者

`Mo233`

## 来源

站点投稿 **`87a0325e4e65`**，原件 zip 大小 **1528 字节**，
sha256 `312f40ce253f5ea53051304a95908696021fadb4a6cb9b1e407aa14eeda7cc0b`
（源文件只读，未改动一个字节）。

## 改了什么（第二版：给「一律归零」加一个**选项开关**）

原件是**一件事、两半**：变量那一半（`client.theme.vars` 的 `--t-fast: 0s` / `--ease-out: linear`）+
一份**无条件的全局 `!important` 归零**（老版 `client/lite.css` 第 6-13 行）。第一版把后一半删掉、
并到引擎的 `prefers-reduced-motion` 通道上；业主裁决的问题随之而来：**引擎通道要用户/系统声明
`reduce` 才生效**，装了包却什么都没发生。第二版因此**不删那一半，而是给它加开关**。

| # | 改动点 | 原做法 | 我们的做法 | 为什么 |
|---|---|---|---|---|
| 1 | `client/lite.css` | `*, *::before, *::after { animation-duration: 0s !important; animation-delay: 0s !important; transition-duration: 0s !important; transition-delay: 0s !important; }`（**无条件**全局归零） | 同一份 4 条 `0s !important` 声明**原值保留**，整段挂到 `:root[data-perf-lite="hard"]`（含 `:root[data-perf-lite="hard"] *` / `*::before` / `*::after`）底下；另加开关自身的样式 | 归零强度与原件**逐字相同**（`0s` vs 引擎那份 `1ms`），但它只在用户勾选时生效；没勾选时这个文件一条规则都不生效，动画与过渡归引擎的 `@media (prefers-reduced-motion: reduce)`（`public/css/theme.css:387-393`）——尊重平台 / 用户偏好 |
| 2 | `client/lite.js` | 只有 `export function mount() { return {}; }`（面板纯当 `styles[]` 的挂载点） | 真正的开关模块：渲染一个 checkbox + 一行状态文字，把状态写进 `<html data-perf-lite="hard">`，并存进引擎既有的面板偏好口；挂载时落一次地、取消挂载时撤掉属性 | 「开关状态要看得见 + 不许静默失败」：勾选、状态文字、根属性、偏好、日志五处同一个值，由同一个 `sync()` 写 |
| 3 | `pack.json` 的 `client.panels[0].slot` | `screen.game.hud`（只在对局屏里存在） | `root.overlays`（引擎按需创建的全局浮层，`public/js/ui/extensions.js MOD_PANEL_CREATED`） | 开关是**全局**的（它改的是根属性），挂在一个只在对局里存在的宿主上就会变成「标题屏/大厅里开关不存在，但归零还在生效」；浮层宿主跨屏存在，且 `.mod-panel` 在那里的 `pointer-events` 就是 `auto`（`public/css/components.css:1090-1095`），可点 |
| 4 | `test/lite.test.mjs` | 无（原件不带测试） | 新增 8 条用例（含一条**真的走一遍引擎 `createPanelRegistry`** 的装载面用例） | 「两种开关状态都装得上」这件事要能被机器复核，不是只靠一次手工观察 |

**保留未改的**：`pack.json` 的 `client.theme.vars`（`--t-fast: 0s` / `--ease-out: linear`，两个变量名都是引擎真实定义的
token：`public/css/theme.css:89` `--ease-out`、`:91` `--t-fast`，而 `--t-fast` 被 `public/css/components.css` 的数十处
`transition` / `animation` 直接引用）；`client.panels[0]` 的 `id` / `module` / `styles` / `order`；`pack.json` 其余字段。

### 开关的两个状态（默认哪一边 · 另一边的强度）

| 开关状态 | 谁生效 | 效果 |
|---|---|---|
| **关（默认）** | 引擎平台通道 `@media (prefers-reduced-motion: reduce)`（`public/css/theme.css:387-393`） | 用户/系统**声明了 reduce** 时，引擎把 `*, *::before, *::after` 的 `animation-duration` / `transition-duration` 收到 `1ms !important`、迭代数收到 1，并停掉三处循环件（`public/css/devices.css:111-113`、`public/css/components.css:840-842`、`public/css/emotes.css:147-150`）；**没声明时动画照常** |
| **开（用户勾选）** | 本包的 `:root[data-perf-lite="hard"]` 那 4 条 `0s !important` | **不管平台偏好，一律归零**：`animation-duration` / `animation-delay` / `transition-duration` / `transition-delay` 全 `0s !important`，强度与原件逐字相同（比引擎的 `1ms !important` 更强，同一条规则的两个声明，包的在后面且更强） |

开关本身**还带着**作者意图的另一半（`client.theme.vars` 的 `--t-fast: 0s` / `--ease-out: linear`），那半是**无条件**的，
两种状态下都在 —— 与原件一致（原件也是这么写的）。

### 机制与理由（用引擎**现成**的东西，没有新造协议、没有改引擎）

| 需要的东西 | 引擎今天给你的通道 | 位置 |
|---|---|---|
| 面板能画东西的挂载点 | `client.panels[].module` 的 `mount(ctx)`，`ctx.host` 就是容器里那个 `.mod-panel` | `public/js/ui/extensions.js` 的挂载路径（`panelContext`） |
| 开关状态存哪（跨页面活着） | **面板偏好口** `ctx.session.setPref(key, value)` / `getPref(key, dflt)`：键自动按 `<包 id>/` 分区（这里是 `perf-lite/hardOff`），值只收标量、越界当场点名；面板**没有** localStorage / store 的写权限，这一格就是为它准备的 | 同一个文件（`PREFS_MAX_KEY` / `PREFS_MAX_VALUE` 与那一格注释） |
| 开关怎么让 CSS 生效 | 包**自己**把状态写成根元素属性 `<html data-perf-lite="hard">`，自带样式表那份归零规则只挂在这个属性底下（包自带样式表由 `client.panels[].styles[]` 注入，注入与移除由注册点管） | `client/lite.css` + `client/lite.js` |
| 面板自带样式表 | `client.panels[].styles[]`（挂载时注入 `<head>`、`dispose()` 时移除） | `public/js/ui/extensions.js` 的 `injectStyles` |
| 装不上要响亮 | 模块 import 不了 / `mount` 抛 ⇒ `CLIENT_PANEL_IMPORT_FAILED` / `CLIENT_PANEL_MOUNT_FAILED`；浏览器缺能力 ⇒ `CLIENT_REQUIRES_UNSUPPORTED` | 同上（`refuse()` 的闭枚举） |

`data-perf-lite` 是**本包自己**的属性名（前缀带包名 = 不会与引擎的 `sp-*` / `data-mod-*` 撞），
只在用户勾选时出现；引擎不认识它、也不需要认识它 —— 这是 `client.panels[].styles[]` 这条通道本来的用法
（「一整份新组件的样式」归包自己）。

### 默认值：**关（走引擎通道）** —— 以及另一种默认怎么写

业主倾向「默认尊重偏好，用户主动打开才一律归零」，本版照此实现：`client/lite.js` 里读偏好时是
`session.getPref(PREF_KEY, false)`，那个 `false`（默认值参数）就是「默认关」。**要反过来**（装上就一律归零，
用户可以关掉）只改一处：把那第二个实参换成 `true` —— 包格式、样式表、属性名、其余逻辑都不用动。
这与原件的差别是**默认值**，不是能力。

### 第三方许可

`GPL-3.0-or-later`（包内 `pack.json.license` 原文，未改）。

### 与包内文本**不一致**的地方（照实说，保持原样未改）

* **`pack.json.name` / `description` 已与实现不符（保持原样未改）。** `name` 是「低配优化（关动画与过渡）」、
  `description` 写「并用一份样式表关掉全局动画与过渡」—— 那是**原件的行为**（无条件关）。本版改成开关之后，
  默认**不**关（走引擎通道），只有用户勾选才关。业主裁决的口径是：原作者字段与包自带元数据不许改，所以
  `name` / `description` / `version` / `author` / `license` / `api` **一字未动**，只在这里注明不符。
* 包内**没有** `README` / `NOTICE` / `LICENSE` 文件（原件只有 `pack.json` + `client/lite.js` + `client/lite.css`），
  所以没有别的「不符」可注。

## 自带素材来源

**无。** 包内只有 `pack.json`、`client/lite.js`、`client/lite.css`、`test/lite.test.mjs` 四个文件，全是代码与文本；
不含图片 / 音频 / 字体 / 解包数据。

## 校验用哈希（改动前 / 改动后）

第一版的行列是「原件 → 第一版」；本表是「原件 → 第一版 → 第二版（本轮）」，三列都给，便于逐版对照。

| 文件 | 原件 sha256（`E:\destop\mod2` 只读） | 第一版 sha256 | 第二版 sha256（本轮成品） |
|---|---|---|---|
| `pack.json` | `ed086e9a05a9400c9643cdcfe74881158d097ba673d6998db300c65e95f5a70a`（695 B） | 同左（未改） | `e84bf232e793b9fe26934d5e07b6a83ea225ddf648c88a71c2bb199442e13665`（693 B，只改 `slot` 一行，字节数 -2） |
| `client/lite.js` | `10197fd13f3467961619150ce4a39ef632a3e281589050f178a321063756c350`（301 B） | 同左（未改） | `3f410a75f2d4b741c646ea0ec5cd760ec88beae8b2c63a09a24c2533298eddc4`（6257 B，开关实现） |
| `client/lite.css` | `b8061ed6d76423d3adc0a48af688fc7e63a565e2be1a2a7062e06e1eb50da473`（669 B） | `22d29b185f353b302541603f93b72a4b1546c3fba8bac188adbb19ae8e6d570b`（1762 B，无规则） | `e6cad7a99c64754d88d68914d00905442d5dc4ee46c51aa93d8fd5f86e398770`（3396 B，归零规则 + 开关样式） |
| `test/lite.test.mjs` | （原件无此文件） | （第一版无此文件） | `6f21d2f3870b4d66b63c72f51bff10589c2c725d51968ea6388b740164c441a7`（10466 B） |
| `PROVENANCE.md` | （原件无此文件） | `288138c763653bcf0470983d98dceacc4cce2017b1762621ae3dde7b4a50e54c`（7020 B） | 见包外交付清单 `../CHECKSUMS.txt`（本文件自述的哈希会随本文件变化，写在包里必然自相矛盾） |

`client/lite.css` 的原件 sha256 与第一版记载逐字相同（`b8061ed6…`，669 B）—— 本轮没有重新读原件，
用的是第一版那次读到的同一份字节。

本成品：`87a0325e4e65-perf-lite.zip`（顶层目录 `perf-lite/`，一包一 zip，条目名一律正斜杠）。
**字节数与 sha256 记在交付索引** `../CHECKSUMS.txt`（与其余统一交付物同一份清单）—— 这里刻意不写：
包内文本一变，包含它的那个 zip 的摘要就跟着变。
