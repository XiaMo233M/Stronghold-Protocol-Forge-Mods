# 公告改由网站发布 · 读取与对接说明（附示范站）

**这是一个说明包（不是功能包）**：零代码、零素材，只在标题屏「公告」里多一条说明。
它解释服务器公告现在怎么发布、在哪读，并给出一枚可直接点开的 https 示范站。

## 它做什么

- 声明 `notices` 两个成员（`pack.json.notices`），每份是**包内相对 `.json` 路径**：
  - `notice/announcement.json` —— 一条公告：`{ version, date, summary, sections: [{ name, items[] }] }`
  - `notice/credits.json` —— 署名/链接表：`[{ name, note, url }]`，`url` 只能是 `https://`
- 服务器把各包公告**并进** `/data/notices.json` 的合并体（**追加**语义）。
- 展示面：标题屏「公告」入口读到合并体。

## 它**不做**什么（重要）

- **不推送、不抓取**：本包本身不发任何网络请求。 "公告从网站来" 是服务端 `SP_ANNOUNCEMENTS_URL`
  做的，与本包无关 —— 装或不装，客户端行为**完全不变**。
- **不能让本包自己变成「热更新」**：`notices` 是纯文本，烘死在包里。想改本包的文字就得重新打包；
  包内的 `routes` 也只服务包内静态 `.json`，没有 fetch 通路。**真正热的是那条外部源，不是这个包。**
- 不改对局、不带素材、服务端零代码。删掉本包目录即完全恢复原状。

## 玩家侧要改什么

**什么都不用改。** 客户端仍请求同一个地址、同一种格式；只有服务端取内容的来源变了。

## 服务端怎么接（真正的机制）

给服务端设置环境变量：

```
SP_ANNOUNCEMENTS_URL=https://你的站点/announcements.json
```

要求：

- 必须是完整的 `http(s)://` 地址，否则当作**未设置**。
- 返回体必须能被 `JSON.parse` 解析（数组或 `{entries:[...]}` 均可）。
- 超过 **2 MB**、内容类型不是 JSON、状态码非 2xx：本次拉取作废，沿用上一次的好结果。
- 单次拉取超过 **8 秒**即放弃。
- 轮询间隔 **60 秒**；超过 6 分钟没成功更新过就退回本机文件。
- **不设置这个变量时**：服务端行为和过去完全一致，只读本机 `data/announcements.json`，一次外部请求都不发。

## 示范站

- 后台（编辑公告）：<https://arknights.jiangjiangze.icu/admin>
- 运行时诊断面（只读数值）：<https://arknights.jiangjiangze.icu/api/status>
- 公告只读源（服务端实际拉取的形状）：<https://arknights.jiangjiangze.icu/api/announcements/game>

三个地址均为 https，已实测 200。

## 上限对照

引擎侧上限（`server/notices.js`）：合并体最多 8 条公告 / 40 条鸣谢；单条公告最多 12 节、每节 40 条、
每条 200 字、摘要 600 字；`credits` 每条 `name` ≤80、`note` ≤200、`url` ≤300。

本包当前：1 条公告、5 节，5 条 `credits`，全部在上限之内。

## 与其它公告包的关系

`notices` 是追加语义 —— 本包与工坊里其它公告包（如 `notice-board`）**共存**，谁的公告都不会被顶掉。
如果两处都放了同一份公告，玩家会看到重复内容，留哪一份由你自己决定。
