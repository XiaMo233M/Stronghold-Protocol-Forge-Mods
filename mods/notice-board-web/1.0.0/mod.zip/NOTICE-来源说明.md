# NOTICE-来源说明

## 原件是什么、从哪来

- **机制原件**：`SP_ANNOUNCEMENTS_URL` 的外部拉取实现，来自 `jingjiangze/stronghold-server`（fork of
  sganggs/Stronghold-Protocol）：`server/http/announcements.js`（拉取与降级）、
  `server/http/static.js`（命中时接管 `/data/announcements.json`）、`server/index.js`（装配）、
  `test/announcements-proxy.test.js`（11 项校验：超时、并发合并、非 JSON 拒绝、空值等同未设置）。
  仓库：<https://github.com/jingjiangze/stronghold-server>
- **展示机制原件**：Forge 的 `notices` 面（`pack.json.notices` → `/data/notices.json` 合并体 →
  标题屏公告弹窗），位于 `XiaMo233M/Stronghold-Protocol-Forge`
  （`shared/workshop.js` 的 `parseNoticesDecl`、`server/notices.js` 的合并逻辑）。
- **示范站**：<https://arknights.jiangjiangze.icu> —— 本作者自己运维的站点，`/admin` 为公告编辑后台，
  `/api/status` 为运行时数据面，`/api/announcements/game` 为公告只读源。
- **本包作者**：上述机制与站点的作者，非第三方改写。

## 它改了什么

**没有改引擎，也没有改游戏客户端。** 只做说明文本的搬运与转写：

| 件 | 说明 |
|---|---|
| `notice/announcement.json` | 把上述机制写成 5 节说明：改了什么 / 玩家在哪读 / 服务端怎么接 / 出问题会怎样 / 关于本包 |
| `notice/credits.json` | 5 条 https 链接：3 条示范站 + 2 条源码仓库 |
| `README.md` | 机制、配置方法、上限对照、与其它公告包的关系 |
| `NOTICE-来源说明.md` | 本文件 |

## 文本与时限的可核验性

以下数值在 `notice/announcement.json` 里写给了玩家，均可在代码中逐行核对（避免说明与实现漂移）：

| 说法 | 代码位置 |
|---|---|
| 「每 60 秒拉一次」 | `server/http/announcements.js:36` `POLL_MS = 60_000` |
| 「超过 8 秒放弃」 | 同上 `:34` `FETCH_TIMEOUT_MS = 8000` |
| 「超过 2MB 作废」 | 同上 `:32` `MAX_BYTES = 2 * 1024 * 1024` |
| 「6 分钟未更新退回本机」 | 同上 `:38` `STALE_GRACE_MULTIPLIER = 6`、`:134` `fresh()` |
| 「不设置则一次请求都不发」 | 同上 `announcementsUrlFrom()` 返回 null，`server/index.js` 据此不建源 |

## 许可

- 本包文本（说明、链接清单）：**CC0-1.0**，可自由改写与再分发。
- 被引用的机制实现按其所在仓库的许可（`stronghold-server` / `Stronghold-Protocol-Forge`）。
- 示范站的页面内容归站点自身所有；本包只引用链接，不转载其页面文本。
- 不含任何游戏素材。
