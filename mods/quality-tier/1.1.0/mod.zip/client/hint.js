// quality-tier/client/hint.js — 画质提示条（`screen.game.overlay` 面板）。
//
// ## 这一包**做不到**原版那件事，先把话说清楚
//
// Paper-Yuan 的画质提升改的是**引擎渲染常量**：
//
//     public/js/render/app/host.js:82   const QUALITY_RES = { high: 2, medium: 1.5, low: 1 };
//     public/js/render/app/host.js:85   const BOARD_RES   = { high: 2, medium: 1.25, low: 1 };
//
// 以及 `antialias` 那个按 devicePixelRatio 的门。这三样都在渲染器里。
//
// Forge 0.16.0 的表面里**没有任何一格**够得到它们：
//   * `client.theme.vars` 只能设 **CSS 自定义属性**（键必须 `--` 开头），而引擎**没有**把画质
//     暴露成 CSS 变量 —— 写 `--quality: 3` 等于什么都没发生（`docs/MOD-SURFACE.md` 的原文：
//     「不叫 --x 的键写进去等于什么都没发生」，反过来说，引擎不消费的变量同样等于没写）；
//   * `client.panels.wraps` 的组件闭集只有 `game.bondStrip` / `game.hud.topBar` /
//     `game.shopCard` / `loadout.detail` —— 渲染器不在其中；
//   * 面板拿不到 store / engine / match（§28.8），也就拿不到 renderer 实例。
//
// 真要抬档得改引擎；而且**抬档本身有性能代价**：dpr 3 的 1080p 屏按 3× 渲染 = 9 倍像素填充，
// 老机型（minSdk 24 / WebView 下限 Chromium 89）余量本就紧。这不是兼容性问题，是设备成本问题。
//
// ## 那这一包做什么
//
// 两件事，都很小，且**都明说不是真抬档**：
//   1. 一条提示条，告诉你当前这台设备的 devicePixelRatio 与视口 —— 让用户自己知道「发虚」
//      到底是不是 dpr 的锅；
//   2. 一段只作用于 `.qtweak` 作用域的样式，对**已画出来的位图**做轻微的锐化/对比补偿
//      （`image-rendering` + `filter`）。这是对结果的修饰，不是提高渲染分辨率 ——
//      抗锯齿与 1080p 点对点都做不到。
//
// 它不碰引擎任何既有元素的选择器，也不改任何引擎变量。

/** devicePixelRatio 分档（只用于显示，不参与任何判据）。 */
export function dprTone(dpr) {
  if (!Number.isFinite(dpr)) return { tone: 'none', text: '未知' };
  if (dpr >= 2.5) return { tone: 'ok', text: `${dpr}×（高分屏）` };
  if (dpr >= 1.5) return { tone: 'warn', text: `${dpr}×` };
  return { tone: 'bad', text: `${dpr}×（偏低）` };
}

export function mount(ctx) {
  const host = ctx.host;
  const box = document.createElement('div');
  box.className = 'qtweak';
  box.setAttribute('aria-label', '画质信息（只读）');

  const line = document.createElement('span');
  line.className = 'qtweak__line';
  box.appendChild(line);

  const note = document.createElement('span');
  note.className = 'qtweak__note';
  note.textContent = '画质档位由引擎决定，包改不了（见说明）';
  box.appendChild(note);

  host.appendChild(box);

  function render() {
    const dpr = typeof window !== 'undefined' && window.devicePixelRatio ? window.devicePixelRatio : NaN;
    const t = dprTone(Math.round(dpr * 100) / 100);
    const w = typeof window !== 'undefined' && window.innerWidth ? window.innerWidth : 0;
    const h = typeof window !== 'undefined' && window.innerHeight ? window.innerHeight : 0;
    line.textContent = `${t.text} · ${w}×${h}`;
    line.className = `qtweak__line is-${t.tone}`;
  }

  render();
  // 旋屏 / 改窗口 / 系统缩放变化时才需要重画；常驻浮层由引擎挂一次。
  const onResize = () => render();
  window.addEventListener('resize', onResize);

  return {
    unmount() {
      window.removeEventListener('resize', onResize);
      if (box.parentNode) box.parentNode.removeChild(box);
    },
  };
}
