# 画质档位 —— **做不到，请先看这一节**

作者：**纸鸢干机**（不是我做的 —— 灵感来自 Paper-Yuan 0.2.4，实现在 Forge 的 mod 表面上）

## 结论：这一包**抬不了画质档位**

Paper-Yuan 的画质提升改的是**引擎渲染常量**：

```js
// public/js/render/app/host.js:82,85
const QUALITY_RES = { high: 2, medium: 1.5, low: 1 };
const BOARD_RES   = { high: 2, medium: 1.25, low: 1 };
```

以及 `public/js/render/app.js` 里那两道按 `devicePixelRatio` 的门：

```js
// :186  dpr 被**封顶**到档位值，不是爱多高多高
const dpr = () => Math.min(globalThis.devicePixelRatio || 1, QUALITY_RES[settings.quality] || 2);
// :199  抗锯齿只在 high 档 **且** dpr < 1.5 时开
antialias: opts.antialias ?? (settings.quality === 'high' && (globalThis.devicePixelRatio || 1) < 1.5),
// :385  3D 那一路：非 low 档 **且** dpr < 2 才开抗锯齿
antialias: settings.quality !== 'low' && (globalThis.devicePixelRatio || 1) < 2,
```

注意 `:186` 的形状：`QUALITY_RES` 是**上限**，不是目标值 ——
`high` 档在 dpr 1 的机器上就是 1× 渲染。抬 `QUALITY_RES.high` 只影响
「dpr 本来就高于它」的机器。同理那两道 `dpr < 1.5` / `dpr < 2` 的门，
在**高分屏上恰恰把抗锯齿关掉了** —— 所以「1080p/2K 屏幕发虚」的根因
不是档位低，而是这两道门在 dpr ≥ 1.5 的机器上主动关了 AA。

Forge 0.16.0 的表面里**没有任何一格**够得到它们：

- `client.theme.vars` 只能设 **CSS 自定义属性**（键必须 `--` 开头），而引擎**没有**把画质
  暴露成 CSS 变量 —— 写 `--quality: 3` 等于什么都没发生；
- `client.panels.wraps` 的组件闭集只有 `game.bondStrip` / `game.hud.topBar` /
  `game.shopCard` / `loadout.detail` —— 渲染器不在其中；
- 面板拿不到 store / engine / match（`docs/design/mod-layer.md` §28.8），也就拿不到 renderer 实例。

## 而且抬档本身有代价（与能不能做 mod 无关）

dpr 3 的 1080p 屏按 3× 渲染 = **9 倍像素填充**。我们的用户群里有老机型
（APK minSdk 24、WebView 下限 Chromium 89），实测余量本就紧。

这不是兼容性问题，是**设备成本**问题：真要抬档得先真机验证。

## 那这一包实际是什么

两件很小的事，且**都明说不是真抬档**：

1. 一条提示条，显示当前设备的 `devicePixelRatio` 与视口 —— 让用户自己知道「发虚」
   到底是不是 dpr 的锅；
2. 一段只作用于 `.qtweak` 作用域的样式，对**已画出来的位图**做轻微的对比/饱和补偿
   （`filter`）。这是对**结果**的修饰，不是提高渲染分辨率 ——
   **抗锯齿与 1080p 点对点都做不到**，别把它当抬档。

它不碰引擎任何既有元素的选择器，也不改任何引擎变量。
