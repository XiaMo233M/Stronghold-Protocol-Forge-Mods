// duel-panel/client/duelNote.js — 只读提示卡。三件事：说清资料在哪、说清为什么不能玩、给一个可关的偏好。
// 约束（工坊包界面层的既有边界，本文件一条都不越）：不 fetch / 不开 WebSocket / 不起定时器 / 不 send 任何消息；
// 状态只走引擎既有的面板偏好口 ctx.session.setPref / getPref（键由引擎按 <包 id>/ 前缀分区）。

export const PREF_HIDDEN = 'hidden';

/** 资料 URL 清单：这些是 duel-data / duel-fighter 两包挂出来的只读 JSON。 */
export const DATA_URLS = Object.freeze([
  '/duel/modes.json', '/duel/rounds.json', '/duel/scoring.json', '/duel/pools.json',
  '/duel/npcs.json', '/duel/consts.json', '/duel/stages.json', '/duel/fighters.json',
]);

/** 不兼容清单：逐条写在这里，玩家看得见「缺的是哪一格」而不是「装了但坏了」。 */
export const BLOCKERS = Object.freeze([
  ['开局', '包不能注册 WebSocket 路径、不能收 POST、不能起进程 —— Duel 的 /lobby 与 /match 无处安放（需要 DESIGN §28.38 / §28.39 的宿主车道，上游在审 PR #4 / PR #5）'],
  ['读实时对局', 'ctx.net 只有 on / send / sendResourceMessage；Duel 的 round / secret / battle / result / finish / bets 事件不在引擎协议的消息表里'],
  ['包通道进对局', 'server.modules[].channels 要 Match.handlePackMsg（上游 PR #2 尚未合并，本包不依赖它）'],
  ['座位与模式', '引擎的 mode 只有 solo / coop；Duel 的礼物对决 8 人 / 竞猜 30 人是另一套参与者模型，属于玩法侧而不是路由侧的事'],
  ['美术', '官方素材（Duel 的 assets/ui.json 等约 44 MB）按红线不进任何包、不分发 —— 本包只搬文字与数据引用'],
]);

export function mount(ctx) {
  const host = ctx && ctx.host;
  if (!host || typeof host.appendChild !== 'function') return;
  const doc = host.ownerDocument || (typeof document !== undefined && document ? document : null);
  if (!doc || typeof doc.createElement !== 'function') return;
  const hidden = readHidden(ctx);
  const card = doc.createElement('div');
  card.className = 'duel-note';
  if (hidden) card.setAttribute('data-hidden', '1');
  card.textContent = '';
  const title = doc.createElement('strong');
  title.className = 'duel-note__title';
  title.textContent = '争锋频道（Duel）· 目前只有资料';
  card.appendChild(title);
  const body = doc.createElement('p');
  body.className = 'duel-note__body';
  body.textContent = '资料：' + DATA_URLS.length + ' 份只读 JSON 已挂在 /duel/*.json；玩法没接上，原因见下。';
  card.appendChild(body);
  for (const [what, why] of BLOCKERS) {
    const row = doc.createElement('div');
    row.className = 'duel-note__row';
    const k = doc.createElement('span');
    k.className = 'duel-note__k';
    k.textContent = what;
    const v = doc.createElement('span');
    v.className = 'duel-note__v';
    v.textContent = why;
    row.appendChild(k);
    row.appendChild(v);
    card.appendChild(row);
  }
  const btn = doc.createElement('button');
  btn.className = 'duel-note__btn';
  btn.type = 'button';
  btn.textContent = hidden ? '显示说明' : '收起说明';
  btn.addEventListener('click', () => {
    const now = card.getAttribute('data-hidden') !== '1';
    if (now) card.setAttribute('data-hidden', '1'); else card.removeAttribute('data-hidden');
    btn.textContent = now ? '显示说明' : '收起说明';
    writeHidden(ctx, now);
  });
  card.appendChild(btn);
  host.appendChild(card);
  if (ctx.log && typeof ctx.log.info === 'function') {
    ctx.log.info('[duel-panel] read-only note mounted; data lives at /duel/*.json, gameplay is not connected (needs host lanes)');
  }
}

export function unmount(ctx) {
  const host = ctx && ctx.host;
  if (host && typeof host.querySelector === 'function') {
    const card = host.querySelector('.duel-note');
    if (card && card.parentNode) card.parentNode.removeChild(card);
  }
}

function readHidden(ctx) {
  try {
    return ctx && ctx.session && typeof ctx.session.getPref === 'function' ? !!ctx.session.getPref(PREF_HIDDEN, false) : false;
  } catch { return false; }
}

function writeHidden(ctx, value) {
  try {
    if (ctx && ctx.session && typeof ctx.session.setPref === 'function') ctx.session.setPref(PREF_HIDDEN, !!value);
  } catch { /* 引擎会点名；这里不静默改状态 */ }
}
