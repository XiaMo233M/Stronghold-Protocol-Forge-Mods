# 来源说明（PROVENANCE）· makoto-voice v1.0.0

## 1 原作者
语音录制与角色版权方为鹰角网络 / Yostar（联动角色结城理来自 Atlus / SEGA）；线上构建未署名个人（原件未署名）。

## 2 许可
本包代码 GPL-3.0-or-later；音频为官方导出物 © Hypergryph / Yostar（含官方素材）。

## 3 兼容改写者
jingjiangze。

## 4 来源
线上构建 https://weishuxieyi.icu/_build/f638115c25cd-20/assets/audio/voice/jp/char_4217_makoto/（14 个 mp3，逐文件原样复制，未转码）。

## 5 改了什么
- 只做一件事：按 12 个官方语音槽位（start / faceEnemy / select×2 / place×2 / skill1-4 / resultFour / resultThree / resultTwo / resultLose）把 cn_019…cn_032 归位。
- 槽位划分沿用已上线 ave-mujica 包的同一条映射（同为 14 条 / 干员），不新造口径。
- 与 makoto-yuki 无键冲突：那个包没有声明 voices。

## 6 自带素材来源（逐条清点）
- 296,371 B / 14 个 mp3（含官方素材）
- voice/jp/char_4217_makoto/cn_019.mp3 … cn_032.mp3

---
非商业声明：本包与其内含的《明日方舟》相关数据、美术、音频素材版权归鹰角网络 / Yostar 所有，
本包与其无任何关联，不主张任何权利，仅供非商业的学习与个人娱乐使用，请勿用于任何商业场景。
提取与打包：jingjiangze，2026-10-13。目标引擎口径：Stronghold-Protocol-Forge 0.18.3（上游 0.2.5）/ MOD API 1。
线上来源：https://weishuxieyi.icu/_build/f638115c25cd-20/（build f638115c25cd-20 / app 0.2.1）
