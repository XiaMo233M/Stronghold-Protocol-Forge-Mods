// ui/capacity.js — 房间容量看板（`root.guide` 面板）：读**引擎自己的** `room.state` 显示当前房间容量，
// 并把 4/8/12/16/20 这套容量选项摆出来。纯只读 —— 不发任何消息、不写 store。
//
// 数据来源只有一处：**引擎自己的房间状态帧** `room.state`（`shared/protocol.js` 的 S2C 表里那一条，
// `server/lobby.js` 的 `Room.toState()`）。它的 `seats` 长度就是房间容量；容量与官方档不同时，同一帧
// 还带 `seatCap`（同一个 `toState()` 加的）。所以这一块**不猜、不重算**：引擎说什么就画什么。
//
// 为什么「什么时候显示」要自己判：`root.guide` 是**固定浮层**（WORKSHOP §1.9.3：挂一次就一直在），
// 所以面板得自己知道现在在不在房间屏上 —— 判据是页面上有没有 `.room-screen`（`screens/room.js` 的根类），
// 与 dmg-board 判 `.screen.result` 同一条路子。离开房间 → 立刻整块不渲染。
//
// 边界（先说清楚）：**房间容量的引擎不在包里。** 真正决定 8/12/16/20 能不能开的是服务端
// （`server/lobby.js` 的 `Room.seatCap` / `Lobby.setSeatCap` + `shared/constants.js` + `match/**` / `economy`），
// 跨 lobby/match/economy，
// 工坊包的面板注入面（没有 store、没有 wire 写口）承载不了。所以本包是**只读显示 + 客户端预览**，
// 「选择器」只改面板自己的预览读数，**不改房间**。要改房间容量，是创建者在引擎的房间设置里做。

/** 本包展示的协作容量档（引擎的官方档 `MAX_SEATS`＝4、默认天花板 `DEFAULT_MAX_SEATS`＝20；这里是固定展示档 4/8/12/16/20）。 */
export const CAPACITIES = Object.freeze([4, 8, 12, 16, 20]);
/** 标准同盟席位数（`shared/constants.js` 的 `MAX_SEATS`）。 */
export const MAX_SEATS = 4;

/** 中文源串（也是 i18n msgid）。导出以便测试与 i18n 对齐。 */
export const MSG = Object.freeze({
  title: '房间容量',
  current: '当前容量：{n} 人',
  expanded: '实验性同盟 · {n} 人模式 · 支持同模式匹配',
  standard: '标准同盟 · 4 人',
  solo: '独立模拟 · 1 人',
  options: '可选容量',
  preview: '预览',
  previewOut: '预览：{n} 人',
  previewHint: '仅预览：房间容量由创建者在房间设置里调整，本包只读显示、不能改房间。',
  note: '数据来自引擎的房间状态帧（room.state），只读展示；不改变对局或房间。',
});

/** 从一帧 `room.state` 读房间容量：优先 `seats.length`；读不到时下面那行再试 `state.experimental.playerCapacity`
 *  —— 那是上游 fork 的字段，本引擎从不发（本引擎用 `room.state.seatCap`），所以实际不会命中。读不到回 null。 */
export function capacityOf(state) {
  if (!state || typeof state !== 'object') return null;
  if (Array.isArray(state.seats) && state.seats.length) return state.seats.length;
  const n = state.experimental && Number(state.experimental.playerCapacity);
  return CAPACITIES.includes(n) ? n : null; // 显式值必须落在本包展示的档里（CAPACITIES；上游 fork 的 isPlayerCapacity 本引擎没有）
}

/** 当前容量的一句话摘要（用注入的 `t`，缺省中文）。 */
export function capacitySummary(state, t) {
  const n = capacityOf(state);
  if (n === null) return '';
  if (n <= 1) return t(MSG.solo);
  if (n <= MAX_SEATS) return t(MSG.standard);
  return t(MSG.expanded, { n });
}

/** 「现在页面上有一个活的房间屏吗」。`doc` 可注入（测试用迷你 DOM）。 */
export function visibleOn(doc) {
  if (!doc || typeof doc.querySelector !== 'function') return false;
  try { return !!doc.querySelector('.room-screen'); } catch { return false; }
}

// i18n：优先用引擎的 t（/shared/i18n.js 由静态面服务，整个 app 都依赖它）；拿不到就退回中文源串 + 简单插值，
// 面板照常工作、绝不静默失败。
let T = null;
function fallbackT(s, vars) {
  if (!vars) return s;
  return String(s).replace(/\{(\w+)\}/g, (_, k) => (vars[k] !== undefined ? String(vars[k]) : `{${k}}`));
}
async function loadT() {
  if (T) return T;
  try {
    const mod = await import('/shared/i18n.js');
    T = mod && typeof mod.t === 'function' ? mod.t : fallbackT;
  } catch {
    T = fallbackT;
  }
  return T;
}

export async function mount(ctx) {
  const t = await loadT();
  const host = ctx.host;
  const doc = host && host.ownerDocument ? host.ownerDocument : (typeof document !== 'undefined' ? document : null);
  const el = (tag, cls, text) => {
    const n = doc.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  };

  const box = el('section', 'cap');
  box.setAttribute('aria-label', MSG.title);
  host.appendChild(box);

  /** 最后一次收到的房间状态（面板自持：切回房间屏立刻还能画）。 */
  let last = null;
  /** 本地预览选择（**只影响本面板**，不改房间）。 */
  let preview = null;
  let drew = false;
  let drawnKey = null;

  function build() {
    box.textContent = '';
    const head = el('div', 'cap__head');
    head.appendChild(el('b', null, t(MSG.title)));
    const summary = capacitySummary(last, t);
    if (summary) head.appendChild(el('small', null, summary));
    box.appendChild(head);

    const n = capacityOf(last);
    if (n !== null && n > 1) box.appendChild(el('p', 'cap__current', t(MSG.current, { n })));

    const opts = el('div', 'cap__options');
    opts.appendChild(el('span', 'cap__label', t(MSG.options)));
    const list = el('ul', 'cap__list');
    for (const c of CAPACITIES) {
      const li = el('li', c === n ? 'cap__item is-current' : 'cap__item', t(MSG.current, { n: c }));
      list.appendChild(li);
    }
    opts.appendChild(list);
    box.appendChild(opts);

    const prev = el('div', 'cap__preview');
    prev.appendChild(el('span', 'cap__label', t(MSG.preview)));
    const select = el('select', 'cap__select');
    for (const c of CAPACITIES) {
      const option = el('option', null, t(MSG.current, { n: c }));
      option.setAttribute('value', String(c));
      if (c === (preview ?? n ?? MAX_SEATS)) option.setAttribute('selected', 'selected');
      select.appendChild(option);
    }
    select.addEventListener('change', (e) => { preview = Number(e.currentTarget.value); draw(true); });
    prev.appendChild(select);
    box.appendChild(prev);

    if (preview !== null) box.appendChild(el('p', 'cap__preview-out', t(MSG.previewOut, { n: preview })));
    box.appendChild(el('p', 'cap__hint', t(MSG.previewHint)));
    box.appendChild(el('p', 'cap__note', t(MSG.note)));
  }

  function draw(force) {
    const show = !!last && visibleOn(doc);
    if (!show) {
      if (!drew) return;
      box.textContent = '';
      drew = false; drawnKey = null;
      return;
    }
    const key = `${capacityOf(last)}:${preview}`;
    if (!force && drew && drawnKey === key) return; // 状态没变：一个 DOM 写都不做
    build();
    drew = true; drawnKey = key;
  }

  // 引擎的房间状态帧（S2C 白名单内，面板可以直接订阅）：到了就存一份并重画。
  const off = ctx.net.on('room.state', (msg) => { last = msg || null; draw(false); });

  // 界面的出现与消失不是消息驱动的 —— 页面结构变了就重判一次（合并到一帧一次；draw 自带状态守卫）。
  let pending = false;
  const schedule = () => {
    if (pending) return;
    pending = true;
    const tick = () => { pending = false; draw(false); };
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(tick);
    else setTimeout(tick, 32);
  };
  let observer = null;
  let timer = null;
  if (doc && typeof MutationObserver === 'function' && doc.body) {
    observer = new MutationObserver(schedule);
    observer.observe(doc.body, { childList: true, subtree: true });
  } else {
    timer = setInterval(() => draw(false), 1000);
  }

  draw(false); // 挂载时可能已经在房间屏上（热装 / 切页回来）

  return {
    unmount() {
      off();
      if (observer) observer.disconnect();
      if (timer) clearInterval(timer);
      box.remove();
    },
  };
}

export default mount;
