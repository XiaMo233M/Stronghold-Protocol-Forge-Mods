// test/capacity.test.mjs — 房间容量看板的纯逻辑与宿主交互验收（作者侧；不需要引擎，不需要浏览器）。
//
// 怎么跑：`node --test capacity-panel/test/capacity.test.mjs`。
// 模块里的 `import('/shared/i18n.js')` 在本机 Node 下会失败 → 面板退回中文源串 + 简单插值（这正是要测的降级路径）。
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { CAPACITIES, MAX_SEATS, MSG, capacityOf, capacitySummary, visibleOn, mount } from '../ui/capacity.js';

// ---- 迷你 DOM（只实现 mount 用到的成员） ----
function makeEl(tag) {
  const el = {
    tagName: tag, children: [], attrs: {}, className: '', _handlers: {},
    setAttribute(k, v) { el.attrs[k] = String(v); },
    getAttribute(k) { return k in el.attrs ? el.attrs[k] : null; },
    addEventListener(type, fn) { (el._handlers[type] = el._handlers[type] || []).push(fn); },
    appendChild(child) { el.children.push(child); child.parentElement = el; return child; },
    remove() {
      if (el.parentElement) el.parentElement.children = el.parentElement.children.filter((c) => c !== el);
      el.parentElement = null;
    },
  };
  Object.defineProperty(el, 'textContent', {
    get: () => el._text || '',
    set: (v) => { el._text = String(v); if (v === '') el.children = []; },
  });
  Object.defineProperty(el, 'value', {
    get: () => {
      const sel = el.children.find((c) => c.attrs && c.attrs.selected !== undefined);
      return sel ? sel.attrs.value : '';
    },
  });
  return el;
}
function makeDoc({ room = false } = {}) {
  const doc = {
    body: makeEl('body'), _room: room,
    createElement: makeEl,
    querySelector(sel) { return sel === '.room-screen' && doc._room ? makeEl('div') : null; },
  };
  doc.body.ownerDocument = doc;
  return doc;
}

const ROOM_STATE = { t: 'room.state', code: 'ABCD', mode: 'coop', seats: new Array(8).fill(null), experimental: { playerCapacity: 8 } };
const STANDARD_STATE = { t: 'room.state', code: 'EFGH', mode: 'coop', seats: new Array(4).fill(null), experimental: {} };

test('CAPACITIES：就是引擎那五档 4/8/12/16/20', () => {
  assert.deepEqual([...CAPACITIES], [4, 8, 12, 16, 20]);
  assert.equal(MAX_SEATS, 4);
});

test('capacityOf：优先 seats.length，退回 experimental.playerCapacity，读不到回 null', () => {
  assert.equal(capacityOf(ROOM_STATE), 8);
  assert.equal(capacityOf(STANDARD_STATE), 4);
  assert.equal(capacityOf({ seats: [], experimental: { playerCapacity: 16 } }), 16, '空 seats → 退回 experimental');
  assert.equal(capacityOf({ experimental: { playerCapacity: 12 } }), 12);
  assert.equal(capacityOf({}), null);
  assert.equal(capacityOf(null), null);
  assert.equal(capacityOf('x'), null);
  assert.equal(capacityOf({ experimental: { playerCapacity: 7 } }), null, '非法档不认（7 不是可选容量）');
});

test('capacitySummary：1=独立 / 4=标准 / >4=实验性（用注入的 t）', () => {
  const t = (s, v) => (v && v.n !== undefined ? s.replace('{n}', String(v.n)) : s);
  assert.equal(capacitySummary({ seats: [null] }, t), MSG.solo);
  assert.equal(capacitySummary(STANDARD_STATE, t), MSG.standard);
  assert.ok(capacitySummary(ROOM_STATE, t).includes('8'));
  assert.equal(capacitySummary({}, t), '');
});

test('visibleOn：只看页面上有没有 .room-screen', () => {
  assert.equal(visibleOn(makeDoc({ room: true })), true);
  assert.equal(visibleOn(makeDoc({ room: false })), false);
  assert.equal(visibleOn(null), false);
  assert.equal(visibleOn({}), false);
});

// ---- mount：订阅 → 判可见 → 画 / 撤 ----
function stage({ room = false } = {}) {
  const doc = makeDoc({ room });
  const host = makeEl('div');
  host.ownerDocument = doc;
  const subs = [];
  const ctx = {
    pack: 'capacity-panel', id: 'capacity', slot: 'root.guide', hostKey: null, host,
    net: { on: (type, fn) => { subs.push({ type, fn, off: false }); return () => { subs.find((s) => s.fn === fn).off = true; }; } },
    log: { info() {}, warn() {}, error() {} },
  };
  const saved = { mo: globalThis.MutationObserver, raf: globalThis.requestAnimationFrame };
  let observer = null, raf = null;
  globalThis.MutationObserver = class { constructor(cb) { observer = { cb, stopped: false }; } observe() {} disconnect() { if (observer) observer.stopped = true; } };
  globalThis.requestAnimationFrame = (fn) => { raf = fn; };
  const restore = () => { globalThis.MutationObserver = saved.mo; globalThis.requestAnimationFrame = saved.raf; };
  return {
    doc, host, subs,
    async start() { const api = await mount(ctx); return api; },
    flush() { const f = raf; raf = null; if (f) f(); },
    pageChanged() { if (observer) observer.cb([]); },
    deliver(msg) { for (const s of subs) if (s.type === 'room.state') s.fn(msg); },
    get observer() { return observer; },
    restore,
  };
}

function findBox(host) { return host.children[0]; }
function collect(node, cls, out = []) {
  if (node.className && String(node.className).includes(cls)) out.push(node);
  for (const c of node.children || []) collect(c, cls, out);
  return out;
}

test('mount：订的是引擎的 room.state；没有数据 / 不在房间屏都不画', async () => {
  const s = stage({ room: false });
  const api = await s.start();
  assert.deepEqual(s.subs.map((x) => x.type), ['room.state']);
  const box = findBox(s.host);
  assert.equal(box.className, 'cap');
  assert.equal(box.children.length, 0, '挂载时：没数据 → 整块空着');
  s.deliver(ROOM_STATE); // 有数据了，但玩家不在房间屏
  s.flush();
  assert.equal(box.children.length, 0, '没有活的房间屏就不画');
  api.unmount();
  s.restore();
});

test('mount：房间屏出现时画（当前容量 + 五档 + 当前档高亮）', async () => {
  const s = stage({ room: false });
  const api = await s.start();
  const box = findBox(s.host);
  s.deliver(ROOM_STATE);
  s.doc._room = true;
  s.pageChanged();
  s.flush();
  assert.ok(box.children.length > 0, '房间屏在 → 画');
  const current = collect(box, 'cap__current');
  assert.equal(current.length, 1);
  assert.ok(current[0]._text.includes('8'), '当前容量 8');
  const items = collect(box, 'cap__item');
  assert.equal(items.length, CAPACITIES.length, '五档都摆出来');
  assert.equal(collect(box, 'cap__item is-current').length, 1, '当前档恰好高亮一个');
  assert.ok(collect(box, 'cap__item is-current')[0]._text.includes('8'));
  api.unmount();
  s.restore();
});

test('mount：预览下拉只改面板预览读数（当前档高亮跟着房间走、不跟预览）；离开房间屏清空；unmount 退订', async () => {
  const s = stage({ room: true });
  const api = await s.start();
  const box = findBox(s.host);
  s.deliver(ROOM_STATE);
  s.pageChanged();
  s.flush();
  const roomHighlight = collect(box, 'cap__item is-current')[0]._text;
  assert.ok(roomHighlight.includes('8'), '高亮 = 房间真实容量 8');
  assert.equal(collect(box, 'cap__preview-out').length, 0, '没选预览 → 不画预览读数');

  // 模拟预览下拉：值改成 16
  const select = collect(box, 'cap__select')[0];
  assert.ok(select, '有预览下拉');
  select._handlers.change[0]({ currentTarget: { value: '16' } });
  const out = collect(box, 'cap__preview-out')[0];
  assert.ok(out && out._text.includes('16'), '预览读数变成 16');
  assert.equal(collect(box, 'cap__item is-current')[0]._text, roomHighlight, '房间真实容量的高亮不随预览变（只读显示）');

  s.doc._room = false;
  s.pageChanged();
  s.flush();
  assert.equal(box.children.length, 0, '离开房间屏 → 清空');

  api.unmount();
  assert.equal(s.subs[0].off, true, '订阅被退掉');
  assert.equal(s.observer.stopped, true, '观察器停了');
  assert.equal(box.parentElement, null, '箱子从宿主里摘掉');
  s.restore();
});
