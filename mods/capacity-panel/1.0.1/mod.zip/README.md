# capacity-panel · 房间容量看板

在房间屏上显示**引擎自己送来的**房间容量，并把 4/8/12/16/20 这套容量档摆出来，附一个**仅预览**的选择下拉。

> **只读 + 预览。** 面板订阅引擎的 `room.state`（S2C）读 `seats.length`（容量 ≠ 官方 4 时同一帧还带 `seatCap`），
> 显示当前容量；「选择器」只改面板自己的预览读数，**不改房间**。房间容量由创建者在引擎的房间设置里调整
> —— 服务端容量引擎跨 lobby/match/economy，工坊包承载不了（原因见 `NOTICE-来源说明.md`）。

## 它显示什么

挂载点 `root.guide`（固定浮层；面板自己判「在不在房间屏」——判据是页面上有没有 `.room-screen`，
与 dmg-board 判 `.screen.result` 同一条路子）：

- **当前容量**：`seats.length`（`server/lobby.js` 的 `Room.toState()`），退回 `room.state.seatCap`（引擎只在容量 ≠ `MAX_SEATS` 时才带这一栏）；
- **容量档**：4 / 8 / 12 / 16 / 20（本包自己列的展示档；引擎的天花板是 `DEFAULT_MAX_SEATS`＝20，官方档 `MAX_SEATS`＝4），当前档高亮；
- **预览下拉**：选一个档只更新面板上的预览读数，**不写房间**；
- 摘要：`独立模拟 · 1 人` / `标准同盟 · 4 人` / `实验性同盟 · N 人模式 · 支持同模式匹配`。

## 界面词条（i18n）

`i18n` 声明了 `en` / `ja` / `ko` / `zh-TW` 四份词条，msgid = 面板里的中文源串。引擎把包内词条并进
`/i18n/<code>.json`（已有键绝不覆盖，WORKSHOP §1.10）；面板用引擎的 `t()` 取词，取不到时退回中文源串。

## 安装

```bash
node tools/workshop-pack.mjs import "房间容量看板.zip"   # 或把 capacity-panel/ 复制进 workshop/
# 重启游戏服务器（包装载是进程级的）
```

## 边界（先知道再装）

- **是显示，不是引擎。** 它不能开 8/12/16/20 人房 —— 那在服务端；本包只读显示 + 预览。
- **不改任何东西。** 注入面只有 `host` 与 `net.on('room.state')`（只读订阅），没有 store / 对局对象，一次 `send` 都没有。
- **零素材。** 不含任何游戏素材。

## 开发/验收

```bash
node --test capacity-panel/test/capacity.test.mjs   # 纯逻辑 + 挂载/撤下（迷你 DOM）
node tools/workshop-validate.mjs --workshop <装好的根>
node tools/check-packs.mjs --engine <Forge 目录> --root packs
```

许可证：代码与词条 GPL-3.0-or-later；本包不含任何游戏素材。
