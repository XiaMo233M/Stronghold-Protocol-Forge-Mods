# NOTICE-来源说明

## 原件名称与来源

- **原件**：`jingjiangze/stronghold-server`（fork of `sganggs/Stronghold-Protocol`）的 **R12** 改动：
  把每间房的座位上限（`seatCap`）做成可调：官方档是 `shared/constants.js` 的 `MAX_SEATS`（4），
  服务端默认天花板是同一文件的 `DEFAULT_MAX_SEATS`（20），下限 `MIN_SEATS`（2），线上闸门在
  `shared/protocol.js` 的 `room.create.seatCap` / `room.setSeatCap`；
  以及它的客户端界面（`public/js/screens/lobby.js` 的 `seatCapRange()` / `SeatCapPicker`、
  `public/js/screens/room.js` 的 `seatCapRoomRange()` / `SeatCapSetter`）。
  仓库：<https://github.com/jingjiangze/stronghold-server>（2026-10-11 快照）。
- 本包 **1.0.0** 由**原作者本人**制作。本 **1.0.1** 是**兼容改写版**：只更正了与引擎不符的文件/字段名
  （逐处改正见站点上本条记录的**兼容说明**），玩法、界面与代码逻辑一字未改；原作者署名与许可原样保留。

## 原作者

jingjiangze（本人）。

## 原件许可

GPL-3.0-or-later（与 fork / 管理器同族）。

## 改了什么

**没有改任何原件字节。** 包内是**新写**的面板模块、样式与四份界面词条：

| 件 | 落点 | 说明 |
|---|---|---|
| `ui/capacity.js` | `client.panels` 的 `root.guide` | 读 `room.state` 显示当前容量 + 容量档 + 预览下拉（只读；不发消息） |
| `ui/capacity.css` | 同上 | 面板样式 |
| `i18n/{en,ja,ko,zh-TW}.json` | `i18n` 表面 | 给已有语种补本包界面的词条（msgid = 面板里的中文源串） |
| `README.md` | — | 用法与边界 |

**它真的做了什么（这一半是功能）**：面板订阅引擎的 `room.state`（`shared/protocol.js` 的 S2C 表里那一条，
`server/lobby.js` 的 `Room.toState()`），读 `seats.length`（`server/lobby.js` 的 `Room.toState()` 送出的座位表；容量 ≠ `MAX_SEATS` 时同一帧还带 `seatCap`），
显示当前房间容量与全部容量档，并挂一个**仅预览**的下拉；界面词条走 `i18n` 合并体
（`/i18n/<code>.json`，WORKSHOP §1.10）。装到带工坊支持的引擎上，房间屏里就能看到这块只读容量看板。

## 做不了的部分（**这一节是重点**）

**服务端的容量引擎做不成包，本包也不假装能改房间。**

- 真正决定容量能不能开的是**服务端**：`server/lobby.js` 的 `Room.seatCap` / `Room.seatCapTo()` /
  `Lobby.setSeatCap()`（越界由 `shared/constants.js` 的 `clampSeats()` 收口；天花板 `LOBBY_DEFAULTS.maxSeats`
  = `maxSeatsFrom(process.env)`，即 `SP_MAX_SEATS`，缺省 20），
  以及 `server/match/**`、经济与匹配池对扩展容量的处理 —— **跨 lobby/match/economy**，工坊包的面板注入面
  （没有 store 句柄、没有 `send()` 写口、没有对局对象）碰不到房间状态，也就改不了容量。
- 客户端 `public/js/screens/lobby.js` 的座位滑杆（`SeatCapPicker` / `seatCapPayload()`）与
  `public/js/screens/room.js` 的 `SeatCapSetter`（`seatCapRoomRange()`）**能改**，是因为它们是**引擎自己的界面**、能拿到 store 与
  wire；工坊面板刻意没有这两样（WORKSHOP §1.9.3 的注入面清单）。所以本包的下拉是**预览**：只改面板自己的
  预览读数，**不改房间**。要改房间容量，是创建者在引擎的房间设置里做。
- 面板订阅 `room.state` 是**只读**的：它把引擎送来的容量画出来，绝不回写。

因此：**本包是房间容量的只读显示 + 客户端预览界面，不是容量引擎。** 容量引擎属于对应版本的服务器
（fork 及其 `shared/` / `server/` 实现），不是包表面。

## 自带素材来源

**没有任何素材。** 没有图标、音频、字体、立绘、spine、解包数据。

## 许可

- 本包 **GPL-3.0-or-later**（面板代码、样式与词条均为本包自写）。
- 《明日方舟》及其素材版权归鹰角网络 / Yostar 所有；本包不含、也不主张任何此类素材。
