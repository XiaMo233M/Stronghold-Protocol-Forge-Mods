# 署名与来源 · PROVENANCE

> 原作者与兼容改写者**分开列出，不抹掉任何一方**。原件未署名的一律写**「原件未署名」**，不代填；
> 许可照实抄自包内 `pack.json` 的 `license` 字段，未改动。

## 包

| 项 | 值 |
|---|---|
| 包 id | `srv-notice` |
| 版本 | `1.0.0` |
| 名称 | 服务器公告 |
| 目录名 = 包 id | 是 |
| 顶层目录 | `srv-notice/` |

## 两份清单（谁读哪一份）

同一份公告，两个宿主各读自己那份清单。**两份都在同一个包内并存**，不需要拿到后再加工一次。
（业主裁决 2026-10-11：「srv-notice 出两份清单」。）

| 给谁 | 清单文件 | 出处 | 顶层键（形状） |
|---|---|---|---|
| **工坊包（本引擎 Stronghold-Protocol）** | `pack.json`（**包根**） | 兼容改写按工坊包格式重写 | `id` / `version` / `name` / `author` / `license` / `description` / `notices.announcement` → `notice/announcement.json` |
| **Stardust 宿主** | `stardust/pack.json` | **原件 `pack.json` 的逐字节副本**（1420 B，sha256 `53bcf67914b34f79634176ec49f7e7a2c521239313af34e09663c2106f64346e`） | `id` / `type` / `target` / `version` / `app` / `name` / `englishName` / `authors` / `license` / `description` / `capabilities` / `announcements[]`（2 条内联记录） |

**为什么工坊那份必须留在包根**：装载器只认一条路径 —— `<工坊根>/<包 id>/pack.json`
（`server/workshop.js:106` 读它；`:94-101` 扫描时只把 `<工坊根>` 下的目录当包）。`pack.json` 放在别处等于不存在。

**为什么另一份放 `stardust/` 子目录**（而不是包根的 `pack.stardust.json`）：三条理由一起成立才选它 ——

1. **不会被装载器误读**：装载器只读包根那一个文件名，从不递归或按前缀找清单，所以子目录里的同名文件永远不会
   被当作清单读走（下面「并存装载实测」有负控：把这份清单放到包根才会被读，并会被整包拒绝）；
2. **一眼看懂给谁**：目录名就是宿主名，`pack.json` = 工坊、`stardust/pack.json` = Stardust，解压下来就分得清；
3. **不用改名就能用**：那份文件本身就叫 `pack.json`，一个按 `<包目录>/pack.json` 找清单的 Stardust 宿主
   （或它的脚本）拿到手就能直接用，不必先改成别的名字。

**怎么用（各自一侧）**

- **工坊侧**：什么都不用做。把整个 `srv-notice/` 放进工坊根（`<工坊根>/srv-notice/`），包根那份 `pack.json`
  就是装载器读的那一份。
- **Stardust 侧**：把 `stardust/pack.json` 当这个包的清单交给它 ——
  `cp -r srv-notice <stardust>/packs/`（或解压 zip 到 `packs/`）之后，
  `cp srv-notice/stardust/pack.json srv-notice/pack.json`，重启；也可以只取 `stardust/pack.json` 这一个文件。
  它是**原件那个文件本身**，一个字节没动，所以 Stardust 侧看到的与投稿时完全相同。

**代价（照实说）**：`stardust/pack.json` 在包目录**之内**，而工坊包的「包身份哈希 + 客户端下载清单」= **包目录下的
全部普通文件**（`server/packFiles.js:8-14`，**刻意零排除**：任何按名字的例外都会重新打开「声明了却谁也下不到」
那个洞）。所以多这一份清单会让包摘要变化、并让客户端多下 1420 字节；它**不产生任何 warn / error**（实测见下）。

## 原作者

`jingjiangze` —— 原件 `pack.json` 里写的是 Stardust 拼法 `"authors": ["jingjiangze"]`，
这一版**两个拼法都在包里、都还是同一个人**：包根 `pack.json` 落成工坊包的 `"author": "jingjiangze"`，
Stardust 清单 `stardust/pack.json` 里是原件那个 `"authors": ["jingjiangze"]`（逐字节）。没有换人。
包内 `README.md` **未被改动**（2878 B，sha256 `523761141cd58cc5effc2b29eaa8e604ed47c367a8b8419d706ea4a38d5191bc`）。

**更正上一版 PROVENANCE 的一处失实**：上一版这里写「其中「下载」一节的源码链接
`https://github.com/jingjiangze/Stronghold-Protocol-Forge`（分支 `feat/stardust-mods`）照旧」。
逐条核对原件后：原件 `README.md` 里**没有**「下载」一节，也**没有任何**仓库链接
（原件 zip 只有 `pack.json` 与 `README.md` 两个条目；`README.md` 全文 52 行，`grep github|下载|源码|http` 零命中）。
那句话没有出处，本次按原件删掉 —— 署名只写原件里真有的东西。

## 许可

`CC0-1.0`（包内 `pack.json.license` 原文，未改；两份清单里都是同一个值）。包内 `README.md` 末尾另写「这份公告文字随你改、随你发」。

## 兼容改写者

`Mo233`

## 来源

站点投稿 **`668e4a303535`**，原件 zip 大小 **2747 字节**，
sha256 `5e2d97bd74446d4dca2adb5a2a04a9f9a8896160f066474a57cb909a85eb45b4`
（源文件只读，未改动一个字节）。

原件是一份**跨引擎清单**（`README.md:5-21` 自述：同一个 `pack.json`，两个宿主各自读得懂）：
写给 **Stardust** 宿主，用 Stardust 自己的字段拼法（`type` / `target` / `app` / `authors` /
`capabilities` / `announcements`）。而工坊包的顶层键是**闭集**（`shared/workshop.js:111-128` 的
`PACK_FIELDS`），一个不认识的键**点名整包拒绝**（`:1435-1441`，码 `PACK_UNKNOWN_FIELD`）。
两份清单就是这两件事各自的落点（见上「两份清单」）。

## 改了什么

> 口径：**「移出包根」不等于「删掉」**。下面每一行说的都是「这个键从工坊那份 `pack.json` 里移出去」，
> 原值一律**逐字**活在 `stardust/pack.json` 里（那个文件就是原件本身）。

| # | 改动点 | 原做法 | 我们的做法 | 为什么 |
|---|---|---|---|---|
| 1 | 顶层字段 `type` | `"type": "mod"` | **移出包根**；原值逐字在 `stardust/pack.json` | `PACK_FIELDS`（`shared/workshop.js:111-128`）里没有这个键。实跑装载器原件的记录就是这一条：`PACK_UNKNOWN_FIELD: pack.json: "type" is not a field of this pack format (…)` —— 声明了却不被读的键宁可当场拒绝，也不静默略过（`:100-105`）。 |
| 2 | 公告载体 | `"announcements": [ { title, date, paragraphs[] }, … ]`（2 条内联记录） | 工坊侧**迁到** `"notices": { "announcement": "notice/announcement.json" }`，正文落成包内相对 `.json`；Stardust 侧**原样保留** `announcements[]` 在 `stardust/pack.json` | 工坊包的公告通道是 `notices`（DESIGN §28.15）：形状只认 `announcement` / `credits` 两个字段（`:1052-1058`），每个是**包内相对 `.json` 路径**（`:1067-1069`）；装载期判文件在不在、可不可读、是不是 JSON（`server/notices.js:123-143`，坏文件整包被拒）；服务面按 `{ version, date, summary, sections: [{ name, items[] }] }` 复判（`server/notices.js:169-192`）。现成先例：`plugin-pack` 的 `"notices": { "credits": "notice/credits.json" }`。Stardust 认的是内联 `announcements[]`，所以那一侧一份字节都不动。 |
| 3 | 顶层字段 `app` | `"app": ">=0.2.0"`（Stardust 的 app 区间） | **移出包根**；原值逐字在 `stardust/pack.json` | `app` **不在**工坊包的 `PACK_FIELDS` 里。删掉 `type` 之后再实跑，装载器报出的下一条就是它：`PACK_UNKNOWN_FIELD: pack.json: "app" is not a field of this pack format (…)` —— 即原件自述的「管理器侧是 gameVersion / game」（`README.md:13`）那一层。工坊包对应的字段是 `gameVersion` / `game`，但**没有素材可填**（原件没有 gameVersion / game 的值），所以不代填，直接移出（见「拿不准 / 需业主裁决」）。 |
| 4 | 顶层字段 `authors` | `"authors": ["jingjiangze"]` | 包根**改成** `"author": "jingjiangze"`；`"authors"` 原值逐字留在 `stardust/pack.json` | 同一个键不能对两个宿主说两种话，而工坊包只认 `author`（字符串）—— 那就在**工坊那份**用 `author`，在 **Stardust 那份**用 `authors`。人名没有变（`README.md:16` 自述的「Stardust 拼法 / 管理器侧是 author」正是这一条）。 |
| 5 | 顶层字段 `target` | `"target": "stardust"`（原件自述：「管理器看到它就不装载、只认识（foreign）」） | **移出包根**；原值逐字在 `stardust/pack.json` | 这一版协调器的**顶层键闭集里没有 `target`**，也没有任何 foreign / 跨宿主识别分支 —— 保留它换来的不是「被识别为外来包」，而是整包被拒。原件 `README.md:11` 描述的那条机制在本引擎里不存在（见「拿不准 / 需业主裁决」）。 |
| 6 | 顶层字段 `capabilities` | `"capabilities": ["announcements"]`（这台宿主实现了它） | **移出包根**；原值逐字在 `stardust/pack.json` | 不在 `PACK_FIELDS` 里；能力声明在工坊包里没有对应通道（`notices` 本身就是那个能力的落点）。 |
| 7 | 顶层字段 `englishName` | `"englishName": "Server notice"` | **移出包根**；原值逐字在 `stardust/pack.json` | 它是**原件自带元数据（英文名）**，但同样**不在** `PACK_FIELDS` 里。本次一开始按「不动自带元数据」把它留着，实跑后装载器报的正是 `"englishName" is not a field of this pack format` —— 于是照「包侧移出未知顶层键、不动装载器」这条纪律移出工坊那份，并在此点名（它的值在 `stardust/pack.json` 里逐字存在，一个字节没丢）。 |

`description` / `name` / `license` / `version` 一字未改（两个文件里都是这四个字的原文）；`README.md` **一字未改**。

**包内 `README.md` 已与实现不符，保持原样未改**（业主已裁决的口径：不改原件，只在这里注明）：

- 「**改文字**」一节写「直接编辑 `pack.json` 里的 `announcements`」—— 工坊那份里已经没有 `announcements`
  （正文在 `notice/announcement.json`）；这一句在 **Stardust 那份**（`stardust/pack.json`）上仍然成立。
- 「**安装（Stardust 宿主）**」一节写 `cp -r srv-notice /path/to/stardust/packs/`，读起来像「包根那份 `pack.json`
  就是 Stardust 的」—— 现在是两份清单，包根那份给工坊；Stardust 侧要取 `stardust/pack.json`（见上「怎么用」）。
- 「**开发/验收**」一节的 `node tools/workshop-validate.mjs --workshop <根>` 仍然成立，但原件那一版的预期结果
  （「它会是 foreign，不进装载集合」）不成立：本引擎没有 foreign 分支，原件那个形状会被**整包拒绝**。

> 即：**包内「安装（Stardust 宿主）」「改文字」「开发/验收」三节已与实现不符（保持原样未改）。**

### 从**包根**移出的字段值（**逐字**还原在 `stardust/pack.json`）

这几个顶层键在工坊包格式里没有落点，本次从**包根** `pack.json` 里移出。值原样抄在这里，并且——
比抄写更强——**原件那个文件的逐字节副本就在包里**（`stardust/pack.json`，1420 B，
sha256 `53bcf67914b34f79634176ec49f7e7a2c521239313af34e09663c2106f64346e`）：

| 键 | 原值（逐字） |
|---|---|
| `type` | `"mod"` |
| `target` | `"stardust"` |
| `app` | `">=0.2.0"` |
| `englishName` | `"Server notice"` |
| `capabilities` | `["announcements"]` |
| `authors` | `["jingjiangze"]`（包根落成工坊包的 `"author": "jingjiangze"`；`"authors"` 原值在 `stardust/pack.json`，人名未丢） |

### 并存装载实测（多一份清单没把装载搞坏）

在**根内只有这一个包**的干净工坊根上跑装载器与校验器，**改动前（只有包根一份清单）**与
**改动后（包根 + `stardust/pack.json`）**对照：

| | 改动前（单份清单） | 改动后（两份清单并存） |
|---|---|---|
| 装载 `errors` | `[]`（0 条） | `[]`（0 条） |
| 载入的包 | `srv-notice` 1 个 | `srv-notice` 1 个 |
| `workshop-validate` | `0 error(s), 0 warning(s)` | `0 error(s), 0 warning(s)` |

**与「多一份清单」相关的 warn / error：一条也没有。** 负控（证明这个位置确实是「不会被误读」的位置）：
把同一份 Stardust 清单放到**包根**当 `pack.json`，同一台装载器立刻报
`PACK_UNKNOWN_FIELD: pack.json: "type" is not a field of this pack format (…)` —— 被读的只有包根那一个文件名，
`stardust/pack.json` 不在其中。

### 公告正文的迁移与**不可表达的部分**（照实列，不自己丢）

新载体 `notice/announcement.json` 的内容**逐字**来自原件的两条 `announcements` 记录：

| 原件 | 迁到工坊侧的哪里 | 逐字？ |
|---|---|---|
| 第 1 条 `title: "本服公告"` | `sections[0].name` | ✅ 逐字 |
| 第 1 条 `paragraphs[0..1]` | `sections[0].items[0..1]` | ✅ 逐字（两段都没丢） |
| 第 2 条 `title: "本服启用了工坊包"` | `sections[1].name` | ✅ 逐字 |
| 第 2 条 `paragraphs[0]` | `sections[1].items[0]` | ✅ 逐字 |
| 第 1 条 `date: "2026-10-11"` | 公告的 `date`（顶层） | ✅ 就是原件自己的日期 |
| 第 2 条 `date: ""` | 无处可去 | ⚠️ 新载体的 `date` 是**公告级**一个值（`server/notices.js:176`），原件第 2 条的日期为空串，本来就没有内容，未丢事实 |
| 第 2 条是**独立的一条公告** | 工坊侧：变成同一份公告的**第 2 个小节** | ❌ **载体差异（只在工坊侧）**：新载体一个包只承载**一条**公告（`server/notices.js:169-190`：一个包一条，`announcements.push` 只走一次），原件是**两条并列记录**。两条标题与全部段落都逐字在里面，但「两条」这个结构在工坊包格式里表达不出来。**Stardust 侧没有这个损失**：`stardust/pack.json` 里就是原件那两条并列记录，一个字节没动。 |
| 公告级 `version`（必填） | `"1.0.0"` | ⚠️ **新增必填项（只在工坊侧）**：新载体要求 `version` / `date` / `summary` 三项非空（`server/notices.js:187-188`）。这里的 `version` 直接取**原件自己的版本号 `1.0.0`**（不是编的数）。 |
| 公告级 `summary`（必填） | 见 `notice/announcement.json` | ⚠️ 同上：工坊侧**新写的导语**，逐字概述了两条标题的内容，没有引入原件之外的事实；Stardust 清单里没有这个键。 |

**Stardust 宿主那一半现在成立**：`stardust/pack.json` 是原件 `pack.json` 的逐字节副本，
原件 `README.md:43` 那条「名字是 `announcements` 不是 `notices`：同一个键不能对两个宿主说两种话」的顾虑，
由**两份清单**解决 —— 同一个键不再需要对两个宿主说两种话，一份清单对一个宿主。

## 自带素材来源

**无。** 包内没有图片 / 音频 / 字体 / 解包数据；公告正文是原作者手写的中文。

## 校验用哈希（改动前 / 改动后）

| 文件 | 改动前 sha256（= 原件） | 改动后 sha256 |
|---|---|---|
| `pack.json`（包根，工坊清单） | `53bcf67914b34f79634176ec49f7e7a2c521239313af34e09663c2106f64346e`（1420 B） | `4a719ff2e784df72f67a46af9423d1c8d37ea78387021950df9799f457ed137f`（548 B，本次未再改） |
| `stardust/pack.json`（Stardust 清单，新增） | —（原件无此路径） | `53bcf67914b34f79634176ec49f7e7a2c521239313af34e09663c2106f64346e`（1420 B）—— **与原件 `pack.json` 同一个摘要**：原件的那份字节原封不动地活在包里 |
| `README.md` | `523761141cd58cc5effc2b29eaa8e604ed47c367a8b8419d706ea4a38d5191bc`（2878 B） | 同左（未改） |
| `notice/announcement.json` | —（原件无此文件） | `23ada4da6da1fb6c49bfe9bc66844590460c882285730805f7cbdcd18f8e492d`（930 B，本次未再改 —— 公告正文逐字未动） |

`README.md` 与 `notice/announcement.json` 的摘要与上一轮**逐字相同**，这就是「公告正文与原件字节都没动」的机器凭据。
`PROVENANCE.md` 自身不列在这里：它的文本一变，包含它的那个包摘要就跟着变，写进包里必然自相矛盾（前几版这里
留过一次自指的旧摘要，本次按同一条理由删掉）。**成品 zip 与包内文件的字节数 / sha256 一律记在交付索引**
`../CHECKSUMS.txt`（与其余统一交付物同一份清单；本次 srv-notice 那一行已更新）。

## 拿不准 / 需业主裁决

1. **两份清单已经按业主裁决落地**（工坊包根 `pack.json` + `stardust/pack.json`）。剩下的一个判断点：
   `stardust/pack.json` 在包目录之内，按引擎自己的规矩它**就是包的一部分** —— 包身份摘要会变、客户端会多下
   1420 字节（`server/packFiles.js:8-14`，装载器/下载清单共用这一份枚举器，零排除项）。本次视为可接受
   （无 warn / 无 error，字节极小，内容无秘密）。若业主不接受「客户端会下到这份 Stardust 清单」，那就只能
   把清单移出包目录（顶层目录不再等于包 id，或另发一个 zip）—— 本次没有那样做。
2. **`target` 描述的机制在本引擎里不存在**：原件 `README.md:11` 的「管理器看到它就只认识、不装载（foreign）」
   在 `PACK_FIELDS` 闭集 + 无 foreign 分支的现实里没有落点。本次按纪律把这份声明留在 Stardust 清单里
   （逐字节），没有去引擎侧加通道。
3. **没有 Stardust 宿主的实机证据**：本机可跑的引擎只有 Stronghold-Protocol（`APP_VERSION 0.15.0`、
   `MOD_API_VERSION 1`、git `d46cfdaa`）。Stardust 侧本次只做到「原件那个文件逐字节还原」，**没有实机装载过** ——
   如果业主手上有 Stardust 宿主，请用它跑一次 `node tools/packs.mjs list --root <装了它的根>` 复核。
4. **`summary` 与公告级 `version` 是工坊侧新增必填项**（`server/notices.js:187-188`）：`version` 取的是**原件自己的
   `1.0.0`**；`summary` 是本次写的**新文字**（导语）。两者都不是原件里有的字，请业主确认这段导语可以留。
5. **`../CHECKSUMS.txt` 是六包共用的一份索引**，本次只改了 srv-notice 那一行（另一个 agent 正在改 `perf-lite`，
   若它整体重写这份索引，本行可能被覆盖）—— 收尾时请以 srv-notice 那一行与实际 zip 的摘要核对一次。
