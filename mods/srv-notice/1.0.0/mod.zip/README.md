# srv-notice · 服务器公告

**给 Stardust 宿主的公告包**：把 `pack.json` 里的公告并进服务器自己的 `/data/announcements.json` —— 大厅的公告板与标题屏的公告弹窗都会看到它，**本服公告排在站内历史前面**。纯数据、零文件、零代码。

这是一份**跨引擎清单**（同一个 `pack.json`，两个宿主各自读得懂）：

```jsonc
{
  "id": "srv-notice",
  "type": "mod",              // Stardust 的包类型（管理器自己装载时不看）
  "target": "stardust",       // 管理器看到它就不装载、只认识（foreign）；Stardust 只认这一个值
  "version": "1.0.0",
  "app": ">=0.2.0",           // Stardust 的 app 区间（管理器侧是 gameVersion / game）
  "name": "服务器公告",
  "englishName": "Server notice",
  "authors": ["jingjiangze"], // Stardust 拼法（管理器侧是 author）
  "license": "CC0-1.0",
  "description": "…",
  "capabilities": ["announcements"],           // 这台宿主实现了它
  "announcements": [ { "title": "…", "date": "…", "paragraphs": ["…"] } ]
}
```

## 安装（Stardust 宿主）

```bash
cp -r srv-notice /path/to/stardust/packs/     # 或解压 zip 到 packs/
# 重启游戏服务器（mod 包的 live:false：能力的数据随启动应用一次）
```

装好后：

- `GET /data/announcements.json` = **本包公告 + 站内公告**（同一份校验器判过；本包公告在前，包按包 id 排序）；
- `GET /healthz` 与 WebSocket `welcome` 的 `mods` 字段出现这台服务器的包集合身份（`{digest, packs:["srv-notice"]}`）。

**改文字**：直接编辑 `pack.json` 里的 `announcements`（改完重启）。**不想要了**：删掉这个包、重启 —— `/data/announcements.json` 回到磁盘上那份，逐字节不变。

## 边界（先知道再装）

- **只加公告，不做别的。** 它声明的是 `announcements` 能力（这台宿主目前实现的唯一能力）；写别的字段会被**点名拒绝**而不是忽略。
- **条数与长度**：整份列表 ≤ 50 条（本包 + 站内合计，超了本包整条不并、服务器日志具名），标题 ≤ 120 字，日期 ≤ 40 字（可空），每条 1–40 段、每段 ≤ 10000 字。
- **站内公告文件坏掉时本包也不生效**：合并拒绝改写操作者自己的文件，原样送出并记一条日志。
- 名字是 `announcements` 不是 `notices`：管理器的格式里已经有一个 `notices`（另一个形状），同一个键不能对两个宿主说两种话。

## 开发/验收

```bash
node tools/packs.mjs list --root <装了它的根>          # Stardust 侧：发现 + 元数据
node tools/workshop-validate.mjs --workshop <根>      # 管理器侧：格式校验（它会是 foreign，不进装载集合）
```

许可证：CC0-1.0（这份公告文字随你改、随你发）。
