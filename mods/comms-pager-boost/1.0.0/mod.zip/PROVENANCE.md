# PROVENANCE — 简易通讯机与寻呼模块：优先核心盟约（`comms-pager-boost` 1.0.0）

本包是**兼容改写**：把原投稿的「整份覆盖引擎文件」拆开、只取其中真正要改的那条规则，改写成工坊包唯一合法的
那条通道（`pack.json` 的 `server.meta`）。规则本身逐句保留，没有重新发明。

## 链

| 环节 | 是谁 | 做了什么 |
|---|---|---|
| 原作者 | **B站@伊佐那邪_** | 写了「简易通讯机 / 寻呼模块 优先携带者最优核心盟约」这条规则 |
| 原投稿 | 站点投稿 **`d3699c76ede3`**「简易通讯机和寻呼模块加强mod」 | 以 `install.mjs` + `payload/**` 安装器形态交付：整份替换 3 个引擎文件 |
| 兼容改写者 | **Mo233**（本包） | 把同一条规则改写成 `server.meta` 模块；逐句移植两个抽人函数，补上行为验收 |

## 原件的可核事实（只读取回，未改动服务器任何文件）

* 服务器路径：`/var/lib/sp-modsite/submissions/d3699c76ede3/mod.zip`
* `sha256 = dcfdb0063c4498dd49c3da165f32289a481b257216da76e582d05a8b7dad540d`，20698 字节，12 个条目
* `meta.json`：`name = 简易通讯机和寻呼模块加强mod`，`uploadedAt = 2026-10-13T13:37:36.477Z`，
  `homepage = https://github.com/yznx09/Stronghold-Protocol-Rhodes-Kazdel-Mod`
* 原件 `README.md` 自述：本功能「已装 **v1.4.9 及以后的盟约整合包**：本功能已包含」，即它是从那套整合包里单独
  提取出来的一小段规则；目标基线是**上游 0.2.4**。
* 原件声明要替换的 3 个文件（`install.mjs` 的 `FILES` 表）：

  | 原文件路径 | 原件给出的「上游 0.2.4 原版」sha256 | 替换后 sha256 |
  |---|---|---|
  | `server/match/builtinMeta.js` | `8350b5d572bccfa970af40b9dbe2cd21092ee01ed9e48adef22e173d3c150116` | `ad12b67165ebc9c071dc17ff0a1a359980beddef377dbd593100a6e844deb160` |
  | `server/sim/content/items/meta.js` | `fba5ef362d514d0dfc87e652e2fc3ca0805f730a5bca6a5d9dd6073fcf80c026` | `6011a10cf6b68c9806e87a373164fb0dab4ce91cc2d917eb40a9c44f1779dcf0` |
  | `shared/bondReward.js` | （新增，无 preimage） | `cb1b0e18ee0c70ae761472de8ad0586568648ecf8ec0d3ad30d46251c56fb0b6` |

* **改写时的实测**：本仓 `HEAD`（引擎 0.18.5 / 上游 0.2.6）上这 3 个路径里前两个的 sha256 与原件声明的
  「0.2.4 原版」**逐字节相同**（`8350b5d5…`、`fba5ef36…`），`shared/bondReward.js` 在本仓**不存在**。
  就是说这条规则在本仓**确实还没有**，不是重复劳动。

## 改了什么（逐条）

原件把三份**引擎文件整份覆盖**，这触了我们「不许整份覆盖引擎文件」的红线。改写只取「行为」，落到声明面：

1. **`shared/bondReward.js`（新增共享模块）→ 删除，两个函数逐句搬进包内 `meta/comms.mjs`。**
   `rewardBondOrder`（最优盟约排序）与 `rollRewardChess`（按序抽人 + 逐盟约回落）逻辑逐字保留，含同层 tie-break
   顺序（`bondOrder` → `bondIds` 数据顺序）与「全是附加盟约时 `rng.pick` 挑一个领头」。
   包模块不能 `import` 引擎内部（`docs/WORKSHOP.md` §1.11），而这两个函数本来就不需要引擎辅助函数，所以搬迁无损。
2. **`server/match/builtinMeta.js` 里 `use_equip_reward_char_chess_with_same_bond`（简易通讯机）→ 改写为
   `registry.item('chess_item_2_06_e', …)`。** 件数仍从具体那一件（普通 `count=1` / 精锐 `count=2`）的
   `rec.params.count` 读；官方上限「等阶不高于当前调度中心等级」保留；一名都没发出来时仍发「没有可获得的同盟约干员」提示。
3. **`server/sim/content/items/meta.js` 里 `chess_item_4_01_e`（寻呼模块）的 wrapper → 改写为
   `registry.item('chess_item_4_01_e', …)`。** `refresh_cnt`（普通/精锐都是 3）保住；「同一名干员不在同一次报价里
   出现两次」的 `exclude` 递进保住；`offerChess(ids, { source: 'item' })` 保住。
4. **原件对 `builtinMeta.js` 的纯注释改动**（`人事部文档` 官方上限 9 的说明等）**不搬运** —— 注释不是行为，
   而本包不许在引擎文件里留痕。
5. **交付形态**：`zip` 根有 `pack.json`（原件是安装器形态，`zip` 根没有 `pack.json`）。
   `pack.json` 的 `server.meta.registers` 逐字写出被覆盖的两个键：
   `["item:chess_item_2_06_e", "item:chess_item_4_01_e"]`（`item:` 键按引擎的 `itemKey` 归一，不带 `_a`/`_b` 后缀，
   所以一件装备的普通与精锐由同一条处理器覆盖）。`combat: true` 是 `server.meta` 的硬要求（DESIGN §29）。

## 已知差异（如实记，只有一条）

**空结果提示文案不走多语言。** 引擎内置那一条用 `msg('{who}：没有可获得的同盟约干员', {who: dn(name)})`
（`server/match/builtinMeta.js:48`），所以它会随语言切换；而包模块拿不到 i18n —— `registry.api` 是包能用的
唯一引擎入口，里头没有 `msg` / `dn`（`docs/WORKSHOP.md` §1.11 明确写「这是唯一的引擎入口」）。

因此 `meta/comms.mjs` 里这句改成纯字符串 `'<装备名>：没有可获得的同盟约干员'`：**中文原文逐字相同**，
在 `en` / `ja` / `ko` / `zh-TW` 下不会翻译。

* 影响面：只在「抽不到任何干员」那一条边界分支上，且只影响提示文字，**不影响任何一件装备发出哪名干员** ——
  也就是说不影响玩法结果、不影响 golden、不进任何数据。
* 这是引擎当前的能力边界，不是本包偷懒；消除它需要引擎给 `registry.api` 加 i18n（属引擎改动，不属本包）。

## 版权

* 非商业同人作品。《明日方舟》及其素材版权归**鹰角网络（Hypergryph）**所有，与 Yostar 及其关联方无关，
  未获授权或认可。
* 本包**不含任何官方美术 / 音频字节**：全部内容是源码 + 元数据，共 3 个文本文件。
* 原投稿**没有 LICENSE 文件**，`pack.json.license` 因此如实写「原投稿未声明许可，见 PROVENANCE.md」。
  改写的授权口径：原投稿在站点公开投稿、其 `README.md` 鼓励「纯 0.2.4 或更早的整合包：可直接安装」，
  本包只沿用其规则、不复制其交付物。若原作者有异议，删包即可（本包不含不可再生内容）。

## 复现与验收

```
node tools/workshop-validate.mjs <本包目录>     # 0 error(s), 0 warning(s) — VALID
```

行为验收（用真数据、走真装载路径 `loadWorkshop → loadMetaModules → buildRoomRegistry`，再与引擎官方那一份
同场对照）见改写时的验收脚本，10 项全过：

* 官方 简易通讯机 向 `ctx.rollChess` 要的是 `{maxTier, filter}`（任意同盟约都行），本包要的是 `{maxTier, bond}`
  （点名携带者最优核心盟约）；
* 「有牙」一项：官方的 `filter` 在官方数据上确实横跨 **≥2 个盟约**，所以这条改写不是空转；
* 层数最高的核心盟约确实排第一，且把层数调过来结果跟着换；
* 第一个盟约没货时自动落到 order 里的下一个，且始终不越出携带者自己的盟约；
* 精锐 `count=2` 两轮都从最优盟约开始；没有核心盟约时走 `rng.pick` 挑领头；
* 寻呼模块出 3 名不重复的干员、`exclude` 逐次变长、只报一次价；
* `registers` 与真正被注册的两个键逐字相同。
