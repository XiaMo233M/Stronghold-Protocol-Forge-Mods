// meta/comms.mjs — 「简易通讯机」「寻呼模块」的抽人规则。
//
// 兼容改写自原投稿 d3699c76ede3（作者 B站@伊佐那邪_）。原投稿把 server/match/builtinMeta.js、
// server/sim/content/items/meta.js、shared/bondReward.js 三份**引擎文件整份覆盖**，触红线①；这里改成工坊包
// 唯一有的那条合法通道：pack.json 的 server.meta（docs/WORKSHOP.md §1.11）。
//
// 与引擎内容模块同形：一个 registerMeta(registry)。注册的两个键**整份覆盖**引擎已注册的那个处理器
// （注册表的规则是「后注册的赢」，而包拿到的是这一局 fork 出来的受控注册表）。受控注册表只放行
// server.meta.registers 里声明过的键，所以两个键都在 pack.json 里逐字写出。
//
// 为什么一句 import 都没有：包模块只许 import 自己包内的文件，引擎辅助函数走 registry.api
// （docs/WORKSHOP.md §1.11「这是唯一的引擎入口」）。这段逻辑需要的东西只有 registry.api 的 buffParams
// 一件，其余全部来自处理器签名里那个 ctx。

/** 数值兜底读法：非有限值当 0（与官方内容模块读黑板同一个）。 */
const num = (v) => (Number.isFinite(v) ? v : 0);
/** 取整的数值兜底读法（件数 / 刷新次数用）。 */
const int = (v, d = 0) => (Number.isFinite(v) ? Math.trunc(v) : d);

/**
 * 携带者**自己**的盟约，按奖励优先级排：层数最高的**核心**盟约在前，同层保持界面顺序（`bondOrder`，
 * 再按 `gd.bondIds` 的数据顺序）；一个核心盟约都没有时，在**附加**盟约里随机挑一个领头。
 *
 * 与商店的装备偏好刻意不同的一条：**不看激活状态**，也不要求有层数 —— 这件装备读的是携带者，不是棋盘。
 *
 * 逐句移植自原投稿的 shared/bondReward.js `rewardBondOrder`（那一半的语义就是本包要保住的东西）。
 *
 * @param {{ bond: (id: string) => any, bondIds?: string[] }} gd 数据视图（`bond(id)` → 带 `isCore` / `bondOrder` 的记录）
 * @param {(id: string) => number} layers 玩家在某个盟约上的层数
 * @param {string[]} bonds 携带者自己的盟约（`ctx.pieceBonds(uid)`）
 * @param {((list: string[]) => string) | null} pick 全是附加盟约时用的随机挑一（`ctx.rng.pick`）
 * @returns {string[]} 盟约 id，最优在前（没有可用盟约时是空数组）
 */
function rewardBondOrder(gd, layers, bonds, pick) {
  const list = [];
  for (const b of Array.isArray(bonds) ? bonds : []) if (typeof b === 'string' && b && !list.includes(b)) list.push(b);
  if (!list.length) return [];
  const idx = new Map(((gd && gd.bondIds) || []).map((id, i) => [id, i]));
  const layerOf = typeof layers === 'function' ? layers : () => 0;
  const bondOf = (id) => (gd && typeof gd.bond === 'function' ? gd.bond(id) : null);
  const order = (id) => { const b = bondOf(id); return b && Number.isFinite(b.bondOrder) ? b.bondOrder : 99; };
  const core = [];
  const addon = [];
  for (const id of list) { const b = bondOf(id); if (b && b.isCore) core.push(id); else addon.push(id); }
  // 层数高的在前；同层按界面顺序（bondOrder，再按数据顺序）
  core.sort((a, b) => (num(layerOf(b)) - num(layerOf(a))) || (order(a) - order(b)) || ((idx.get(a) ?? 99) - (idx.get(b) ?? 99)));
  if (core.length) return [...core, ...addon];
  if (addon.length > 1 && typeof pick === 'function') {
    const head = pick(addon);
    if (typeof head === 'string' && addon.includes(head)) return [head, ...addon.filter((x) => x !== head)];
  }
  return addon;
}

/**
 * 按 `order` 的顺序抽一名同盟约干员：某个盟约在 `maxTier` 下已经没有可用干员（池子抽空 / 商店等级低于该干员的
 * 等阶）就落到下一个盟约。`exclude` 让「一次刷出 N 张」的报价不出现重复。
 *
 * 逐句移植自原投稿的 shared/bondReward.js `rollRewardChess`。
 *
 * @param {string[]} order rewardBondOrder 的结果
 * @param {(opts: object) => string | null} roll 调用方的 `ctx.rollChess`
 * @param {{ maxTier?: number, exclude?: string[] | null }} [opts]
 * @returns {string | null}
 */
function rollRewardChess(order, roll, { maxTier, exclude = null } = {}) {
  if (!Array.isArray(order) || !order.length || typeof roll !== 'function') return null;
  const filter = Array.isArray(exclude) && exclude.length ? (id) => !exclude.includes(id) : null;
  for (const bond of order) {
    const id = roll(filter ? { maxTier, bond, filter } : { maxTier, bond });
    if (id) return id;
  }
  return null;
}

/** 携带者的盟约，按奖励优先级排（两个处理器共用的那一句）。 */
function rewardBondsOf(ctx, uid) {
  return rewardBondOrder(ctx.gd, (id) => ctx.layers(id), ctx.pieceBonds(uid), (list) => ctx.rng.pick(list));
}

/** 这一件装备的名字（提示文案用）。 */
function itemName(ctx, ev) {
  const rec = ctx.gd.item(ev && ev.item && ev.item.id);
  return (rec && rec.name) || '';
}

/**
 * 什么都没发出来 —— 但它是「装备时销毁」，所以要说清为什么（GitHub #401 的既有口径）。
 *
 * ⚠️ 与引擎内置的那条提示的唯一差别：引擎用 `msg(...)` / `dn(...)` 走多语言，而包模块拿不到 i18n
 * （`registry.api` 是唯一的引擎入口，里头没有 `msg`）。所以这里的中文原文逐字相同，但不会随语言切换。
 * 见 PROVENANCE.md「已知差异」。
 */
function toastNothing(ctx, ev) {
  ctx.toast(`${itemName(ctx, ev)}：没有可获得的同盟约干员`, 'warn');
}

export function registerMeta(registry) {
  const { buffParams } = registry.api;

  // 简易通讯机 — use_equip_reward_char_chess_with_same_bond {count}
  //
  // 官方：装备时销毁，随机获得 count 名与该干员有相同盟约的干员（等阶不高于当前调度中心等级）。
  // 本包：那 count 名改为**优先来自携带者自己层数最高的核心盟约**；该盟约在这个等级下没有可用干员就落到下一个。
  // 官方上限保留；`count` 仍从具体那一件（普通 / 精锐）的记录里读。
  registry.item('chess_item_2_06_e', {
    onEquip(ctx, ev) {
      const rec = ev && ev.item ? ctx.gd.item(ev.item.id) : null;
      const p = rec && rec.params && typeof rec.params === 'object' ? rec.params : {};
      const n = Math.max(1, int(p.count, 1));
      const order = rewardBondsOf(ctx, ev.target.uid);
      const maxTier = ctx.shopLevel();
      let got = 0;
      for (let k = 0; k < n; k++) {
        const id = rollRewardChess(order, ctx.rollChess, { maxTier });
        if (id && ctx.grantChess(id)) got++;
      }
      if (!got) toastNothing(ctx, ev);
    },
  });

  // 寻呼模块 — use_equip_reward_special_goods_char_chess {refresh_cnt, choice_cnt}
  //
  // 官方：特殊刷新出 refresh_cnt 名**不同**的同盟约干员，等阶不高于当前调度中心等级，由玩家取一名。
  // 本包：同样是携带者最优盟约优先，一个盟约抽空就落到下一个；「不重复」与官方上限都保留。
  // （原投稿把这条写在内容侧的 server/sim/content/items/meta.js 里包住内置处理器；工坊包没有内容侧文件，
  //  所以这里一次性写全，语义与那一份逐句相同。）
  registry.item('chess_item_4_01_e', {
    onEquip(ctx, ev) {
      const rec = ev && ev.item ? ctx.gd.item(ev.item.id) : null;
      const p = buffParams(rec, 'use_equip_reward_special_goods_char_chess') || {};
      const n = Math.max(1, int(p.refresh_cnt, 3));
      const order = rewardBondsOf(ctx, ev.target.uid);
      const maxTier = ctx.shopLevel();
      const ids = [];
      for (let k = 0; k < n; k++) {
        // 一名干员不在同一次报价里出现两次（用户实测 #6 第 19 条）：池子抽空时卡片更少
        const id = rollRewardChess(order, ctx.rollChess, { maxTier, exclude: ids });
        if (id) ids.push(id);
      }
      if (ids.length) ctx.offerChess(ids, { source: 'item' });
      else toastNothing(ctx, ev);
    },
  });
}
