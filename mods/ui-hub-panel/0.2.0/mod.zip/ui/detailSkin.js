// ui/detailSkin.js — 干员详情面板（loadout.detail）的 hub 皮肤。两件事，同一个模块：
//   mount(ctx) → 引擎在 .dpanel 内部渲染的那一格宿主里画一条 hub 标题带（ctx.hostKey 告诉我们是哪位干员）
//   wrap(ctx)  → 在 .dpanel 外面套一层 display:contents 的作用域，给样式表一个稳定的高优先级钩子 + props 数据属性
// 定位/宽高一律不动：那是 game-panels.css 与 devices.css 的（.dpanel 是 position:absolute，且多处覆写 bottom）。
import { html } from '/js/ui/components.js';

const esc = (s) => String(s == null ? '' : s);

/** charId → 干员名：只读本包声明过的 chess 表，读不到就不编名字。 */
function nameOf(ctx, charId) {
  if (!charId) return '';
  try {
    const chess = ctx.data && ctx.data.get ? ctx.data.get('chess') : null;
    if (!chess) return '';
    for (const rec of Object.values(chess)) {
      if (rec && rec.charId === charId && typeof rec.name === 'string' && rec.name) return rec.name;
    }
  } catch { /* 表缺就当没名字，不抛 */ }
  return '';
}

export function mount(ctx) {
  const host = ctx.host;
  if (!host) return;
  host.classList.add('uhb');
  const name = nameOf(ctx, ctx.hostKey);
  const cn = document.createElement('b');
  cn.textContent = name || '干员详情';
  const en = document.createElement('span');
  en.textContent = 'OPERATOR DOSSIER';
  const mark = document.createElement('i');
  mark.className = 'uhb__mark';
  host.append(mark, cn, en);
}

export function wrap(ctx) {
  const p = ctx.props || {};
  const type = p.detail && typeof p.detail.type === 'string' ? p.detail.type : '';
  const side = p.side === 'right' ? 'right' : 'left';
  return (orig) => html`<div class="uhd-scope" data-uhd-type=${esc(type)} data-uhd-side=${esc(side)}>${orig}</div>`;
}
