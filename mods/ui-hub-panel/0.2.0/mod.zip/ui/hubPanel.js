// ui/hubPanel.js — 盟约中枢浮层（root.overlays）。只画界面：工坊包没有 store 句柄，入口卡给的是指引不是跳转。
// 立绘走引擎自己的资源解析（站点模块，不是包内文件；包里一个字节美术都不带）。
import { chessPortraitUrl } from '/js/ui/assetUrls.js';

const THEMES = ['night', 'frost', 'ember', 'calm'];
const THEME_NAME = { night: '夜巡', frost: '霜原', ember: '烬野', calm: '静默' };

const ENTRIES = [
  { key: 'solo', name: '独立模拟', desc: '单人开局，进度自结算', tag: 'SOLO' },
  { key: 'ally', name: '同盟模拟', desc: '搜寻队友后进房', tag: 'COOP' },
  { key: 'create', name: '创建同盟', desc: '拿到房间密钥再邀人', tag: 'HOST' },
  { key: 'join', name: '加入同盟', desc: '在房间界面输入密钥', tag: 'GUEST' },
];

const W = 1600;
const H = 600;

/** 固定种子的伪随机：同一台机器每次画出同一道山脊（沿用 hub 那一版的「种子化」做法，不碰 Math.random）。 */
function rng(seed) {
  let s = seed >>> 0;
  return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296);
}

function ridge(seed, steps, amp, base) {
  const r = rng(seed);
  const dx = W / steps;
  let y = H * base;
  const pts = [];
  for (let i = 0; i <= steps; i++) {
    y = Math.min(H * 0.92, Math.max(H * 0.28, y + (r() - 0.5) * amp));
    pts.push(`${i ? 'L' : 'M'}${(i * dx).toFixed(1)} ${y.toFixed(1)}`);
  }
  return `${pts.join(' ')}V${H}H0Z`;
}

function motes(count) {
  const r = rng(20261013);
  let out = '';
  for (let i = 0; i < count; i++) {
    const left = (r() * 100).toFixed(1);
    const top = (55 + r() * 40).toFixed(1);
    const delay = (-r() * 9).toFixed(2);
    out += `<i class="uh__mote" style="left:${left}%;top:${top}%;animation-delay:${delay}s"></i>`;
  }
  return out;
}

function svgRidge(seed, steps, amp, base, cls) {
  return `<path class="${cls}" d="${ridge(seed, steps, amp, base)}" />`;
}

function template(cast) {
  return `
  <div class="uh__panel">
    <div class="uh__bg" aria-hidden="true">
      <div class="uh__sky"></div>
      <div class="uh__haze"></div>
      <svg class="uh__ridge" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">
        ${svgRidge(11, 22, 90, 0.52, 'uh-r-far')}
        ${svgRidge(77, 30, 70, 0.68, 'uh-r-mid')}
        ${svgRidge(303, 40, 46, 0.82, 'uh-r-near')}
      </svg>
      <div class="uh__grid"></div>
      <div class="uh__motes">${motes(16)}</div>
    </div>
    <div class="uh__head">
      <svg class="uh__radar" viewBox="0 0 100 100" aria-hidden="true">
        <circle cx="50" cy="50" r="46" fill="none" stroke="var(--uh-rim)" stroke-width="1"/>
        <circle cx="50" cy="50" r="30" fill="none" stroke="var(--uh-rim)" stroke-width=".6" opacity=".6"/>
        <circle cx="50" cy="50" r="14" fill="none" stroke="var(--uh-rim)" stroke-width=".5" opacity=".4"/>
        <path class="uh__radar-sweep" d="M50 50 L50 4 A46 46 0 0 1 86 27 Z" fill="var(--uh-radar)"/>
        <circle cx="50" cy="50" r="2.4" fill="var(--uh-beacon)"/>
      </svg>
      <div class="uh__title">盟约中枢</div>
      <div class="uh__en">ALLIANCE HUB</div>
    </div>
    ${cast.length ? `
    <div class="uh__cast">
      ${cast.map((c) => `
        <div class="uh__cast__cell" data-uh-name="${c.name}">
          <img class="uh__cast__img" alt="" src="${c.url}">
          <div class="uh__cast__name">${c.name}</div>
        </div>`).join('')}
    </div>` : ''}
    <div class="uh__body">
      ${ENTRIES.map((e) => `
        <div class="uh__entry" data-uh-entry="${e.key}" role="button" tabindex="0">
          <span class="uh__ico"></span>
          <div class="uh__entry__txt"><b>${e.name}</b><span>${e.desc}</span></div>
          <span class="uh__tag">${e.tag}</span>
        </div>`).join('')}
    </div>
    <div class="uh__themes">
      ${THEMES.map((t) => `<button type="button" class="uh__sw" data-uh-swatch="${t}" title="${THEME_NAME[t]}" aria-pressed="${t === 'night' ? 'true' : 'false'}"></button>`).join('')}
      <span class="uh__themes__label">背景四景</span>
    </div>
    <div class="uh__foot">
      <p class="uh__note" data-uh-note></p>
      <div class="uh__credit">视觉语言来自 hub 包 · 工坊包不含官方美术</div>
    </div>
  </div>
  <div class="uh__fab" data-uh-fab role="button" tabindex="0"><span class="uh__beacon"></span>盟约中枢</div>`;
}

const NOTE = {
  solo: '独立模拟：回到大厅主界面即可开局（本面板只做指引，工坊包不接管跳转）。',
  ally: '同盟模拟：大厅的搜寻入口。房间里的「开始搜寻」需要服务器支持 match.queue 消息。',
  create: '创建同盟：在大厅创建房间，把密钥发给队友。',
  join: '加入同盟：在房间界面输入 6 位密钥；浏览公开同盟需要服务器支持 room.list。',
};

/** 名片干员：按 charId 排序取前 n 个「本机资源清单里真有立绘」的干员（顺序不随装载次序变）。 */
function castOf(ctx, n = 4) {
  try {
    const chess = ctx.data && ctx.data.get ? ctx.data.get('chess') : null;
    const manifest = ctx.data && ctx.data.get ? ctx.data.get('assets') : null;
    if (!chess || !manifest) return [];
    const seen = new Set();
    const rows = [];
    for (const rec of Object.values(chess).sort((a, b) => String(a && a.charId).localeCompare(String(b && b.charId)))) {
      if (!rec || typeof rec.charId !== 'string' || seen.has(rec.charId)) continue;
      const url = chessPortraitUrl(manifest, rec);
      if (!url) continue;
      seen.add(rec.charId);
      rows.push({ charId: rec.charId, name: typeof rec.name === 'string' ? rec.name : rec.charId, url });
      if (rows.length >= n) break;
    }
    return rows;
  } catch {
    return [];
  }
}

export function mount(ctx) {
  const host = ctx.host;
  if (!host) return;
  const cast = castOf(ctx);
  host.classList.add('uh');
  host.dataset.open = '0';
  host.dataset.uhTheme = 'night';
  host.innerHTML = template(cast);

  const setOpen = (v) => { host.dataset.open = v ? '1' : '0'; };
  const note = host.querySelector('[data-uh-note]');

  /** 四景跟着走：主题写到根元素上，本包其它界面（干员详情皮肤）读同一组令牌。 */
  const applyTheme = (t) => {
    host.dataset.uhTheme = t;
    document.documentElement.dataset.uhTheme = t;
    for (const b of host.querySelectorAll('.uh__sw')) b.setAttribute('aria-pressed', String(b.dataset.uhSwatch === t));
  };
  document.documentElement.dataset.uhTheme = 'night';

  const handlers = [
    ['[data-uh-fab]', 'click', () => setOpen(true)],
    ['[data-uh-fab]', 'keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setOpen(true); } }],
  ];
  for (const t of THEMES) handlers.push([`[data-uh-swatch="${t}"]`, 'click', () => applyTheme(t)]);
  for (const e of ENTRIES) {
    handlers.push([`[data-uh-entry="${e.key}"]`, 'click', () => { if (note) note.textContent = NOTE[e.key]; }]);
  }
  const bound = [];
  for (const [sel, ev, fn] of handlers) {
    const el = host.querySelector(sel);
    if (el) { el.addEventListener(ev, fn); bound.push([el, ev, fn]); }
  }
  // 本机没有那张立绘（资源没提取）时退回程序化卡面，不留破图
  for (const img of host.querySelectorAll('.uh__cast__img')) {
    img.addEventListener('error', () => img.closest('.uh__cast__cell').classList.add('uh--noart'));
  }

  if (ctx.log) ctx.log.info(`hub panel mounted (theme=night, entries=${ENTRIES.length})`);

  return {
    unmount() {
      for (const [el, ev, fn] of bound) el.removeEventListener(ev, fn);
      delete document.documentElement.dataset.uhTheme;
      host.innerHTML = '';
      host.classList.remove('uh');
    },
  };
}

export default mount;
