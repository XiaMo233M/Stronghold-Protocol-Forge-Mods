# PROVENANCE —— 本站改写记录（rimbilliton）

本站收件为**改写件**，改动**只有一处**，逐条留档如下。

## 1. 移除顶层键 `stripDiyOverlaps`

- 来件 `pack.json` 顶层有 `"stripDiyOverlaps": true`。
- 本站包格式的字段表是
  `id, name, version, author, license, description, gameVersion, game, api, layer, combat, content, overrides, voices, voiceLangs, bondIcons, itemIcons, art, skins, support, operators, i18n, forms, fx, notices, playtest, enabled, callBudget, variants, behaviour, assets, client, server, routes, target, dependencies, conflicts`
  —— **没有这个字段**，装载器**不读**它 ⇒ 改写前实测 `PACK_UNKNOWN_FIELD`，**整包被点名拒收**（errors=1）。
- ⚠️ **该键的语义本站未知**：站点格式里没有对应文档，作者也未在包内说明。
  本站口径是**不凭空给语义** ⇒ 只做**移除**，不做任何映射、不猜。
- ⚠️ **可能影响原意**：若作者原意不是下面第 2 条那个意思，则本包相对来件的**行为可能不同**。

## 2. 按本站引擎的「包级声明通道」等价表达该意图

- 键名 `stripDiyOverlaps`（"strip Diy overlaps"）与本站行为开关 `diyPoolOverlap` 同指一事：
  一个包把某位**官方干员**做成自己的棋子，而这位干员**本来就在自选池**（`data/backups.json` 的
  `diy.ownedPool`）里 ⇒ 他能被上两次，而且自选槽绕过棋子自己的盟约。
- 依据不是猜：引擎自带的 `test/diyPoolOverlap.test.js:1` 逐字写着
  「行为开关 `diyPoolOverlap`（DESIGN §28.43 第 5 格，投稿 `stripDiyOverlaps`）」。
- 本站引擎对这一格有**包级声明通道**（DESIGN §28.43 第 5 格）：

  ```json
  "behaviour": [{ "switch": "diyPoolOverlap", "option": "strip" }]
  ```

  读取点是 `shared/workshop.js` 的 `stripPackOperators`
  （判据 `behaviourValue(pack.behaviour, 'diyPoolOverlap') === 'strip'`）。
- 因此改写件**加上**这条声明 —— 这是对作者原键的**等价表达**，不是新增功能。
- 口径说明：本站凡收带 `stripDiyOverlaps` 的改写件，**一律**「删键 + 加这条声明」，
  同一类改写不给两种处置。本包早先曾上线过一版**只删键、未加声明**的改写
  （站上 `e08b6fe733f2`）；本版按同一口径补上声明，与之一致。

## 3. 未改动的部分

- 来件 351 个文件中，**350 个逐字节未改**（含 `assets/`、`kits/`、`meta/`、`battle/` 与全部
  JSON / `README.md`）。
- 只有 `pack.json` 改了上述**一处**（一行删除、一行新增）。
- 本文件（`PROVENANCE.md`）为本站新增。

## 4. 改写前后实测（引擎 `tools/workshop-validate.mjs`，只读调用，引擎仓一字未改）

- 改写前：`1 error(s), 0 warning(s)` ——
  `PACK_UNKNOWN_FIELD: pack.json: "stripDiyOverlaps" is not a field of this pack format`（整包不装载）。
- 改写后：`0 error(s), 75 warning(s)` —— `VALID: the engine accepts this content.`
- 75 条 warning 全部是作者侧的 `BB_UNKNOWN_KEY` / `CLASS_OVERRIDE` / `VOICE_UNKNOWN_OPERATOR`
  （本包自带 kits 与语音表的既有状况），与本次改写无关。

## 5. 素材

本包含 `assets/`（约 16.5 MB：9 名卡池干员的立绘 / 头像 / Spine `.skel` / `.atlas` 骨骼动画、
技能图、盟约图、羁绊图标、道具图与皮肤，以及随包语音）。这些是从《明日方舟》解包出的官方素材，
版权归上海鹰角网络科技有限公司 / Yostar 及其授权方所有；本包与发布者不主张任何权利，
仅供非商业学习与个人娱乐。作者未在包内附素材来源 URL 与授权说明，本站如实照录。
