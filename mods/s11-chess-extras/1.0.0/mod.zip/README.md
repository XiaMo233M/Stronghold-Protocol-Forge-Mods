# 十一服棋子扩充（24 名干员）

把 十一服（`https://exastrisrestart.top/`，app 0.15.0）`data/chess.json` 里引擎没有、且无冲突的 **24 条**棋子记录搬过来（chess_char_* 8 + chess_ws_col_* 16（哥伦比亚分支））。

## 实测
抽样上场成功，技能名正确：谬因「连续映射」、丰川祥子、若叶睦、娜斯提、涤火杰西卡。

## 不兼容 / 边界
- **⚠️ 会影响对局结果**，包已标 `combat: true`
- **不含素材**：图标/立绘/Spine 需另行配置，界面显示占位
- **kit 覆盖部分**：charId 命中引擎 kit 注册表的正常复用引擎技能；未命中的落通用 kit（效果简化）
- 与已上传的 `clemntia-chess` / `s8-chess-extras` 及他服零 id 冲突（逐条核验）
- 来源与许可见 `PROVENANCE.md`
