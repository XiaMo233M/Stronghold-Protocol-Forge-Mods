// ui/hubSections.js — 大厅栏位开关: show or hide each feature of the lobby hub, plus a slide-away handle.
//
// 这是「大厅栏位开关」mod 的**创意工坊版**：同一个功能，改成工坊包的客户端面板（`pack.json.client.panels`），
// 一个引擎文件都不覆盖。逻辑与原版逐字相同：
//
//   center    .hub-center                     the emblem, "STRONGHOLD PROTOCOL ALLIANCE" and the title
//   right     .hub-right                      the whole right column (master switch)
//   recruit   .hub-right .hub-recruit         缺人同盟 card
//   sweep     .hub-right .hub-plate--sweep    S.W.E.E.P.报告 plate
//   loadout   .hub-right .hub-plate--loadout  干员调配 plate
//
// 与原版的唯一差别在**开关放在哪里**：原版给 `settings.js` 加一行、把开关做成「设置 → 大厅栏位」的一行；
// 工坊客户端层今天没有「设置面板」这个宿主（九个挂载槽里没有大厅），所以这里把同一组开关做成大厅里的一个
// 小浮层按钮（`root.overlays` 槽位）。**隐藏逻辑一个字没改** —— 仍然是注入样式表 + `<html>` 上的
// `data-hub-*` 属性 + 追加进 `.hub-right__plates` 的把手。
//
// This module stays self-contained:
//
//   * the choice is a localStorage pref of its own (`hub.sections`，键与安装版相同，所以换装不丢设置)；
//   * the hiding is CSS, injected at load, keyed off data-hub-* attributes on <html> — neither lobby.js (the
//     markup) nor lobby.css (the layout) is touched, and with no JavaScript the hub paints as designed;
//   * the handle is appended at runtime and re-attached through a MutationObserver, because the lobby mounts and
//     unmounts as routes change. Being absolutely positioned inside the plates block, it takes no layout space.

/** The five switches, in display order. `right` is the master for the column. */
export const HUB_SECTIONS = Object.freeze([
  { id: 'center', label: '大厅中央徽标', note: '徽标、STRONGHOLD PROTOCOL ALLIANCE 与「卫戍协议：盟约」标题' },
  { id: 'right', label: '右侧栏整体', note: '整个右侧栏（缺人同盟 + S.W.E.E.P.报告 + 干员调配）' },
  { id: 'recruit', label: '缺人同盟', note: '右侧栏的缺人同盟卡片' },
  { id: 'sweep', label: 'S.W.E.E.P.报告', note: '右侧栏的 S.W.E.E.P.报告 铭牌' },
  { id: 'loadout', label: '干员调配', note: '右侧栏的干员调配 铭牌（不影响房间里的同款按钮）' },
]);

const PREF_KEY = 'hub.sections';
const STYLE_ID = 'sp-hub-sections-style';
const HANDLE_ID = 'sp-hub-collapse-handle';
/** The handle mounts inside the plates block so it can hug the plates' left edge at their vertical centre. */
const MOUNT_SEL = '.hub-right__plates';
/** The floating panel's root id (one per page; a second mount reuses it). */
export const PANEL_ID = 'sp-hub-sections-panel';

/** Default: everything on, nothing collapsed — the lobby as the UI hub drew it. */
export const HUB_SECTIONS_DEFAULT = Object.freeze({
  center: true, right: true, recruit: true, sweep: true, loadout: true, collapsed: false,
});

/** The saved choice, sanitised: unknown / missing / non-boolean fields fall back to the defaults. */
export function loadHubSections() {
  const raw = loadPref(PREF_KEY, null);
  const o = raw && typeof raw === 'object' ? raw : {};
  const out = {};
  for (const s of HUB_SECTIONS) out[s.id] = o[s.id] !== false;
  out.collapsed = o.collapsed === true;
  return out;
}

/** Persist a choice (the caller passes the whole object). */
export function saveHubSections(next) {
  const clean = {};
  for (const s of HUB_SECTIONS) clean[s.id] = next?.[s.id] !== false;
  clean.collapsed = next?.collapsed === true;
  savePref(PREF_KEY, clean);
  return clean;
}

// ---- the pref store: engine `public/js/store.js` 的 `loadPref` / `savePref` 用的是 `sp.pref.<key>`，
//      这里照抄一份（同样的键、同样的 JSON 形状），所以面板与安装版读的是同一格 localStorage。
//      不 import 引擎模块是**故意**的：包的模块只依赖浏览器与 import map，不依赖引擎文件的路径。
function loadPref(key, fallback) {
  try {
    const raw = globalThis.localStorage?.getItem('sp.pref.' + key);
    return raw == null ? fallback : JSON.parse(raw);
  } catch { return fallback; }
}
function savePref(key, value) {
  try { globalThis.localStorage?.setItem('sp.pref.' + key, JSON.stringify(value)); } catch { /* quota / private mode */ }
}

/** A tiny observable store (get / set / subscribe), same shape as the engine's `createStore`. */
function createStore(initial) {
  let state = { ...initial };
  const listeners = new Set();
  return {
    get: () => state,
    set(patch) {
      const p = typeof patch === 'function' ? patch(state) : patch;
      if (!p || typeof p !== 'object') return;
      state = { ...state, ...p };
      for (const fn of [...listeners]) { try { fn(state); } catch { /* one bad listener must not stop the rest */ } }
    },
    subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
  };
}

/**
 * The stylesheet that does the hiding. Feature switches are display:none (no reflow of the rest of the grid).
 * The collapse slides .hub-right out to the right; the handle rides inside it but cancels the slide with its own
 * mirrored transform, so it ends up parked on the screen edge.
 */
function ensureStyle() {
  const doc = globalThis.document;
  if (!doc || doc.getElementById(STYLE_ID)) return;
  const el = doc.createElement('style');
  el.id = STYLE_ID;
  el.textContent = [
    // feature switches — the three inner ones scoped under .hub-right so room.js is never touched
    'html[data-hub-center="off"] .hub-center { display: none !important; }',
    'html[data-hub-right="off"] .hub-right { display: none !important; }',
    'html[data-hub-recruit="off"] .hub-right .hub-recruit { display: none !important; }',
    'html[data-hub-sweep="off"] .hub-right .hub-plate--sweep { display: none !important; }',
    'html[data-hub-loadout="off"] .hub-right .hub-plate--loadout { display: none !important; }',
    // both plates off leaves the handle's anchor empty — nothing to fold back in, so no tab
    'html[data-hub-sweep="off"][data-hub-loadout="off"] .sp-hub-handle { display: none !important; }',
    // the plates block is the handle's containing block (it is otherwise static, so the column would be)
    '.hub-right__plates { position: relative; }',
    // the handle: a slim tab just left of the plates, centred on them (absolute — takes no layout space)
    '.sp-hub-handle { position: absolute; z-index: 3; top: 50%; right: calc(100% + .12rem);',
    '  transform: translateY(-50%);',
    '  width: .5rem; height: 1.05rem; padding: 0; display: grid; place-items: center;',
    '  font: 700 .3rem/1 ui-monospace, Consolas, monospace; color: rgba(223, 230, 226, .8);',
    '  background: rgba(9, 17, 16, .8); border: 1px solid rgba(223, 230, 226, .22); border-right: 0;',
    '  cursor: pointer; transition: transform .28s ease, color .12s ease;',
    '  border-radius: .05rem 0 0 .05rem; }',
    '.sp-hub-handle:hover { color: var(--mint-400); }',
    '.sp-hub-handle span { display: block; transition: transform .28s ease; }',
    // collapse: the column slides out right; its content fades (not the column — the handle lives inside it)
    '.hub-right { transition: transform .28s ease; }',
    // the fade is on the column's CONTENT, and excludes the handle
    '.hub-recruit, .hub-right__plates > :not(.sp-hub-handle) { transition: opacity .28s ease; }',
    'html[data-hub-collapsed="on"] .hub-right { transform: translateX(calc(100% + 1rem)); pointer-events: none; }',
    'html[data-hub-collapsed="on"] .hub-recruit { opacity: 0; }',
    'html[data-hub-collapsed="on"] .hub-right__plates > :not(.sp-hub-handle) { opacity: 0; }',
    // the handle rides the slide and then eases back to the screen edge
    'html[data-hub-collapsed="on"] .sp-hub-handle { pointer-events: auto;',
    '  transform: translateX(-.54rem) translateY(-50%); }',
    'html[data-hub-collapsed="on"] .sp-hub-handle span { transform: rotate(180deg); }',
    // the slid-out column must not grow a scrollbar on the mobile stage
    'html[data-hub-collapsed="on"] .hub-stage { overflow-x: hidden; }',
    // touch: a 44px-tall tap target on the same tab
    ':is(.sp-touch, .sp-coarse) .sp-hub-handle { width: max(.5rem, 22px); height: max(1.05rem, 48px); }',
    // phones (the stacked layout): the fold is a desktop convenience there
    '@media (max-aspect-ratio: 4/3) { .sp-hub-handle { display: none !important; }',
    '  html[data-hub-collapsed="on"] .hub-right { transform: none; pointer-events: auto; }',
    '  html[data-hub-collapsed="on"] .hub-recruit, html[data-hub-collapsed="on"] .hub-right__plates > * { opacity: 1; } }',
  ].join('\n');
  doc.head?.appendChild(el);
}

/**
 * Put the choice on <html> as `data-hub-center` / … / `data-hub-collapsed` (`on` | `off`). The attributes —
 * not inline styles — keep the default in the stylesheet: without JavaScript the hub paints as the design drew it.
 * @param {Record<string, boolean>} [pref]
 */
export function applyHubSections(pref = store.get()) {
  ensureStyle();
  const el = globalThis.document?.documentElement;
  if (!el) return;
  for (const s of HUB_SECTIONS) el.dataset['hub' + s.id[0].toUpperCase() + s.id.slice(1)] = pref[s.id] !== false ? 'on' : 'off';
  el.dataset.hubCollapsed = pref.collapsed === true ? 'on' : 'off';
  ensureHandle();
}

// ---- the collapse handle ---------------------------------------------------------------------------

/** Keep the handle inside the live plates block (the lobby mounts / unmounts as routes change). */
function ensureHandle() {
  const doc = globalThis.document;
  if (!doc) return;
  const plates = doc.querySelector?.(MOUNT_SEL);
  let el = doc.getElementById?.(HANDLE_ID);
  if (!plates) { if (el?.remove) el.remove(); return; }
  if (!el) {
    el = doc.createElement('button');
    el.id = HANDLE_ID;
    el.className = 'sp-hub-handle';
    el.type = 'button';
    el.title = '收起 / 展开右侧栏';
    el.setAttribute('aria-label', '收起 / 展开右侧栏');
    el.innerHTML = '<span>\u203A</span>';
    el.addEventListener('click', () => setHubCollapsed(store.get().collapsed !== true));
  }
  if (el.parentNode !== plates) plates.appendChild(el);
}

let stageWatcher = null;
/** Re-attach the handle when it goes missing (route change, or Preact diffing the plates on a re-render). */
function watchStage() {
  const doc = globalThis.document;
  const MO = globalThis.MutationObserver;
  if (!doc || stageWatcher || typeof MO !== 'function' || !doc.body) return;
  stageWatcher = new MO(() => {
    const plates = doc.querySelector?.(MOUNT_SEL);
    if (!plates) { const h = doc.getElementById?.(HANDLE_ID); if (h?.remove) h.remove(); return; }
    if (doc.getElementById?.(HANDLE_ID)?.parentNode !== plates) ensureHandle();
  });
  stageWatcher.observe(doc.body, { childList: true, subtree: true });
}

/** The live store; a change is saved and applied at once. */
export const store = createStore(loadHubSections());
store.subscribe((s) => { saveHubSections(s); applyHubSections(s); });
// before the first render of the lobby — no flash of the hidden regions
applyHubSections(store.get());
watchStage();

/** Flip one feature switch. @param {"center"|"right"|"recruit"|"sweep"|"loadout"} id */
export function setHubSection(id, on) {
  if (!HUB_SECTIONS.some((s) => s.id === id)) return;
  store.set({ ...store.get(), [id]: !!on });
}

/** Fold or unfold the whole right column (the handle). */
export function setHubCollapsed(v) {
  store.set({ ...store.get(), collapsed: !!v });
}

// ---- the floating panel (the workshop pack's own UI; the installer mod put this row in 设置) ----------

const BTN_ID = 'sp-hub-sections-btn';

/**
 * 面板本体：一个固定在大厅左下角的小按钮，点开是一行一个开关的浮层。样式全在 `ui/hubSections.css`
 * （宿主 `root.overlays` 只给地址、不给样子）。
 * @param {any} ctx 工坊面板的注入面（这里只用到 `host`）
 */
export function mount(ctx) {
  const host = ctx && ctx.host;
  const doc = (host && host.ownerDocument) || globalThis.document;
  if (!host || !doc) return {};

  const root = doc.createElement('div');
  root.className = 'sphub';
  root.id = PANEL_ID;

  const btn = doc.createElement('button');
  btn.type = 'button';
  btn.id = BTN_ID;
  btn.className = 'sphub__btn';
  btn.setAttribute('aria-haspopup', 'true');
  btn.setAttribute('aria-expanded', 'false');
  btn.title = '大厅栏位：显示 / 隐藏大厅的各个功能块';
  btn.innerHTML = '<span class="sphub__glyph" aria-hidden="true"></span><span class="sphub__label">栏位</span>';

  const pop = doc.createElement('section');
  pop.className = 'sphub__pop';
  pop.setAttribute('role', 'dialog');
  pop.setAttribute('aria-label', '大厅栏位');
  pop.hidden = true;

  const head = doc.createElement('header');
  head.className = 'sphub__head';
  const titles = doc.createElement('div');
  titles.className = 'sphub__titles';
  const micro = doc.createElement('span');
  micro.className = 'sphub__micro';
  micro.textContent = 'HUB SECTIONS';
  const h2 = doc.createElement('h2');
  h2.className = 'sphub__title';
  h2.textContent = '大厅栏位';
  titles.appendChild(micro); titles.appendChild(h2);
  const close = doc.createElement('button');
  close.type = 'button';
  close.className = 'sphub__close';
  close.setAttribute('aria-label', '关闭');
  close.textContent = '\u00D7';
  head.appendChild(titles); head.appendChild(close);

  const list = doc.createElement('ul');
  list.className = 'sphub__list';

  const note = doc.createElement('p');
  note.className = 'sphub__note';
  note.textContent = '全部默认开。关掉任何一块都不会把其它东西挤走（display:none）；「右侧栏展开」对应铭牌左边的小把手。选择只存在本机浏览器（localStorage 的 hub.sections），每个玩家各记各的。';

  pop.appendChild(head); pop.appendChild(list); pop.appendChild(note);
  root.appendChild(btn); root.appendChild(pop);
  host.appendChild(root);

  let open = false;

  /** One row: a switch button that flips `id`. */
  const row = (id, label, noteText, isOn, onFlip) => {
    const li = doc.createElement('li');
    li.className = 'sphub__row' + (isOn ? ' is-on' : '');
    const b = doc.createElement('button');
    b.type = 'button';
    b.className = 'sphub__switch' + (isOn ? ' is-on' : '');
    b.setAttribute('role', 'switch');
    b.setAttribute('aria-checked', isOn ? 'true' : 'false');
    b.setAttribute('data-testid', 'hub-section-' + id);
    b.title = noteText || label;
    const track = doc.createElement('span');
    track.className = 'sphub__track';
    const knob = doc.createElement('span');
    knob.className = 'sphub__knob';
    track.appendChild(knob);
    const text = doc.createElement('span');
    text.className = 'sphub__text';
    const strong = doc.createElement('b');
    strong.textContent = label;
    const small = doc.createElement('span');
    small.className = 'sphub__meta';
    small.textContent = isOn ? '已显示' : '已隐藏';
    text.appendChild(strong); text.appendChild(small);
    b.appendChild(track); b.appendChild(text);
    b.addEventListener('click', onFlip);
    li.appendChild(b);
    return li;
  };

  const draw = () => {
    const s = store.get();
    list.textContent = '';
    for (const x of HUB_SECTIONS) {
      list.appendChild(row(x.id, x.label, x.note, s[x.id] !== false, () => setHubSection(x.id, !(store.get()[x.id] !== false))));
    }
    list.appendChild(row('collapse', '右侧栏展开', '右侧栏是否展开（铭牌左侧的小把手同样可以）', s.collapsed !== true, () => setHubCollapsed(!(store.get().collapsed === true))));
    btn.classList.toggle('is-active', open);
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    pop.hidden = !open;
  };

  const setOpen = (v) => { open = !!v; draw(); };
  const onDocClick = (e) => { if (open && !root.contains(e.target)) setOpen(false); };
  const onKey = (e) => { if (e.key === 'Escape' && open) setOpen(false); };

  btn.addEventListener('click', () => setOpen(!open));
  close.addEventListener('click', () => setOpen(false));
  doc.addEventListener('click', onDocClick);
  doc.addEventListener('keydown', onKey);

  const unsub = store.subscribe(() => draw());
  draw();

  return {
    unmount() {
      unsub();
      doc.removeEventListener('click', onDocClick);
      doc.removeEventListener('keydown', onKey);
      root.remove();
    },
  };
}

export default mount;
