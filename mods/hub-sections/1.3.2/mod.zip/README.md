# 大厅栏位开关（创意工坊包）· `hub-sections` v1.3.2

把安装器版「大厅栏位开关 v1.3.2」重铸成**创意工坊包**：只往 `app/workshop/` 放一个文件夹，
**不覆盖任何引擎文件**，卸载 = 删文件夹。

## 装什么

| 文件 | 作用 |
|---|---|
| `pack.json` | 包身份 + 一条 `client.panels` 声明（槽 `root.overlays`、模块 `ui/hubSections.js`、样式 `ui/hubSections.css`） |
| `ui/hubSections.js` | 全部逻辑：注入隐藏样式表、把选择写到 `<html>` 的 `data-hub-*`、把收起把手挂进 `.hub-right__plates`、以及大厅左下角那个浮层按钮 |
| `ui/hubSections.css` | 浮层按钮与浮层自己的样式（引擎的 `root.overlays` 只给地址、不给样子） |

**没有** `content` / `server` / `routes` / 素材：这是一个纯客户端包（`client` 本身就是贡献项，所以它不是一个空包）。

## 五个开关 + 一个把手

| 开关 | 控制内容 |
|---|---|
| **大厅中央徽标** | 徽标、`STRONGHOLD PROTOCOL ALLIANCE`、「卫戍协议：盟约」标题 |
| **右侧栏整体** | 整个右侧栏（总开关） |
| **缺人同盟** | 右侧栏的缺人同盟卡片 |
| **S.W.E.E.P.报告** | 右侧栏的 S.W.E.E.P.报告 铭牌 |
| **干员调配** | 右侧栏的干员调配 铭牌（**不影响房间里的同款按钮**） |
| **右侧栏展开** | 对应把手：把整栏向右滑出屏幕、把手贴到屏幕右缘，再点滑回 |

全部默认**开**。选择存在浏览器本地（`localStorage` 的 `sp.pref.hub.sections`）—— **与安装器版是同一格**，
所以换装不丢设置；每个玩家各记各的。

## 与原版（安装器）的差别

| | 安装器版 | 创意工坊版（本包） |
|---|---|---|
| 装法 | `node install.mjs <目标>`，改 `settings.js` 两行 + 新增 2 个模块 | 放一个文件夹进 `workshop/` |
| 开关在哪 | 设置 →「大厅栏位」的一行 | 大厅**左下角**的「栏位」浮层按钮 |
| 引擎文件 | 改 `public/js/ui/settings.js` | **一个字节都不改** |
| 卸载 | `--uninstall` 逐字节还原 | 删文件夹 |
| 隐藏逻辑 | 注入样式表 + `<html>` 上的 `data-hub-*` | **逐字相同** |
| 把手 | 追加进 `.hub-right__plates` + MutationObserver | **逐字相同** |
| 本地设置键 | `sp.pref.hub.sections` | **同一格** |

**为什么开关不在「设置」里**：工坊的客户端层今天只有九个挂载槽
（`root.overlays` / `root.guide` / `screen.game.*` / `screen.loadout.detail`）和四个可改写组件
（`game.bondStrip` / `game.hud.topBar` / `game.shopCard` / `loadout.detail`）—— **没有大厅宿主**。
所以「设置面板里加一行」这条通道今天不存在；本包用**引擎已经有的能力**把同一组开关做成大厅里的浮层，
一个引擎文件都不动。（要让它回到设置里，得先在引擎里加一个大厅 / 设置宿主组件，那是引擎侧的决定。）

## 安装

```powershell
# 方式 A：官方导入器（先校验再落盘）
node tools/workshop-pack.mjs import hub-sections.zip

# 方式 B：直接把文件夹复制到 app/workshop/ 下
```

装完**重启游戏服务器**才生效，之后玩家刷新页面。开关与把手本身**即时生效**，不用刷新。

## 校验

```powershell
node tools/workshop-validate.mjs app/workshop/hub-sections
```

实测：**0 error(s), 0 warning(s)**、`VALID: the engine accepts this content.`

另外本仓库的 `work/verify-hub-packs.mjs` 在 Node 里真跑了一遍（真引擎装载器 + 一个够 Preact 用的 mini DOM）：
默认值、`<html>` 上的属性、注入的样式表、把手挂载与点击、浮层按钮 / 6 个开关 / 状态同步、卸载零残留 —— 全绿。

## 已知事项

- **没有任何大厅宿主**，所以按钮固定在大厅**左下角**（`root.overlays` 浮层）。它与「大厅轮播图」包不抢位置
  （那个在右下角）。
- 隐藏用 `display: none`，关掉任何一块都**不会**把其它东西挤走。
- 手机竖屏布局下把手自动隐藏（与原版一致）。
- 界面文案是中文（与原版一致），没有带 `i18n` 词条。

## 授权

非商业同人作品。《明日方舟》及其素材版权归鹰角网络所有。包内只有本项目自己写的代码与样式。
